<?php
$style = 'class="form-control" id="box_id"';
echo form_dropdown("box_id",$box,'',$style);
?>
