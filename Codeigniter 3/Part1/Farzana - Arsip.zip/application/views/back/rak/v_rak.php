<?php
$style = 'class="form-control" id="rak_id"';
echo form_dropdown("rak_id",$rak,'',$style);
?>
