<body style="overflow: hidden;">
    <embed src="<?php echo base_url('assets/images/bukti_tf/' . $instansi->instansi_name . '/') . $pesanan->bukti_tf; ?>#toolbar=0" height="3000px" width="100%" style="overflow: hidden;">
</body>