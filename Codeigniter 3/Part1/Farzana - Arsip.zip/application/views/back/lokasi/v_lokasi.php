<?php
$style = 'class="form-control" id="lokasi_id"';
echo form_dropdown("lokasi_id",$lokasi,'',$style);
?>
