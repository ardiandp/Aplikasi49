<?php
$style = 'class="form-control" id="user_id"';
echo form_dropdown("user_id",$user,'',$style);
?>
