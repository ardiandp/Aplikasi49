<body style="overflow: hidden;">
    <embed src="<?php echo base_url('assets/images/covers/' . $arsip->instansi_name . '/') . $arsip->cover; ?>#toolbar=0" height="1300px" width="100%" style="overflow: hidden;">
</body>