<body style="overflow: hidden;">
    <embed src="<?php echo base_url('assets/file_arsip/' . $arsip->instansi_name . '/') . $file_upload->file_upload; ?>#toolbar=0" height="1300px" width="100%" style="overflow: hidden;">
</body>