<!doctype html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>Desa Keden</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Website Resmi Desa Keden" name="description" />
        <meta content="Desa Keden" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?=base_url('assets/'); ?>img/klaten333.ico">

        <!-- Bootstrap Css -->
        <link href="<?=base_url('assets_user/'); ?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?=base_url('assets_user/'); ?>css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?=base_url('assets_user/'); ?>css/app.min.css" rel="stylesheet" type="text/css" />

    </head>