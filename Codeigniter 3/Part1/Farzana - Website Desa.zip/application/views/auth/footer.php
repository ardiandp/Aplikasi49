<!-- end Account pages -->

        <!-- JAVASCRIPT -->
        <script src="<?=base_url('assets_user/'); ?>libs/jquery/jquery.min.js"></script>
        <script src="<?=base_url('assets_user/'); ?>libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?=base_url('assets_user/'); ?>libs/metismenu/metisMenu.min.js"></script>
        <script src="<?=base_url('assets_user/'); ?>libs/simplebar/simplebar.min.js"></script>
        <script src="<?=base_url('assets_user/'); ?>libs/node-waves/waves.min.js"></script>

        <script src="https://unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>

        <script src="<?=base_url('assets_user/'); ?>js/app.js"></script>

    </body>
</html>