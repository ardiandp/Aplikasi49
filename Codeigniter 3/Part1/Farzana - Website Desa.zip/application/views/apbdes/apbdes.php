<main id="main">
<script src="<?=base_url('assets_user/'); ?>js/charts/Chart.js"></script>
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center">
      <h2>Realisasi APBDes 2020</h2>
      <ol>
        <li><a href="index.html">Home</a></li>
        <li>Realisasi APBDes 2020</li>
      </ol>
    </div>

  </div>
</section><!-- End Breadcrumbs -->

<!-- ======= About Section ======= -->
<section id="about" class="about">
  <div class="container">
  <img src="<?=base_url('assets/'); ?>img/apbdes/realisasi.jpg" class="img-fluid" alt="Responsive image">
  </div>
</section><!-- End About Section -->

</main><!-- End #main -->

