<main id="main">
<script src="<?=base_url('assets_user/'); ?>js/charts/Chart.js"></script>
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center">
      <h2>Transparasi APBDes 2021</h2>
      <ol>
        <li><a href="index.html">Home</a></li>
        <li>Transparasi APBDes 2021</li>
      </ol>
    </div>

  </div>
</section><!-- End Breadcrumbs -->

<!-- ======= About Section ======= -->
<section id="about" class="about">
  <div class="container">
  <img src="<?=base_url('assets/'); ?>img/apbdes/Transparasi.jpg" class="img-fluid" alt="Responsive image">
  </div>
</section><!-- End About Section -->

</main><!-- End #main -->

