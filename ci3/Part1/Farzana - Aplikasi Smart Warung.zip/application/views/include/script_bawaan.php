<script>
  $(document).ready(function() {
    $('#dataTable').DataTable();
  });
</script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>

<script src="<?php echo base_url('assets/') ?>js/jquery-migrate-3.0.1.min.js"></script>
<script src="<?php echo base_url('assets/') ?>js/popper.min.js"></script>
<script src="<?php echo base_url('assets/') ?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url('assets/') ?>js/jquery.easing.1.3.js"></script>
<script src="<?php echo base_url('assets/') ?>js/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url('assets/') ?>js/jquery.stellar.min.js"></script>
<script src="<?php echo base_url('assets/') ?>js/owl.carousel.min.js"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script> -->
<script src="<?php echo base_url('assets/') ?>js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url('assets/') ?>js/aos.js"></script>
<script src="<?php echo base_url('assets/') ?>js/jquery.animateNumber.min.js"></script>
<script src="<?php echo base_url('assets/') ?>js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url('assets/') ?>js/scrollax.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script> -->
<!-- <script src="<?php echo base_url('assets/') ?>js/google-map.js"></script> -->
<script src="<?php echo base_url('assets/') ?>js/main.js"></script>