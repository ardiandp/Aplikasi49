<div class="container-fluid m-0">
<div class="row m-5">
            <div class="col-sm-12">
                <h4 class="text-center">Warung Terlaku</h4>
                <canvas id="invoiceChart"></canvas>
            </div>
            <div class="col-sm-12">
                <h4 class="text-center">Pembeli Tersering</h4>
                <canvas id="invoiceBuyerChart"></canvas>
            </div>
            <div class="col-sm-12">
                <h4 class="text-center">Total Warung Pendapatan </h4>
            <canvas id="invoiceStatusChart"></canvas>
            </div>
        </div>
</div>