                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                2021 © SmartWarung.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-right d-none d-sm-block">
                                    Developed with <i class="mdi mdi-heart text-danger"></i> by Yenny
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- JAVASCRIPT -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/node-waves/waves.min.js"></script>

        <script src="https://unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>

        <!-- dropzone js -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/dropzone/min/dropzone.min.js"></script>

        <!--tinymce js-->
        <script src="<?php echo base_url('assets_admin/') ?>libs/tinymce/tinymce.min.js"></script>

        <!--ck editor js-->
        <script src="<?php echo base_url('assets_admin/') ?>libs/ckeditor4/ckeditor.js"></script>

        <!-- init js -->
        <script src="<?php echo base_url('assets_admin/') ?>js/pages/form-editor.init.js"></script>

        <!-- Spectrum colorpicker -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/spectrum-colorpicker/spectrum.js"></script>

        <!-- Selectize -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/selectize/js/standalone/selectize.min.js"></script>

        <!-- datepicker -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/air-datepicker/js/datepicker.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/air-datepicker/js/i18n/datepicker.en.js"></script>

        <script src="<?php echo base_url('assets_admin/') ?>libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>

        <!-- Required datatable js -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        
        <!-- Buttons examples -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/jszip/jszip.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
        <!-- Responsive examples -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

        <!-- Datatable init js -->
        <script src="<?php echo base_url('assets_admin/') ?>js/pages/datatables.init.js"></script>

        <!-- apexcharts -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/apexcharts/apexcharts.min.js"></script>

        <script src="<?php echo base_url('assets_admin/') ?>libs/jquery-knob/jquery.knob.min.js"></script> 

        <!-- Jq vector map -->
        <script src="<?php echo base_url('assets_admin/') ?>libs/jqvmap/jquery.vmap.min.js"></script>
        <script src="<?php echo base_url('assets_admin/') ?>libs/jqvmap/maps/jquery.vmap.usa.js"></script>

        <script src="<?php echo base_url('assets_admin/') ?>js/pages/dashboard.init.js"></script>

        <script src="<?php echo base_url('assets_admin/') ?>js/app.js"></script>

    </body>
</html>
