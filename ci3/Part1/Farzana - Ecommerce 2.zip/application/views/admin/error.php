<div class="content-wrapper mt-3">
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">

                        <div class="card-body text-center mb-5">
                            <h3 class="mt-5 mb-2">Maaf, halaman yang Anda minta tidak ditemukan</h3><br>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>