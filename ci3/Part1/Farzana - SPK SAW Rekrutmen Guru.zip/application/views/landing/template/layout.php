<?php
 
$this->load->view('landing/template/header'); 
$this->load->view('landing/template/navbar');
$this->load->view($content);
$this->load->view('landing/template/footer');
 ?>
