<header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto mt-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i data-feather="list"></i></div>
                        Data Kriteria - <?= $kriteria->nama_kriteria ?>
                    </h1>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="container-xl px-4 mt-n10">
    <div class="card mb-4">
        <div class="card-body">
            <?= $this->session->flashdata('msg') ?>

            <table class="table table-bordered table-striped table-hover" style="max-height: 300px">

                <tbody>

                    <tr>
                        <th style="width: 30%">
                            ID Kriteria
                        </th>
                        <td>

                            <?= $kriteria->id_kriteria ?>

                        </td>
                    </tr>
                    <tr>
                        <th style="width: 30%">
                            Nama Kriteria
                        </th>
                        <td>

                            <?= $kriteria->nama_kriteria ?>

                        </td>
                    </tr>
                    <tr>
                        <th style="width: 30%">
                            Bobot Vektor
                        </th>
                        <td>

                            <?= $kriteria->bobot_vektor ?>%

                        </td>
                    </tr>

                    <tr>
                        <th style="width: 30%">
                            Tipe
                        </th>
                        <td>

                            <?= $kriteria->tipe ?>

                        </td>
                    </tr>

                    <tr>
                        <th style="width: 30%">
                            Penilai
                        </th>
                        <td>

                            <?= $kriteria->penilai ?>

                        </td>
                    </tr>

                </tbody>

            </table>
            <br>
            <center>
                <button type="button" data-bs-toggle="modal" data-bs-target="#edit" class="btn btn-primary">Edit Kriteria</button>
                <button type="button" data-bs-toggle="modal" data-bs-target="#hapus" class="btn btn-danger">Hapus Kriteria</button>
            </center>
        </div>
    </div>

</div>

<div class="container-xl px-4">
    <div class="card mb-4">
        <div class="card-body">
            <div class="card-header">
                <h3 class="card-title">Data Bobot Kriteria</h3>
            </div>
            <button type="button" data-bs-toggle="modal" data-bs-target="#tambahbobot" class="btn btn-primary">Tambah Bobot Kriteria</button>

            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Keterangan</th>
                        <th>Bobot</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1;
                    foreach ($list_sub as $row) : ?>
                        <tr>
                            <td><?= $i++ ?></td>

                            <td><?= $row->keterangan ?></td>
                            <td><?= $row->bobot ?></td>
                            <td>

                                <a type="button" data-bs-toggle="modal" data-bs-target="#edit-<?= $row->id_bobot ?>" href="">
                                    <button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="edit"></i></button>
                                </a>
                                <a type="button" data-bs-toggle="modal" data-bs-target="#delete-<?= $row->id_bobot ?>" href="">

                                    <button class="btn btn-datatable btn-icon btn-transparent-dark"><i data-feather="trash-2"></i></button>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Edit Kriteria</h5>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('operator/kriteria') ?>" method="Post">
                    <table class="table table-bordered table-striped table-hover" style="max-height: 300px">
                        <input type="hidden" name="id_kriteria" value="<?= $kriteria->id_kriteria ?>">
                        <tbody>
                            <tr>
                                <th>Nama Kriteria</th>
                                <th>
                                    <input type="text" class="form-control" name="nama_kriteria" placeholder="Masukkan Nama Kriteria " required autofocus value="<?= $kriteria->nama_kriteria ?>">
                                </th>
                            </tr>
                            <tr>
                                <th>Bobot Vektor</th>
                                <th>
                                    <input type="number" min="1" class="form-control" name="bobot" placeholder="Masukkan Bobot Vektor Kriteria (%)" required autofocus value="<?= $kriteria->bobot_vektor ?>">
                                </th>
                            </tr>
                            <tr>
                                <th>Tipe</th>
                                <th>
                                    <input name="tipe" type="radio" id="tipe1" <?php if ($kriteria->tipe == "Benefit") {
                                                                                    echo "checked";
                                                                                } ?> value="Benefit" required />
                                    <label for="tipe1">Benefit</label>
                                    <input name="tipe" type="radio" id="tipe2" <?php if ($kriteria->tipe == "Cost") {
                                                                                    echo "checked";
                                                                                } ?> value="Cost" required />
                                    <label for="tipe2">Cost</label>
                                </th>
                            </tr>
                            <tr>
                                <th>Penilai</th>
                                <th>
                                    <input name="penilai" type="radio" id="penilai1" <?php if ($kriteria->penilai == "Operator") {
                                                                                            echo "checked";
                                                                                        } ?> value="Operator" required />
                                    <label for="penilai1">Operator</label>
                                    <input name="penilai" type="radio" id="penilai2" <?php if ($kriteria->penilai == "Kepala Sekolah") {
                                                                                            echo "checked";
                                                                                        } ?> value="Kepala Sekolah" required />
                                    <label for="penilai2">Kepala Sekolah</label>
                                </th>
                            </tr>

                        </tbody>
                    </table>
                    <div class="modal-footer">
                        <input type="submit" class="btn bg-primary text-white" name="edit" value="Simpan">
                    </div>

                    <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Hapus Kriteria?</h5>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= base_url('operator/kriteria') ?>" method="Post">
                <input type="hidden" value="<?= $kriteria->id_kriteria ?>" name="id_kriteria">
                <div class="modal-body">
                    <table class="table table-bordered">
                        <tr>
                            <th>ID Kriteria</th>
                            <th>
                                <?= $kriteria->id_kriteria ?>
                            </th>
                        </tr>
                        <tr>
                            <th>Nama Kriteria</th>
                            <th>
                                <?= $kriteria->nama_kriteria ?>
                            </th>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-primary btn-block text-white " name="hapus" value="Hapus">
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="tambahbobot" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Form Tambah Bobot Kriteria</h5>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= base_url('operator/bobot') ?>" method="Post">
                <div class="modal-body">
                    <input type="hidden" class="form-control" name="id_kriteria" required autofocus value="<?= $kriteria->id_kriteria ?>">

                    <table class="table table-bordered table-striped table-hover" style="max-height: 300px">

                        <tbody>

                            <tr>
                                <th style="width: 30%">
                                    Keterangan
                                </th>
                                <td>


                                    <input type="text" class="form-control" name="ket" placeholder="Keterangan" required autofocus>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Bobot</th>
                                <th>Nilai</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Sangat Rendah</td>
                                <td>1</td>
                            </tr>
                            <tr>
                                <td>Rendah</td>
                                <td>2</td>
                            </tr>
                            <tr>
                                <td>Cukup</td>
                                <td>3</td>
                            </tr>
                            <tr>
                                <td>Tinggi</td>
                                <td>4</td>
                            </tr>
                            <tr>
                                <td>Sangat Tinggi</td>
                                <td>5</td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-bordered table-striped table-hover" style="max-height: 300px">

                        <tbody>

                            <tr>
                                <th style="width: 30%">
                                    Nilai
                                </th>
                                <td>


                                    <input type="number" class="form-control" name="nilai" placeholder="Nilai" required autofocus min="1" max="5">
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-primary btn-block text-white " name="tambah" value="Simpan">
                </div>
            </form>
        </div>
    </div>
</div>


<?php $i = 1;
foreach ($list_sub as $row) : ?>
    <div class="modal fade" id="edit-<?= $row->id_bobot ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Edit Bobot Kriteria</h5>
                    <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('operator/bobot') ?>" method="Post">

                        <input type="hidden" value="<?= $kriteria->id_kriteria ?>" name="id_kriteria">
                        <input type="hidden" value="<?= $row->id_bobot ?>" name="id_bobot">

                        <table class="table table-bordered table-striped table-hover" style="max-height: 300px">

                            <tbody>

                                <tr>
                                    <th style="width: 30%">
                                        Keterangan
                                    </th>
                                    <td>


                                        <input type="text" class="form-control" name="ket" placeholder="Keterangan" required autofocus value="<?= $row->keterangan ?>">

                                    </td>
                                </tr>

                            </tbody>
                        </table>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Bobot</th>
                                    <th>Nilai</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Sangat Rendah</td>
                                    <td>1</td>
                                </tr>
                                <tr>
                                    <td>Rendah</td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>Cukup</td>
                                    <td>3</td>
                                </tr>
                                <tr>
                                    <td>Tinggi</td>
                                    <td>4</td>
                                </tr>
                                <tr>
                                    <td>Sangat Tinggi</td>
                                    <td>5</td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-bordered table-striped table-hover" style="max-height: 300px">

                            <tbody>

                                <tr>
                                    <th style="width: 30%">
                                        Bobot
                                    </th>
                                    <td>


                                        <input type="number" class="form-control" name="nilai" placeholder="Nilai" required autofocus min="1" max="5" step="any" value="<?= $row->bobot ?>">
                                    </td>
                                </tr>

                            </tbody>
                        </table>


                </div>

                <div class="modal-footer">
                    <input type="submit" class="btn bg-primary text-white" name="edit" value="Simpan">
                </div>

                <?php echo form_close() ?>
            </div>
        </div>
    </div>
<?php endforeach; ?>



<?php $i = 1;
foreach ($list_sub as $row) : ?>
    <div class="modal fade" id="delete-<?= $row->id_bobot ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Hapus Bobot Kriteria?</h5>
                    <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?= base_url('operator/bobot') ?>" method="Post">
                    <input type="hidden" value="<?= $kriteria->id_kriteria ?>" name="id_kriteria">
                    <input type="hidden" value="<?= $row->id_bobot ?>" name="id_bobot">
                    <<div class="modal-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>ID Bobot Kriteria</th>
                                <th>
                                    <?= $row->id_bobot ?>
                                </th>
                            </tr>
                            <tr>
                                <th>Keterangan</th>
                                <th>
                                    <?= $row->keterangan ?>
                                </th>
                            </tr>
                        </table>
            </div>
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary btn-block text-white " name="hapus" value="Hapus">
            </div>
            </form>
        </div>
    </div>
    </div>
<?php endforeach; ?>