$(document).ready(function() {
    $('.js-member-basic-single').select2();
});