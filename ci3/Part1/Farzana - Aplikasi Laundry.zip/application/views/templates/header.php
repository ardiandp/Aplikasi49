<!DOCTYPE html>
<html lang="en" id="page-top">
  <head>
	<?php include 'include-css.php'; ?>
	<title><?= $title; ?></title>
  </head>
  <body>
	<div>
		<div>
   			<div class="container-fluid">