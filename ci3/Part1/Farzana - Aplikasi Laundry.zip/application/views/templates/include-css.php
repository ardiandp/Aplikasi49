<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css'); ?>">
<!-- Datatables CSS -->
<link rel="stylesheet" href="<?= base_url('assets/vendor/datatables/datatables/css/dataTables.bootstrap4.min.css'); ?>">
<!-- Fancybox CSS -->
<link rel="stylesheet" href="<?= base_url('assets/vendor/fancybox/jquery.fancybox.min.css'); ?>">
<!-- Fontawesome CSS -->
<link rel="stylesheet" href="<?= base_url('assets/vendor/fontawesome/css/all.min.css'); ?>">
<!-- Sweetalert2 CSS -->
<link rel="stylesheet" href="<?= base_url('assets/vendor/sweetalert2/sweetalert2.min.css'); ?>">
<!-- Select2 CSS -->
<link rel="stylesheet" href="<?= base_url('assets/vendor/select2/select2.min.css'); ?>">
<!-- Sidebar CSS -->
<link rel="stylesheet" href="<?= base_url('assets/vendor/jquery/jquery.mCustomScrollbar.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/sidebar.css'); ?>">

<!-- My CSS -->
<link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">

<!-- Icon -->
<link rel="icon" href="<?= base_url('assets/img/img_properties/icon.png'); ?>">
