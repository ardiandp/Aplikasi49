<script src="<?php echo base_url() ?>assets/plugins/morris/morris.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<!-- SlimScroll -->
<script src="<?php echo base_url() ?>assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url() ?>assets/plugins/fastclick/fastclick.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/dist/js/demo.js"></script>
<!-- page script -->
<script src="<?php echo base_url() ?>assets/plugins/raphael/raphael-min.js"></script>
<!-- sweetalert -->
<script src="<?php echo base_url() ?>assets/plugins/sweetalert/sweetalert.min.js"></script>
<!-- font awesome picker -->

<script src="<?php echo base_url() ?>assets/plugins/fapicker/dist/js/fontawesome-iconpicker.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/sweetalert/sweetalert2.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/Bootstrap-validator/validator.js"></script>
<script src="<?php echo base_url() ?>assets/app/core/alert.js"></script>
<script src="<?php echo base_url() ?>assets/app/core/iconpicker.js"></script>

<script>
    <?= $this->session->flashdata('messageAlert'); ?>
</script>