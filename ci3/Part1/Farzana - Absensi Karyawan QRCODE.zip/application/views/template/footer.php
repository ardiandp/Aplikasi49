<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.3.1
    </div>
    <strong> &copy; 2022 <a href="#">Absensi Karyawan</a>.</strong> Template by Admin LTE. | Repost by <a href='https://sharecodingan.blogspot.com/' title='sharecodingan.blogspot.com' target='_blank'>ShareCodingan.</a>
	
</footer>
