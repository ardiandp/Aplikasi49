$(function() {
    $('.timepicker').timepicker({
        timeFormat: 'HH:mm:ss p',
        showInputs: false,
        showMeridian: false,
        interval: 60,
    })
});
