<div class="content-wrapper">
<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col">
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">
      <div class="alert alert-info" role="alert">
        Anda <b>Belum Berhak</b> Membuka Halaman Ini Sekarang!
      </div>
  
    </section>
</div>
</div>
<br>