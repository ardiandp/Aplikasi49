<div class="content-wrapper">
<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col">
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">
      <div class="alert alert-warning" role="alert">
        Anda <b>Belum Berhak</b> Mendaftar Ulang Untuk Saat Ini!
      </div>
  
    </section>
</div>
</div>
<br>