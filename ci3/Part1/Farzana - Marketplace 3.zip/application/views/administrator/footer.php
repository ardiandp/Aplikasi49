
<strong>Copyright &copy; 2022 - <?php echo date('Y'); ?> <a target='_BLANK' href="https://www.cnkponcol.com/"> Ekstore</a>.</strong> All rights reserved.