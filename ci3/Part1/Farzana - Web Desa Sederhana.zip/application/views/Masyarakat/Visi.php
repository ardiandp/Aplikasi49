          
        <div class="header-body text-center mb-7">
          <div class="row justify-content-center">
            <div class="col-xl-5 col-lg-6 col-md-8 mt-5 px-5">
              <span id="visimisi"><h1 class="text-blue"><b>MENUJU DESA MODERN<b></h1></span>
              <p class="text-lead text-blue">Melayani masyarakat secara cepat, aman, dan nyaman dengan mengikuti perkembangan teknologi adalah komitmen kami dalam memajukan Desa Ngendrosari. Maka website publikasi dan sistem informasi desa ini kami hadirkan untuk mewujudkan Desa Modern</p>
            </div>
          </div>
        </div>