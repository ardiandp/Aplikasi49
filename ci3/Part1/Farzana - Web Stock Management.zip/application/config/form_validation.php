<?php
$config['error_preffix'] = '<small class="text-danger">';
$config['error_suffix'] = '</small>';
