
<p align="center" style="font-weight:bold;font-size:16pt">LAPORAN TRANSAKSI PENJUALAN</p>

<div class="table-responsive">
<table id="print" class="table table-striped table-bordered text-center" style="width:100%">
<thead>
<tr>
        <th rowspan="2" scope="rowgroup">No</th>
        <th colspan="5" scope="colgroup">tes</th>
</tr>
    <tr>
        <th scope="col">Tanggal</th>
        <th scope="col">Nama Barang</th>
        <th scope="col">Jumlah</th>
        <th scope="col">Harga</th>
        <th scope="col">Total</th>
</tr>
</thead>
<tbody>
<tr>
    <td align="center">1</td>
    <td align="center">2021-11-01</td>
    <td>LCD Monitor </td>
    <td align="center">2</td>
    <td align="right">2.500.000</td>
    <td align="right">5.000.000</td>
</tr>
<tr>
    <td align="center">2</td>
    <td align="center">2021-11-02</td>
    <td>Mouse </td>
    <td align="center">3</td>
    <td align="right">150.000</td>
    <td align="right">450.000</td>
</tr>
<tr>
    <td align="center">3</td>
    <td align="center">2021-11-05</td>
    <td>Keyboard </td>
    <td align="center">1</td>
    <td align="right">175.000</td>
    <td align="right">175.000</td>
</tr>
</tbody>
</table>
</div>

<p align="center">
<input type="button" value="Export Excel" onclick="window.open('laporan_excel.php')">
</p>





