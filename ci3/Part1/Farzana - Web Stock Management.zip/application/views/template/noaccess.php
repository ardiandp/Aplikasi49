      <!-- Main Content -->
      <div class="main-content">
          <section class="section">
              <div class="section-header">
              </div>
              <div class="section-body">
              <center><font color="red"><h1>AKSES TIDAK DI IZINKAN !</h1></font>
              <img src="./assets/img/noaccess.gif" /></center>
              </div>
          </section>
      </div>