      <!-- Main Content -->
      <div class="main-content">
          <section class="section">
              <div class="section-header">
              </div>
              <div class="section-body">
              <center><h1>HALAMAN INI BELUM DIBIKIN</h1>
              <img src="./assets/img/belumtersedia.gif" /></center>
              </div>
          </section>
      </div>