<?php
header ('Location:http://www.dicsr-qnt.com/');
?>