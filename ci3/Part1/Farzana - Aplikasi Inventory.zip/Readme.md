# Inventory App (Codeigniter 3)

Ini adalah project pertama saya, project ini dibuat untuk memenuhi syarat kelulusan di sekolah saya. Project hanya berisikan stock pengelolaan barang, dengan hanya dua role saja yakni admin dan petugas.

<h4>Berikut cara configurasi projectnya : </h4>

1. Pastikan kalian mempunyai XAMPP.
2. Setelah clone atau sudah mendownload source code nya, kalian bisa letakkan file projectnya di htdocs pada folder xampp.
3. Lalu buat databasenya dengan nama inventory_barang
4. Lalu import table-table nya dari file inventory_barang.sql yang ada di dalam folder projectnya.
5. Lalu untuk menjalankan projectnya bisa mengetikkan pada url yakni "localhost/inventory-app"


<h4>List user untuk login : </h4>

1. Admin
- email : admin123@gmail.com
- password : 123

2. Petugas
- email : petugas123@gmail.com
- password : 123
