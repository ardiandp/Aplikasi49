#Fitur Website Halaman Depan :

- Beranda
- Sambutan Kepala Sekolah
- Data Guru
- Alamat Sekolah (Menggunakan google Maps)
- Pengumuman Sekolah
- Agenda Sekolah
- Download File Belajar
- Galeri Sekolah
- Berita Sekolah
- Video Interaktif Belajar Siswa (Fitur Unggulan)

Fitur Website Halaman Administrator :

- Beranda
- Tambah/Edit Guru
- Tambah/Edit Agenda Sekolah
- Tambah/Edit Pengumuman Sekolah
- Tambah/Edit Files Download
- Tambah/EditData Mata Pelajaran
- Tambah/Edit Data Kelas
- Tambah/Edit Data Video belajar
- Tambah/Edit Data Berita
- Tambah/Edit Data Galeri Sekolah

Versi XAMPP Yang Digunakan Pada Sistem Ini Sebagai Berikut :
- XAMPP Versi 5.6.37
- Apache/2.4.34
- PHPMyadmin 4.8.2

Frontend : CSS Template
Backend : SB Admin
Versi Framework CI yang digunakan 3.1.9

Cara Instalasi Sistem Ini Pada Komputer/Laptop/Netbook
- Copy file yang telah di download
- letakkan pada folder instalasi xampp (biasanya terletak di C:\xampp\htdocs\)
- Lalu buat database pada PHPMyadmin klik tombol export arahkan file .sql pada folder yang telah kita sediakan
- lalu buka browser (bisa menggunakan chrome,firefox,atau lainnya) dan ketikkan pada browser http://localhost/nama-folder-kamu
