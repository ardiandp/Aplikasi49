-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2023 at 12:08 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kip`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(6) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `Nama` varchar(100) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Level` int(11) DEFAULT NULL,
  `Barcode` varchar(100) DEFAULT NULL,
  `Username` varchar(100) DEFAULT NULL,
  `Golongan` varchar(100) DEFAULT NULL,
  `Jabatan` varchar(100) DEFAULT NULL,
  `PegawaiId` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `CreatedBy`, `CreatedUtc`, `LastModifiedBy`, `LastModifiedUtc`, `DeletedBy`, `DeletedUtc`, `Nama`, `Password`, `Level`, `Barcode`, `Username`, `Golongan`, `Jabatan`, `PegawaiId`) VALUES
(1, 'gama', '2023-01-10 16:34:45', 'Super Admin', '2023-01-15 07:07:13', NULL, NULL, 'Ardana Gama Prasetyo', '21232f297a57a5a743894a0e4a801fc3', 1, '0003', 'admin', NULL, NULL, NULL),
(5, 'Ardana Gama Prasetyo', '2023-01-23 13:18:15', NULL, NULL, 'Ardana Gama Prasetyo', '2023-01-23 13:21:18', 'Ardana Gama', 'admin', 1, '12233256', 'gama', NULL, 'Koordinator Pengolahan', 3),
(6, 'Ardana Gama Prasetyo', '2023-01-23 13:21:28', NULL, NULL, NULL, NULL, 'Ardana Gama', '21232f297a57a5a743894a0e4a801fc3', 1, '12233256', 'gama', NULL, 'Koordinator Pengolahan', 3),
(7, 'Ardana Gama Prasetyo', '2023-01-23 13:26:03', NULL, NULL, NULL, NULL, 'Yokana Adita', 'bc805e04ccf4d7b301f422a039e20202', 2, '11100005', 'yoka', NULL, 'Admin', 4);

-- --------------------------------------------------------

--
-- Table structure for table `bagian`
--

CREATE TABLE `bagian` (
  `Id` int(6) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `NamaBagian` varchar(100) DEFAULT NULL,
  `UnitId` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bagian`
--

INSERT INTO `bagian` (`Id`, `CreatedBy`, `CreatedUtc`, `LastModifiedBy`, `LastModifiedUtc`, `DeletedBy`, `DeletedUtc`, `NamaBagian`, `UnitId`) VALUES
(1, 'Super Admin', '2023-01-12 05:00:26', 'Super Admin', '2023-01-12 07:24:39', 'Super Admin', '2023-01-12 07:24:23', 'KEPERAWATAN 222', 2),
(2, 'Super Admin', '2023-01-12 07:15:44', NULL, NULL, 'Super Admin', '2023-01-12 11:58:19', 'Keuangan', 1),
(3, 'Super Admin', '2023-01-12 08:33:45', 'Ardana Gama Prasetyo', '2023-01-18 07:53:00', NULL, NULL, 'Rekam Medis', 1),
(4, 'Super Admin', '2023-01-12 12:02:58', NULL, NULL, 'Super Admin', '2023-01-12 12:05:16', NULL, NULL),
(5, 'Super Admin', '2023-01-12 12:08:59', NULL, NULL, 'Super Admin', '2023-01-12 12:09:04', NULL, NULL),
(6, 'Ardana Gama Prasetyo', '2023-01-18 09:40:32', NULL, NULL, NULL, NULL, 'Pendaftaran', 5),
(7, 'Ardana Gama Prasetyo', '2023-01-23 12:43:44', 'Ardana Gama Prasetyo', '2023-01-23 12:44:23', NULL, NULL, 'Pelaporan1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bulan`
--

CREATE TABLE `bulan` (
  `Id` int(6) NOT NULL,
  `NamaBulan` varchar(50) DEFAULT NULL,
  `Index` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bulan`
--

INSERT INTO `bulan` (`Id`, `NamaBulan`, `Index`) VALUES
(1, 'Januari', 1),
(2, 'Februari', 2),
(3, 'Maret', 3),
(4, 'April', 4),
(5, 'Mei', 5),
(6, 'Juni', 6),
(7, 'Juli', 7),
(8, 'Agustus', 8),
(9, 'September', 9),
(10, 'Oktober', 10),
(11, 'November', 11),
(12, 'Desember', 12);

-- --------------------------------------------------------

--
-- Table structure for table `jabatan`
--

CREATE TABLE `jabatan` (
  `Id` int(6) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `NamaJabatan` varchar(100) DEFAULT NULL,
  `Golongan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jabatan`
--

INSERT INTO `jabatan` (`Id`, `CreatedBy`, `CreatedUtc`, `LastModifiedBy`, `LastModifiedUtc`, `DeletedBy`, `DeletedUtc`, `NamaJabatan`, `Golongan`) VALUES
(1, 'Super Admin', '2023-01-13 07:27:29', NULL, NULL, 'Super Admin', '2023-01-13 07:27:35', 'Manager', NULL),
(2, 'Super Admin', '2023-01-13 07:29:26', 'Ardana Gama Prasetyo', '2023-01-18 09:40:59', NULL, NULL, 'Koordinator Pengolahan', 'struktural'),
(3, 'Ardana Gama Prasetyo', '2023-01-18 09:40:52', NULL, NULL, NULL, NULL, 'Admin', 'pelaksana');

-- --------------------------------------------------------

--
-- Table structure for table `keterangan`
--

CREATE TABLE `keterangan` (
  `Id` int(6) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `NilaiMinimal` double DEFAULT NULL,
  `NilaiMaximal` double DEFAULT NULL,
  `Kategori` varchar(100) DEFAULT NULL,
  `Keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `Id` int(6) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `Barcode` varchar(100) DEFAULT NULL,
  `Nama` varchar(100) DEFAULT NULL,
  `TTL` date DEFAULT NULL,
  `Alamat` text DEFAULT NULL,
  `Telepon` varchar(100) DEFAULT NULL,
  `JabatanId` int(6) DEFAULT NULL,
  `BagianId` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`Id`, `CreatedBy`, `CreatedUtc`, `LastModifiedBy`, `LastModifiedUtc`, `DeletedBy`, `DeletedUtc`, `Barcode`, `Nama`, `TTL`, `Alamat`, `Telepon`, `JabatanId`, `BagianId`) VALUES
(2, 'Super Admin', '2023-01-14 04:53:56', 'Super Admin', '2023-01-14 10:33:50', 'Super Admin', '2023-01-14 14:26:29', '12233256', 'Ardana Gama', '2023-01-14', 'makam haji 111', '0856204852', 2, 3),
(3, 'Super Admin', '2023-01-14 14:31:03', 'Super Admin', '2023-01-14 14:35:30', NULL, NULL, '12233256', 'Ardana Gama', '2023-01-13', 'Pandawa Regency 2', '0856204852', 2, 3),
(4, 'Ardana Gama Prasetyo', '2023-01-18 09:08:34', 'Ardana Gama Prasetyo', '2023-01-18 09:41:14', NULL, NULL, '11100005', 'Yokana Adita', '2023-01-10', '', '0856204852', 3, 6);

-- --------------------------------------------------------

--
-- Table structure for table `penilaian`
--

CREATE TABLE `penilaian` (
  `Id` int(6) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `PegawaiId` int(6) DEFAULT NULL,
  `KPI_P1_1` double(18,2) DEFAULT NULL,
  `KPI_P2_1` double(18,2) DEFAULT NULL,
  `KPI_P2_2` double(18,2) DEFAULT NULL,
  `KPI_P2_3` double(18,2) DEFAULT NULL,
  `KPI_P2_4` double(18,2) DEFAULT NULL,
  `KPI_P3_1` double(18,2) DEFAULT NULL,
  `KPI_P3_2` double(18,2) DEFAULT NULL,
  `Behav_1` double(18,2) DEFAULT NULL,
  `Behav_2` double(18,2) DEFAULT NULL,
  `Behav_3` double(18,2) DEFAULT NULL,
  `Behav_4` double(18,2) DEFAULT NULL,
  `Behav_5` double(18,2) DEFAULT NULL,
  `Behav_6` double(18,2) DEFAULT NULL,
  `Behav_7` double(18,2) DEFAULT NULL,
  `LDS_1` double(18,2) DEFAULT NULL,
  `LDS_2` double(18,2) DEFAULT NULL,
  `LDS_3` double(18,2) DEFAULT NULL,
  `LDS_4` double(18,2) DEFAULT NULL,
  `LDS_5` double(18,2) DEFAULT NULL,
  `Keterangan` text DEFAULT NULL,
  `PeriodeAwalId` int(3) DEFAULT NULL,
  `PeriodeAkhirId` int(3) DEFAULT NULL,
  `Tahun` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penilaian`
--

INSERT INTO `penilaian` (`Id`, `CreatedBy`, `CreatedUtc`, `LastModifiedBy`, `LastModifiedUtc`, `DeletedBy`, `DeletedUtc`, `PegawaiId`, `KPI_P1_1`, `KPI_P2_1`, `KPI_P2_2`, `KPI_P2_3`, `KPI_P2_4`, `KPI_P3_1`, `KPI_P3_2`, `Behav_1`, `Behav_2`, `Behav_3`, `Behav_4`, `Behav_5`, `Behav_6`, `Behav_7`, `LDS_1`, `LDS_2`, `LDS_3`, `LDS_4`, `LDS_5`, `Keterangan`, `PeriodeAwalId`, `PeriodeAkhirId`, `Tahun`) VALUES
(1, 'Ardana Gama Prasetyo', '2023-01-18 10:57:02', NULL, NULL, NULL, NULL, 3, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, NULL, 1, 2, NULL),
(2, 'Ardana Gama Prasetyo', '2023-01-18 10:59:53', NULL, NULL, NULL, NULL, 4, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, NULL, 1, 2, 2023),
(3, 'Ardana Gama Prasetyo', '2023-01-18 11:54:02', NULL, NULL, NULL, NULL, 3, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, NULL, 3, 4, 2023);

-- --------------------------------------------------------

--
-- Table structure for table `penilaianpelaksana`
--

CREATE TABLE `penilaianpelaksana` (
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `PegawaiId` int(6) DEFAULT NULL,
  `PeriodeAwalId` int(6) DEFAULT NULL,
  `PeriodeAkhirId` int(6) DEFAULT NULL,
  `Tahun` int(3) DEFAULT NULL,
  `KPI_P1_1` double(10,2) DEFAULT NULL,
  `KPI_P1_2` double(10,2) DEFAULT NULL,
  `KPI_P1_3` double(10,2) DEFAULT NULL,
  `KPI_P1_4` double(10,2) DEFAULT NULL,
  `Behav_1` double(10,2) DEFAULT NULL,
  `Behav_2` double(10,2) DEFAULT NULL,
  `Behav_3` double(10,2) DEFAULT NULL,
  `Behav_4` double(10,2) DEFAULT NULL,
  `Behav_5` double(10,2) DEFAULT NULL,
  `Behav_6` double(10,2) DEFAULT NULL,
  `Behav_7` double(10,2) DEFAULT NULL,
  `Id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penilaianpelaksana`
--

INSERT INTO `penilaianpelaksana` (`CreatedBy`, `CreatedUtc`, `LastModifiedBy`, `LastModifiedUtc`, `DeletedBy`, `DeletedUtc`, `PegawaiId`, `PeriodeAwalId`, `PeriodeAkhirId`, `Tahun`, `KPI_P1_1`, `KPI_P1_2`, `KPI_P1_3`, `KPI_P1_4`, `Behav_1`, `Behav_2`, `Behav_3`, `Behav_4`, `Behav_5`, `Behav_6`, `Behav_7`, `Id`) VALUES
('Ardana Gama Prasetyo', '2023-01-18 12:02:05', NULL, NULL, NULL, NULL, 3, 1, 2, 2023, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `Id` int(6) NOT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `CreatedUtc` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(100) DEFAULT NULL,
  `LastModifiedUtc` datetime DEFAULT NULL,
  `DeletedBy` varchar(100) DEFAULT NULL,
  `DeletedUtc` datetime DEFAULT NULL,
  `NamaUnit` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`Id`, `CreatedBy`, `CreatedUtc`, `LastModifiedBy`, `LastModifiedUtc`, `DeletedBy`, `DeletedUtc`, `NamaUnit`) VALUES
(1, 'gama', '2023-01-11 17:37:51', 'Ardana Gama Prasetyo', '2023-01-18 07:52:41', NULL, NULL, 'Struktural'),
(4, 'Super Admin', '2023-01-12 12:13:59', NULL, NULL, 'Super Admin', '2023-01-12 12:14:27', 'Operasional'),
(5, 'Super Admin', '2023-01-12 12:15:45', 'Ardana Gama Prasetyo', '2023-01-18 07:52:27', NULL, NULL, 'Pelaksana'),
(6, 'Super Admin', '2023-01-14 04:53:34', NULL, NULL, 'Ardana Gama Prasetyo', '2023-01-18 07:52:31', 'TEXTILE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `bagian`
--
ALTER TABLE `bagian`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `bulan`
--
ALTER TABLE `bulan`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `keterangan`
--
ALTER TABLE `keterangan`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `penilaian`
--
ALTER TABLE `penilaian`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `penilaianpelaksana`
--
ALTER TABLE `penilaianpelaksana`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bagian`
--
ALTER TABLE `bagian`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bulan`
--
ALTER TABLE `bulan`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `keterangan`
--
ALTER TABLE `keterangan`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `penilaian`
--
ALTER TABLE `penilaian`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `penilaianpelaksana`
--
ALTER TABLE `penilaianpelaksana`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
