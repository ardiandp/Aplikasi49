<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PenilaianPelaksana extends CI_Controller
{

	function __construct()

	{
		parent::__construct();
		$this->sesnama = $this->session->userdata('usersnama');
		$this->seslevel = $this->session->userdata('level');
		$this->sesstatus = $this->session->userdata('status');

		if ($this->sesstatus != 'login') {
			redirect('login');
		}
	}

	public function index()
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Penilaian";
		$data['judul_top'] = "Penilaian | Key Performence Indicator";
		$data['pageM'] = 'penilaian';
		$data['page'] = '';
		$data['p_pelaksana_view'] = $this->PenilaianPelaksana_model->penilaianPelaksana_view();

		$data['content'] = 'v_penilaianPelaksana/index';
		$this->load->view('template', $data);
	}

	public function view($PenilaianId)
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Penilaian";
		$data['judul_top'] = "Penilaian | Key Performence Indicator";
		$data['pageM'] = 'penilaian';
		$data['page'] = '';
		$data['p_pelaksana'] = $this->PenilaianPelaksana_model->penilaianPelaksana_detail($PenilaianId);
		$data['bulan_view'] = $this->Bulan_model->bulan_view();

		$data['content'] = 'v_penilaianPelaksana/view';
		$this->load->view('template', $data);
	}

	public function create()
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Penilaian";
		$data['judul_top'] = "Penilaian | Key Performence Indicator";
		$data['pageM'] = 'penilaian';
		$data['page'] = '';
		$data['unit_view'] = $this->Unit_model->unit_view();
		$data['pegawai_view'] = $this->Pegawai_model->pegawai_view();
		$data['bulan_view'] = $this->Bulan_model->bulan_view();

		$data['content'] = 'v_penilaianPelaksana/create';
		$this->load->view('template', $data);
	}

	function add()
	{


		$params = array(
			'PegawaiId' => $this->input->post('PegawaiId'),
			'PeriodeAwalId' => $this->input->post('PeriodeAwalId'),
			'PeriodeAkhirId' => $this->input->post('PeriodeAkhirId'),
			'Tahun' => $this->input->post('Tahun'),
			'KPI_P1_1' => $this->input->post('KPI_P1_1'),
			'KPI_P1_2' => $this->input->post('KPI_P1_2'),
			'KPI_P1_3' => $this->input->post('KPI_P1_3'),
			'KPI_P1_4' => $this->input->post('KPI_P1_4'),
			'Behav_1' => $this->input->post('Behav_1'),
			'Behav_2' => $this->input->post('Behav_2'),
			'Behav_3' => $this->input->post('Behav_3'),
			'Behav_4' => $this->input->post('Behav_4'),
			'Behav_5' => $this->input->post('Behav_5'),
			'Behav_6' => $this->input->post('Behav_6'),
			'Behav_7' => $this->input->post('Behav_7'),
			'CreatedBy' => $this->sesnama,
			'CreatedUtc' => date('Y-m-d H:i:s')
		);

		$this->PenilaianPelaksana_model->penilaianPelaksana_add($params);
		redirect('penilaianPelaksana');
	}


	function penilaian_edit($PenilaianId)
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Penilaian";
		$data['judul_top'] = "Penilaian | Key Performence Indicator";
		$data['pageM'] = 'penilaian';
		$data['page'] = '';
		$data['p_pelaksana'] = $this->PenilaianPelaksana_model->penilaianPelaksana_detail($PenilaianId);
		$data['bulan_view'] = $this->Bulan_model->bulan_view();

		$data['content'] = 'v_penilaianPelaksana/edit';
		$this->load->view('template', $data);
	}

	function penilaian_update($Id)
	{
		$params = array(

			
			'KPI_P1_1' => $this->input->post('KPI_P1_1'),
			'KPI_P1_2' => $this->input->post('KPI_P1_2'),
			'KPI_P1_3' => $this->input->post('KPI_P1_3'),
			'KPI_P1_4' => $this->input->post('KPI_P1_4'),
			'Behav_1' => $this->input->post('Behav_1'),
			'Behav_2' => $this->input->post('Behav_2'),
			'Behav_3' => $this->input->post('Behav_3'),
			'Behav_4' => $this->input->post('Behav_4'),
			'Behav_5' => $this->input->post('Behav_5'),
			'Behav_6' => $this->input->post('Behav_6'),
			'Behav_7' => $this->input->post('Behav_7'),
			'LastModifiedBy' => $this->sesnama,
			'LastModifiedUtc' => date('Y-m-d H:i:s')
		);

		$this->PenilaianPelaksana_model->penilaianPelaksana_update($Id, $params);
		redirect('penilaianPelaksana');
	}

	function penilaian_delete($Id)
	{
		$params = array(

			'DeletedBy' => $this->sesnama,
			'DeletedUtc' => date('Y-m-d H:i:s')
		);

		$this->Penilaian_model->penilaian_delete($Id, $params);
		redirect('penilaian');
	}

	function cetak_penilaian_pelaksana1($Id)
	{
		//ob_start();

		$data['pdf_pelaksana_view'] = $this->PenilaianPelaksana_model->penilaianPelaksana_detail($Id);
		$this->load->view('v_penilaianPelaksana/print', $data);
		$html = ob_get_contents();
		//ob_end_clean();

		require_once('./design/html2pdf/html2pdf.class.php');
		$pdf = new HTML2PDF('P', 'A4', 'en', true, 'UTF-8', array(10, 10, 10, 10));
		$pdf->WriteHTML($html);
		$pdf->Output('Penilaian Pelaksana.pdf', 'V');
	}
	function cetak_penilaian_pelaksana($Id)
	{
		$this->load->library('dompdf_gen');

		$datum = $this->PenilaianPelaksana_model->penilaianPelaksana_detail($Id);

		$data['pdf_pelaksana'] = $datum;
		$bulan_view = $this->Bulan_model->bulan_view();

            foreach ($bulan_view as $row) {
                $selected = "";
                if ($row->Id == $datum['PeriodeAwalId'])

                    $PeriodeAwal = $row->NamaBulan;

                if ($row->Id == $datum['PeriodeAkhirId'])
                    $PeriodeAkhir  = $row->NamaBulan;
            }
         $data['PeriodeAwal'] = $PeriodeAwal;
         $data['PeriodeAkhir'] = $PeriodeAkhir;
        
		$this->load->view('v_penilaianPelaksana/print', $data);

		$paper_size = 'A4';
		$orientation = 'landscape';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("Penilaian_Pelaksana.pdf", array('Attachment' => 0));
	}
}
