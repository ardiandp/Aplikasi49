<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bagian extends CI_Controller
{

	function __construct()

	{
		parent::__construct();
		$this->sesnama = $this->session->userdata('usersnama');
		$this->seslevel = $this->session->userdata('level');
		$this->sesstatus = $this->session->userdata('status');

		if ($this->sesstatus != 'login') {
			redirect('login');
		}
	}

	public function index()

	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Bagian";
		$data['judul_top'] = "Bagian | Key Performence Indicator";
		$data['pageM'] = 'master';
		$data['page'] = 'bagian';
		$data['bagian_view'] = $this->Bagian_model->bagian_view();
		$data['unit_view'] = $this->Unit_model->unit_view();

		$data['content'] = 'v_bagian/index';
		$this->load->view('template', $data);
	}

	function bagian_add()
	{


		$params = array(
			'NamaBagian' => $this->input->post('NamaBagian'),
			//'UnitId' => $this->input->post('UnitId'),
			'CreatedBy' => $this->sesnama,
			'CreatedUtc' => date('Y-m-d H:i:s')
		);

		$this->Bagian_model->bagian_add($params);
		redirect('bagian');
	}


	function bagian_edit($BagianId)
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Bagian";
		$data['judul_top'] = "Bagian | Key Performence Indicator";
		$data['pageM'] = 'master';
		$data['page'] = 'bagian';
		//$data['bagian_view'] = $this->Bagian_model->bagian_view();
		$data['unit_view'] = $this->Unit_model->unit_view();


		$data['bagian'] = $this->Bagian_model->bagian_getid($BagianId);
		$data['content'] = 'v_bagian/edit';

		$this->load->view('template', $data);
	}

	function bagian_update($Id)
	{
		$params = array(

			'NamaBagian' => $this->input->post('NamaBagian'),
			//'UnitId' => $this->input->post('UnitId'),
			'LastModifiedBy' => $this->sesnama,
			'LastModifiedUtc' => date('Y-m-d H:i:s')
		);

		$this->Bagian_model->bagian_update($Id, $params);
		redirect('bagian');
	}

	function bagian_delete($Id)
	{
		$params = array(

			'DeletedBy' => $this->sesnama,
			'DeletedUtc' => date('Y-m-d H:i:s')
		);

		$this->Bagian_model->bagian_delete($Id, $params);
		redirect('bagian');
	}
}
