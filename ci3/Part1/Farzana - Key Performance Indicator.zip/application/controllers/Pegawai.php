<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pegawai extends CI_Controller
{

	function __construct()

	{
		parent::__construct();
		$this->sesnama = $this->session->userdata('usersnama');
		$this->seslevel = $this->session->userdata('level');
		$this->sesstatus = $this->session->userdata('status');

		if ($this->sesstatus != 'login') {
			redirect('login');
		}
	}

	public function index()
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Pegawai";
		$data['judul_top'] = "Pegawai | Key Performence Indicator";
		$data['pageM'] = 'master';
		$data['page'] = 'pegawai';
		$data['pegawai_view'] = $this->Pegawai_model->pegawai_view();
		$data['jabatan_view'] = $this->Jabatan_model->jabatan_view();
		$data['bagian_view'] = $this->Bagian_model->bagian_view();
		$data['content'] = 'v_pegawai/index';
		$this->load->view('template', $data);
	}

	function pegawai_add()
	{
		$params = array(
			'Barcode' => $this->input->post('Barcode'),
			'Nama' => $this->input->post('Nama'),
			'TTL' => $this->input->post('TTL'),
			'Alamat' => $this->input->post('Alamat'),
			'Telepon' => $this->input->post('Telepon'),
			'JabatanId' => $this->input->post('JabatanId'),
			'BagianId' => $this->input->post('BagianId'),
			'CreatedBy' => $this->sesnama,
			'CreatedUtc' => date('Y-m-d H:i:s')
		);

		$this->Pegawai_model->pegawai_add($params);
		redirect('pegawai');
	}


	function pegawai_edit($PegawaiId)
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Pegawai";
		$data['judul_top'] = "Pegawai | Key Performence Indicator";
		$data['pageM'] = 'master';
		$data['page'] = 'pegawai';
		//$data['pegawai_view'] = $this->Pegawai_model->pegawai_view();
		$data['jabatan_view'] = $this->Jabatan_model->jabatan_view();
		$data['bagian_view'] = $this->Bagian_model->bagian_view();


		$data['pegawai'] = $this->Pegawai_model->pegawai_getid($PegawaiId);
		$data['content'] = 'v_pegawai/edit';

		$this->load->view('template', $data);
	}

	function pegawai_update($Id)
	{
		$params = array(

			'Barcode' => $this->input->post('Barcode'),
			'Nama' => $this->input->post('Nama'),
			'TTL' => $this->input->post('TTL'),
			'Alamat' => $this->input->post('Alamat'),
			'Telepon' => $this->input->post('Telepon'),
			'JabatanId' => $this->input->post('JabatanId'),
			'BagianId' => $this->input->post('BagianId'),
			'LastModifiedBy' => $this->sesnama,
			'LastModifiedUtc' => date('Y-m-d H:i:s')
		);

		$this->Pegawai_model->pegawai_update($Id, $params);
		redirect('pegawai');
	}

	function pegawai_delete($Id)
	{
		$params = array(

			'DeletedBy' => $this->sesnama,
			'DeletedUtc' => date('Y-m-d H:i:s')
		);

		$this->Pegawai_model->pegawai_delete($Id, $params);
		redirect('pegawai');
	}
}
