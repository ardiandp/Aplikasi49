<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Unit extends CI_Controller
{

	function __construct()

	{
		parent::__construct();
		$this->sesnama = $this->session->userdata('usersnama');
		$this->seslevel = $this->session->userdata('level');
		$this->sesstatus = $this->session->userdata('status');

		if ($this->sesstatus != 'login') {
			redirect('login');
		}
	}

	public function index()

	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Unit";
		$data['judul_top'] = "Unit | Key Performence Indicator";
		$data['pageM'] = 'master';
		$data['page'] = 'unit';
		//$data['bagian_view'] = $this->Bagian_model->bagian_view();
		$data['unit_view'] = $this->Unit_model->unit_view();

		$data['content'] = 'v_unit/index';
		$this->load->view('template', $data);
	}

	function unit_add()
	{


		$params = array(
			'NamaUnit' => $this->input->post('NamaUnit'),
			//'UnitId' => $this->input->post('UnitId'),
			'CreatedBy' => $this->sesnama,
			'CreatedUtc' => date('Y-m-d H:i:s')
		);

		$this->Unit_model->unit_add($params);
		redirect('unit');
	}


	function unit_edit($Id)
	{
		$data['ses_nama'] = $this->sesnama;
		$data['ses_level'] = $this->seslevel;
		$data['judul'] = "Bagian";
		$data['judul_top'] = "Bagian | Key Performence Indicator";
		$data['pageM'] = 'master';
		$data['page'] = 'bagian';
		//$data['bagian_view'] = $this->Bagian_model->bagian_view();
		$data['unit_view'] = $this->Unit_model->unit_view();


		$data['unit'] = $this->Unit_model->unit_getid($Id);
		$data['content'] = 'v_unit/edit';

		$this->load->view('template', $data);
	}

	function unit_update($Id)
	{
		$params = array(

			'NamaUnit' => $this->input->post('NamaUnit'),
			'LastModifiedBy' => $this->sesnama,
			'LastModifiedUtc' => date('Y-m-d H:i:s')
		);

		$this->Unit_model->unit_update($Id, $params);
		redirect('unit');
	}

	function unit_delete($Id)
	{
		$params = array(

			'DeletedBy' => $this->sesnama,
			'DeletedUtc' => date('Y-m-d H:i:s')
		);

		$this->Unit_model->unit_delete($Id, $params);
		redirect('unit');
	}
}
