<aside id="leftsidebar" class="sidebar">
    <!-- User Info -->
    <div class="user-info">
        <div class="image">
            <img src="images/user/admin.jpg" width="60" height="60" alt="" />
        </div>
        <div class="info-container">
            <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?= strtoupper($ses_nama) ?></div>
            <div class="email"> Manager </div>
            <div class="btn-group user-helper-dropdown">
                <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                <ul class="dropdown-menu pull-right">
                    <li><a href="<?php echo base_url(); ?>users"><i class="material-icons">person</i>Users</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="<?php echo base_url(); ?>login"><i class="material-icons">input</i>Sign Out</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- #User Info -->
    <!-- Menu -->
    <div class="menu">
        <ul class="list">


            <li class="header">MENU UTAMA</li>

            <li <?php if ($pageM == 'dashboard') {
                    echo 'class="active"';
                } ?>>
                <a href="<?php echo base_url(); ?>dashboard">
                    <i class="material-icons">home</i>
                    <span>DASHBOARD</span>
                </a>
            </li>

            <li <?php if ($pageM == 'master') {
                    echo 'class="active"';
                } ?>>
                <a href="javascript:void(0);" class="menu-toggle">
                    <i class="material-icons">view_list</i>
                    <span>MASTER</span>
                </a>
                <ul class="ml-menu">
                    <li <?php if ($page == 'bagian') {
                            echo 'class="active"';
                        } ?>>
                        <a href="<?php echo base_url(); ?>bagian">Bagian</a>
                    </li>
                    <!-- <li <?php if ($page == 'unit') {
                                    echo 'class="active"';
                                } ?>>
                        <a href="<?php echo base_url(); ?>unit">Unit</a>
                    </li> -->
                    <li <?php if ($page == 'jabatan') {
                            echo 'class="active"';
                        } ?>>
                        <a href="<?php echo base_url(); ?>jabatan">Jabatan</a>
                    </li>
                    <li <?php if ($page == 'pegawai') {
                            echo 'class="active"';
                        } ?>>
                        <a href="<?php echo base_url(); ?>pegawai">Pegawai</a>
                    </li>


                </ul>
            </li>

            <li <?php if ($pageM == 'penilaianStruktural') {
                    echo 'class="active"';
                } ?>>
                <a href="<?php echo base_url(); ?>penilaianStruktural">
                    <i class="material-icons">poll</i>
                    <span>PENILAIAN STRUKTURAL</span>
                </a>
            </li>


            <li <?php if ($pageM == 'penilaian') {
                    echo 'class="active"';
                } ?>>
                <a href="<?php echo base_url(); ?>penilaianPelaksana">
                    <i class="material-icons">poll</i>
                    <span>PENILAIAN PELAKSANA</span>
                </a>
            </li>



        </ul>
    </div>
    <!-- #Menu -->
    <!-- Footer -->
    <div class="legal">
        <div class="copyright">
            &copy; 2023 <a href="javascript:void(0);">KIP Web</a>.
        </div>
        <div class="version">
            <b>Version: </b> 1.0.0
        </div>
    </div>
    <!-- #Footer -->
</aside>