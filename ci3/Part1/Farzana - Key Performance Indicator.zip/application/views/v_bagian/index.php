<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2><?= strtoupper($judul) ?> </h2>
            </div>

            <div class="header">

                <button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#defaultModal">
                    <i class="material-icons">add</i><span>Tambah</span>
                </button>

            </div>

            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NAMA BAGIAN</th>
                                <!-- <th>UNIT</th> -->
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php foreach ($bagian_view as $row) { ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= strtoupper($row->NamaBagian) ?></td>
                                    <!-- <td><?= strtoupper($row->NamaUnit) ?></td> -->


                                    <td>
                                        <a href="<?= site_url('bagian/bagian_edit/' . $row->Id); ?>" class="btn btn-warning waves-effect btn-xs">
                                            <i class="material-icons">edit</i></a>
                                        <a href="<?php echo base_url() . 'bagian/bagian_delete/' . $row->Id; ?>" class="btn btn-danger waves-effect btn-xs" onclick="return confirm('Apakah Anda Yakin Menghapus Bagian <?= $row->NamaBagian ?> ?')">
                                            <i class="material-icons">close</i></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">TAMBAH <?= strtoupper($judul) ?> BARU</h4>
            </div>
            <div class="modal-body">

                <?php echo form_open_multipart('bagian/bagian_add'); ?>




                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" name="NamaBagian" id="NamaBagian" required="required" class="form-control">
                        <label class="form-label">NAMA</label>
                    </div>
                </div>

                <!-- <label>Unit</label>
                <div class="form-group form-float">
                    <div class="form-line">
                        <select name="UnitId" id="UnitId" class="form-control show-tick" required oninvalid="this.setCustomValidity('Mohon Diisi Terlebih Dahulu')">
                            <option value="">-- Unit --</option>
                            <?php foreach ($unit_view as $row) {  ?>
                                <option value="<?= $row->Id ?>"><?= strtoupper($row->NamaUnit) ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div> -->

            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary waves-effect">Simpan</button>
                <button type="reset" class="btn btn-danger waves-effect">Reset</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">Batal</button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>