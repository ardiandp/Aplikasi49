<nav class="navbar">
    <div class="container-fluid">
        <div class="navbar-header">
            <a href="javascript:void(0);" class="bars"></a>
            <a class="navbar-brand" href="#"><b>Key Performance Indicator </b> <?= date('Y') ?>&trade;</a>
        </div>
    </div>
</nav>