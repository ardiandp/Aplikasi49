<html><head>
    <title>PDF</title>
    <style>
        *{
            margin: 0;
            padding: 0;
        }
        #table {
           
            border-collapse: collapse;
            width: 100%;
            padding-bottom: 40px;
        }

        #table td,
        #table th {
            border: 1px solid #ddd;
            padding: 0px;
        }

        #table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #table tr:hover {
            background-color: #ddd;
        }

        #table th {
            padding-top: 5px;
            padding-bottom: 5px;
            text-align: left;
            

        }

        #table{
            border-collapse: collapse;
        }

        #table1 {
            
            border-collapse: collapse;
            width: 100%;
        }
        #table2 {
            padding-top: 50px;
            border-collapse: collapse;
            width: 100%;
            border: 2px;
        }

        .content{
            margin-left: 20px;
            margin-top: 20px;
            margin-bottom: 20px;
            margin-right: 20px;
        }
    </style>
</head><body>
    <div class="content">
        <div style="text-align:center">
            <h3> Penilaian Kinerja Non Medis-Pelaksana</h3>
        </div>
        <br>
        <br>
        <table id="table1">
            <tr>
                <td>Nama</td>
                <td>: &nbsp;<?= $pdf_pelaksana['NamaPegawai']?></td>
                <td>Unit Kerja</td>
                <td>: &nbsp;<?= $pdf_pelaksana['NamaBagian']?></td>
            </tr>
            
            <tr>
                <td>Jabatan</td>
                <td>: &nbsp;<?= $pdf_pelaksana['NamaJabatan']?></td>
                <td>Periode Penilaian</td>
                <td>: &nbsp;<?= $PeriodeAwal." - ".$PeriodeAkhir." ".$pdf_pelaksana['Tahun']?></td>
            </tr>
        </table>
    <br>
    <br>
        <table id="table">
            
            <tbody>
                <tr>
                    <th>No. </th>
                    <th>Indikator</th>
                    <th>Definisi Operasional</th>
                    <th>Ket</th>
                    <th>Target</th>
                    <th>Capain</th>
                    <th>Bobot</th>
                    <th>Hasil</th>
                </tr>
                <tr>
                    <td colspan="8" align=center style="background-color:#dcdbda"><b>A. Key Performance Indikator (KPI)</b></td>
                </tr>
                <?php
                    $hasil_KPI_P1_1 = $pdf_pelaksana['KPI_P1_1']/100*15;
                    $hasil_KPI_P1_2 = $pdf_pelaksana['KPI_P1_2']/100*15;
                    $hasil_KPI_P1_3 = $pdf_pelaksana['KPI_P1_3']/100*15;
                    $hasil_KPI_P1_4 = $pdf_pelaksana['KPI_P1_4']/3*15;

                    $hasilTotal_KPI_P1 = $hasil_KPI_P1_1 + $hasil_KPI_P1_2 + $hasil_KPI_P1_3 + $hasil_KPI_P1_4;
                ?>
                <tr>
                    <th>1</th>
                    <td>Kecepatan Registrasi pasien baru </td>
                    <td>Registrasi pasien baru selesai dalam waktu 5 menit</td>
                    <td>Pasien</td>
                    <td>100%</td>
                    <td>
                        <?php echo $pdf_pelaksana['KPI_P1_1'];  ?>
                    </td>
                    <td>15</td>
                    <td><?php echo $pdf_pelaksana['KPI_P1_1']/100*15;  ?> </td>
                </tr>
                <tr>
                    <th>2</th>
                    <td>Kecepatan Registrasi pasien lama</td>
                    <td>Registrasi pasien lama selesai dalam waktu 2 menit</td>
                    <td>Pasien</td>
                    <td>100%</td>
                    <td>
                        <?php echo $pdf_pelaksana['KPI_P1_2'];  ?>
                        
                    </td>
                    <td>15</td>
                    <td><?php echo $pdf_pelaksana['KPI_P1_2']/100*15;  ?></td>
                </tr>
                <tr>
                    <th>3</th>
                    <td>Registrasi pasien rawat inap</td>
                    <td>Registrasi pasien rawat inap selesai dalam waktu 15 menit</td>
                    <td>Pasien</td>
                    <td>100%</td>
                    <td>
                        <?php echo $pdf_pelaksana['KPI_P1_3'];  ?>
                    </td>
                    <td>15</td>
                    <td><?php echo $pdf_pelaksana['KPI_P1_3']/100*15;  ?></td>
                </tr>
                <tr>
                    <th >4</th>
                    <td>Kegiatan kendali mutu kendali biaya</td>
                    <td>Turut aktif dalam pelaksanaan kendali mutu kendali biaya, missal: memberi ide solusi, menemukan masalah, dll</td>
                    <td>Ide</td>
                    <td>3</td>
                    <td>
                        <?php echo $pdf_pelaksana['KPI_P1_4'];  ?>
                    </td>
                    <td>15</td>
                    <td><?php echo $pdf_pelaksana['KPI_P1_4']/3*15;  ?></td>
                </tr>
                <tr>
                    <td colspan="6" style="background-color:#f5e751">Jumlah Nilai KPI</td>
                    
                    <td>60</td>
                    <td> <?= $hasilTotal_KPI_P1;?></td>
                </tr>
                <tr>
                    <td colspan="8" align=center style="background-color:#dcdbda"><b>B. Perilaku</b></td>
                </tr>
                <?php
                    $hasil_Behav_1 = $pdf_pelaksana['Behav_1']/12*5.7;
                    $hasil_Behav_2 = $pdf_pelaksana['Behav_2']/12*5.7;
                    $hasil_Behav_3 = $pdf_pelaksana['Behav_3']/12*5.7;
                    $hasil_Behav_4 = $pdf_pelaksana['Behav_4']/12*5.7;
                    $hasil_Behav_5 = $pdf_pelaksana['Behav_5']/12*5.7;
                    $hasil_Behav_6 = $pdf_pelaksana['Behav_6']/12*5.7;
                    $hasil_Behav_7 = $pdf_pelaksana['Behav_7']/12*5.7;

                    $hasilTotal_Behav = $hasil_Behav_1 + $hasil_Behav_2 + $hasil_Behav_3 + $hasil_Behav_4 + $hasil_Behav_5 + $hasil_Behav_6 + $hasil_Behav_7;
                ?>
                <tr>
                    <th>1</th>
                    <td>Ketelitian</td>
                    <td>Teliti dalam melaksanakan tugas</td>
                    <td>Kategori</td>
                    <td>12</td>
                    <td>
                        <?php echo $pdf_pelaksana['Behav_1'];  ?>
                    </td>
                    <td>5.7</td>
                    <td><?= $hasil_Behav_1; ?></td>
                </tr>
                <tr>
                    <th>2</th>
                    <td>Kerja sama</td>
                    <td>Bekerja sama dengan orang lain</td>
                    <td>Kategori</td>
                    <td>12</td>
                    <td>
                        <?php echo $pdf_pelaksana['Behav_2'];  ?>
                    </td>
                    <td>5.7</td>
                    <td><?= $hasil_Behav_2; ?></td>
                </tr>
                <tr>
                    <th>3</th>
                    <td>Tanggung Jawab</td>
                    <td>Menyelesaikan tugas sesuai target yang ditetapkan</td>
                    <td>Kategori</td>
                    <td>12</td>
                    <td>
                        <?php echo $pdf_pelaksana['Behav_3'];  ?>
                    </td>
                    <td>5.7</td>
                    <td><?= $hasil_Behav_3; ?></td>
                </tr>
                <tr>
                    <th>4</th>
                    <td>Sikap</td>
                    <td>Bersikap sopan terhadap, pasien, keluarga pasien, atasan dan rekan kerja</td>
                    <td>Kategori</td>
                    <td>12</td>
                    <td>
                        <?php echo $pdf_pelaksana['Behav_4'];  ?>
                    </td>
                    <td>5.7</td>
                    <td><?= $hasil_Behav_4; ?></td>
                </tr>

                <tr>
                    <th>5</th>
                    <td>Loyalitas</td>
                    <td>Kesetiaan, pengabdian dan kepercayaan terhadap rumah sakit</td>
                    <td>Kategori</td>
                    <td>12</td>
                    <td>
                       <?php echo $pdf_pelaksana['Behav_5'];  ?>
                    </td>
                    <td>5.7</td>
                    <td><?= $hasil_Behav_5; ?></td>
                </tr>
                <tr>
                    <th>6</th>
                    <td>Ketaatan</td>
                    <td>Melaksanakan perintah tugas dengan ikhlas & tanggung jawab</td>
                    <td>Kategori</td>
                    <td>12</td>
                    <td>
                        <?php echo $pdf_pelaksana['Behav_6'];  ?>
                    </td>
                    <td>5.7</td>
                    <td><?= $hasil_Behav_6; ?></td>
                </tr>
                <tr>
                    <th>7</th>
                    <td>Kehadiran</td>
                    <td>Tidak Meninggalkan tempat tugas saat jam dinas untuk keperluan pribadi</td>
                    <td>Kategori</td>
                    <td>12</td>
                    <td>
                        <?php echo $pdf_pelaksana['Behav_7'];  ?>
                    </td>
                    <td>5.7</td>
                    <td><?= $hasil_Behav_7; ?></td>
                </tr>
                <tr >
                    <td colspan="6" style="background-color:#f5e751">Jumlah Nilai KPI</td>
                    
                    <td style="background-color:#f5e751">60</td>
                    <td style="background-color:#f5e751"> <?= $hasilTotal_Behav;?></td>
                </tr>
                <tr >
                    <td colspan="7" style="background-color:#82faae">Jumlah Nilai KPI</td>
                    
                    
                    <td style="background-color:#82faae"> <?= $hasilTotal_Behav + $hasilTotal_KPI_P1;?></td>
                </tr>
                
            </tbody>
            
            
        </table>


            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
 <table>
    
    <tbody>
        <tr>
            <td>jjjjj</td>
        </tr>
        <tr>
            <td>jjjjj</td>
        </tr>
    </tbody>
        
            

        
        

    
</table>
        
   <!--  </div>

        <br>
        <br>

        <p>aaaaaaaaaa</p> -->
</body></html> 