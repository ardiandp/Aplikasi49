<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">

            <div class="header">
                <h2>
                    <?= $judul ?>
                </h2>
                <ul class="header-dropdown m-r--5">
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="material-icons">more_vert</i>
                        </a>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="javascript:void(0);">Action</a></li>
                            <li><a href="javascript:void(0);">Another action</a></li>
                            <li><a href="javascript:void(0);">Something else here</a></li>
                        </ul>
                    </li>
                </ul>
            </div>

            <div class="body">

                <form action="<?php echo base_url(); ?>penilaianPelaksana/add/" class="signin-form" method="post">


                    <div class="col-sm-6">
                        <label>Nama Pegawai</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="NamaPegawai" id="NamaPegawai" required="required" readonly class="form-control" value="<?php echo $p_pelaksana['NamaPegawai'];  ?>">

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <label>Barcode</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="Barcode" id="Barcode" required="required" readonly class="form-control" value="<?php echo $p_pelaksana['Barcode'];  ?>">

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <label>Unit Kerja</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="Bagian" id="Bagian" required="required" readonly class="form-control" value="<?php echo $p_pelaksana['NamaBagian'];  ?>">

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <label>Jabatan</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="Jabatan" id="Jabatan" required="required" readonly class="form-control" value="<?php echo $p_pelaksana['NamaBagian'];  ?>">

                            </div>
                        </div>
                    </div>

                    <?php
                    foreach ($bulan_view as $row) {
                        $selected = "";
                        if ($row->Id == $p_pelaksana['PeriodeAwalId'])

                            $PeriodeAwal = $row->NamaBulan;

                        if ($row->Id == $p_pelaksana['PeriodeAkhirId'])
                            $PeriodeAkhir  = $row->NamaBulan;
                    }
                    ?>
                    <div class="col-sm-4">
                        <label>Periode Awal</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="PeriodeAwalId" id="PeriodeAwalId" required="required" readonly class="form-control" value="<?= $PeriodeAwal; ?>">

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <label>Periode Akhir</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="PeriodeAkhirId" id="PeriodeAkhirId" required="required" readonly class="form-control" value="<?= $PeriodeAkhir; ?>">

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <label>Tahun</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="Tahun" id="Tahun" required="required" readonly class="form-control" value="<?php echo $p_pelaksana['Tahun'];  ?>">

                            </div>
                        </div>
                    </div>

                    <div class="body table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>Indikator</th>
                                    <th>Definisi Operasional</th>
                                    <th>Keterangan</th>
                                    <th>Target</th>
                                    <th>Capaian</th>
                                    <th>Bobot</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="8" align=center style="background-color:#dcdbda"><b>A. Key Performance Indikator (KPI)</b></td>

                                </tr>
                                <tr>
                                    <th scope="row">1</th>
                                    <td>Kecepatan Registrasi pasien baru </td>
                                    <td>Registrasi pasien baru selesai dalam waktu 5 menit</td>
                                    <td>Pasien</td>
                                    <td>100%</td>
                                    <td>
                                        <input type="text" name="KPI_P1_1" required="required" size="10" readonly value="<?php echo $p_pelaksana['KPI_P1_1'];  ?>">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <th scope="row">2</th>
                                    <td>Kecepatan Registrasi pasien lama</td>
                                    <td>Registrasi pasien lama selesai dalam waktu 2 menit</td>
                                    <td>Pasien</td>
                                    <td>100%</td>
                                    <td>
                                        <input type="text" name="KPI_P1_2" required="required" size="10" readonly value="<?php echo $p_pelaksana['KPI_P1_2'];  ?>">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <th scope="row">3</th>
                                    <td>Registrasi pasien rawat inap</td>
                                    <td>Registrasi pasien rawat inap selesai dalam waktu 15 menit</td>
                                    <td>Pasien</td>
                                    <td>100%</td>
                                    <td>
                                        <input type="text" name="KPI_P1_3" required="required" size="10" readonly value="<?php echo $p_pelaksana['KPI_P1_3'];  ?>">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <th scope="row">4</th>
                                    <td>Kegiatan kendali mutu kendali biaya</td>
                                    <td>Turut aktif dalam pelaksanaan kendali mutu kendali biaya, missal: memberi ide solusi, menemukan masalah, dll</td>
                                    <td>Ide</td>
                                    <td>3</td>
                                    <td>
                                        <input type="text" name="KPI_P1_4" required="required" size="10" readonly value="<?php echo $p_pelaksana['KPI_P1_4'];  ?>">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <td colspan="8" align=center style="background-color:#dcdbda"><b>B. Perilaku</b></td>

                                </tr>
                                <tr>
                                    <th scope="row">1</th>
                                    <td>Ketelitian</td>
                                    <td>Teliti dalam melaksanakan tugas</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_1" required="required" size="10" readonly value="<?php echo $p_pelaksana['Behav_1'];  ?>">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">2</th>
                                    <td>Kerja sama</td>
                                    <td>Bekerja sama dengan orang lain</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_2" required="required" size="10" readonly value="<?php echo $p_pelaksana['Behav_2'];  ?>">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">3</th>
                                    <td>Tanggung Jawab</td>
                                    <td>Menyelesaikan tugas sesuai target yang ditetapkan</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_3" required="required" size="10" readonly value="<?php echo $p_pelaksana['Behav_3'];  ?>">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">4</th>
                                    <td>Sikap</td>
                                    <td>Bersikap sopan terhadap, pasien, keluarga pasien, atasan dan rekan kerja</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_4" required="required" size="10" readonly value="<?php echo $p_pelaksana['Behav_4'];  ?>">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">5</th>
                                    <td>Loyalitas</td>
                                    <td>Kesetiaan, pengabdian dan kepercayaan terhadap rumah sakit</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_5" required="required" size="10" readonly value="<?php echo $p_pelaksana['Behav_5'];  ?>">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">6</th>
                                    <td>Ketaatan</td>
                                    <td>Melaksanakan perintah tugas dengan ikhlas & tanggung jawab</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_6" required="required" size="10" readonly value="<?php echo $p_pelaksana['Behav_6'];  ?>">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">7</th>
                                    <td>Kehadiran</td>
                                    <td>Tidak Meninggalkan tempat tugas saat jam dinas untuk keperluan pribadi</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_7" required="required" size="10" readonly value="<?php echo $p_pelaksana['Behav_7'];  ?>">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>


                    <a href="<?php echo site_url('penilaianPelaksana/cetak_penilaian_pelaksana/' . $p_pelaksana['Id']); ?>" class="btn btn-primary waves-effect"><i class="material-icons">print</i>
                        <span> Cetak </span>
                    </a>
                    <a href="<?= site_url('penilaianPelaksana'); ?>" class="btn btn-danger waves-effect">
                        <i class="material-icons">close</i></a>
                </form>
                <script type="text/javascript">
                    <?php echo $jsArray; ?>
                    console.log($jsArray);

                    function changeValue(x) {
                        document.getElementById('barcode').value = prdName[x].barcode;
                        document.getElementById('bagian').value = prdName[x].bagian;
                        document.getElementById('jabatan').value = prdName[x].jabatan;
                    };
                </script>
            </div>

        </div>
    </div>