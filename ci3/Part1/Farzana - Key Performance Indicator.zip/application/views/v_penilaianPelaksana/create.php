<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">

            <div class="header">
                <h2>
                    <?= $judul ?>
                </h2>
                <ul class="header-dropdown m-r--5">
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="material-icons">more_vert</i>
                        </a>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="javascript:void(0);">Action</a></li>
                            <li><a href="javascript:void(0);">Another action</a></li>
                            <li><a href="javascript:void(0);">Something else here</a></li>
                        </ul>
                    </li>
                </ul>
            </div>

            <div class="body">

                <form action="<?php echo base_url(); ?>penilaianPelaksana/add/" class="signin-form" method="post">


                    <div class="col-sm-6">
                        <label>Nama Pegawai</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <select name="PegawaiId" id="PegawaiId" class="form-control show-tick" onchange="changeValue(this.value)" required oninvalid="this.setCustomValidity('Mohon Diisi Terlebih Dahulu')">
                                    <option value="">-- Pegawai --</option>
                                    <?php
                                    $jsArray = "var prdName = new Array();\n";
                                    foreach ($pegawai_view as $row) {  ?>
                                        <option value="<?= $row->PegawaiId ?>"><?= strtoupper($row->Nama) ?></option>

                                    <?php
                                        $jsArray .= "prdName['" . $row->PegawaiId . "'] = 
                                        {nama:'" . addslashes($row->Nama) . "',
                                         barcode:'" . addslashes($row->Barcode) . "',
                                         jabatan:'" . addslashes($row->NamaJabatan) . "',
                                         bagian:'" . addslashes($row->NamaBagian) . "'};\n";
                                    } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <label>Barcode</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="Barcode" id="barcode" required="required" class="form-control">

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <label>Unit Kerja</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="Bagian" id="bagian" required="required" class="form-control">

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <label>Jabatan</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="Jabatan" id="jabatan" required="required" class="form-control">

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <label>Periode Awal</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <select name="PeriodeAwalId" id="PeriodeAwalId" class="form-control show-tick" onchange="changeValue(this.value)" required oninvalid="this.setCustomValidity('Mohon Diisi Terlebih Dahulu')">
                                    <option value="">-- Bulan --</option>
                                    <?php foreach ($bulan_view as $row) {  ?>
                                        <option value="<?= $row->Id ?>"><?= strtoupper($row->NamaBulan) ?></option>
                                    <?php } ?>

                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <label>Periode Akhir</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <select name="PeriodeAkhirId" id="PeriodeAkhirId" class="form-control show-tick" onchange="changeValue(this.value)" required oninvalid="this.setCustomValidity('Mohon Diisi Terlebih Dahulu')">
                                    <option value="">-- Bulan --</option>
                                    <?php foreach ($bulan_view as $row) {  ?>
                                        <option value="<?= $row->Id ?>"><?= strtoupper($row->NamaBulan) ?></option>
                                    <?php } ?>

                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <label>Tahun</label>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <select name="Tahun" id="Tahun" class="form-control show-tick" onchange="changeValue(this.value)" required oninvalid="this.setCustomValidity('Mohon Diisi Terlebih Dahulu')">
                                    <option value="">-- Tahun --</option>
                                    <?php
                                    for ($i = date('Y'); $i >= date('Y') - 10; $i -= 1) {
                                        echo "<option value='$i'> $i </option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="body table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>Indikator</th>
                                    <th>Definisi Operasional</th>
                                    <th>Keterangan</th>
                                    <th>Target</th>
                                    <th>Capaian</th>
                                    <th>Bobot</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="8" align=center style="background-color:#dcdbda"><b>A. Key Performance Indikator (KPI)</b></td>

                                </tr>
                                <tr>
                                    <th scope="row">1</th>
                                    <td>Kecepatan Registrasi pasien baru </td>
                                    <td>Registrasi pasien baru selesai dalam waktu 5 menit</td>
                                    <td>Pasien</td>
                                    <td>100%</td>
                                    <td>
                                        <input type="text" name="KPI_P1_1" required="required" size="10">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <th scope="row">2</th>
                                    <td>Kecepatan Registrasi pasien lama</td>
                                    <td>Registrasi pasien lama selesai dalam waktu 2 menit</td>
                                    <td>Pasien</td>
                                    <td>100%</td>
                                    <td>
                                        <input type="text" name="KPI_P1_2" required="required" size="10">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <th scope="row">3</th>
                                    <td>Registrasi pasien rawat inap</td>
                                    <td>Registrasi pasien rawat inap selesai dalam waktu 15 menit</td>
                                    <td>Pasien</td>
                                    <td>100%</td>
                                    <td>
                                        <input type="text" name="KPI_P1_3" required="required" size="10">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <th scope="row">4</th>
                                    <td>Kegiatan kendali mutu kendali biaya</td>
                                    <td>Turut aktif dalam pelaksanaan kendali mutu kendali biaya, missal: memberi ide solusi, menemukan masalah, dll</td>
                                    <td>Ide</td>
                                    <td>3</td>
                                    <td>
                                        <input type="text" name="KPI_P1_4" required="required" size="10">
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <td colspan="8" align=center style="background-color:#dcdbda"><b>B. Perilaku</b></td>

                                </tr>
                                <tr>
                                    <th scope="row">1</th>
                                    <td>Ketelitian</td>
                                    <td>Teliti dalam melaksanakan tugas</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_1" required="required" size="10">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">2</th>
                                    <td>Kerja sama</td>
                                    <td>Bekerja sama dengan orang lain</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_2" required="required" size="10">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">3</th>
                                    <td>Tanggung Jawab</td>
                                    <td>Menyelesaikan tugas sesuai target yang ditetapkan</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_3" required="required" size="10">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">4</th>
                                    <td>Sikap</td>
                                    <td>Bersikap sopan terhadap, pasien, keluarga pasien, atasan dan rekan kerja</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_4" required="required" size="10">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">5</th>
                                    <td>Loyalitas</td>
                                    <td>Kesetiaan, pengabdian dan kepercayaan terhadap rumah sakit</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_5" required="required" size="10">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">6</th>
                                    <td>Ketaatan</td>
                                    <td>Melaksanakan perintah tugas dengan ikhlas & tanggung jawab</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_6" required="required" size="10">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                                <tr>
                                    <th scope="row">7</th>
                                    <td>Kehadiran</td>
                                    <td>Tidak Meninggalkan tempat tugas saat jam dinas untuk keperluan pribadi</td>
                                    <td>Kategori</td>
                                    <td>12</td>
                                    <td>
                                        <input type="text" name="Behav_7" required="required" size="10">
                                    </td>
                                    <td>5.7</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>






                    <button class="btn btn-primary waves-effect" type="submit">Buat</button>
                    <a href="<?= site_url('bagian'); ?>" class="btn btn-danger waves-effect btn-xs">
                        <i class="material-icons">close</i></a>
                </form>
                <script type="text/javascript">
                    <?php echo $jsArray; ?>
                    console.log($jsArray);

                    function changeValue(x) {
                        document.getElementById('barcode').value = prdName[x].barcode;
                        document.getElementById('bagian').value = prdName[x].bagian;
                        document.getElementById('jabatan').value = prdName[x].jabatan;
                    };
                </script>
            </div>

        </div>
    </div>
</div>