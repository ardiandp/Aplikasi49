<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2><?= strtoupper($judul) ?> </h2>
            </div>

            <div class="header">


                <button type="button" class="btn btn-primary waves-effect" onclick="window.location.replace('<?php echo base_url(); ?>penilaianpelaksana/create');">
                    <i class="material-icons">add</i><span>Tambah</span>
                </button>


            </div>

            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NAMA PEGAWAI</th>
                                <th>JABATAN</th>
                                <th>BAGIAN</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php foreach ($p_pelaksana_view as $row) { ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= strtoupper($row->Nama) ?></td>
                                    <td><?= strtoupper($row->NamaJabatan) ?></td>
                                    <td><?= strtoupper($row->NamaBagian) ?></td>


                                    <td>
                                        <a href="<?= site_url('penilaianpelaksana/view/' . $row->Id); ?>" class="btn btn-primary waves-effect btn-xs">
                                            <i class="material-icons">visibility</i></a>
                                        <a href="<?= site_url('penilaianpelaksana/penilaian_edit/' . $row->Id); ?>" class="btn btn-warning waves-effect btn-xs">
                                            <i class="material-icons">edit</i></a>
                                        <a href="<?php echo base_url() . 'pegawai/pegawai_delete/' . $row->PegawaiId; ?>" class="btn btn-danger waves-effect btn-xs" onclick="return confirm('Apakah Anda Yakin Menghapus Pegawai <?= $row->Nama ?> ?')">
                                            <i class="material-icons">close</i></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>