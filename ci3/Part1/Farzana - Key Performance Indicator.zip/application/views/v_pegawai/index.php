<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2><?= strtoupper($judul) ?> </h2>
            </div>

            <div class="header">

                <button type="button" class="btn btn-primary waves-effect" data-toggle="modal" data-target="#defaultModal">
                    <i class="material-icons">add</i><span>Tambah</span>
                </button>

            </div>

            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>BARCODE</th>
                                <th>NAMA PEGAWAI</th>
                                <th>JABATAN</th>
                                <th>BAGIAN</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php foreach ($pegawai_view as $row) { ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= strtoupper($row->Barcode) ?></td>
                                    <td><?= strtoupper($row->Nama) ?></td>
                                    <td><?= strtoupper($row->NamaJabatan) ?></td>
                                    <td><?= strtoupper($row->NamaBagian) ?></td>


                                    <td>
                                        <a href="<?= site_url('pegawai/pegawai_edit/' . $row->PegawaiId); ?>" class="btn btn-warning waves-effect btn-xs">
                                            <i class="material-icons">edit</i></a>
                                        <a href="<?php echo base_url() . 'pegawai/pegawai_delete/' . $row->PegawaiId; ?>" class="btn btn-danger waves-effect btn-xs" onclick="return confirm('Apakah Anda Yakin Menghapus Pegawai <?= $row->Nama ?> ?')">
                                            <i class="material-icons">close</i></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">TAMBAH <?= strtoupper($judul) ?> BARU</h4>
            </div>
            <div class="modal-body">

                <?php echo form_open_multipart('pegawai/pegawai_add'); ?>

                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" name="Barcode" id="Barcode" required="required" class="form-control">
                        <label class="form-label">BARCODE</label>
                    </div>
                </div>


                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" name="Nama" id="Nama" required="required" class="form-control">
                        <label class="form-label">NAMA</label>
                    </div>
                </div>

                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="date" name="TTL" id="TTL" required="required" class="form-control">
                        <label class="form-label">TANGGAL</label>
                    </div>
                </div>
                <label>Alamat</label>
                <div class="form-group">
                    <div class="form-line">
                        <textarea rows="4" class="form-control no-resize" placeholder="Please type what you want..."></textarea>
                    </div>
                </div>
                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" name="Telepon" id="Telepon" required="required" class="form-control">
                        <label class="form-label">Telepon</label>
                    </div>
                </div>


                <label>Jabatan</label>
                <div class="form-group form-float">
                    <div class="form-line">
                        <select name="JabatanId" id="JabatanId" class="form-control show-tick" required oninvalid="this.setCustomValidity('Mohon Diisi Terlebih Dahulu')">
                            <option value="">-- Jabatan --</option>
                            <?php foreach ($jabatan_view as $row) {  ?>
                                <option value="<?= $row->Id ?>"><?= strtoupper($row->NamaJabatan) ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <label>Bagian</label>
                <div class="form-group form-float">
                    <div class="form-line">
                        <select name="BagianId" id="BagianId" class="form-control show-tick" required oninvalid="this.setCustomValidity('Mohon Diisi Terlebih Dahulu')">
                            <option value="">-- Bagian --</option>
                            <?php foreach ($bagian_view as $row) {  ?>
                                <option value="<?= $row->Id ?>"><?= strtoupper($row->NamaBagian) ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>








            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary waves-effect">Simpan</button>
                <button type="reset" class="btn btn-danger waves-effect">Reset</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">Batal</button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>