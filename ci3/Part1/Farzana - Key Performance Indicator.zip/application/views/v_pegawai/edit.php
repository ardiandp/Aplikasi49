<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">

            <div class="header">
                <h2>
                    <?= $judul ?>
                </h2>
                <ul class="header-dropdown m-r--5">
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="material-icons">more_vert</i>
                        </a>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="javascript:void(0);">Action</a></li>
                            <li><a href="javascript:void(0);">Another action</a></li>
                            <li><a href="javascript:void(0);">Something else here</a></li>
                        </ul>
                    </li>
                </ul>
            </div>

            <div class="body">
                <?php echo form_open('pegawai/pegawai_update/' . $pegawai['Id']); ?>
                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" class="form-control" name="Barcode" required="required" value="<?php echo $pegawai['Barcode'];  ?>">

                        <label class="form-label">BARCODE</label>
                    </div>
                </div>

                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" class="form-control" name="Nama" required="required" value="<?php echo $pegawai['Nama'];  ?>">

                        <label class="form-label">NAMA PEGAWAI</label>
                    </div>
                </div>

                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="date" name="TTL" id="TTL" required="required" class="form-control" value="<?php echo $pegawai['TTL'];  ?>">
                        <label class="form-label">TANGGAL LAHIR</label>
                    </div>
                </div>

                <label>Alamat</label>
                <div class="form-group">
                    <div class="form-line">
                        <textarea name="Alamat" class="form-control no-resize" rows="5" cols="40"><?php echo $pegawai['Alamat']; ?></textarea>
                    </div>
                </div>

                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" class="form-control" name="Telepon" required="required" value="<?php echo $pegawai['Telepon'];  ?>">

                        <label class="form-label">Telepon</label>
                    </div>
                </div>


                <label class="form-label">Jabatan</label>
                <div class="form-group form-float">
                    <div class="form-line">
                        <select name="JabatanId" id="JabatanId" required="required" class="form-control show-tick">
                            <option value="">-- PILIH Jabatan --</option>
                            <?php
                            foreach ($jabatan_view as $row) {
                                $selected = "";
                                if ($row->Id == $pegawai['JabatanId'])
                                    $selected = 'selected="selected"';

                                echo "<option value='" . $row->Id . "' $selected>" . $row->NamaJabatan . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <label class="form-label">Bagian</label>
                <div class="form-group form-float">
                    <div class="form-line">
                        <select name="BagianId" id="BagianId" required="required" class="form-control show-tick">
                            <option value="">-- PILIH Bagian --</option>
                            <?php
                            foreach ($bagian_view as $row) {
                                $selected = "";
                                if ($row->Id == $pegawai['BagianId'])
                                    $selected = 'selected="selected"';

                                echo "<option value='" . $row->Id . "' $selected>" . $row->NamaBagian . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>







                <button class="btn btn-primary waves-effect" type="submit">Update</button>
                <a href="<?= site_url('pegawai'); ?>" class="btn btn-danger waves-effect btn-xs">
                    <i class="material-icons">close</i></a>

            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>