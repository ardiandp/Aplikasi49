<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Unit_model extends CI_Model
{

	function unit_view()
	{
		$sql = "SELECT  * FROM  unit
				where DeletedBy IS NULL
				 ";

		return $this->db->query($sql)->result();
	}

	function unit_add($params)
	{

		$this->db->insert('unit', $params);
		return $this->db->insert_id();
	}

	function unit_delete($Id, $params)
	{
		$this->db->where('Id', $Id);
		return $this->db->update('unit', $params);
	}

	function unit_getid($Id)
	{
		$sql = "SELECT * FROM unit WHERE Id='$Id'";

		return $this->db->query($sql)->row_array();
	}

	function unit_update($Id, $params)
	{

		$this->db->where('Id', $Id);
		return $this->db->update('unit', $params);
	}
}
