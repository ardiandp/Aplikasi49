<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class PenilaianPelaksana_model extends CI_Model
{

	function penilaianPelaksana_view()
	{
		$sql = "SELECT  
				a.Id,
				b.Id as PegawaiId,
				b.Nama,
				b.Barcode,

				c.NamaJabatan,
				d.NamaBagian


				FROM  penilaianpelaksana a
				left join pegawai b on a.PegawaiId = b.Id
				left join jabatan c on c.Id = b.JabatanId
				left join bagian d on d.Id = b.BagianId 
				where
				a.DeletedBy IS NULL 
				-- b.DeletedBy IS NULL
				 ";

		return $this->db->query($sql)->result();
	}

	function penilaianPelaksana_detail($id)
	{
		//$sql = "SELECT * FROM penilaianPelaksana WHERE Id='$id'";

		$sql = "SELECT  
				a.Id,
				b.Id as PegawaiId,
				b.Nama as NamaPegawai,
				b.Barcode,
				c.NamaJabatan,
				d.NamaBagian,
				a.PeriodeAwalId,
				a.PeriodeAkhirId,
				a.Tahun,
				a.KPI_P1_1,a.KPI_P1_2,a.KPI_P1_3,a.KPI_P1_4,
				a.Behav_1, a.Behav_2,a.Behav_3,a.Behav_4,a.Behav_5,a.Behav_6,a.Behav_7 


				FROM  penilaianpelaksana a
				left join pegawai b on a.PegawaiId = b.Id
				left join jabatan c on c.Id = b.JabatanId
				left join bagian d on d.Id = b.BagianId 
				where
				a.DeletedBy IS NULL and
				a.Id='$id'
				-- b.DeletedBy IS NULL
				 ";


		return $this->db->query($sql)->row_array();
	}

	function penilaianPelaksana_add($params)
	{

		$this->db->insert('penilaianPelaksana', $params);
		return $this->db->insert_id();
	}

	function penilaianPelaksana_delete($Id, $params)
	{
		$this->db->where('Id', $Id);
		return $this->db->update('penilaianPelaksana', $params);
	}

	function penilaianPelaksana_getid($id)
	{
		$sql = "SELECT * FROM penilaianPelaksana WHERE Id='$id'";

		return $this->db->query($sql)->row_array();
	}

	function penilaianPelaksana_update($Id, $params)
	{

		$this->db->where('Id', $Id);
		return $this->db->update('penilaianPelaksana', $params);
	}
}
