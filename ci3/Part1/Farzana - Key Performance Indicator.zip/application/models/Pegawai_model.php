<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pegawai_model extends CI_Model
{

	function pegawai_view()
	{
		$sql = "SELECT  
				a.Id as PegawaiId,
				a.Nama,
				a.Barcode,
				a.TTL,
				a.Alamat,
				a.Telepon,
				a.JabatanId,
				a.BagianId,
				b.NamaJabatan,
				b.Golongan,
				c.NamaBagian
				FROM  pegawai a
				left join jabatan b on a.JabatanId = b.Id 
				left join bagian c on a.BagianId = c.Id 
				where
				a.DeletedBy IS NULL

				and b.DeletedBy IS NULL
				and c.DeletedBy IS NULL
				 ";

		return $this->db->query($sql)->result();
	}

	function pegawai_add($params)
	{

		$this->db->insert('pegawai', $params);
		return $this->db->insert_id();
	}

	function pegawai_delete($Id, $params)
	{
		$this->db->where('Id', $Id);
		return $this->db->update('pegawai', $params);
	}

	function pegawai_getid($id)
	{
		$sql = "SELECT * FROM pegawai WHERE Id='$id'";

		return $this->db->query($sql)->row_array();
	}

	function pegawai_update($Id, $params)
	{
		$this->db->where('Id', $Id);
		return $this->db->update('pegawai', $params);
	}
}
