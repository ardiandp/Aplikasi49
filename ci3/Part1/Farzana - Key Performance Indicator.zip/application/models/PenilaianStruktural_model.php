<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class PenilaianStruktural_model extends CI_Model
{

	function penilaianStruktural_view()
	{
		$sql = "SELECT  
				*
				FROM  penilaian
				where
				DeletedBy IS NULL 
				-- b.DeletedBy IS NULL
				 ";

		return $this->db->query($sql)->result();
	}

	function penilaianStruktural_add($params)
	{

		$this->db->insert('penilaian', $params);
		return $this->db->insert_id();
	}

	function penilaian_delete($Id, $params)
	{
		$this->db->where('Id', $Id);
		return $this->db->update('penilaian', $params);
	}

	function penilaian_getid($id)
	{
		$sql = "SELECT * FROM penilaian WHERE Id='$id'";

		return $this->db->query($sql)->row_array();
	}

	function penilaian_update($Id, $params)
	{

		$this->db->where('Id', $Id);
		return $this->db->update('penilaian', $params);
	}
}
