<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Bagian_model extends CI_Model
{

	function bagian_view()
	{
		// $sql = "SELECT  
		// 		b.Id as UnitId,
		// 		a.Id,
		// 		a.NamaBagian,
		// 		b.NamaUnit

		// 		FROM  bagian a
		// 		left join unit b on a.UnitId = b.Id
		// 		where
		// 		a.DeletedBy IS NULL 
		// 		-- b.DeletedBy IS NULL
		// 		 ";

		$sql = "SELECT  *
				FROM  bagian
				where
				DeletedBy IS NULL 
				";

		return $this->db->query($sql)->result();
	}

	function bagian_add($params)
	{

		$this->db->insert('bagian', $params);
		return $this->db->insert_id();
	}

	function bagian_delete($Id, $params)
	{
		$this->db->where('Id', $Id);
		return $this->db->update('bagian', $params);
	}

	function bagian_getid($id)
	{
		$sql = "SELECT * FROM bagian WHERE Id='$id'";

		return $this->db->query($sql)->row_array();
	}

	function bagian_update($Id, $params)
	{

		$this->db->where('Id', $Id);
		return $this->db->update('bagian', $params);
	}
}
