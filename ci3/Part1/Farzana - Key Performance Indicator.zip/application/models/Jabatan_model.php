<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Jabatan_model extends CI_Model
{

	function jabatan_view()
	{
		$sql = "SELECT  
				*
				FROM  jabatan
				where
				DeletedBy IS NULL 
				-- b.DeletedBy IS NULL
				 ";

		return $this->db->query($sql)->result();
	}

	function jabatan_add($params)
	{

		$this->db->insert('jabatan', $params);
		return $this->db->insert_id();
	}

	function jabatan_delete($Id, $params)
	{
		$this->db->where('Id', $Id);
		return $this->db->update('jabatan', $params);
	}

	function jabatan_getid($id)
	{
		$sql = "SELECT * FROM jabatan WHERE Id='$id'";

		return $this->db->query($sql)->row_array();
	}

	function jabatan_update($Id, $params)
	{

		$this->db->where('Id', $Id);
		return $this->db->update('jabatan', $params);
	}
}
