<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8" />

    <title>Request Ubah Password</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

</head>

<body>

    <div>


        <center>
            <h2>Request Ubah Password</h2>
            <p>Berikut Link Yang digunakan untuk ubah password  <a href="http://desaberufgedarat.my.id/ForgotPassword/change_password/<?=$token?>">Link</a></p>
           
        </center>

    </div>

</body>

</html>