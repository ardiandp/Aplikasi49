<div class="site-section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="title-section text-center mb-3">
          <h2>GRAFIK <strong class="text-primary">PERKEMBANGAN ANAK</strong></h2>
        </div>
        <div class="card card-profile text-black">
          <div class="col-4">
            <div class="list-group" id="list-tab" role="tablist">
              <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Data PA</a>
            </div>
          </div>
          <div class="card-body" style="margin-top: 30px; height: 370px;">
            <div class="container">
              <div class="row justify-content-center">
                <div class="col-10">
                  <div id="graph2"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>