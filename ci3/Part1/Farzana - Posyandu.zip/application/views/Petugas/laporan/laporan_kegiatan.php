<?php
if ($this->session->flashdata('petugas')) {
  $this->session->set_flashdata('petugas', 'Success as a petugas.');
} else {
  redirect('auth');
}
?>
<div class="content">
  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title">Laporan</h4>
          <p class="card-category">Laporan</p>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                <option value=""></option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="">Hari</label>
              <select name="hari" id="hari" class="form-control">
                  <option value=""></option>
              </select>
            </div>
          </div>
          <button class="btn btn-primary float-right" type="submit">Go</button>
        </div>
      </div>
    </div>
  </div>
</div>