/*
Author       : Dreamguys
Template Name: Medifab - Health & Medical HTML Template
Version      : 1.3
*/

$(document).ready(function () {
	// Datepicker
	$("#datepicker").datepicker({
		autoclose: true,
		todayHighlight: true,
	});
});
