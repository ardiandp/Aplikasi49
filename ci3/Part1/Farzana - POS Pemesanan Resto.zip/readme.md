# Sistem Informasi Pemesanan Restoran
Sistem Informasi Pemesanan Restoran dengan menggunakan framework CodeIgniter ini memiliki tampilan yang sederhana dan fitur yang mampu berfungsi dengan baik. Aplikasi ini juga dilengkapi fitur sistem pendukung keputusan dengan menggunakan metode SAW.

To access admin page, add url /admin. Example http://localhost/restoran/admin

## Tampilan Aplikasi
![ss](assets/ss1.png)
![ss](assets/ss2.png)
![ss](assets/ss3.png)
![ss](assets/ss4.png)
![ss](assets/ss5.png)

## Admin Account
|  Level  |      Username     | Password |
|:-------:|:-----------------:|---------:|
| Admin   |  admin@gmail.com  | admin    |
| Pegawai |  yunii@gmail.com  | yunii    |

## Sistem Requirement
- CodeIgniter
- Database MySQL
- XAMPP / PHP 5.6
