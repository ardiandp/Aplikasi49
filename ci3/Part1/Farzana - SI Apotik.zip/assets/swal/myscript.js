const flashdata1 : $('.flash-data').data('flashdata');


if (flashdata1) {}

	else {

		swal({

			tittle : 'Hai',
			text : 'Hai',
			type : 'success'

		});


	}