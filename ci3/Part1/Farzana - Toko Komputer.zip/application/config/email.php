<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'protocol' => 'smtp', // 'mail', 'sendmail', or 'smtp'
    'smtp_host' => 'e123.idcloudhosting.com', 
    'smtp_port' => '465',
    'smtp_user' => 'no-reply@lintasdigitalmakmur.com',
    'smtp_pass' => 'Noreply88#*',
    'smtp_crypto' => 'ssl', //can be 'ssl' or 'tls' for example
    'mailtype' => 'html', //plaintext 'text' mails or 'html'
    'smtp_timeout' => '5', //in seconds
    'charset' => 'utf-8',
    'wordwrap' => TRUE,
    'newline' => "\r\n",
    'crlf' => "\r\n"
);
