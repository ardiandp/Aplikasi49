<?php $this->load->view('components/head'); ?>
<?php $this->load->view($subview); ?>
<?php $this->load->view('components/foot'); ?>

