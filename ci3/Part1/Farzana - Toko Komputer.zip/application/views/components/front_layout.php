<?php $this->load->view('components/front_head'); ?>
<?php $this->load->view($subview); ?>
<?php $this->load->view('components/front_foot'); ?>

