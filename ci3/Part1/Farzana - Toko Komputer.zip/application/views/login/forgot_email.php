<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>User Reset Password Notaris - Management Information System</title>
</head>
<body>
<h3>Yth Bapak/Ibu <?=$name?> </h3>
<br>
Pada tanggal <?=$date?> pukul <?=$hours?> sistem kami menerima permintaan reset password akun untuk Anda. Informasi akun baru anda berikut ini:<br>
<br>
Email : <?=$email?> <br>
Password : <?=$password?> <br>
<br>
Hormat Kami,<br>
Administrator <br>
Notaris - Management Information System<br>
https://lintasdigitalmakmur.com/<br>
<br>
Email ini dikirimkan secara otomatis oleh sistem, kami tidak melakukan pengecakan email yang dikirimkan ke email ini.
<br>
<hr>
<font face="Verdana" color="Gray" size="1">PENTING<br>
<br>
Informasi yang disampaikan melalui e-mail ini hanya diperuntukkan bagi pihak penerima sebagaimana dimaksud pada tujuan e-mail ini saja. E-mail ini dapat berisi informasi atau hal-hal yang secara hukum bersifat rahasia. Segala bentuk kajian, penyampaian kembali, penyebarluasan, penyediaan untuk dapat diakses, dan/atau penggunaan lain atau tindakan sejenis atas informasi ini oleh pihak baik orang maupun badan selain dari pihak yang dimaksud pada tujuan e-mail ini adalah dilarang dan dapat diancam sanksi sesuai dengan ketentuan yang berlaku. Jika karena suatu kesalahan anda menerima informasi ini harap menghubungi Notaris - Management Information System dan segera menghapus e-mail ini beserta setiap salinan dan seluruh lampirannya.<br>
</font>
</body>
</html>
