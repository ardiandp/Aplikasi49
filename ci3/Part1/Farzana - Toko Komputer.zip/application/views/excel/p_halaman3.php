<!--*************Author : Hariselmi ********************-->
<style>
.foto{
	width:60px;
	height:60px;
}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/pdf.css" />


<table>
	<tr>
		<h5><u>KETERANGAN TENTANG DIRI PESERTA DIDIK</u></h5>
	</tr>
</table>


<table class="no-border">
		<tr>
			<td class="no">1.</td>
			<td class="width3">Nama Siswa</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">2.</td>
			<td class="width3">Nomor Induk Siswa Nasional</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">3.</td>
			<td class="width3">Tempat dan Tgl Lahir</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">4.</td>
			<td class="width3">Jenis Kelamin</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">5.</td>
			<td class="width3">Agama</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">6.</td>
			<td class="width3">Status dalam Keluarga</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">7.</td>
			<td class="width3">Anak ke</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">8.</td>
			<td class="width3">Alamat Siswa</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no"></td>
			<td class="width3">Telepon</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">9.</td>
			<td class="width3">Sekolah Asal</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">10.</td>
			<td class="width3">Diterima di Sekolah ini</td>
			<td class="no"></td>
			<td></td>
		</tr>
		<tr>
			<td class="no"></td>
			<td class="width3">Di Kelas</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td></td>
			<td class="width3">Pada Tanggal</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">11.</td>
			<td class="width3">Nama Orang Tua</td>
			<td class="no"></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td class="width3">a. Ayah</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td></td>
			<td class="width3">b. Ibu</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">12.</td>
			<td class="width3">Alamat Orang Tua</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td></td>
			<td class="width3">Telepon</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">13.</td>
			<td class="width3">Pekerjaan Orang Tua</td>
			<td class="no"></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td class="width3">a. Ayah</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td></td>
			<td class="width3">b. Ibu</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">14.</td>
			<td class="width3">Nama Wali</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">15.</td>
			<td class="width3">Alamat Wali</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td></td>
			<td class="width3">Telepon</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="no">16.</td>
			<td class="width3">Pekerjaan Wali</td>
			<td class="no">:</td>
			<td>Dummy</td>
		</tr>
</table>


<table class="no-border">
	<tr>
		<td rowspan="3">
			
		</td>
		<td>Tempat, tgl bulan tahun<br>Kepala Sekolah,<br></td>
	</tr>

	<tr>
		<td><b><u>nama kepsek</u></b></td>
	</tr>
</table>
