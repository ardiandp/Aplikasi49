<!--*************Author : Hariselmi ********************-->
<style>
.foto{
	width:60px;
	height:60px;
}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/pdf.css" />

<table style="width: 100%;" class="no-border">
	<tr>
		<td class="width1">Name of School</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
		<td class="ml1 width1">Class</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>

	<tr>
		<td class="width1">Address</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
		<td class="tab1 width1">Semester</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>

	<tr>
		<td class="width1">Name of Student</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
		<td class="tab1 width1">Academic Year</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>

	<tr>
		<td class="width1">Student ID Number</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>
</table>

<b>C. Ekstra Kurikuler/<i>Extra-Curricular</i></b>

<table>
	<thead>
		<tr>
			<th class="no" rowspan="2">No</th>
			<th rowspan="2" class="headerTable">Kegiatan Ekstra Kurikuler/<br><i>Extracurricular Activities</i></th>
			<th class="headerTable" >Nilai/<i>Grade</i></th>
			<th class="headerTable" >Deskripsi/<i>Description</i></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td rowspan="2">1</td>
			<td rowspan="2">-</td>
			<td rowspan="2">-</td>
			<td>-</td>
		</tr>
		<tr>
			<td>-</td>
		</tr>

		<tr>
			<td rowspan="2">2</td>
			<td rowspan="2">-</td>
			<td rowspan="2">-</td>
			<td>-</td>
		</tr>
		<tr>
			<td>-</td>
		</tr>

		<tr>
			<td rowspan="2">3</td>
			<td rowspan="2">-</td>
			<td rowspan="2">-</td>
			<td>-</td>
		</tr>
		<tr>
			<td>-</td>
		</tr>

		<tr>
			<td rowspan="2">4</td>
			<td rowspan="2">-</td>
			<td rowspan="2">-</td>
			<td>-</td>
		</tr>
		<tr>
			<td>-</td>
		</tr>
		
	</tbody>
</table>

<b>D. Prestasi</b>

<table>
	<thead>
		<tr>
			<th class="no" rowspan="2">No</th>
			<th rowspan="2" class="headerTable">Jenis Prestasi/<i>Award</i></th>
			<th class="headerTable" >Keterangan/<i>Information</i></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td rowspan="2">1</td>
			<td>-</td>
			<td rowspan="2">-</td>
		</tr>
		<tr>
			<td>-</td>
		</tr>
		<tr>
			<td rowspan="2">2</td>
			<td>-</td>
			<td rowspan="2">-</td>
		</tr>
		<tr>
			<td>-</td>
		</tr>
		<tr>
			<td rowspan="2">3</td>
			<td>-</td>
			<td rowspan="2">-</td>
		</tr>
		<tr>
			<td>-</td>
		</tr>
	</tbody>
</table>

<b>E. Ketidak Hadiran/<i>Attendance</i></b>

<table>
	<thead>
		<tr>
			<th class="no" rowspan="2">No</th>
			<th rowspan="2" colspan="2" class="headerTable">Ktidak Hadiran/<br><i>Attendance</i></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>1</td>
			<td>Sakit/<i>Sick</i></td>
			<td class="width1">-</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Izin/<i>With Permission</i></td>
			<td class="width1">-</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Tanpa Keterangan/<i>Absen w/o Notice</i></td>
			<td class="width1">-</td>
		</tr>
	</tbody>
</table>


<table>
	<thead>
		<tr>
			<th class="border-bottom1">
				<b>F. Catatan Wali Kelas/<i>Adviser's Comments</i></b>
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Ini Catatan</td>
		</tr>
		<tr>
			<td>This is Comments</td>
		</tr>
	</tbody>
</table>


<table>
	<thead>
		<tr class="border-bottom1">
			<th><b>G. Tanggapan Orang Tua/Wali<i>(Parent/Guardian Response)</i></b></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Ini Tanggapan</td>
		</tr>
	</tbody>
</table>
<br>
<table class="no-border">
	<tr>
		<td style="text-align: center;">Mengetahui/<i>Acknowledged by,</i></td>
		<td style="text-align: center;"></td>
		<td style="text-align: center;">Batam, 17 Desember 2021</td>
	</tr>
	<tr>
		<td style="text-align: center;">Orang Tua / Wali Siswa/<i>Parent/Guardian</i></td>
		<td ></td>
		<td style="text-align: center;">Wali Kelas/<i> Adviser,</i></td>
	</tr>
	<tr>
		<td></td>
		<td style="text-align: center;">Mengetahui/<i>Noted</i></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td style="text-align: center;">SMA Principal</td>
		<td></td>
	</tr>
	<tr>
		<td style="text-align: center;">Nama Ortu</td>
		<td style="text-align: center;";></td>
		<td style="text-align: center;"><u>Nama Walas</u></td>
	</tr>
	<tr>
		<td></td>
		<td style="width: 40%;"></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td style="text-align: center;"><u>Nama Kepsek</u></td>
		<td></td>
	</tr>
</table>

