<!--*************Author : Hariselmi ********************-->
<style>
.foto{
	width:60px;
	height:60px;
}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/pdf.css" />


<table style="width: 100%;" class="no-border">
	<tr>
		<td class="width1">Name of School</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
		<td class="ml1 width1">Class</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>

	<tr>
		<td class="width1">Address</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
		<td class="tab1 width1">Semester</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>

	<tr>
		<td class="width1">Name of Student</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
		<td class="tab1 width1">Academic Year</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>

	<tr>
		<td class="width1">Student ID Number</td>
		<td class="width2">:</td>
		<td>DUMMY</td>
	</tr>
</table>

<table style="width: 100%;" class="no-border">
	<tr>
		<td class="width1">Capaian Hasil Belajar Learning Outcomes</td>
	</tr>
</table>

	<b>A. Sikap/<i>Attitude</i></b>
	<br>
	<b class="ml1">1. Sikap Spritual/<i>Spritual Attitude</i></b>

<table class="ml1">
	<thead>
		<tr>
			<th class="center width3">Predikat/<i>Predicate</i></th>
			<th class="center">Deskripsi/<i>Description</i></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><b>Sangat Baik</b></td>
			<td>texttexttexttexttexttexttexttexttexttexttexttexttexttexttexttexttext</td>
		</tr>
		<tr>
			<td><b>Very Good</b></td>
			<td>texttexttexttexttexttexttexttexttexttexttexttexttexttexttexttexttext</td>
		</tr>
	</tbody>
</table>

<b class="ml1">2. Sikap Sosial</b>

<table class="ml1">
	<thead>
		<tr>
			<th class="center width3">Predikat/<i>Predicate</i></th>
			<th class="center">Deskripsi/<i>Description</i></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><b>Sangat Baik</b></td>
			<td>texttexttexttexttexttexttexttexttexttexttexttexttexttexttexttexttext</td>
		</tr>
		<tr>
			<td><b>Very Good</b></td>
			<td>texttexttexttexttexttexttexttexttexttexttexttexttexttexttexttexttext</td>
		</tr>
	</tbody>
</table>

<b>B. Pengetahuan dan Keterampilan/<i>Knowledge and Skill</i></b>

<table>
	<thead>
		<tr>
			<th class="no" rowspan="2">No</th>
			<th rowspan="2" class="headerTable">MATA PELAJARAN</th>
			<th class="headerTable" colspan="2">Pengetahuan/<i>Cognitive</i></th>
			<th class="headerTable" colspan="2">Keterampilan/<i>Psychomotor</i></th>
		</tr>
		<tr>
			<th class="headerTable width1">Angka/<i>Grade</i></th>
			<th class="headerTable width1">Predikat/<i>Predicate</i></th>
			<th class="headerTable width1">Angka/<i>Grade</i></th>
			<th class="headerTable width1">Predikat/<i>Predicate</i></th>
		</tr>
		<tr>
			<th colspan="6">A. Kurikulum Nasional/<i>National Curriculum</i></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>1</td>
			<td>Pendidikan Agama dan Budi Pekerti/<i>Religion</i></td>
			<td>90</td>
			<td>B</td>
			<td>90</td>
			<td>B</td>
		</tr>
		<tr>
			<th colspan="6">B. Pearson Edexcel Curriculum Subjects</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Business Studies</td>
			<td>90</td>
			<td>B</td>
			<td>90</td>
			<td>B</td>
		</tr>
	</tbody>
</table>