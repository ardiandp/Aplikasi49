<!--*************Author : Hariselmi ********************-->
<style>
.foto{
	width:60px;
	height:60px;
}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/pdf.css" />


<table style="width: 100%;" class="no-border">
			<tr>

			<td style="width: 100%; text-align: center;">
			<img src="assets/images/logo.png" width="100" height="100%" />
			</td>

			</tr>
</table>

<h1>LAPORAN<br>CAPAIAN KOMPETENSI PESERTA DIDIK<br>SEKOLAH MENENGAH ATAS<br>(SMA)</h1>


<table style="width: 100%;" class="no-border">
			<tr>

			<td style="width: 100%; text-align: center;">
			<img src="assets/images/logo.png" width="100" height="100%" />
			</td>

			</tr>
</table>

<h5>NAMA PESERTA DIDIK</h5>
<table class="border-bottom">
	<tr>
		<td >
			Dummy
		</td>
	</tr>
</table>

<h5>NOMOR INDUK</h5>
<table class="border-bottom">
	<tr>

		<td style="width: 50%; text-align: center;">
			Dummy
		</td>

	</tr>
</table>

<table style="width: 40%; text-align: center; margin-left: 30%; margin-right: 30%" class="no-border">
			<tr>

			<td align="center">
			<img src="assets/images/logo.png" width="100" height="100%" />
			</td>
			<td align= "center">
			<img src="assets/images/logo.png" width="100" height="100%" />
			</td>

			</tr>
</table>

<h1>KEMENTERIAN PENDIDIKAN DAN KEBUDAYAAN<br>REPUBLIK INDONESIA</h1>

<table style="width: 100%;" class="no-border">
			<tr>

			<td style="width: 100%; text-align: center;">
			<img src="assets/images/logo.png" width="100" height="100%" />
			</td>

			</tr>
</table>