<!--*************Author : Hariselmi ********************-->
<style>
.foto{
	width:60px;
	height:60px;
}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/pdf.css" />


<table style="width: 100%;" class="no-border">
	<tr>
		<td class="width1">Deskripsi Pengetahuan dan Keterampilan Description of Knowledge and Skill</td>
	</tr>
</table>


<table>
	<thead>
		<tr>
			<th class="center ml1 width2">NO</th>
			<th class="center width3">Subject</th>
			<th class="center width3">Aspek/<i>Aspect</i></th>
			<th class="center">Deskripsi/<i>Description</i></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td rowspan="4"><b>1</b></td>
			<td rowspan="4">Pendidikan Agama</td>
			<td rowspan="2">Pengetahuan/<i>Cognitive</i></td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td>Dummy</td>
		</tr>
		<tr>
			<td rowspan="2">Keterampilan/<i>Psychomotor</i></td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td>Dummy</td>
		</tr>

		<tr>
			<td rowspan="4"><b>2</b></td>
			<td rowspan="4">Pancasila</td>
			<td rowspan="2">Pengetahuan/<i>Cognitive</i></td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td>Dummy</td>
		</tr>
		<tr>
			<td rowspan="2">Keterampilan/<i>Psychomotor</i></td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td>Dummy</td>
		</tr>
	</tbody>
</table>