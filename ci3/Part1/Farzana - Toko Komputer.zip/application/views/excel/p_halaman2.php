<!--*************Author : Hariselmi ********************-->
<style>
.foto{
	width:60px;
	height:60px;
}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/pdf.css" />


<table>
	<tr>
		<h5>LAPORAN<br>CAPAIAN KOMPETENSI PESERTA DIDIK<br>SEKOLAH MENENGAH ATAS<br>(SMA)</h5>
	</tr>
</table>


<table class="no-border">
		<tr>
			<td class="width1">Nama Sekolah</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">NPSN/NSS</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">Alamat Sekolah</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">Kelurahan</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">Kecamatan</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">Kabupaten/Kota</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">Provinsi</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">Website</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
		<tr>
			<td class="width1">E-mail</td>
			<td class="width2">:</td>
			<td>Dummy</td>
		</tr>
</table>
