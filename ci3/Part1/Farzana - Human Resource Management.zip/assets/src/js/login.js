$(document).ready(function () {
  $("#showApproval").show("slow");
});

const chkCompareOrApproval = (event) => {
  if (event.currentTarget.value == "0") {
    $("#email").val("");
    $("#passwordPegawai").val("");
    $("#showApproval").show("slow");
    $("#showCompare").hide("slow");
  } else {
    $("#username").val("");
    $("#passwordAdmin").val("");
    $("#showApproval").hide("slow");
    $("#showCompare").show("slow");
  }
  $("#password").val("");
};

const handlerLogin = () => {
  let types = "";

  $(".chkCompareOrApproval").each(function () {
    if ($(this).is(":checked")) {
      if ($(this).val() == "0") {
        types = 0;
      }

      if ($(this).val() == "1") {
        types = 1;
      }
    }
  });

  checkLogin(types);
};

const checkLogin = (types) => {
  let username = $("#username").val();
  let email = $("#email").val();
  let passwordAdmin = $("#passwordAdmin").val();
  let passwordPegawai = $("#passwordPegawai").val();

  if (types === 0) {
    if (username == "") {
      new PNotify({
        text: "Username tidak boleh kosong",
        type: "error",
        styling: "bootstrap3",
        delay: 2000,
        history: false,
      });
      return false;
    }

    if (passwordAdmin === "") {
      new PNotify({
        text: "Password tidak boleh kosong",
        type: "error",
        styling: "bootstrap3",
        delay: 2000,
        history: false,
      });
      return false;
    }
  }

  if (types === 1) {
    if (email == "") {
      new PNotify({
        text: "Email tidak boleh kosong",
        type: "error",
        styling: "bootstrap3",
        delay: 2000,
        history: false,
      });
      return false;
    }

    if (passwordPegawai === "") {
      new PNotify({
        text: "Password tidak boleh kosong",
        type: "error",
        styling: "bootstrap3",
        delay: 2000,
        history: false,
      });
      return false;
    }
  }

  $.ajax({
    url: base_url + "Auth/action",
    type: "POST",
    data: {
      username: types == 0 ? username : email,
      password: types == 0 ? passwordAdmin : passwordPegawai,
      type: types == 0 ? "admin" : "pegawai",
    },
    dataType: "json",
    success: function (response) {
      if (response.type == 200) {
        new PNotify({
          text: "Anda berhasil masuk aplikasi",
          type: "success",
          styling: "bootstrap3",
          delay: 2000,
          history: false,
        });
        location.href = base_url + response.url;
      }

      if (response.type == 203 || response.type == 204) {
        new PNotify({
          text: response.message,
          type: "error",
          styling: "bootstrap3",
          delay: 2000,
          history: false,
        });
      }
      console.log(response);
    },
    error: function (response) {
      new PNotify({
        text: "Server Error",
        type: "error",
        styling: "bootstrap3",
        delay: 2000,
        history: false,
      });
      console.log(response);
    },
  });
};
