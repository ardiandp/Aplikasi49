<div class="page-title">
    <div class="title_left">
        <h3>Form Monitoring Aktivitas</h3>
    </div>

</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2><small>Data Aktivitas</small></h2>
                <!-- <button id="showformtambah" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Buat Presensi Kehadiran Dan Pulang</button> -->
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <br>

                <div id="divtablepresensi">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input type="month" id="Filtertanggal" class="form-control" name="Filtertanggal" value="<?= date('Y-m') ?>" autocomplete="off">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                                <div class="col-md-9 col-sm-9 ">
                                    <select name="karyawan" class="form-control select2" id="karyawan">
                                        <option value="">Pilih Karyawan</option>
                                        <?php foreach (show_data("karyawan") as $k) {
                                            echo "<option value='" . $k->id . "'>" . $k->name . "</option>";
                                        } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="item form-group">
                                <div class="col-md-4 col-sm-4 ">
                                    <button type="button" class="btn btn-primary" onclick="handlerFilterKehadiranKaryawan()"><i class="fa fa-search"></i> Filter</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="tablemonitoring">
                            <thead>
                                <tr class="bg-dark text-white">
                                    <th style="vertical-align: middle" class="text-center">Nama Karyawan</th>
                                    <th style="vertical-align: middle" class="text-center">Nama Hari</th>
                                    <th style="vertical-align: middle" class="text-center">Tanggal</th>
                                    <th style="vertical-align: middle" class="text-center">Aktivitas</th>
                                    <th style="vertical-align: middle" class="text-center">Waktu</th>
                                    <!-- <th style="vertical-align: middle" class="text-center" rowspan="2">Aksi</th> -->
                                </tr>

                            </thead>
                            <tbody>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });

        $('#tablemonitoring').DataTable();


    })

    const handlerFilterKehadiranKaryawan = () => {
        let tanggal = $('#Filtertanggal').val()
        let idkaryawan = $('#karyawan option:selected').val();
        if (idkaryawan == '') {
            alert('Pilih Karyawan')
            return false;
        }
        $.ajax({
            type: 'POST',
            url: '<?= base_url('Timesheet/getDataMonitoringAktivitas') ?>',
            async: false,
            data: {
                idkaryawan,
                tanggal
            },
            dataType: "JSON",
            success: function(response) {

                if (response != null) {
                    if ($.fn.DataTable.isDataTable('#tablemonitoring')) {
                        $('#tablemonitoring').DataTable().destroy();
                    }
                    $('#tablemonitoring >tbody').empty();
                    $.each(response, function(i, v) {
                        const newDate = new Date(v.tglaktivitas);
                        const namaHari = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
                        console.log(namaHari[newDate.getDay() - 1]);

                        $('#tablemonitoring >tbody').append(`<tr id='${i}'>
                            
                            <td>${v.name_karyawan}</td>
                            <td>${namaHari[newDate.getDay() - 1]}</td>
                            <td>${formatTanggal(v.tanggal_aktivitas)}</td>
                            <td>${v.judul_aktivitas} </td>
                            <td>${v.durasi} jam</td>
                        </tr>`);

                    })
                    $('#tablemonitoring').DataTable();
                }
            }
        })
    }
</script>