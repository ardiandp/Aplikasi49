<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Reset Password - Aplikasi HRM YBM </title>

  <!-- Bootstrap -->
  <link href="<?= base_url('assets/') ?>vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="<?= base_url('assets/') ?>vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- NProgress -->
  <link href="<?= base_url('assets/') ?>vendors/nprogress/nprogress.css" rel="stylesheet">
  <!-- Animate.css -->
  <link href="<?= base_url('assets/') ?>vendors/animate.css/animate.min.css" rel="stylesheet">

  <!-- Custom Theme Style -->
  <link href="<?= base_url('assets/') ?>build/css/custom.min.css" rel="stylesheet">
  <!-- PNotify -->
  <link href="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.css" rel="stylesheet">
  <link href="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
  <link href="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">

  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


</head>

<body class="login">
  <div>
    <a class="hiddenanchor" id="signup"></a>
    <a class="hiddenanchor" id="signin"></a>

    <div class="login_wrapper">
      <div class="animate form login_form">
        <section class="login_content">
          <h1>Reset Password Form</h1>
          <div>
            <input type="password" class="form-control" placeholder="password baru" autocomplete="off" id="password" />
          </div>

          <div class="mt-4">
            <button type="button" class="btn btn-success btn-reset-password" onclick="handlerResetPassword()">Reset Password</button>
          </div>

          <div class="clearfix"></div>

          <div class="clearfix"></div>
          <br />

          <div>
            <h1><i class="fa fa-desktop"></i> HRM YBM PLN</h1>
            <p>Copyright <?= date("Y") ?> &copy; All Rights Reserved.</p>
          </div>
      </div>

      </section>
    </div>


  </div>
  </div>
  <!-- jQuery -->
  <script src="<?= base_url('assets/') ?>vendors/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?= base_url('assets/') ?>vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FastClick -->
  <script src="<?= base_url('assets/') ?>vendors/fastclick/lib/fastclick.js"></script>
  <!-- NProgress -->
  <script src="<?= base_url('assets/') ?>vendors/nprogress/nprogress.js"></script>
  <!-- bootstrap-progressbar -->
  <script src="<?= base_url('assets/') ?>vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
  <!-- iCheck -->
  <script src="<?= base_url('assets/') ?>vendors/iCheck/icheck.min.js"></script>
  <!-- PNotify -->
  <script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.js"></script>
  <script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.buttons.js"></script>
  <script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.nonblock.js"></script>
  <!-- Login -->
  <script>
    const base_url = "<?= base_url('') ?>";
  </script>
  <script>
    const urlSearchParams = new URLSearchParams(window.location.search);
    const email = Object.fromEntries(urlSearchParams.entries()).email;
    const token = Object.fromEntries(urlSearchParams.entries()).token;

    const handlerResetPassword = () => {
      let password = $("#password").val();

      if (password == "") {
        new PNotify({
          text: "Password tidak boleh kosong",
          type: "error",
          styling: "bootstrap3",
          delay: 2000,
          history: false,
        });
        return false;
      }

      $.ajax({
        url: base_url + "Auth/reset_password_action",
        type: "POST",
        data: {
          email: email,
          token: token,
          password: password,
        },
        dataType: "json",
        beforeSend: function() {
          Swal.fire({
            title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
            showConfirmButton: false,
            allowOutsideClick: false
          });
        },
        success: function(response) {
          if (response.type == 200) {
            new PNotify({
              text: response.message,
              type: "success",
              styling: "bootstrap3",
              delay: 2000,
              history: false,
            });
            setTimeout(() => {

              location.href = "<?= base_url('Auth') ?>";

            }, 2000);

          }

          if (response.type == 203) {
            new PNotify({
              text: response.message,
              type: "error",
              styling: "bootstrap3",
              delay: 2000,
              history: false,
            });
          }
        },
        error: function(response) {
          Swal.fire({
            title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
            showConfirmButton: false,
            allowOutsideClick: false,
            timer: 10
          });

          new PNotify({
            text: "Server Error",
            type: "error",
            styling: "bootstrap3",
            delay: 2000,
            history: false,
          });


        },
        complete: function() {
          Swal.fire({
            title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
            showConfirmButton: false,
            allowOutsideClick: false,
            timer: 10
          });
        },
      });
    };
  </script>

</body>

</html>