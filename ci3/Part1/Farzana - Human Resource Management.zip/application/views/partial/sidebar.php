<!-- sidebar menu -->
<?php

$fullUrl = explode('/', $_SERVER['REQUEST_URI']);
$deleteFirstAndSecondUrl = array_splice($fullUrl, 2);
$newUrl = implode('/', $deleteFirstAndSecondUrl);


?>
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
            <?php foreach ($menuHakAkses['parentMenu'] as $value) { ?>
                <?php if ($value->url !== "") { ?>
                    <?php if ($value->url == '/') { ?>
                        <?php if ($this->session->userdata('user') == 'admin') { ?>
                            <li class="<?= $newUrl != "" ? ($value->url == $newUrl ? 'active' : '') : '' ?>"><a href="<?= base_url('/') ?>"><i class="<?= $value->icon ?>"></i> <?= $value->nama ?> </a></li>
                        <?php } else { ?>
                            <li class="<?= $newUrl != "" ? ("Pegawai/dashboard" == $newUrl ? 'active' : '') : '' ?>"><a href="<?= base_url('Pegawai/dashboard') ?>"><i class="<?= $value->icon ?>"></i> <?= $value->nama ?> </a></li>
                        <?php } ?>
                    <?php } else {  ?>
                        <li class="<?= $newUrl != "" ? ($value->url == $newUrl ? 'active' : '') : '' ?>"><a href="<?= base_url($value->url) ?>"><i class="<?= $value->icon ?>"></i> <?= $value->nama ?> </a></li>
                    <?php } ?>
                <?php } else { ?>
                    <li class="<?= $newUrl != "" ? ($value->url == $newUrl ? 'active' : '') : '' ?>"><a><i class="<?= $value->icon ?>"></i> <?= $value->nama ?> <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <?php foreach ($menuHakAkses['mainMenu'] as $val) { ?>
                                <?php if ($value->id == $val->id_parent_menu) { ?>
                                    <?php if ($val->url !== "") { ?>
                                        <li class="<?= $val->url == $newUrl ? 'current-page' : '' ?>"><a href="<?= base_url($val->url) ?>"><?= $val->nama ?></a></li>
                                    <?php } else { ?>
                                        <li class="<?= $val->url == $newUrl ? 'active' : '' ?>"><a><?= $val->nama ?><span class="fa fa-chevron-down"></span></a>
                                            <ul class="nav child_menu">
                                                <?php foreach ($menuHakAkses['subMenu'] as $v) { ?>
                                                    <?php if (($value->id == $val->id_parent_menu) && ($val->id == $v->id_main_menu)) { ?>
                                                        <li class="sub_menu <?= $v->url == $newUrl ? 'active' : '' ?>"><a href="<?= base_url($v->url) ?>"><?= $v->nama ?></a></li>
                                                    <?php } ?>
                                                <?php } ?>
                                            </ul>
                                        </li>
                                    <?php } ?>
                                <?php } ?>
                            <?php } ?>
                        </ul>
                    </li>
                <?php } ?>
            <?php } ?>
        </ul>
    </div>

</div>
<!-- /sidebar menu -->