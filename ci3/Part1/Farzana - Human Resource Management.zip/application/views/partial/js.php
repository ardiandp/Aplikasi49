<!-- Bootstrap -->
<script src="<?= base_url('assets/') ?>vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="<?= base_url('assets/') ?>vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?= base_url('assets/') ?>vendors/nprogress/nprogress.js"></script>
<!-- iCheck -->
<script src="<?= base_url('assets/') ?>vendors/iCheck/icheck.min.js"></script>
<!-- Datatables -->


<script src="<?= base_url('assets/') ?>vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/jszip/dist/jszip.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/pdfmake/build/pdfmake.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/pdfmake/build/vfs_fonts.js"></script>


<script src="<?= base_url('assets/') ?>vendors/switchery/dist/switchery.min.js"></script>

<!-- Custom Theme Scripts -->
<script src="<?= base_url('assets/') ?>build/js/custom.min.js"></script>

<!-- PNotify -->
<script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.js"></script>
<script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.buttons.js"></script>
<script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.nonblock.js"></script>

<!-- bootstrap-daterangepicker -->
<script src="<?= base_url('assets/') ?>vendors/moment/min/moment.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap-datetimepicker -->
<script src="<?= base_url('assets/') ?>vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>

<!-- Datatables Button -->
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.colVis.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.flash.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.html5.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.print.js"></script>

<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/dataTables.buttons.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/datatables.net-buttons/js/buttons.print.min.js"></script>



<?php if ($this->session->flashdata('error')) { ?>
    <script type="text/javascript">
        new PNotify({
            text: '<?= $this->session->flashdata('error') ?>',
            type: 'error',
            styling: 'bootstrap3',
            delay: 2000,
            history: false
        })
    </script>
<?php } else if ($this->session->flashdata('success')) { ?>
    <script type="text/javascript">
        new PNotify({
            text: '<?= $this->session->flashdata('success') ?>',
            type: 'success',
            styling: 'bootstrap3',
            delay: 2000,
            history: false
        })
    </script>
<?php } ?>