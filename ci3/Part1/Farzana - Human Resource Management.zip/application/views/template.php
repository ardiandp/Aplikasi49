<!DOCTYPE html>
<html lang="en">

<?php $this->load->view("partial/header"); ?>

<body class="nav-md">

  <div class="container body">
    <div class="main_container">
      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">
          <div class="navbar nav_title" style="border: 0;">
            <a href="index.html" class="site_title"><i class="fa fa-users"></i> <span>HRM YBM</span></a>
          </div>

          <div class="clearfix"></div>

          <!-- menu profile quick info -->
          <div class="profile clearfix">
            <div class="profile_pic">
              <img src="<?= base_url('assets/ybn.png') ?> " alt="PT. Delta Globat Technindo" class="img-circle profile_img" height="50" width="50">
            </div>
            <div class="profile_info">
              <span>Selama Datang,</span><br>
              <?= $this->session->userdata('username') ?>
            </div>
          </div>
          <!-- /menu profile quick info -->

          <br />
          <?php if ($this->session->userdata('login') == TRUE) {
            $this->load->view("partial/sidebar");
          } ?>
          <?php if ($this->session->userdata('login') == TRUE) { ?>
            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?= base_url('auth/logout') ?>">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          <?php } ?>
        </div>
      </div>

      <!-- top navigation -->
      <?php $this->load->view("partial/navbar"); ?>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        <?= $contents ?>
      </div>
      <!-- /page content -->

      <!-- footer content -->
      <footer>
        <div class="pull-right">
          Aplikasi Penggajian by <a href="">Technopreneur Div, PeTIK Jombang</a>
        </div>
        <div class="clearfix"></div>
      </footer>
      <!-- /footer content -->
    </div>
  </div>


  <?php $this->load->view("partial/js"); ?>
  <script type="text/javascript">
    const showMessage = (type, message) => {
      new PNotify({
        text: message,
        type: type,
        styling: 'bootstrap3',
        delay: 2000,
        history: false
      })
    }

    function formatTanggal(string) {

      bulanIndo = [

        "",

        "Januari",

        "Februari",

        "Maret",

        "April",

        "Mei",

        "Juni",

        "Juli",

        "Agustus",

        "September",

        "Oktober",

        "November",

        "Desember",

      ];



      date = string.split(" ")[0];

      // time = string.split(" ")[1];



      tanggal = date.split("-")[2];

      bulan = date.split("-")[1];

      tahun = date.split("-")[0];



      return tanggal + " " + bulanIndo[Math.abs(bulan)] + " " + tahun

    }

    function doRefresh() {
      $('.whatsapp').load("<?= base_url('welcome/server_wa') ?>");
      setTimeout(function() {
        doRefresh();
      }, 10000);
    }

    function checkInvitedEmailKaryawan() {

      setInterval(function() {
        $.ajax({
          url: "<?= base_url('welcome/checkInvitedEmail') ?>",
          type: "GET",
          async: false,
          success: function(response) {
            console.log(response);
          },
        });
      }, 60 * 1000);
    }

    $(document).ready(function() {
      $('#tableApproval').DataTable();
      $('#tgl').datetimepicker({
        format: 'YYYY-MM-DD'
      });
      $('#tgl_masuk').datetimepicker({
        format: 'YYYY-MM-DD'
      });
      // doRefresh();
      checkInvitedEmailKaryawan();

      $(".lainnya_tunjangan").on('keyup', function() {
        var toal_tunjangan = $('.total').val();
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var jml_tunjangan = parseInt(toal_tunjangan) + parseInt(tunjangan_lainnnya);
        $(".total_tunjangan").val(jml_tunjangan);
      })
      $("#pay_masa").on('keyup', function() {
        var pay_masa = $('#pay_masa').val();
        var pay_grade = $('#pay_grade').val();
        var total_p1 = parseInt(pay_grade) + parseInt(pay_masa);
        $("#total_p1").val(total_p1);
      })
      $("#pay_grade").on('keyup', function() {
        var pay_masa = $('#pay_masa').val();
        var pay_grade = $('#pay_grade').val();
        var total_p1 = parseInt(pay_grade) + parseInt(pay_masa);
        $("#total_p1").val(total_p1);
      })
      $(".save_p1").click(function() {
        var username = $(".karyawan_p1").val();
        var password = $(".total_p1").val();
        var p1_1 = $(".p1_1").val();
        var p1_2 = $(".p1_2").val();
        $.ajax({
          url: "penggajian/save_pay_one",
          type: "POST",
          data: {
            "karyawan": username,
            "total_p1": password,
            "p1_1": p1_1,
            "p1_2": p1_2
          },
          success: function(response) {

            if (response == "success") {
              new PNotify({
                text: 'Pay For Person (P1) berhasil disimpan',
                type: 'success',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
              window.location.replace("penggajian?jenis=1&user=" + username)
            } else {
              new PNotify({
                text: 'Pay For Person (P1) gagal disimpan',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
            }
            console.log(response);
          },
          error: function(response) {
            new PNotify({
              text: username,
              type: 'error',
              styling: 'bootstrap3',
              delay: 2000,
              history: false
            })
            console.log(response);

          }

        });

      })
      $(".lainnya_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".posisi_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".komunikasi_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $("#total_tunjangan").val(total_p2);
      })
      $(".khusus_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".sertifukasi_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".kemahalan_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".cuti_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".perumahan_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".komunikasi_tunjangan").on('keyup', function() {
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var total_p2 = parseInt(tunjangan_lainnnya) + parseInt(tunjangan_posisi) + parseInt(tunjangan_komunikasi) + parseInt(tunjangan_khusus) + parseInt(tunjangan_sertifukasi) + parseInt(tunjangan_kemahalan) + parseInt(tunjangan_cuti) + parseInt(tunjangan_perumahan);
        $(".total_tunjangan").val(total_p2);
      })
      $(".save_p2").click(function() {
        var username = $(".karyawan_p2").val();
        var password = $(".total_tunjangan").val();
        var tunjangan_lainnnya = $('.lainnya_tunjangan').val();
        var tunjangan_posisi = $('.posisi_tunjangan').val();
        var tunjangan_komunikasi = $('.komunikasi_tunjangan').val();
        var tunjangan_khusus = $('.khusus_tunjangan').val();
        var tunjangan_sertifukasi = $('.sertifukasi_tunjangan').val();
        var tunjangan_kemahalan = $('.kemahalan_tunjangan').val();
        var tunjangan_perumahan = $('.perumahan_tunjangan').val();
        var tunjangan_cuti = $('.cuti_tunjangan').val();
        $.ajax({
          url: "penggajian/save_pay_two",
          type: "POST",
          data: {
            "karyawan": username,
            "total_p2": password,
            "lainnya": tunjangan_lainnnya,
            "cuti": tunjangan_cuti,
            "kemahalan": tunjangan_kemahalan,
            "sertifukasi": tunjangan_sertifukasi,
            "khusus": tunjangan_khusus,
            "perumahan": tunjangan_perumahan,
            "komunikasi": tunjangan_komunikasi,
            "posisi": tunjangan_posisi
          },
          success: function(response) {

            if (response == "success") {
              new PNotify({
                text: 'Pay For Person (P2) berhasil disimpan',
                type: 'success',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
              window.location.replace("penggajian?jenis=1&user=" + username)
            } else {
              new PNotify({
                text: 'Pay For Person (P2) gagal disimpan',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
            }
            console.log(response);
          },
          error: function(response) {
            new PNotify({
              text: username,
              type: 'error',
              styling: 'bootstrap3',
              delay: 2000,
              history: false
            })
            console.log(response);

          }

        });

      })
      $(".lainnya_bonus").on('keyup', function() {
        var lainnya_bonus = $('.lainnya_bonus').val();
        var insentif_ramadhan_bonus = $('.insentif_ramadhan_bonus').val();
        var thr_bonus = $('.thr_bonus').val();
        var iks_i_2022_bonus = $('.iks_i_2022_bonus').val();
        var total_p3 = parseInt(lainnya_bonus) + parseInt(insentif_ramadhan_bonus) + parseInt(thr_bonus) + parseInt(iks_i_2022_bonus);
        $(".total_p3").val(total_p3);
      })
      $(".insentif_ramadhan_bonus").on('keyup', function() {
        var lainnya_bonus = $('.lainnya_bonus').val();
        var insentif_ramadhan_bonus = $('.insentif_ramadhan_bonus').val();
        var thr_bonus = $('.thr_bonus').val();
        var iks_i_2022_bonus = $('.iks_i_2022_bonus').val();
        var total_p3 = parseInt(lainnya_bonus) + parseInt(insentif_ramadhan_bonus) + parseInt(thr_bonus) + parseInt(iks_i_2022_bonus);
        $(".total_p3").val(total_p3);
      })
      $(".thr_bonus").on('keyup', function() {
        var lainnya_bonus = $('.lainnya_bonus').val();
        var insentif_ramadhan_bonus = $('.insentif_ramadhan_bonus').val();
        var thr_bonus = $('.thr_bonus').val();
        var iks_i_2022_bonus = $('.iks_i_2022_bonus').val();
        var total_p3 = parseInt(lainnya_bonus) + parseInt(insentif_ramadhan_bonus) + parseInt(thr_bonus) + parseInt(iks_i_2022_bonus);
        $(".total_p3").val(total_p3);
      })
      $(".iks_i_2022_bonus").on('keyup', function() {
        var lainnya_bonus = $('.lainnya_bonus').val();
        var insentif_ramadhan_bonus = $('.insentif_ramadhan_bonus').val();
        var thr_bonus = $('.thr_bonus').val();
        var iks_i_2022_bonus = $('.iks_i_2022_bonus').val();
        var total_p3 = parseInt(lainnya_bonus) + parseInt(insentif_ramadhan_bonus) + parseInt(thr_bonus) + parseInt(iks_i_2022_bonus);
        $(".total_p3").val(total_p3);
      })
      $(".save_p3").click(function() {
        var username = $(".karyawan_p3").val();
        var password = $(".total_p3").val();
        var lainnya_bonus = $('.lainnya_bonus').val();
        var insentif_ramadhan_bonus = $('.insentif_ramadhan_bonus').val();
        var thr_bonus = $('.thr_bonus').val();
        var iks_i_2022_bonus = $('.iks_i_2022_bonus').val();
        $.ajax({
          url: "penggajian/save_pay_three",
          type: "POST",
          data: {
            "karyawan": username,
            "total_p3": password,
            "lainnya": lainnya_bonus,
            "thr": thr_bonus,
            'ramadhan': insentif_ramadhan_bonus,
            'iks_i_2022': iks_i_2022_bonus
          },
          success: function(response) {

            if (response == "success") {
              new PNotify({
                text: 'Pay For Person (P3) berhasil disimpan',
                type: 'success',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
              window.location.replace("penggajian?jenis=1&user=" + username)
            } else {
              new PNotify({
                text: 'Pay For Person (P3) gagal disimpan',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
            }
            console.log(response);
          },
          error: function(response) {
            new PNotify({
              text: username,
              type: 'error',
              styling: 'bootstrap3',
              delay: 2000,
              history: false
            })
            console.log(response);

          }

        });

      })
      $(".hitung_gaji").click(function() {
        var username = $(".karyawan_total").val();
        var password = $(".total_gaji").val();
        $.ajax({
          url: "penggajian/hitung_gaji",
          type: "POST",
          data: {
            "karyawan": username,
            "total_gaji": password,
          },
          success: function(response) {

            if (response == "success") {
              new PNotify({
                text: 'Gaji berhasil diakumulasi',
                type: 'success',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
              window.location.replace("penggajian?jenis=1&user=" + username)
            } else {
              new PNotify({
                text: 'Gaji gagal diakumulasi',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
            }
            console.log(response);
          },
          error: function(response) {
            new PNotify({
              text: username,
              type: 'error',
              styling: 'bootstrap3',
              delay: 2000,
              history: false
            })
            console.log(response);

          }

        });

      })
      $("#dplk").on('keyup', function() {
        var dplk = $('#dplk').val();
        var pot_lainnya = $('#pot_lainnya').val();
        var total_potongan = parseInt(dplk) + parseInt(pot_lainnya);
        $("#total_potongan").val(total_potongan);
      })
      $("#pot_lainnya").on('keyup', function() {
        var dplk = $('#dplk').val();
        var pot_lainnya = $('#pot_lainnya').val();
        var total_potongan = parseInt(dplk) + parseInt(pot_lainnya);
        $("#total_potongan").val(total_potongan);
      })
      $(".save_potongan").click(function() {
        var karyawan = $(".karyawan_potongan").val();
        var dplk = $("#dplk").val();
        var pot_lainnya = $("#pot_lainnya").val();
        var total_potongan = $("#total_potongan").val();
        $.ajax({
          url: "penggajian/hitung_potongan",
          type: "POST",
          data: {
            "karyawan": karyawan,
            "dplk": dplk,
            "pot_lainnya": pot_lainnya,
            "total_potongan": total_potongan,
          },
          success: function(response) {

            if (response == "success") {
              new PNotify({
                text: 'Gaji berhasil diakumulasi',
                type: 'success',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
              window.location.replace("penggajian?jenis=1&user=" + karyawan)
            } else {
              new PNotify({
                text: 'Gaji gagal diakumulasi',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
            }
            console.log(response);
          },
          error: function(response) {
            new PNotify({
              text: karyawan,
              type: 'error',
              styling: 'bootstrap3',
              delay: 2000,
              history: false
            })
            console.log(response);

          }

        });

      })
      $(".genrate").click(function() {
        var username = $(".users").val();
        var password = $(".tgl").val();
        $.ajax({
          url: "penggajian/genrate_gaji",
          type: "POST",
          data: {
            "karyawan": username,
            "date": password,
          },
          success: function(response) {

            if (response == "success") {
              new PNotify({
                text: 'Gaji berhasil diakumulasi',
                type: 'success',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
              window.location.replace("penggajian?jenis=1&user=" + username)
            } else {
              new PNotify({
                text: 'Gaji gagal diakumulasi',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
              })
            }
            console.log(response);
          },
          error: function(response) {
            new PNotify({
              text: username,
              type: 'error',
              styling: 'bootstrap3',
              delay: 2000,
              history: false
            })
            console.log(response);

          }

        });

      })
      $(".select_unit").change(function() {
        var id = $(".select_unit").val();
        $(".show_users").load("<?= base_url('penggajian/karyawan/') ?>" + id)
      })
      $(".lap-thn").change(function() {
        var thn = $(".lap-thn").val();
        var bln = $(".lap-bulan").val();
        if (bln == 0) {
          new PNotify({
            text: "Silahkan pilih bulan terlebih dahulu",
            type: 'error',
            styling: 'bootstrap3',
            delay: 2000,
            history: false
          })
          $(".lap-thn").prop("selectedIndex", 0);
        } else {
          window.location.replace("laporan?bulan=" + bln + "&tahun=" + thn)
        }
      })
    });

    function shortFormatTanggal(string) {

      bulanIndo = [
        "",
        "Januari",
        "Februari",
        "Maret",
        "April",
        "Mei",
        "Juni",
        "Juli",
        "Agustus",
        "September",
        "Oktober",
        "November",
        "Desember",
      ];

      date = string.split(" ")[0];
      bulan = date.split("-")[1];
      tahun = date.split("-")[0];

      return bulanIndo[Math.abs(bulan)] + " " + tahun
    }
  </script>
</body>

</html>
<!-- // let nama_karyawan = $("input[name=cbpilihapproval]:checked").parent().siblings("td.nama_karyawan").text();
    // let idx_aproval = $("input[name=cbpilihapproval]:checked").parent().siblings("td.idx_approval").text();

    // // let radioapproval = $("input[name=cbpilihapproval]:checked").parent().siblings(`td.radioapproval${idx_aproval}`).text();
    // // let radioapproval = $("input[name=cbpilihapproval]:checked").parent().siblings(`td.radioapproval_${idx_aproval}`).children('input').val()
    // let radioapproval = $("input[name=cbpilihapproval]:checked").parent().find("input[type='radio']:checked").text()
    // console.log({
    //   'idx': idx_aproval,
    //   'nama': nama_karyawan,
    //   'radio': radioapproval
    // });
    // // console.log("radioapproval", radioapproval);
    // let sku_barang_id = $("input[name=cbpilihapproval]:checked").parent().siblings("td.sku_barang_id").text();
    // let sku_barang_harga_temp = $("input[name=cbpilihapproval]:checked").parent().siblings("td.sku_barang_harga_temp").text();
    // let sku_barang_harga = $("input[name=rd]:checked").parent().siblings("td.sku_barang_harga").children('input').val() == undefined ? $("input[name=rd]:checked").parent().siblings("td.sku_barang_harga").text() : $("input[name=rd]:checked").parent().siblings("td.sku_barang_harga").children('input').val(); -->