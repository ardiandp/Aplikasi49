<?php if (isset($_GET['del'])) {
  $this->db->delete("karyawan", ['id' => $_GET['del']]);
  $this->session->set_flashdata("success", 'Data karyawan berhasil dihapus');
  redirect("Users/karyawan");
} ?>
<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>

    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">

    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Input Karyawan</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <?php
          if (isset($_GET['id'])) {
            $row = where_row("karyawan", ['id' => $_GET['id']]);
            $job = where_row("penerimaan", ['karyawan' => $_GET['id']]);
          } ?>
          <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link <?= (isset($_GET['step']) && $_GET['step'] == 0 ? "active" : "") ?>" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Data Diri</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= (isset($_GET['step']) && $_GET['step'] == 1 ? "active" : "") ?>" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Data Kontak</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  <?= (isset($_GET['step']) && $_GET['step'] == 2 ? "active" : "") ?>" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Data Pendidikan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  <?= (isset($_GET['step']) && $_GET['step'] == 3 ? "active" : "") ?>" id="job-tab" data-toggle="tab" href="#job" role="tab" aria-controls="job" aria-selected="false">Data Pekerjaan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  <?= (isset($_GET['step']) && $_GET['step'] == 4 ? "active" : "") ?>" id="rekening-tab" data-toggle="tab" href="#rekening" role="tab" aria-controls="rekening" aria-selected="false">Data Rekening</a>
            </li>
          </ul>
          <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 0 ? "show active" : "") ?>" id="home" role="tabpanel" aria-labelledby="home-tab">
              <form class="form-horizontal" method="post" action="<?= base_url('Users/karyawan/save_karyawan') ?>">
                <input type="hidden" name="id" value="<?= (isset($_GET['id']) ? $row->id : "") ?>">
                <div class="item form-group">
                  <label class="col-md-2">Jabatan<span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <select name="id_jabatan" id="id_jabatan" class="form-control">
                      <option>--Pilih Jabatan--</option>
                      <?php foreach ($dataJabatan as $value) { ?>
                        <?php if (isset($_GET['id'])) { ?>
                          <?php if ($row->id_jabatan == $value->id) { ?>
                            <option value="<?= $value->id ?>" selected><?= $value->name ?></option>
                          <?php } else { ?>
                            <option value="<?= $value->id ?>"><?= $value->name ?></option>
                          <?php } ?>
                        <?php } else { ?>
                          <option value="<?= $value->id ?>"><?= $value->name ?></option>
                        <?php } ?>
                      <?php } ?>
                    </select>
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">NIP<span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" name="nip" class="form-control" required autocomplete="off" placeholder="Nomor Induk Pegawai" value="<?= (isset($_GET['id']) ? $row->nip : "") ?>">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">NIK<span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" name="nik" class="form-control" required autocomplete="off" placeholder="Nomor Induk Kependudukan" value="<?= (isset($_GET['id']) ? $row->nik : "") ?>">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">Nama Lengkap <span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" name="name" value="<?= (isset($_GET['id']) ? $row->name : "") ?>" class="form-control" required autocomplete="off" placeholder="Masukan Nama Lengkap disini">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">Tempat Lahir <span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" name="tmp_lahir" value="<?= (isset($_GET['id']) ? $row->tmp_lahir : "") ?>" class="form-control" required autocomplete="off" placeholder="Tempat Lahir">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">Tanggal Lahir <span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" name="tgl_lahir" value="<?= (isset($_GET['id']) ? $row->tgl_lahir : "") ?>" id="tgl" class="form-control" required autocomplete="off" placeholder="yyyy-mm-dd">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">Jenis Kelamin <span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="jenis_kelamin" id="inlineRadio1" <?= (isset($_GET['id']) && $row->jenis_kelamin == 0 ? "checked" : "") ?> value="0">
                      <label class="form-check-label" for="inlineRadio1">Laki - Laki</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="jenis_kelamin" id="inlineRadio2" <?= (isset($_GET['id']) && $row->jenis_kelamin == 1 ? "checked" : "") ?> value="1">
                      <label class="form-check-label" for="inlineRadio2">Perempuan</label>
                    </div>
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2"></label>
                  <div class="col-md-10">
                    <button class="btn btn-primary">Selanjutnya</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- Home -->
            <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 1 ? "show active" : "") ?>" id="profile" role="tabpanel" aria-labelledby="profile-tab">
              <form class="form-horizontal" method="post" action="<?= base_url('Users/karyawan/save_karyawan') ?>">
                <input type="hidden" name="id" value="<?= (isset($_GET['id']) ? $row->id : "") ?>">
                <div class="item form-group">
                  <label class="col-md-3">Email<span class="text-danger">*</span></label>
                  <div class="col-md-9">
                    <input type="text" name="email" value="<?= (isset($_GET['id']) ? $row->email : "") ?>" class="form-control" required autocomplete="off" placeholder="Email">
                  </div>
                </div>

                <div class="item form-group">
                  <label class="col-md-3">Password &nbsp;<?= isset($_GET['id']) ? '<small class="text-danger">abaikan jika tidak dirubah</small>' : '<small class="text-danger">Default 12345678</small>' ?> </label>
                  <div class="col-md-9">
                    <input type="password" name="password" class="form-control" autocomplete="off" <?= isset($_GET['id']) ? '' : 'disabled' ?> value="<?= isset($_GET['id']) ? '' : create_pass('12345678') ?>" placeholder="********">
                  </div>
                </div>

                <div class="item form-group">
                  <label class="col-md-3">No. Handphone<span class="text-danger">*</span></label>
                  <div class="col-md-9">
                    <input type="text" name="phone" value="<?= (isset($_GET['id']) ? $row->phone : "") ?>" class="form-control" required autocomplete="off" placeholder="Nomor Handphone">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-3"></label>
                  <div class="col-md-9">
                    <button class="btn btn-primary">Selanjutnya</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- Profile -->
            <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 2 ? "show active" : "") ?>" id="contact" role="tabpanel" aria-labelledby="contact-tab">

              <div class="clearfix"></div>
              <form class="form-horizontal" method="post" action="<?= base_url('Users/karyawan/save_sekolah') ?>">
                <input type="hidden" name="karyawan" value="<?= (isset($_GET['id']) ? $row->id : "") ?>">
                <?php
                $sekolah = $this->db->get("pendidikan")->result();
                $option = "";
                foreach ($sekolah as $s) {
                  $option .= "<option value='" . $s->id . "'>" . $s->name . "</option>";
                } ?>
                <div class="item form-group">
                  <label class="col-md-2">
                    <select class="form-control" name="sekolah">
                      <?= $option ?>
                    </select>
                  </label>
                  <div class="col-md-4">
                    <input type="text" name="name" class="form-control" required autocomplete="off" placeholder="Nama Sekolah">
                  </div>
                  <div class="col-md-4">
                    <input type="text" name="tahun" class="form-control" required autocomplete="off" placeholder="Tahun Lulus">
                  </div>
                  <div class="col-md-2">
                    <button class="btn btn-primary">Simpan</button>
                  </div>
                </div>
              </form>
              <hr>
              <?php if (isset($_GET['id'])) { ?>
                <?php $cek = where_count("int_sekolah", ['karyawan' => $_GET['id']]);
                if ($cek > 0) { ?>
                  <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Tingkat</th>
                        <th>Nama Sekolah</th>
                        <th>Tahun Kelulusan</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $record = $this->db->get_where('int_sekolah', ['karyawan' => $_GET['id']])->result();
                      $no = 0;
                      foreach ($record as $rc) {
                        $no++;
                        $sk = where_row("pendidikan", ['id' => $rc->sekolah]);
                        echo "<tr>
                        <td>" . $no . "</td>
                        <td>" . $sk->name . "</td>
                        <td>" . $rc->name . "</td>
                        <td>" . $rc->tahun . "</td>
                        <td><a href='" . base_url('Users/karyawan/hapus_sekolah/?id=') . $rc->id . "&karyawan=" . $_GET['id'] . "' class='btn btn-sm btn-danger'><i class='fa fa-trash'></i></a></td>
                        </tr>";
                      } ?>
                    </tbody>
                  </table>
                <?php } ?>
              <?php } ?>

            </div>
            <!-- contact -->
            <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 3 ? "show active" : "") ?>" id="job" role="tabpanel" aria-labelledby="job-tab">
              <form class="form-horizontal" method="post" action="<?= base_url('Users/karyawan/save_pekerjaan') ?>">
                <input type="hidden" name="karyawan" value="<?= (isset($_GET['id']) ? $_GET['id'] : "") ?>">
                <div class="item form-group">
                  <label class="col-md-2">Unit Kerja<span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <select class="form-control" name="unit" required="required">
                      <option>Pilih Unit Kerja</option>
                      <?php foreach (show_data("unit") as $un) {
                        echo "<option " . (isset($_GET['id']) && $job  && $un->id == $job->unit ? "selected" : "") . " value='" . $un->id . "'>" . $un->name . "</option>";
                      }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">Tanggal Masuk<span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" placeholder="Tanggal Masuk" required="required" class="form-control" value="<?= (isset($_GET['id'])  && $job ? $job->date : "") ?>" name="date" id="tgl_masuk" autocomplete="off">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2"></label>
                  <div class="col-md-10">
                    <button class="btn btn-primary">Selanjutnya</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- job -->
            <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 4 ? "show active" : "") ?>" id="rekening" role="tabpanel" aria-labelledby="rekening-tab">
              <?php if (isset($_GET['id'])) { ?>
                <?php
                $rek = $this->db->get_where("rekening_kar", ['karyawan' => $_GET['id']])->row();
                ?>
              <?php } ?>
              <form class="form-horizontal" method="post" action="<?= base_url('Users/karyawan/save_rekening') ?>">
                <input type="hidden" name="karyawan" value="<?= (isset($_GET['id']) ? $row->id : "") ?>">
                <div class="item form-group">
                  <label class="col-md-2">Nama Bank<span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" name="bank" value="<?= isset($rek) ? ($rek ? $rek->bank : "") : "" ?>" class="form-control" required autocomplete="off" placeholder="Nama Bank">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2">No. Rekening<span class="text-danger">*</span></label>
                  <div class="col-md-10">
                    <input type="text" name="no_rek" value="<?= isset($rek) ? ($rek ? $rek->no_rek : "") : "" ?>" class="form-control" required autocomplete="off" placeholder="Nomor Rekening">
                  </div>
                </div>
                <div class="item form-group">
                  <label class="col-md-2"></label>
                  <div class="col-md-10">
                    <button class="btn btn-primary">Simpan</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- Rek -->
          </div>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>