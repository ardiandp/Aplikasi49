<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>
    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-4">
      <div class="x_panel">
        <div class="x_title">
          <h2>Tambah Users</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <form data-parsley-validate method="post" action="<?= base_url('Users/pengguna/save_pengguna') ?>">
            <div class="form-group">
              <label for="first-name">Jabatan<span class="text-danger">*</span>
              </label>
              <select class="form-control" name="id_jabatan">
                <?php foreach ($dataJabatan as $key => $value) { ?>
                  <option value="<?= $value->id ?>"><?= $value->name ?></option>
                <?php } ?>
              </select>
            </div>
            <div class="form-group">
              <label for="first-name">Nama<span class="text-danger">*</span>
              </label>
              <input type="text" placeholder="Nama Lengkap" required="required" class="form-control" name="name" autocomplete="off">
            </div>
            <div class="form-group">
              <label for="first-name">Username<span class="text-danger">*</span>
              </label>
              <input type="text" placeholder="Username" required="required" class="form-control" name="username" autocomplete="off">
            </div>
            <div class="form-group">
              <label for="first-name">Password<span class="text-danger">*</span>
              </label>
              <input type="password" placeholder="Username" required="required" class="form-control" name="password" autocomplete="off">
            </div>
            <div class="form-group">
              <button class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
            </div>
          </form>
        </div>
      </div>
      <!-- content -->
    </div>
    <div class="col-md-8">
      <div class="x_panel">
        <div class="x_title">
          <h2><?= $title ?></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content table-responsive">
          <table id="datatable" class="table table-striped table-bordered" style="width:100%">
            <thead>
              <tr>
                <th>No</th>
                <th>Name</th>
                <th>Username</th>
                <th>Jabatan</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($data as $key => $value) { ?>
                <tr>
                  <td><?= $key + 1 ?></td>
                  <td><?= $value->name ?></td>
                  <td><?= $value->username ?></td>
                  <td><?= $value->jabatan ?></td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>