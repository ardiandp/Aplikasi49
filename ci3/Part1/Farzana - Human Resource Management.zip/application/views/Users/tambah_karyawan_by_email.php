<style>
    .principle-brand-btn {
        position: relative;
        height: 30px;
        background: #333;
        border-radius: 4px;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: 0.5s;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        text-decoration: none;
    }

    .principle-brand-btn.active {
        background: green;
    }

    .principle-brand-btn span {
        position: absolute;
        right: 20px;
        width: 15px;
        height: 15px;
        display: inline-block;
        background: #fff;
        border-bottom-left-radius: 3px;
        border-bottom-right-radius: 3px;
        transition: 0.5s;
    }

    .principle-brand-btn:hover span {
        transform: scale(1.5) rotate(-60deg) translateY(10px);
    }

    .principle-brand-btn.active span {
        left: 50%;
        transform: translateX(-50%) rotate(-45deg);
        border-radius: 0;
        width: 20px;
        height: 10px;
        background: transparent;
        border-left: 2px solid #fff;
        border-bottom: 2px solid #fff;
    }

    .principle-brand-btn span::before {
        content: '';
        position: absolute;
        top: -3px;
        right: 0;
        width: 100%;
        height: 2px;
        background: #fff;
        box-shadow: 12px -2px 0 #333, 12px -3px 0 #333, 15px -1px 0 #333, 3px -2px 0 #fff;
        transition: 0.5s
    }

    .principle-brand-btn.active:hover span::before,
    .principle-brand-btn.active span::before {
        transform: scale(0);
    }

    .principle-brand-btn:hover span::before {
        transform: rotate(90deg) translateX(-50%) translateY(-10px);
    }

    .principle-brand-btn text {
        position: absolute;
        left: 20px;
        color: #fff;
        font-size: 12px;
        transition: 0.5s;
    }

    .principle-brand-btn:hover text,
    .principle-brand-btn.active text {
        transform: translateX(120px) translateY(-5px) scale(0);
    }

    #listEmail {
        display: flex;
        flex-wrap: wrap;
        justify-content: start;
        margin-top: 20px;
    }
</style>

<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="x_panel">
            <div class="x_title">
                <h2><?= $title ?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="container">
                    <div class="row form-horizontal form-label-left">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="tambah_email">Email </label>
                                <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                    <input type="text" class="form-control" name="tambah_email" class="tambah_email" id="tambah_email" placeholder="enter email" />
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-primary" onclick="handlerAddEmail()"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <button type="button" class="btn btn-success" onclick="handlerSaveData()">Simpan</button>
                        </div>
                    </div>

                    <div id="listEmail"></div>

                    <div id="listEmailAvailable" class="row" style="margin-top: 20px;"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function handlerAddEmail() {

        let value = $('#tambah_email');

        if (value.val() == "") {
            alert('isi email terlebih dahulu');
            return false;
        }

        var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (!value.val().match(validRegex)) {
            alert('invalid email');
            return false;
        }

        $("#listEmail").append(`
            <div class="new-row">
                <button type="button" class="principle-brand-btn">
                    <span></span><text class="check-length">` + value.val() + `</text>
                </button><input type="hidden" name="data_principle_brand" class="form-control" value="` + value.val() + `" />
            </div>
        `);
        WidthDynamicAppend();

        // WidthDynamicAppend();
        value.val("");
        value.focus();
        value[0].scrollIntoView({
            behavior: "smooth",
        });
    }

    function WidthDynamicAppend() {
        let length_text_btn = $(".check-length");
        let arr = [];
        $(".new-row").each(function() {
            let currentRow = $(this);
            let element = currentRow.find(".principle-brand-btn");
            arr.push(element);
        });
        check_lenght_principle(arr);
    }

    function check_lenght_principle(length_text_btn) {
        let data = length_text_btn;
        $.each(data, function(i, v) {
            if (v.length >= 0) {
                let row = $(this).find(".check-length");
                let width = row.width() + 100;
                $(this).css("width", width + "px");
            }
        });
    }

    $("#listEmail").on("click", '.principle-brand-btn', function() {
        $(this).addClass("active");
        setTimeout(() => {
            $(this).removeClass("active");
            $(this).parents(".new-row").remove();
        }, 1000);
    });

    const handlerSaveData = () => {

        let emailData = [];

        $("input[name='data_principle_brand']").each(function(i, v) {
            emailData.push($(this).val());
        });

        if (emailData.length == 0) {
            alert('minimal 1 data email');
            return false;
        }

        $('#listEmailAvailable').empty();

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveKaryawanByEmail') ?>",
            dataType: "JSON",
            data: {
                emailData
            },
            beforeSend: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false
                });
            },
            success: function(response) {
                if (response.type == 200) {
                    new PNotify({
                        text: response.message,
                        type: 'success',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })

                    location.reload();
                }

                if (response.type == 203) {
                    new PNotify({
                        text: response.message,
                        type: 'error',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })
                }
            },
            error: function(xhr) { // if error occured
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
            complete: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
        });
    }
</script>