<?php

if (isset($_GET['mode'])) {
    $dataUsers = where_row("karyawan", ['id' => $_GET['id']]);
    $showTabPane = "d-block";
} else if (isset($_GET['id'])) {
    $dataUsers = where_row("karyawan", ['id' => $_GET['id']]);
    $showTabPane = "d-block";
} else {
    $showTabPane = "d-none";
}



?>

<style>
    .nav-pills .nav-link {
        background: transparent;
        border: 0px;
    }

    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        color: #007bff;
        background: transparent;
        border-bottom: 1px solid #007bff !important;
    }

    #personalData tr {
        line-height: 1.5em;
    }

    .modal-body {
        max-height: calc(100vh - 210px);
        overflow-x: auto;
        overflow-y: auto;
    }
</style>

<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= isset($_GET['mode']) ? 'View Data Karyawan' : (isset($_GET['id'])  ? 'Edit Data Karyawan' : 'Input Data Karyawan') ?></h3>
        </div>
        <div>
            <a href="<?= base_url('Users/Karyawan') ?>" class="btn btn-dark btn-sm pull-right"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-3">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Karyawan</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="list-group" id="list-tab" role="tablist">
                        <a class="list-group-item list-group-item-action active" id="list-data-umum-list" data-toggle="list" href="#list-data-umum" role="tab" aria-controls="dataUmum">Data Umum</a>
                        <a class="list-group-item list-group-item-action <?= $showTabPane ?>" id="list-time-management-list" data-toggle="list" href="#list-time-management" role="tab" aria-controls="timeManagement">Time Management</a>
                        <a class="list-group-item list-group-item-action <?= $showTabPane ?>" id="list-payroll-list" data-toggle="list" href="#list-payroll" role="tab" aria-controls="payroll">Payroll</a>
                        <a class="list-group-item list-group-item-action <?= $showTabPane ?>" id="list-keuangan-list" data-toggle="list" href="#list-keuangan" role="tab" aria-controls="keuangan">Keuangan</a>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
        <div class="col-md-9">
            <div class="x_panel">
                <div class="x_content">
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="list-data-umum" role="tabpanel" aria-labelledby="list-data-umum-list">
                            <?php $this->load->view('Users/DataKepegawaian/section/DataUmum/dataumum') ?>
                        </div>
                        <div class="tab-pane fade" id="list-time-management" role="tabpanel" aria-labelledby="list-time-management-list">
                            <?php $this->load->view('Users/DataKepegawaian/section/TimeManagement/index') ?>
                        </div>
                        <div class="tab-pane fade" id="list-payroll" role="tabpanel" aria-labelledby="list-payroll-list">
                            <?php $this->load->view('Users/DataKepegawaian/section/Payroll/index') ?>
                        </div>
                        <div class="tab-pane fade" id="list-keuangan" role="tabpanel" aria-labelledby="list-keuangan-list">
                            <?php $this->load->view('Users/DataKepegawaian/section/Keuangan/index') ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddWaktu" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Waktu undangan email</h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="form-group">
                        <label>Waktu Batas Edit Data</label> <small class="text-danger">Default 7 hari</small>
                        <input type="text" name="waktu" id="waktu" class="form-control numeric" placeholder="waktu batas edit data users / karyawan" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary sendEmail" type="button" onclick="sendEmailE(event)">Send Email</button>
                <button class="btn btn-dark" type="button" onclick="closeModal()">kembali</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalDeleteData" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <button class="btn btn-danger deleteData" type="button" onclick="handlerDeleteData(event)">Delete Data</button>
            </div>

        </div>
    </div>
</div>

<script>
    const urlString = window.location.href;
    const urlSearchParams = new URLSearchParams(window.location.search);
    const url = new URL(urlString);
    const idUrl = url.searchParams.get("id");
    const mode = Object.fromEntries(urlSearchParams.entries()).mode;


    const urlEditId = idUrl !== null ? 1 : 0;


    $(document).ready(function() {
        getDataKeluargaInti();
        getDataKeluargaAnda();
        getDataKeluargaEmergency();

        getDataPendidikanFormal();
        getDataPendidikanInformal();
        getDataPengalamanKerja();
        getDataSKPengangkatan();
        getDataPelatihan();
        getDataInfoTambahan();
        getDataTransaksiKeuangan();

        $(".select2").select2({
            width: "100%"
        });

        if (urlEditId == 1) {
            $('#provinsiKTP').val("<?= isset($dataUsers) ? $dataUsers->provinsi : '' ?>").trigger('change');
            $('#kotaKTP').val("<?= isset($dataUsers) ? $dataUsers->kota : '' ?>").trigger('change');
            $('#kecamatanKTP').val("<?= isset($dataUsers) ? $dataUsers->kecamatan : '' ?>").trigger('change');
            $('#desaKTP').val("<?= isset($dataUsers) ? $dataUsers->desa : '' ?>").trigger('change');

            $('#provinsiDomisili').val("<?= isset($dataUsers) ? $dataUsers->provinsi_domisili : '' ?>").trigger('change');
            $('#kotaDomisili').val("<?= isset($dataUsers) ? $dataUsers->kota_domisili : '' ?>").trigger('change');
            $('#kecamatanDomisili').val("<?= isset($dataUsers) ? $dataUsers->kecamatan_domisili : '' ?>").trigger('change');
            $('#desaDomisili').val("<?= isset($dataUsers) ? $dataUsers->desa_domisili : '' ?>").trigger('change');
        }

        // $("#tableemergency").DataTable()
    });

    const handlerProvinsiKTPChange = (idProvinsi) => {
        ajaxRequesProvinsiChange('ktp', idProvinsi);
    }

    const handlerKotaKTPChange = (idKota) => {
        ajaxRequesKotaChange('ktp', idKota)
    }

    const handlerKecamatanKTPChange = (idKecamatan) => {
        ajaxRequesKecamatanChange('ktp', idKecamatan)
    }

    const handlerProvinsiDomisiliChange = (idProvinsi) => {
        ajaxRequesProvinsiChange('domisili', idProvinsi);
    }

    const handlerKotaDomisiliChange = (idKota) => {
        ajaxRequesKotaChange('domisili', idKota)
    }

    const handlerKecamatanDomisiliChange = (idKecamatan) => {
        ajaxRequesKecamatanChange('domisili', idKecamatan)
    }

    const handlerProvinsiKeluargaAndaChange = (idProvinsi) => {
        ajaxRequesProvinsiChange('keluargaAnda', idProvinsi);
    }

    const handlerKotaKeluargaAndaChange = (idKota) => {
        ajaxRequesKotaChange('keluargaAnda', idKota)
    }

    const handlerKecamatanKeluargaAndaChange = (idKecamatan) => {
        ajaxRequesKecamatanChange('keluargaAnda', idKecamatan)
    }

    const ajaxRequesProvinsiChange = (type, idProvinsi) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKotaByProvinsiId') ?>",
            data: {
                idProvinsi
            },
            dataType: "JSON",
            async: false,
            success: function(response) {
                if (type === 'ktp') {
                    $("#kotaKTP").empty();
                }
                if (type === 'domisili') {
                    $("#kotaDomisili").empty();
                }
                if (type === 'keluargaAnda') {
                    $("#kotaKeluargaAnda").empty();
                }

                let html = "";
                html += `<option value="">--Pilih Kabupaten / Kota--</option>`
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        html += `<option value="${v.id}">${v.nama}</option>`
                    })
                }

                if (type === 'ktp') {
                    $("#kotaKTP").append(html);
                }
                if (type === 'domisili') {
                    $("#kotaDomisili").append(html);
                }

                if (type === 'keluargaAnda') {
                    $("#kotaKeluargaAnda").append(html);
                }
            }
        });
    }

    const ajaxRequesKotaChange = (type, idKota) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKecamatanByKotaId') ?>",
            data: {
                idKota
            },
            dataType: "JSON",
            async: false,
            success: function(response) {
                if (type === 'ktp') {
                    $('#kecamatanKTP').empty();
                }
                if (type === 'domisili') {
                    $("#kecamatanDomisili").empty();
                }

                if (type === 'keluargaAnda') {
                    $("#kecamatanKeluargaAnda").empty();
                }

                let html = "";
                html += `<option value="">--Pilih Kecamatan--</option>`
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        html += `<option value="${v.id}">${v.nama}</option>`
                    })
                }

                if (type == 'ktp') {
                    $("#kecamatanKTP").append(html);
                }
                if (type == 'domisili') {
                    $("#kecamatanDomisili").append(html);
                }
                if (type === 'keluargaAnda') {
                    $("#kecamatanKeluargaAnda").append(html);
                }
            }
        });
    }

    const ajaxRequesKecamatanChange = (type, idKecamatan) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataDesaByKecamatanId') ?>",
            data: {
                idKecamatan
            },
            dataType: "JSON",
            async: false,
            success: function(response) {
                if (type === 'ktp') {
                    $('#desaKTP').empty();
                }
                if (type === 'domisili') {
                    $("#desaDomisili").empty();
                }
                if (type === 'keluargaAnda') {
                    $("#desaKeluargaAnda").empty();
                }
                let html = "";
                html += `<option value="">--Pilih Desa--</option>`
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        html += `<option value="${v.id}">${v.nama}</option>`
                    })
                }

                if (type == 'ktp') {
                    $("#desaKTP").append(html);
                }
                if (type == 'domisili') {
                    $("#desaDomisili").append(html);
                }
                if (type === 'keluargaAnda') {
                    $("#desaKeluargaAnda").append(html);
                }
            }
        });
    }

    const handlerChkDomisili = (event) => {
        if (event.currentTarget.checked) {
            $("#valueChkDomisili").val(0);
            $("#showFieldDomisili").hide('slow');
            $("#provinsiDomisili").prop('required', false);
            $("#kotaDomisili").prop('required', false);
            $("#kecamatanDomisili").prop('required', false);
            $("#desaDomisili").prop('required', false);
            $("#alamatDomisili").prop('required', false);
        } else {
            $("#valueChkDomisili").val(1);
            $("#showFieldDomisili").show('slow');
            $("#provinsiDomisili").prop('required', true);
            $("#kotaDomisili").prop('required', true);
            $("#kecamatanDomisili").prop('required', true);
            $("#desaDomisili").prop('required', true);
            $("#alamatDomisili").prop('required', true);
        }
    }

    const getDataKeluargaInti = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaInti') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablekeluargainti > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {
                        let disChk = v.is_emergency_contact == 1 ? 'disabled checked' : '';

                        let chk = typeof mode !== 'undefined' ? `${i + 1}` : `<input type="checkbox" class="form-control check-item-keluargaInti" ${disChk} name="check-item-keluargaInti" style="transform: scale(1.2)" id="check-item-keluargaInti" value="${v.id}" />`;

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="btn btn-warning btn-sm" onclick="handlerEditDataKeluarga('1','${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm" onclick="handlerHapusDataKeluarga('1','${v.id}', '${v.nama}')"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </td>`
                        }

                        $('#tablekeluargainti > tbody').append(`
                            <tr>
                                <td>${chk}</td>
                                <td>${v.nik}</td>
                                <td>${v.nama}</td>
                                <td>${v.tempat_lahir}, ${formatTanggal(v.tanggal_lahir)}</td>
                                <td>${v.jenis_kelamin == 0 ? 'L' : 'P'}</td>
                                <td>${v.hubungan}</td>
                                <td>${v.status == 0 ? 'Menikah' :  v.status == 1 ? 'Belum Menikah' : v.status == 2 ? 'Cerai' : 'Cerai Mati'}</td>
                                <td>${v.pekerjaan}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablekeluargainti > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '8' : '9'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const getDataKeluargaAnda = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaAnda') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablekeluargaanda > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {
                        let disChk = v.is_emergency_contact == 1 ? 'disabled checked' : '';

                        let chk = typeof mode != 'undefined' ? `${i + 1}` : `<input type="checkbox" class="form-control check-item-keluargaAnda" ${disChk} name="check-item-keluargaAnda" style="transform: scale(1.2)" id="check-item-keluargaAnda" value="${v.id}" />`;

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="btn btn-warning btn-sm" onclick="handlerEditDataKeluarga('2','${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm" onclick="handlerHapusDataKeluarga('2','${v.id}', '${v.nama}')"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </td>`
                        }

                        $('#tablekeluargaanda > tbody').append(`
                            <tr>
                                <td>${chk}</td>
                                <td>${v.nik}</td>
                                <td>${v.nama}</td>
                                <td>${v.tempat_lahir}, ${formatTanggal(v.tanggal_lahir)}</td>
                                <td>${v.jenis_kelamin == 0 ? 'L' : 'P'}</td>
                                <td>${v.hubungan}</td>
                                <td>${v.status == 0 ? 'Menikah' :  v.status == 1 ? 'Belum Menikah' : v.status == 2 ? 'Cerai' : 'Cerai Mati'}</td>
                                <td>${v.pekerjaan}</td>
                                <td>${v.phone == null ? '-' : v.phone}</td>
                                <td>${v.provinsiNama == null ? '-' : v.provinsiNama}</td>
                                <td>${v.kotaNama == null ? '-' : v.kotaNama}</td>
                                <td>${v.kecamatanNama == null ? '-' : v.kecamatanNama}</td>
                                <td>${v.desaNama == null ? '-' : v.desaNama}</td>
                                <td>${v.alamat == null ? '-' : v.alamat}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablekeluargaanda > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode != 'undefined' ? '14' : '15'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const getDataKeluargaEmergency = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaEmergency') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tableemergency > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {
                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                        <button class="btn btn-danger btn-sm" onclick="handlerHapusDataKeluarga('3','${v.id}', '${v.nama}')"><i class="fa fa-trash"></i></button>
                                  </td>`
                        }
                        $('#tableemergency > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.nik}</td>
                                <td>${v.nama}</td>
                                <td>${v.tempat_lahir}, ${formatTanggal(v.tanggal_lahir)}</td>
                                <td>${v.jenis_kelamin == 0 ? 'L' : 'P'}</td>
                                <td>${v.hubungan}</td>
                                <td>${v.status == 0 ? 'Menikah' :  v.status == 1 ? 'Belum Menikah' : v.status == 2 ? 'Cerai' : 'Cerai Mati'}</td>
                                <td>${v.pekerjaan}</td>
                                <td>${v.phone == null ? '-' : v.phone}</td>
                                <td>${v.provinsiNama == null ? '-' : v.provinsiNama}</td>
                                <td>${v.kotaNama == null ? '-' : v.kotaNama}</td>
                                <td>${v.kecamatanNama == null ? '-' : v.kecamatanNama}</td>
                                <td>${v.desaNama == null ? '-' : v.desaNama}</td>
                                <td>${v.alamat == null ? '-' : v.alamat}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tableemergency > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode != 'undefined' ? '14' : '15'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const handlerSendEmailByUser = () => {
        if ($('#idUsers').val() == '') {
            new PNotify({
                text: 'Data karyawan belum disimpan, silahkan simpan terlebih dahulu',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
            })
            return false;
        }

        $('#modalAddWaktu').modal('show');
    }

    const closeModal = () => {
        $('#modalAddWaktu').modal('hide');
        $('#type').val('');
    }

    const sendEmailE = (event) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveKaryawanByEmail') ?>",
            dataType: "JSON",
            data: {
                dataChecked: $('#idUsers').val(),
                type: 'invited',
                waktu: null
            },
            beforeSend: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false
                });
            },
            success: function(response) {
                if (response.type == 200) {
                    new PNotify({
                        text: response.message,
                        type: 'success',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })

                    location.reload();
                }

                if (response.type == 202) {

                    $.each(response.data, function(i, v) {
                        new PNotify({
                            text: `Email dari username <strong>${v}</strong> kosong, silahkan update data karyawan terlebih dahulu`,
                            type: 'error',
                            styling: 'bootstrap3',
                            delay: 2000,
                            history: false
                        });
                    })
                }

                if (response.type == 203) {
                    new PNotify({
                        text: response.message,
                        type: 'error',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })
                }
            },
            error: function(xhr) { // if error occured
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
            complete: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
        });
    }

    const handlerBtnAddKeluargaInti = (type, mode) => {
        resetFormKeluarga();
        $('#modalAddKeluarga').modal('show');
        $('#modalAddKeluarga .modal-title').html('Tambah Data Keluarga Inti');
        $('.addKeluarga').attr('data-type', type)
        $('.addKeluarga').attr('data-mode', mode)
        $('#showAlamatKeluargaAnda').hide('slow');
    }

    const handlerBtnAddKeluargaAnda = (type, mode) => {
        resetFormKeluarga();
        $('#modalAddKeluarga').modal('show');
        $('#modalAddKeluarga .modal-title').html('Tambah Data Keluarga Anda');
        $('.addKeluarga').attr('data-type', type)
        $('.addKeluarga').attr('data-mode', mode)
        $('#showAlamatKeluargaAnda').show('slow');
    }

    const handlerEditDataKeluarga = (type, idKeluarga, mode) => {
        resetFormKeluarga();
        $('#modalAddKeluarga').modal('show');
        if (type == '1') {
            $('#modalAddKeluarga .modal-title').html('Edit Data Keluarga Inti');
            $('#showAlamatKeluargaAnda').hide('slow');
        } else {
            $('#modalAddKeluarga .modal-title').html('Edit Data Keluarga Anda');
            $('#showAlamatKeluargaAnda').show('slow');
        }
        $('.addKeluarga').attr('data-id', idKeluarga)
        $('.addKeluarga').attr('data-type', type)
        $('.addKeluarga').attr('data-mode', mode)

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaById') ?>",
            data: {
                idKeluarga
            },
            dataType: "JSON",
            success: function(response) {
                $('#nik').val(response.nik)
                $('#nama').val(response.nama)
                $('#tempat_lahir').val(response.tempat_lahir)
                $('#tanggal_lahir').val(response.tanggal_lahir)
                $('#jenis_kelamin').val(response.jenis_kelamin).trigger('change')
                $('#hubungan').val(response.hubungan).trigger('change')
                $('#status').val(response.status).trigger('change')
                $('#pekerjaan').val(response.pekerjaan)

                if (type == '2') {
                    $('#phoneKeluargaAnda').val(response.phone);
                    $('#provinsiKeluargaAnda').val(response.provinsi).trigger('change');
                    $('#kotaKeluargaAnda').val(response.kota).trigger('change');
                    $('#kecamatanKeluargaAnda').val(response.kecamatan).trigger('change');
                    $('#desaKeluargaAnda').val(response.desa).trigger('change');
                    $('#alamatKeluargaAnda').val(response.alamat);
                    response.is_emergency_contact == 1 ? $('#chkEmergency').prop('checked', true) : $('#chkEmergency').prop('checked', false);
                }
            }
        });
    }

    const handlerHapusDataKeluarga = (type, idKeluarga, nama) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idKeluarga)
        $('.deleteData').attr('data-type', type)
        $('.deleteData').attr('data-modul', 'keluarga')
        if (type == '3') {
            $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data emergency contact <strong>${nama}</strong></h6>`);
        } else {
            $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data karyawan <strong>${nama}</strong></h6>`);
        }
    }

    const handlerAddKeluarga = (event) => {
        let idKeluarga = event.currentTarget.getAttribute('data-id');
        let type = event.currentTarget.getAttribute('data-type');
        let mode = event.currentTarget.getAttribute('data-mode');
        let nik = $('#nik').val();
        let nama = $('#nama').val();
        let tempat_lahir = $('#tempat_lahir').val();
        let tanggal_lahir = $('#tanggal_lahir').val();
        let jenis_kelamin = $('#jenis_kelamin').val();
        let hubungan = $('#hubungan').val();
        let status = $('#status').val();
        let pekerjaan = $('#pekerjaan').val();

        let noPhone = $('#phoneKeluargaAnda').val();
        let provinsi = $('#provinsiKeluargaAnda').val();
        let kota = $('#kotaKeluargaAnda').val();
        let kecamatan = $('#kecamatanKeluargaAnda').val();
        let desa = $('#desaKeluargaAnda').val();
        let alamat = $('#alamatKeluargaAnda').val();

        if (nik == "") {
            showMessage('error', 'NIK harus terisi')
            return false;
        }

        if (nama == "") {
            showMessage('error', 'Nama harus terisi')
            return false;
        }

        if (tempat_lahir == "") {
            showMessage('error', 'Tempat lahir harus terisi')
            return false;
        }

        if (tanggal_lahir == "") {
            showMessage('error', 'Tanggal lahir harus terisi')
            return false;
        }

        if (jenis_kelamin == "") {
            showMessage('error', 'Jenis kelamin harus terisi')
            return false;
        }

        if (hubungan == "") {
            showMessage('error', 'Hubungan harus terisi')
            return false;
        }

        if (status == "") {
            showMessage('error', 'Status harus terisi')
            return false;
        }

        if (pekerjaan == "") {
            showMessage('error', 'Pekerjaan harus terisi')
            return false;
        }

        if (type == '2') {
            if (noPhone == "") {
                showMessage('error', 'No. Handphone harus terisi')
                return false;
            }

            if (provinsi == "") {
                showMessage('error', 'Provinsi harus terisi')
                return false;
            }

            if (kota == "") {
                showMessage('error', 'Kota harus terisi')
                return false;
            }

            if (kecamatan == "") {
                showMessage('error', 'Kecamatan harus terisi')
                return false;
            }

            if (desa == "") {
                showMessage('error', 'Desa harus terisi')
                return false;
            }

            if (alamat == "") {
                showMessage('error', 'Alamat harus terisi')
                return false;
            }
        }


        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveKeluargaKaryawan') ?>",
            dataType: "JSON",
            data: {
                idKeluarga: mode == 'update' ? idKeluarga : null,
                idUsers: $('#idUsers').val(),
                type,
                mode,
                nik,
                nama,
                tempat_lahir,
                tanggal_lahir,
                jenis_kelamin,
                hubungan,
                status,
                pekerjaan,
                noPhone,
                provinsi,
                kota,
                kecamatan,
                desa,
                alamat,
                isEmegercy: $('#chkEmergency').prop('checked') == true ? 1 : 0
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    // location.reload();
                    if (response.type == '1') {
                        getDataKeluargaInti();
                    }

                    if (response.type == '2') {
                        getDataKeluargaAnda();
                        getDataKeluargaEmergency();
                    }
                    resetFormKeluarga();
                    $('#modalAddKeluarga').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const resetFormKeluarga = () => {
        $('#modalAddKeluarga .modal-title').html();
        $('#nik').val('')
        $('#nama').val('')
        $('#tempat_lahir').val('')
        $('#tanggal_lahir').val('')
        $('#jenis_kelamin').val('')
        $('#hubungan').val('')
        $('#status').val('')
        $('#pekerjaan').val('')

        $('#phoneKeluargaAnda').val('');
        $('#provinsiKeluargaAnda').val('');
        $('#kotaKeluargaAnda').val('');
        $('#kecamatanKeluargaAnda').val('');
        $('#desaKeluargaAnda').val('');
        $('#alamatKeluargaAnda').val('');
        $('#chkEmergency').prop('checked', false);
    }

    const closeModalKeluarga = () => {
        $('#modalAddKeluarga').modal('hide');
        resetFormKeluarga();
    }

    function checkAll(e, type) {
        var checkboxes = $(`input[name='check-item-${type}']`);
        if (e.checked) {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox' && !(checkboxes[i].disabled)) {
                    checkboxes[i].checked = true;
                }
            }
        } else {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox' && !(checkboxes[i].disabled)) {
                    checkboxes[i].checked = false;
                }
            }
        }
    }

    const handlerBtnAddEmergency = (type) => {
        let dataIdKeluarga = [];

        if (type == '1') {
            dataIdKeluarga = $(".check-item-keluargaInti").map(function() {
                if (this.checked == true && !(this.disabled)) {
                    return this.value;
                }
            }).get();
        }

        if (type == '2') {
            dataIdKeluarga = $(".check-item-keluargaAnda").map(function() {
                if (this.checked == true && !(this.disabled)) {
                    return this.value;
                }
            }).get();
        }

        if (dataIdKeluarga.length == 0) {
            showMessage('error', 'pilih data yang akan disimpan ke emergency contact minimal 1');
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/updateDataKeluargaToEmergemcy') ?>",
            dataType: "JSON",
            data: {
                dataIdKeluarga,
                type,
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    // location.reload();
                    if (response.type == '1') {
                        getDataKeluargaInti();
                    }

                    if (response.type == '2') {
                        getDataKeluargaAnda();
                    }

                    getDataKeluargaEmergency()

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });

    }


    /************************************************ Form Pekerjaan ******************************************************/

    const getDataPendidikanFormal = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataPendidikanFormal') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablePendidikanFormal > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="btn btn-warning btn-sm" onclick="handlerEditDataPendidikan('1','${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm" onclick="handlerHapusDataPendidikan('1','${v.id}')"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </td>`
                        }

                        $('#tablePendidikanFormal > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.jenjang}</td>
                                <td>${v.nama_sekolah}</td>
                                <td>${v.jurusan == null ? '-' : v.jurusan}</td>
                                <td>${v.tahun_masuk} - ${v.tahun_keluar}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablePendidikanFormal > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '6' : '7'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const getDataPendidikanInformal = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataPendidikanInformal') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablePendidikanInformal > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="btn btn-warning btn-sm" onclick="handlerEditDataPendidikan('2','${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm" onclick="handlerHapusDataPendidikan('2','${v.id}')"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </td>`
                        }

                        $('#tablePendidikanInformal > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.penyelenggara}</td>
                                <td>${v.nama_kursus}</td>
                                <td>${v.tempat}</td>
                                <td>${v.tahun}</td>
                                <td>${v.keterangan == null ? '-' : v.keterangan}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablePendidikanInformal > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '7' : '8'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const handlerGetLokasiUnit = (value) => {
        $('#lokasiKantor').hide('slow')
        if (value == "") {
            showMessage('error', 'Cabang / Unit tidak oleh kosong');
            return false
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getLokasiUnitById') ?>",
            dataType: "JSON",
            data: {
                value
            },
            success: function(response) {
                $('#lokasiKantor').show('slow')
                $('#alamatKantor').val(response.alamat)
                $('#longitudeKantor').val(response.longitude)
                $('#latitudeKantor').val(response.latitude)

            }
        });
    }

    const handlerAddPendidkan = (type, mode) => {
        resetFormPendidikan();
        $('#modalAddPekerjaan').modal('show');

        if (type == "1") {
            $('#modalAddPekerjaan .modal-title').html('Tambah Data Pekerjaan Formal');
            $('#formPendidikanFormal').show('slow');
            $('#formPendidikanInformal').hide('slow');
        }

        if (type == "2") {
            $('#modalAddPekerjaan .modal-title').html('Tambah Data Pekerjaan Informal');
            $('#formPendidikanFormal').hide('slow');
            $('#formPendidikanInformal').show('slow');

        }

        $('.addPendidikan').attr('data-type', type)
        $('.addPendidikan').attr('data-mode', mode)
    }

    const resetFormPendidikan = () => {
        $('#modalAddPekerjaan .modal-title').html();
        $('#jenjangFormal').val('')
        $('#namaSekolahFormal').val('')
        $('#jurusanFormal').val('')
        $('#tahunMasukFormal').val('')
        $('#tahunKeluarFormal').val('')

        $('#penyelenggaraInformal').val('')
        $('#namaKursusInformal').val('')
        $('#tempatInformal').val('')
        $('#tahunInformal').val('')
        $('#keteranganInformal').val('');
    }

    const closeModalPendidikan = () => {
        $('#modalAddPekerjaan').modal('hide');
        resetFormPendidikan();
    }

    const handlerAddPendidikan = (event) => {
        let idSekolah = event.currentTarget.getAttribute('data-id');
        let type = event.currentTarget.getAttribute('data-type');
        let mode = event.currentTarget.getAttribute('data-mode');
        let jenjangFormal = $('#jenjangFormal').val()
        let namaSekolahFormal = $('#namaSekolahFormal').val()
        let jurusanFormal = $('#jurusanFormal').val()
        let tahunMasukFormal = $('#tahunMasukFormal').val()
        let tahunKeluarFormal = $('#tahunKeluarFormal').val()

        let penyelenggaraInformal = $('#penyelenggaraInformal').val()
        let namaKursusInformal = $('#namaKursusInformal').val()
        let tempatInformal = $('#tempatInformal').val()
        let tahunInformal = $('#tahunInformal').val()
        let keteranganInformal = $('#keteranganInformal').val();

        if (type == '1') {
            if (jenjangFormal == "") {
                showMessage('error', 'Jenjang harus terisi')
                return false;
            }

            if (namaSekolahFormal == "") {
                showMessage('error', 'Nama Sekolah harus terisi')
                return false;
            }

            if (tahunMasukFormal == "") {
                showMessage('error', 'Tahun Masuk harus terisi')
                return false;
            }

            if (tahunKeluarFormal == "") {
                showMessage('error', 'Tahun Keluar harus terisi')
                return false;
            }
        }

        if (type == '2') {
            if (penyelenggaraInformal == "") {
                showMessage('error', 'Penyelenggara harus terisi')
                return false;
            }

            if (namaKursusInformal == "") {
                showMessage('error', 'Nama Kursus harus terisi')
                return false;
            }

            if (tempatInformal == "") {
                showMessage('error', 'Tempat harus terisi')
                return false;
            }

            if (tahunInformal == "") {
                showMessage('error', 'Tahun harus terisi')
                return false;
            }
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveSekolahKaryawan') ?>",
            dataType: "JSON",
            data: {
                idSekolah: mode == 'update' ? idSekolah : null,
                idUsers: $('#idUsers').val(),
                type,
                mode,
                jenjangFormal,
                namaSekolahFormal,
                jurusanFormal,
                tahunMasukFormal,
                tahunKeluarFormal,
                penyelenggaraInformal,
                namaKursusInformal,
                tempatInformal,
                tahunInformal,
                keteranganInformal
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    // location.reload();
                    if (response.type == '1') {
                        getDataPendidikanFormal();
                    }

                    if (response.type == '2') {
                        getDataPendidikanInformal();
                    }
                    resetFormPendidikan();
                    $('#modalAddPekerjaan').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const handlerEditDataPendidikan = (type, idSekolah, mode) => {
        $('#modalAddPekerjaan').modal('show');

        if (type == "1") {
            $('#modalAddPekerjaan .modal-title').html('Edit Data Pekerjaan Formal');
            $('#formPendidikanFormal').show('slow');
            $('#formPendidikanInformal').hide('slow');
        }

        if (type == "2") {
            $('#modalAddPekerjaan .modal-title').html('Edit Data Pekerjaan Informal');
            $('#formPendidikanFormal').hide('slow');
            $('#formPendidikanInformal').show('slow');
        }

        $('.addPendidikan').attr('data-id', idSekolah)
        $('.addPendidikan').attr('data-type', type)
        $('.addPendidikan').attr('data-mode', mode)

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataPendidikanById') ?>",
            data: {
                idSekolah
            },
            dataType: "JSON",
            success: function(response) {
                if (type == '1') {
                    $('#jenjangFormal').val(response.id_pendidikan).trigger('change')
                    $('#namaSekolahFormal').val(response.nama_sekolah)
                    $('#jurusanFormal').val(response.jurusan)
                    $('#tahunMasukFormal').val(response.tahun_masuk).trigger('change')
                    $('#tahunKeluarFormal').val(response.tahun_keluar).trigger('change')
                }

                if (type == '2') {
                    $('#penyelenggaraInformal').val(response.penyelenggara)
                    $('#namaKursusInformal').val(response.nama_kursus)
                    $('#tempatInformal').val(response.tempat)
                    $('#tahunInformal').val(response.tahun).trigger('change')
                    $('#keteranganInformal').val(response.keterangan);
                }
            }
        });
    }

    const handlerHapusDataPendidikan = (type, idSekolah) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idSekolah)
        $('.deleteData').attr('data-type', type)
        $('.deleteData').attr('data-modul', 'pendidikan')
        $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data pendidikan</h6>`);
    }


    /************************************************ Form Pekerjaan ******************************************************/

    /************************************************ Form Pengalaman Kerja ***********************************************/

    const getDataPengalamanKerja = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataPengalamanKerja') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablePengalamanKerja > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="btn btn-warning btn-sm" onclick="handlerAddPengalamanKerja('${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm" onclick="handlerHapusDataPengalamanKerja('${v.id}')"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </td>`
                        }

                        $('#tablePengalamanKerja > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.nama_pekerjaan}</td>
                                <td>${v.jabatan}</td>
                                <td>${v.tahun_masuk} - ${v.is_now_work == 1 ? 'Sekarang' : v.tahun_keluar}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablePengalamanKerja > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '5' : '6'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const handlerAddPengalamanKerja = (idPengalamanKerja, mode) => {
        $('#modalAddPengalamanKerja').modal('show');
        if (mode == 'insert') {
            $('#modalAddPengalamanKerja .modal-title').html('Tambah Data Pengalaman Kerja');
        } else {
            $('#modalAddPengalamanKerja .modal-title').html('Edit Data Pengalaman Kerja');
            $.ajax({
                type: 'POST',
                url: "<?= base_url('Users/Karyawan/getDataPengalamanKerjaById') ?>",
                data: {
                    idPengalamanKerja
                },
                dataType: "JSON",
                success: function(response) {

                    $('#namaPekerjaanPengalamanKerja').val(response.nama_pekerjaan)
                    $('#jabatanPengalamanKerja').val(response.jabatan)
                    $('#tahunMasukPengalamanKerja').val(response.tahun_masuk).trigger('change')
                    if (response.tahun_keluar != null) {
                        $('#tahunKeluarPengalamanKerja').val(response.tahun_keluar).trigger('change')
                    }
                    if (response.is_now_work != null) {
                        $('#thnPngalamanNow').prop('checked', true);
                        $('.tahunKeluarPengalamanKerja').hide();
                    } else {
                        $('.tahunKeluarPengalamanKerja').show();
                    }
                }
            });
            $('.addPengalamanKerja').attr('data-id', idPengalamanKerja)
        }

        $('.addPengalamanKerja').attr('data-mode', mode)
    }

    const handlerTahunKluarPengalamanKerja = (event) => {
        // console.log($(this).prop('checked'));
        if (event.currentTarget.checked) {
            $('.tahunKeluarPengalamanKerja').hide();
            $('#tahunKeluarPengalamanKerja').val('');
        } else {
            $('.tahunKeluarPengalamanKerja').show();
            $('#tahunKeluarPengalamanKerja').val('');
        }
    }

    const closeModalPengalamanKerja = () => {
        $('#modalAddPengalamanKerja').modal('hide');
        resetFormPengalamanKerja();
    }

    const resetFormPengalamanKerja = () => {
        $('#modalAddPengalamanKerja .modal-title').html();
        $('#namaPekerjaanPengalamanKerja').val('')
        $('#jabatanPengalamanKerja').val('')
        $('#tahunMasukPengalamanKerja').val('')
        $('#tahunKeluarPengalamanKerja').val('')
        $('#thnPngalamanNow').prop('checked', false)
    }

    const handlerSavePengalamanKerja = (event) => {
        let idPengalamanKerja = event.currentTarget.getAttribute('data-id');
        let mode = event.currentTarget.getAttribute('data-mode');
        let namaPekerjaanPengalamanKerja = $('#namaPekerjaanPengalamanKerja').val()
        let jabatanPengalamanKerja = $('#jabatanPengalamanKerja').val()
        let tahunMasukPengalamanKerja = $('#tahunMasukPengalamanKerja').val()
        let tahunKeluarPengalamanKerja = $('#tahunKeluarPengalamanKerja').val()
        let thnPngalamanNow = $('#thnPngalamanNow')

        if (namaPekerjaanPengalamanKerja == "") {
            showMessage('error', 'Nama Pekerjaan harus terisi')
            return false;
        }

        if (jabatanPengalamanKerja == "") {
            showMessage('error', 'Jabatan harus terisi')
            return false;
        }

        if (tahunMasukPengalamanKerja == "") {
            showMessage('error', 'Tahun Masuk harus terisi')
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/savePengalamanKerjaKaryawan') ?>",
            dataType: "JSON",
            data: {
                idPengalamanKerja: mode == 'update' ? idPengalamanKerja : null,
                idUsers: $('#idUsers').val(),
                mode,
                namaPekerjaanPengalamanKerja,
                jabatanPengalamanKerja,
                tahunMasukPengalamanKerja,
                tahunKeluarPengalamanKerja,
                thnPngalamanNow: thnPngalamanNow.prop('checked') == true ? true : false
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    getDataPengalamanKerja();
                    resetFormPengalamanKerja();
                    $('#modalAddPengalamanKerja').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const handlerHapusDataPengalamanKerja = (idPengalamanKerja) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idPengalamanKerja)
        $('.deleteData').attr('data-modul', 'pengalamanKerja')
        $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data Pengalaman Kerja</h6>`);
    }

    /************************************************ Form Pengalaman Kerja ***********************************************/

    /************************************************ Form SK Pengangkatan ***********************************************/

    function formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [day, month, year].join('-');
    }

    const getLastNomorSK = () => {
        $.ajax({
            type: 'GET',
            url: "<?= base_url('Users/Karyawan/getLastNomorSK') ?>",
            dataType: "JSON",
            success: function(response) {
                $('#nomorSKPengangkatan').val(response)
            }
        });
    }

    const getDataSKPengangkatan = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataSKPengangkatan') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tableSKPengangkatan > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                        <div class="d-flex align-items-center justify-content-center">
                                            <button class="btn btn-warning btn-sm" onclick="handlerAddSKPengangkatan('${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm" onclick="handlerHapusDataSKPengangkatan('${v.id}')"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </td>`
                        }

                        $('#tableSKPengangkatan > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${formatDate(v.tanggal_sk)}</td>
                                <td>${v.nomor_sk}</td>
                                <td>${v.keterangan}</td>
                                <td>${v.is_aktif == null ? '-' : v.is_aktif}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tableSKPengangkatan > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '6' : '7'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const handlerAddSKPengangkatan = (idSKPengangkatan, mode) => {
        $('#modalAddSKPengangkatan').modal('show');
        if (mode == 'insert') {
            $('#modalAddSKPengangkatan .modal-title').html('Tambah Data SK Pengangkatan');
            getLastNomorSK();
        } else {
            $('#modalAddSKPengangkatan .modal-title').html('Edit Data SK Pengangkatan');
            $.ajax({
                type: 'POST',
                url: "<?= base_url('Users/Karyawan/getDataSKPengangkatanById') ?>",
                data: {
                    idSKPengangkatan
                },
                dataType: "JSON",
                success: function(response) {

                    $('#tanggalSKPengangkatan').val(response.tanggal_sk)
                    $('#nomorSKPengangkatan').val(response.nomor_sk)
                    $('#keteranganSKPengangkatan').val(response.keterangan)
                    if (response.is_aktif == 'Active') {
                        $('#chkSKaktif').prop('checked', true);
                    }
                }
            });
            $('.addSKPengangkatan').attr('data-id', idSKPengangkatan)
        }

        $('.addSKPengangkatan').attr('data-mode', mode)
    }

    const closeModalSKPengangkatan = () => {
        $('#modalAddSKPengangkatan').modal('hide');
        resetFormSKPengangkatan();
    }

    const resetFormSKPengangkatan = () => {
        $('#modalAddSKPengangkatan .modal-title').html();
        $('#tanggalSKPengangkatan').val('')
        $('#nomorSKPengangkatan').val('')
        $('#keteranganSKPengangkatan').val('')
    }

    const handlerSaveSKPengangkatan = (event) => {
        let idSKPengangkatan = event.currentTarget.getAttribute('data-id');
        let mode = event.currentTarget.getAttribute('data-mode');
        let tanggalSKPengangkatan = $('#tanggalSKPengangkatan').val()
        let nomorSKPengangkatan = $('#nomorSKPengangkatan').val()
        let keteranganSKPengangkatan = $('#keteranganSKPengangkatan').val()

        if (tanggalSKPengangkatan == "") {
            showMessage('error', 'Tanggal harus terisi')
            return false;
        }

        if (keteranganSKPengangkatan == "") {
            showMessage('error', 'Keterangan harus terisi')
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveSKPengangkatanKaryawan') ?>",
            dataType: "JSON",
            data: {
                idSKPengangkatan: mode == 'update' ? idSKPengangkatan : null,
                idUsers: $('#idUsers').val(),
                mode,
                tanggalSKPengangkatan,
                nomorSKPengangkatan,
                keteranganSKPengangkatan,
                isActive: $('#chkSKaktif').prop('checked') == true ? 1 : 2
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    getDataSKPengangkatan();
                    resetFormSKPengangkatan();
                    $('#modalAddSKPengangkatan').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const handlerHapusDataSKPengangkatan = (idSKPengangkatan) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idSKPengangkatan)
        $('.deleteData').attr('data-modul', 'SKPengangkatan')
        $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data SK Pengangkatan</h6>`);
    }

    /************************************************ Form SK Pengangkatan ***********************************************/

    /************************************************ Form Pelatihan ***********************************************/

    const getDataPelatihan = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataPelatihan') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablePelatihan > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                        <div class="d-flex align-items-center justify-content-center">
                                            <button class="btn btn-warning btn-sm" onclick="handlerAddPelatihan('${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm" onclick="handlerHapusDataPelatihan('${v.id}')"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </td>`
                        }

                        $('#tablePelatihan > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.nama_pelatihan}</td>
                                <td>${v.status}</td>
                                <td>${v.tahun}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablePelatihan > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '5' : '6'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const handlerAddPelatihan = (idPelatihan, mode) => {
        $('#modalAddPelatihan').modal('show');
        if (mode == 'insert') {
            $('#modalAddPelatihan .modal-title').html('Tambah Data Pelatihan');
        } else {
            $('#modalAddPelatihan .modal-title').html('Edit Data Pelatihan');
            $.ajax({
                type: 'POST',
                url: "<?= base_url('Users/Karyawan/getDataPelatihanById') ?>",
                data: {
                    idPelatihan
                },
                dataType: "JSON",
                success: function(response) {

                    $('#namaPelatihanPelatihan').val(response.nama_pelatihan)
                    $('#statusPelatihan').val(response.status)
                    $('#tahunPelatihan').val(response.tahun).trigger('change')
                }
            });
            $('.addPelatihan').attr('data-id', idPelatihan)
        }

        $('.addPelatihan').attr('data-mode', mode)
    }

    const closeModalPelatihan = () => {
        $('#modalAddPelatihan').modal('hide');
        resetFormPelatihan();
    }

    const resetFormPelatihan = () => {
        $('#modalAddPelatihan .modal-title').html();
        $('#namaPelatihanPelatihan').val('')
        $('#statusPelatihan').val('')
        $('#tahunPelatihan').val('')
    }

    const handlerSavePelatihan = (event) => {
        let idPelatihan = event.currentTarget.getAttribute('data-id');
        let mode = event.currentTarget.getAttribute('data-mode');
        let namaPelatihanPelatihan = $('#namaPelatihanPelatihan').val()
        let statusPelatihan = $('#statusPelatihan').val()
        let tahunPelatihan = $('#tahunPelatihan').val()

        if (namaPelatihanPelatihan == "") {
            showMessage('error', 'Nama Pelatihan harus terisi')
            return false;
        }

        if (statusPelatihan == "") {
            showMessage('error', 'Status harus terisi')
            return false;
        }

        if (tahunPelatihan == "") {
            showMessage('error', 'Tahun harus terisi')
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/savePelatihanKaryawan') ?>",
            dataType: "JSON",
            data: {
                idPelatihan: mode == 'update' ? idPelatihan : null,
                idUsers: $('#idUsers').val(),
                mode,
                namaPelatihanPelatihan,
                statusPelatihan,
                tahunPelatihan,
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    getDataPelatihan();
                    resetFormPelatihan();
                    $('#modalAddPelatihan').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const handlerHapusDataPelatihan = (idPelatihan) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idPelatihan)
        $('.deleteData').attr('data-modul', 'Pelatihan')
        $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data Pelatihan</h6>`);
    }

    /************************************************ Form Pelatihan ***********************************************/

    /************************************************ Form Info Tambahan ***********************************************/

    const getDataInfoTambahan = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataInfoTambahan') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tableInfoTambahan > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                        <div class="d-flex align-items-center justify-content-center">
                                            <button class="btn btn-warning btn-sm" onclick="handlerAddInfoTambahan('${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm" onclick="handlerHapusDataInfoTambahan('${v.id}')"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </td>`
                        }

                        $('#tableInfoTambahan > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.deskripsi}</td>
                                <td>${v.value}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tableInfoTambahan > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '5' : '6'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const handlerAddInfoTambahan = (idInfoTambahan, mode) => {
        $('#modalAddInfoTambahan').modal('show');
        if (mode == 'insert') {
            $('#modalAddInfoTambahan .modal-title').html('Tambah Data Info Tambahan');
        } else {
            $('#modalAddInfoTambahan .modal-title').html('Edit Data Info Tambahan');
            $.ajax({
                type: 'POST',
                url: "<?= base_url('Users/Karyawan/getDataInfoTambahanById') ?>",
                data: {
                    idInfoTambahan
                },
                dataType: "JSON",
                success: function(response) {

                    $('#deskripsiInfoTambahan').val(response.deskripsi)
                    $('#valueInfoTambahan').val(response.value)
                }
            });
            $('.addInfoTambahan').attr('data-id', idInfoTambahan)
        }

        $('.addInfoTambahan').attr('data-mode', mode)
    }

    const closeModalInfoTambahan = () => {
        $('#modalAddInfoTambahan').modal('hide');
        resetFormInfoTambahan();
    }

    const resetFormInfoTambahan = () => {
        $('#modalAddInfoTambahan .modal-title').html();
        $('#deskripsiInfoTambahan').val('')
        $('#valueInfoTambahan').val('')
    }

    const handlerSaveInfoTambahan = (event) => {
        let idInfoTambahan = event.currentTarget.getAttribute('data-id');
        let mode = event.currentTarget.getAttribute('data-mode');
        let deskripsiInfoTambahan = $('#deskripsiInfoTambahan').val()
        let valueInfoTambahan = $('#valueInfoTambahan').val()

        if (deskripsiInfoTambahan == "") {
            showMessage('error', 'Deskripsi harus terisi')
            return false;
        }

        if (valueInfoTambahan == "") {
            showMessage('error', 'Value harus terisi')
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveInfoTambahanKaryawan') ?>",
            dataType: "JSON",
            data: {
                idInfoTambahan: mode == 'update' ? idInfoTambahan : null,
                idUsers: $('#idUsers').val(),
                mode,
                deskripsiInfoTambahan,
                valueInfoTambahan
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    getDataInfoTambahan();
                    resetFormInfoTambahan();
                    $('#modalAddInfoTambahan').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const handlerHapusDataInfoTambahan = (idInfoTambahan) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idInfoTambahan)
        $('.deleteData').attr('data-modul', 'infoTambahan')
        $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data Info Tambahan</h6>`);
    }

    /************************************************ Form Info Tambahan ***********************************************/


    /************************************************ Form Upload Dokumen Pekerjaan ***********************************************/

    const handlerAddDokumenPekerjaan = (type) => {
        $('#modalAddDokumenPekerjaan').modal('show');
        if (type == '1') {
            $('#modalAddDokumenPekerjaan .modal-title').html('Upload dokumen SK Pengangkatan');
        }

        if (type == '2') {
            $('#modalAddDokumenPekerjaan .modal-title').html('Upload dokumen Ijazah');
        }

        if (type == '3') {
            $('#modalAddDokumenPekerjaan .modal-title').html('Upload dokumen Sertifikat');
        }

        if (type == '4') {
            $('#modalAddDokumenPekerjaan .modal-title').html('Upload dokumen Surat Referensi');
        }

        $('.addDokumenPekerjaan').attr('data-type', type)
    }

    const handlerSaveDokumenPekerjaan = (event) => {
        const type = event.currentTarget.getAttribute('data-type');

        if ($("#namaDokumen").val() == "") {
            showMessage('error', 'Nama Dokumen harus terisi')
            return false;
        }
        if ($("#file").val() == "") {
            showMessage('error', 'File harus terisi')
            return false;
        }

        let dataPost = new FormData();
        dataPost.append('type', type);
        dataPost.append('idUsers', $("#idUsers").val());
        dataPost.append('namaDokumen', $("#namaDokumen").val());
        dataPost.append('file', $('#file')[0].files[0]);

        $.ajax({
            type: "POST",
            url: "<?= base_url('Users/Karyawan/saveUploadDokumenPekerjaan'); ?>",
            data: dataPost,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(response) {
                if (response.status == 201) {
                    $('#modalAddDokumenPekerjaan').modal('hide');
                    showMessage('success', response.message);
                    setTimeout(() => {
                        location.reload();
                    }, 2000)
                }

                if (response.status == 400) {
                    showMessage('error', response.message);
                }
            }
        });


    }

    /************************************************ Form Upload Dokumen Pekerjaan ***********************************************/

    /************************************************ Form Payroll ***********************************************/

    const handlerChangePayrollInformasi = (date) => {
        let dateSplit = date.split('-')
        $.ajax({
            url: base_url + "Users/Karyawan/getGajiKaryawanByDate",
            type: "POST",
            data: {
                idUsers: $('#idUsers').val(),
                date
            },
            dataType: 'JSON',
            success: function(response) {
                if (response) {
                    $('#initDataGajiKaryawan > tbody').empty();
                    let html = "";
                    $.each(response.dataGaji, function(i, v) {
                        console.log(v);
                        html += `<tr>
                                    <td>${i + 1}</td>
                                    <td>${v.p1_1}</td>
                                    <td>${v.p1_2}</td>
                                    <td>${v.p1}</td>`;
                        if (response.dataTunjangan.length > 0) {
                            $.each(response.dataTunjangan, function(idx, tun) {
                                html += `<td>${tun}</td>`;
                            });
                        } else {
                            for (let index = 0; index < <?= count_table('tunjangan') ?>; index++) {
                                html += '<td>0</td>'

                            }
                        }
                        html += `<td>${v.p2}</td>`;
                        if (response.dataBonus.length > 0) {
                            $.each(response.dataBonus, function(idx, bon) {
                                html += `<td>${bon}</td>`;
                            });
                        } else {
                            for (let inn = 0; inn < <?= count_table('bonus') ?>; inn++) {
                                html += '<td>0</td>'
                            }
                        }
                        html += `<td>${v.p3}</td>`;
                        html += `<td>${v.total}</td>`;
                        html += `</tr>`;


                    })
                    $('#initDataGajiKaryawan > tbody').append(html)
                    $('#initDataGajiKaryawan').DataTable();
                }
            }

        });
    }

    /************************************************ Form Payroll ***********************************************/

    /************************************************ Form Keuangan ***********************************************/


    const getDataTransaksiKeuangan = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataTransaksiKeuangan') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#initDataTransaksiKeuangan > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                        <div class="d-flex align-items-center justify-content-center">
                                            <button class="btn btn-warning btn-sm" onclick="handlerEditTransaksiKeuangan('${v.id}')"><i class="fa fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm" onclick="handlerHapusDataTransaksiKeuangan('${v.id}')"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </td>`
                        }

                        $('#initDataTransaksiKeuangan > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.name}</td>
                                <td>Rp. ${v.nominal}</td>
                                <td>${formatTanggal(v.tanggal)}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#initDataTransaksiKeuangan > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '4' : '5'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const resetFormTransaksiKeuangan = () => {
        $('#jenisTransaksi').prop("selectedIndex", 0).trigger('change')
        $('#nominalTransaksi').val('')
        $('#dateTransaksi').val('')
    }

    const handlerEditTransaksiKeuangan = (idTransaksi) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataTransaksiKeuanganById') ?>",
            data: {
                idTransaksi
            },
            dataType: "JSON",
            success: function(response) {
                $('#idTransaksiKeuangan').val(response.id)
                $('#jenisTransaksi').val(response.id_jenis_transaksi_keuangan).trigger('change')
                $('#nominalTransaksi').val(response.nominal)
                $('#dateTransaksi').val(response.tanggal)

            }
        });
        $('.transaksiKeuanganBtn').attr('data-mode', 'update')
    }

    const handlerSaveDataTransaksiKeuangan = (event) => {
        let mode = event.currentTarget.getAttribute('data-mode');
        console.log(mode);
        let idTransaksiKeuangan = $('#idTransaksiKeuangan').val()
        let jenisTransaksi = $('#jenisTransaksi').val()
        let nominalTransaksi = $('#nominalTransaksi').val()
        let dateTransaksi = $('#dateTransaksi').val()

        if (jenisTransaksi == "") {
            showMessage('error', 'Jenis harus terisi')
            return false;
        }

        if (nominalTransaksi == "") {
            showMessage('error', 'Nominal harus terisi')
            return false;
        }

        if (dateTransaksi == "") {
            showMessage('error', 'Tanggal harus terisi')
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveTransaksiKeuanganKaryawan') ?>",
            dataType: "JSON",
            data: {
                idTransaksiKeuangan: mode !== null ? idTransaksiKeuangan : null,
                idUsers: $('#idUsers').val(),
                mode: mode !== null ? 'update' : 'insert',
                jenisTransaksi,
                nominalTransaksi,
                dateTransaksi
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    getDataTransaksiKeuangan();
                    resetFormTransaksiKeuangan();
                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const handlerHapusDataTransaksiKeuangan = (idTransaksiKeuangan) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idTransaksiKeuangan)
        $('.deleteData').attr('data-modul', 'TransaksiKeuangan')
        $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data Transaksi Keuangan</h6>`);
    }

    /************************************************ Form Keuangan ***********************************************/


    const handlerDeleteData = (event) => {
        let id = event.currentTarget.getAttribute('data-id');
        let type = event.currentTarget.getAttribute('data-type');
        let modul = event.currentTarget.getAttribute('data-modul');

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/deleteData') ?>",
            dataType: "JSON",
            data: {
                id,
                type,
                modul
            },
            success: function(response) {
                if (response.status == 200) {
                    if (modul == 'keluarga') {
                        showMessage('success', response.message)
                        // location.reload();
                        if (response.type == '1') {
                            getDataKeluargaInti();
                        }

                        if (response.type == '2') {
                            getDataKeluargaAnda();
                        }

                        if (response.type == '3') {
                            getDataKeluargaInti();
                            getDataKeluargaAnda();
                        }
                        getDataKeluargaEmergency();
                        $('#modalDeleteData').modal('hide');
                    }

                    if (modul == 'pendidikan') {
                        showMessage('success', response.message)
                        // location.reload();
                        if (response.type == '1') {
                            getDataPendidikanFormal();
                        }

                        if (response.type == '2') {
                            getDataPendidikanInformal();
                        }
                        resetFormPendidikan();
                        $('#modalDeleteData').modal('hide');
                    }

                    if (modul == 'pengalamanKerja') {
                        showMessage('success', response.message)
                        // location.reload();
                        getDataPengalamanKerja();
                        resetFormPengalamanKerja();
                        $('#modalDeleteData').modal('hide');
                    }

                    if (modul == 'SKPengangkatan') {
                        showMessage('success', response.message)
                        // location.reload();
                        getDataSKPengangkatan();
                        resetFormSKPengangkatan();
                        $('#modalDeleteData').modal('hide');
                    }

                    if (modul == 'Pelatihan') {
                        showMessage('success', response.message)
                        // location.reload();
                        getDataPelatihan();
                        resetFormPelatihan();
                        $('#modalDeleteData').modal('hide');
                    }

                    if (modul == 'infoTambahan') {
                        showMessage('success', response.message)
                        // location.reload();
                        getDataInfoTambahan();
                        resetFormInfoTambahan();
                        $('#modalDeleteData').modal('hide');
                    }

                    if (modul == 'TransaksiKeuangan') {
                        showMessage('success', response.message)
                        // location.reload();
                        getDataTransaksiKeuangan();
                        resetFormTransaksiKeuangan();
                        $('#modalDeleteData').modal('hide');
                    }

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });

    }
</script>