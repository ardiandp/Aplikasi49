<?php

if (isset($_GET['mode'])) {
    $dataUsers = where_row("karyawan", ['id' => $_GET['id']]);
    $disabled = "disabled";
    $dataView = $this->db->query("SELECT karyawan.*,
                                    provinces.prov_name as provinsi_kk,
                                    cities.city_name as kota_kk,
                                    districts.dis_name as kecamatan_kk,
                                    subdistricts.subdis_name as desa_kk,
                                    provinces2.prov_name as provinsi_dom,
                                    cities2.city_name as kota_dom,
                                    districts2.dis_name as kecamatan_dom,
                                    subdistricts2.subdis_name as desa_dom
                                from karyawan
                                left join provinces on karyawan.provinsi = provinces.prov_id
                                left join provinces provinces2 on karyawan.provinsi_domisili = provinces2.prov_id
                                left join cities on karyawan.kota = cities.city_id
                                left join cities cities2 on karyawan.kota_domisili = cities2.city_id
                                left join districts on karyawan.kecamatan = districts.dis_id
                                left join districts districts2 on karyawan.kecamatan_domisili = districts2.dis_id
                                left join subdistricts on karyawan.desa = subdistricts.subdis_id
                                left join subdistricts subdistricts2 on karyawan.desa_domisili = subdistricts2.subdis_id
                                where karyawan.id = '" . $_GET['id'] . "'")->row();
} else if (isset($_GET['id'])) {
    $dataUsers = where_row("karyawan", ['id' => $_GET['id']]);
    $disabled = "";
} else {
    $disabled = "";
}

?>


<div class="container">
    <?php if (isset($_GET['mode'])) { ?>
        <div class="table-responsive">
            <h4><strong>1. Basic Info</strong></h4>
            <table class="table table-striped" width="100%">
                <tr>
                    <td width="30%">Nama</td>
                    <td width="2%"> : </td>
                    <td width="68%"><?= $dataView->name ?></td>
                </tr>
                <tr>
                    <td>NIP</td>
                    <td> : </td>
                    <td><?= $dataView->nip ?></td>
                </tr>
                <tr>
                    <td>No. NPWP</td>
                    <td> : </td>
                    <td><?= $dataView->no_npwp ?></td>
                </tr>
                <tr>
                    <td>No. KTP</td>
                    <td> : </td>
                    <td><?= $dataView->no_ktp ?></td>
                </tr>
                <tr>
                    <td>Tempat, Tanggal Lahir</td>
                    <td> : </td>
                    <td><?= $dataView->tmp_lahir ?>, <?= date_indo($dataView->tgl_lahir) ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td> : </td>
                    <td><?= $dataView->email ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td> : </td>
                    <td><?= $dataView->jenis_kelamin == 0 ? 'Laki - Laki' : 'Perempuan' ?></td>
                </tr>
                <tr>
                    <td>Alamat sesuai KK</td>
                    <td> : </td>
                    <td>
                        <p>Provinsi : <?= $dataView->provinsi_kk == null ? '-' : $dataView->provinsi_kk ?></p>
                        <p>Kab/Kota : <?= $dataView->kota_kk == null ? '-' : $dataView->kota_kk ?></p>
                        <p>Kecamatan : <?= $dataView->kecamatan_kk == null ? '-' : $dataView->kecamatan_kk ?></p>
                        <p>Kelurahan/Desa : <?= $dataView->desa_kk == null ? '-' : $dataView->desa_kk ?></p>
                        <p>Alamat : <?= $dataView->alamat == null ? '-' : $dataView->alamat ?></p>
                    </td>
                </tr>
                <tr>
                    <td>Alamat Domisili</td>
                    <td> : </td>
                    <td>
                        <p>Provinsi : <?= $dataView->provinsi_dom == null ? '-' : $dataView->provinsi_dom ?></p>
                        <p>Kab/Kota : <?= $dataView->kota_dom == null ? '-' : $dataView->kota_dom ?></p>
                        <p>Kecamatan : <?= $dataView->kecamatan_dom == null ? '-' : $dataView->kecamatan_dom ?></p>
                        <p>Kelurahan/Desa : <?= $dataView->desa_dom == null ? '-' : $dataView->desa_dom ?></p>
                        <p>Alamat : <?= $dataView->alamat_domisili == null ? '-' : $dataView->alamat_domisili ?></p>
                    </td>
                </tr>
                <tr>
                    <td>Tanggal Daftar</td>
                    <td> : </td>
                    <td><?= longdate_indo(date('Y-m-d'), strtotime($dataView->created_at)) ?></td>
                </tr>
                <tr>
                    <td>Status Akun</td>
                    <td> : </td>
                    <td><?= $dataView->status == 0 ? 'Nonactive' : 'Active' ?></td>
                </tr>
            </table>
        </div>
    <?php } ?>
    <?php if (!isset($_GET['mode'])) { ?>
        <div class="table-responsive">
            <table style="width: 100%;" id="personalData">
                <form id="saveheaderDataUmumKaryawan" action="<?= base_url('Users/Karyawan/save_karyawan') ?>" method="POST">
                    <tr>
                        <td colspan="4" style="text-align: left;">
                            <h4><strong>1. Basic Info</strong></h4>
                        </td>
                        <td>
                            <input type="hidden" name="idUsers" id="idUsers" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
                            <?php if (!isset($_GET['mode'])) { ?>
                                <button type="button" class="btn btn-info btn-sm pull-right" <?= isset($_GET['id']) && $dataUsers->is_invited == 1 ? 'disabled' : '' ?> onclick="handlerSendEmailByUser()"><i class="fa fa-envelope"></i></button>
                                <button type="submit" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i></button>
                            <?php } ?>
                        </td>
                    </tr>
                    <tr>
                        <td width="5%"></td>
                        <td width="20%">
                            <h6><strong>Data Personal</strong></h6>
                        </td>
                        <td width="18%">Jabatan</td>
                        <td width="30%">
                            <select name="jabatanPersonal" id="jabatanPersonal" <?= $disabled ?> class="form-control select2">
                                <option>--Pilih Jabatan--</option>
                                <?php foreach ($dataJabatan as $value) { ?>
                                    <?php if (isset($dataUsers)) { ?>
                                        <?php if ($dataUsers->id_jabatan == $value->id) { ?>
                                            <option value="<?= $value->id ?>" selected><?= $value->name ?></option>
                                        <?php } else { ?>
                                            <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                    <?php } ?>
                                <?php } ?>
                            </select>
                        </td>
                        <td width="10%"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Nama</td>
                        <td>
                            <input type="text" class="form-control" name="namaPersonal" id="namaPersonal" placeholder="Nama" value="<?= isset($dataUsers) ? $dataUsers->name : '' ?>" <?= $disabled ?> required>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Telepon</td>
                        <td>
                            <input type="text" class="form-control" name="teleponPersonal" id="teleponPersonal" placeholder="Telepon" value="<?= isset($dataUsers) ? $dataUsers->phone : '' ?>" <?= $disabled ?> required>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Email</td>
                        <td>
                            <input type="email" class="form-control" name="emailPersonal" id="emailPersonal" placeholder="Email" value="<?= isset($dataUsers) ? $dataUsers->email : '' ?>" <?= $disabled ?> required>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Jenis kelamin</td>
                        <td>
                            <select name="genderPersonal" id="genderPersonal" <?= $disabled ?> class="form-control select2">
                                <option value="">--Pilih Jenis Kelamin--</option>
                                <option <?= (isset($dataUsers) && $dataUsers->jenis_kelamin == 0 ? "selected" : "") ?> value="0">Laki - Laki</option>
                                <option <?= (isset($dataUsers) && $dataUsers->jenis_kelamin == 1 ? "selected" : "") ?> value="1">Perempuan</option>
                            </select>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Tempat Lahir</td>
                        <td><input type="text" class="form-control" name="tempatLahirPersonal" id="tempatLahirPersonal" placeholder="Tempat Lahir" value="<?= isset($dataUsers) ? $dataUsers->tmp_lahir : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Tanggal Lahir</td>
                        <td><input type="date" class="form-control" name="tanggalLahirPersonal" id="tanggalLahirPersonal" placeholder="Tanggal Lahir" value="<?= isset($dataUsers) ? $dataUsers->tgl_lahir : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Suku</td>
                        <td><input type="text" class="form-control" name="sukuPersonal" id="sukuPersonal" placeholder="Suku" value="<?= isset($dataUsers) ? $dataUsers->suku : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Agama</td>
                        <td><input type="text" class="form-control" name="agamaPersonal" id="agamaPersonal" placeholder="Agama" value="<?= isset($dataUsers) ? $dataUsers->agama : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Golongan Darah</td>
                        <td><input type="text" class="form-control" name="golDarahPersonal" id="golDarahPersonal" placeholder="Golongan Darah" value="<?= isset($dataUsers) ? $dataUsers->golongan_darah : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Status Pernikahan</td>
                        <td>
                            <select name="statusPernikahanPersonal" id="statusPernikahanPersonal" <?= $disabled ?> class="form-control select2">
                                <option value="">--Pilih Status pernikahan--</option>
                                <option <?= (isset($dataUsers) && $dataUsers->status_pernikahan == 0 ? "selected" : "") ?> value="0">Belum Nikah</option>
                                <option <?= (isset($dataUsers) && $dataUsers->status_pernikahan == 1 ? "selected" : "") ?> value="1">Sudah Nikah</option>
                            </select>
                        </td>
                        <td></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td>
                            <h6><strong>ID dan Alamat</strong></h6>
                        </td>
                        <td>No. KTP</td>
                        <td><input type="text" class="form-control" name="noKTPPersonal" id="noKTPPersonal" placeholder="No. KTP" value="<?= isset($dataUsers) ? $dataUsers->no_ktp : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td></td>
                        <td>No. NPWP</td>
                        <td><input type="text" class="form-control" name="noNPWPPersonal" id="noNPWPPersonal" placeholder="No. NPWP" value="<?= isset($dataUsers) ? $dataUsers->no_npwp : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>NIP</td>
                        <td><input type="text" class="form-control" name="nipPersonal" id="nipPersonal" placeholder="NIP" value="<?= isset($dataUsers) ? $dataUsers->nip : '' ?>" <?= $disabled ?> required></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Alamat - Sesuai KTP</td>
                        <td>
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="provinsiKTP">Provinsi</label>
                                        <select name="provinsiKTP" id="provinsiKTP" <?= $disabled ?> class="form-control select2" onchange="handlerProvinsiKTPChange(this.value)" required>
                                            <option value="">--Pilih Provinsi--</option>
                                            <?php foreach ($dataProvinsi as $key => $value) { ?>
                                                <?php if (isset($dataUsers)) { ?>
                                                    <?php if ($dataUsers->provinsi == $value->id) { ?>
                                                        <option value="<?= $value->id ?>" selected><?= $value->nama ?></option>
                                                    <?php } else { ?>
                                                        <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                    <?php } ?>
                                                <?php } else { ?>
                                                    <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                <?php } ?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="kotaKTP">Kabupaten / Kota</label>
                                        <select name="kotaKTP" id="kotaKTP" <?= $disabled ?> class="form-control select2" onchange="handlerKotaKTPChange(this.value)" required>
                                            <option value="">--Pilih Kabupaten / Kota--</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="kecamatanKTP">Kecamatan</label>
                                        <select name="kecamatanKTP" id="kecamatanKTP" <?= $disabled ?> class="form-control select2" onchange="handlerKecamatanKTPChange(this.value)" required>
                                            <option value="">--Pilih Kecamatan--</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="desaKTP">Desa</label>
                                        <select name="desaKTP" id="desaKTP" <?= $disabled ?> class="form-control select2" required>
                                            <option value="">--Pilih Desa--</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="alamatKTP">Alamat Lengkap</label>
                                        <textarea name="alamatKTP" id="alamatKTP" cols="3" rows="3" <?= $disabled ?> class="form-control" style="white-space: normal" required><?= isset($dataUsers) ? $dataUsers->alamat : '' ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <hr>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Domisili</td>
                        <td>
                            <div>
                                <input type="hidden" name="valueChkDomisili" id="valueChkDomisili" value="<?= isset($dataUsers) ? ($dataUsers->is_domisili_same_kk == null || $dataUsers->is_domisili_same_kk == "" ? 0 : 1) : '' ?>">
                                <input type="checkbox" name="chkDomisili" style="margin-top:10px;transform: scale(1.5)" <?= $disabled ?> id="chkDomisili" <?= isset($dataUsers) ? ($dataUsers->is_domisili_same_kk == 1 ? 'checked' : '') : 'checked' ?> onchange="handlerChkDomisili(event)">
                                <span style="margin-left: 10px;font-size:15px;font-weight:700" name="CAPTION-PENGAJUANAPPROVAL">Alamat Sesui KK ?</span>
                            </div>

                            <div class="row mt-3" id="showFieldDomisili" style="display: <?= isset($dataUsers) ? ($dataUsers->is_domisili_same_kk == 1 ? 'none' : 'block') : 'none' ?>">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="provinsiDomisili">Provinsi</label>
                                        <select name="provinsiDomisili" id="provinsiDomisili" <?= $disabled ?> class="form-control select2" onchange="handlerProvinsiDomisiliChange(this.value)">
                                            <option value="">--Pilih Provinsi--</option>
                                            <?php foreach ($dataProvinsi as $key => $value) { ?>
                                                <?php if (isset($dataUsers)) { ?>
                                                    <?php if ($dataUsers->provinsi_domisili == $value->id) { ?>
                                                        <option value="<?= $value->id ?>" selected><?= $value->nama ?></option>
                                                    <?php } else { ?>
                                                        <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                    <?php } ?>
                                                <?php } else { ?>
                                                    <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                <?php } ?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="kotaDomisili">Kabupaten / Kota</label>
                                        <select name="kotaDomisili" id="kotaDomisili" <?= $disabled ?> class="form-control select2" onchange="handlerKotaDomisiliChange(this.value)">
                                            <option value="">--Pilih Kabupaten / Kota--</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="kecamatanDomisili">Kecamatan</label>
                                        <select name="kecamatanDomisili" id="kecamatanDomisili" <?= $disabled ?> class="form-control select2" onchange="handlerKecamatanDomisiliChange(this.value)">
                                            <option value="">--Pilih Kecamatan--</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="desaDomisili">Desa</label>
                                        <select name="desaDomisili" id="desaDomisili" <?= $disabled ?> class="form-control select2">
                                            <option value="">--Pilih Desa--</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="alamatDomisili">Alamat Lengkap</label>
                                        <textarea name="alamatDomisili" id="alamatDomisili" cols="3" rows="3" <?= $disabled ?> class="form-control" style="white-space: normal"><?= isset($dataUsers) ? $dataUsers->alamat_domisili : '' ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td></td>
                    </tr>
                </form>
            </table>
        </div>
    <?php } ?>
    <hr>
    <div>
        <h4><strong>2. Keluarga</strong></h4>
        <div class="ml-4 mb-4">
            <div class="d-flex align-items-center justify-content-between">
                <smll><strong>Keluarga inti bila anda sudah menikah <span class="text-danger">Keluarga Sesuai KK</span></strong></smll>
                <div>
                    <?php if (!isset($_GET['mode'])) { ?>
                        <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddKeluargaInti('1', 'insert')"><i class="fa fa-plus"></i></button>
                        <button class="btn btn-success btn-sm pull-right" title="tambah ke emergency contact" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddEmergency('1')"><i class="fa fa-check"></i></button>
                    <?php } ?>

                </div>
            </div>
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tablekeluargainti" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td>
                                    <input type="checkbox" name="select-all-keluargaInti" style="transform: scale(1.2)" onchange="checkAll(this, 'keluargaInti')" id="select-all-keluargaInti">
                                </td>

                            <?php } else { ?>
                                <td><strong>#</strong></td>
                            <?php } ?>

                            <td><strong>NIK</strong></td>
                            <td><strong>Nama</strong></td>
                            <td><strong>TTL</strong></td>
                            <td><strong>L/P</strong></td>
                            <td><strong>Hubungan</strong></td>
                            <td><strong>Status</strong></td>
                            <td><strong>Pekerjaan</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>

                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
        <div class="ml-4">
            <div class="d-flex align-items-center justify-content-between">
                <smll><strong>Keluarga Anda (Ayah, Ibu, saudara sekandung termasuk anda) <span class="text-danger">Keluarga Anda</span></strong></smll>
                <div>
                    <?php if (!isset($_GET['mode'])) { ?>
                        <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddKeluargaAnda('2', 'insert')"><i class="fa fa-plus"></i></button>
                        <button class="btn btn-success btn-sm pull-right" title="tambah ke emergency contact" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddEmergency('2')"><i class="fa fa-check"></i></button>
                    <?php } ?>

                </div>
            </div>
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tablekeluargaanda" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td>
                                    <input type="checkbox" name="select-all-keluargaAnda" style="transform: scale(1.2)" onchange="checkAll(this, 'keluargaAnda')" id="select-all-keluargaAnda">
                                </td>

                            <?php } else { ?>
                                <td><strong>#</strong></td>
                            <?php } ?>

                            <td><strong>NIK</strong></td>
                            <td><strong>Nama</strong></td>
                            <td><strong>TTL</strong></td>
                            <td><strong>L/P</strong></td>
                            <td><strong>Hubungan</strong></td>
                            <td><strong>Status</strong></td>
                            <td><strong>Pekerjaan</strong></td>
                            <td><strong>Phone</strong></td>
                            <td><strong>Provinsi</strong></td>
                            <td><strong>Kota</strong></td>
                            <td><strong>Kecamatan</strong></td>
                            <td><strong>Desa</strong></td>
                            <td><strong>Alamat</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
    <hr>
    <div>
        <h4><strong>3. Emergency Contact</strong></h4>
        <div class="ml-4 mb-4">
            <div class="d-flex align-items-center justify-content-between">
                <smll><strong>Keluarga tidak serumah <span class="text-danger">Emergency Contact</span></strong></smll>
            </div>
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tableemergency" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No</strong></td>
                            <td><strong>NIK</strong></td>
                            <td><strong>Nama</strong></td>
                            <td><strong>TTL</strong></td>
                            <td><strong>L/P</strong></td>
                            <td><strong>Hubungan</strong></td>
                            <td><strong>Status</strong></td>
                            <td><strong>Pekerjaan</strong></td>
                            <td><strong>Phone</strong></td>
                            <td><strong>Provinsi</strong></td>
                            <td><strong>Kota</strong></td>
                            <td><strong>Kecamatan</strong></td>
                            <td><strong>Desa</strong></td>
                            <td><strong>Alamat</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddKeluarga" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" name="nik" id="nik" class="form-control" placeholder="NIK" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="tempat_lahir">Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control" placeholder="Tempat lahir" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="tanggal_lahir">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control" placeholder="Tanggal lahir" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="jenis_kelamin">Jenis Kelamin</label>
                        <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                            <option value="">--Pilih Jenis Kelamin--</option>
                            <option value="0">Laki - Laki</option>
                            <option value="1">Perempuan</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="hubungan">Hubungan</label>
                        <select name="hubungan" id="hubungan" class="form-control">
                            <option value="">--Pilih Hubungan--</option>
                            <option value="1">Kepala Keluarga</option>
                            <option value="2">Istri</option>
                            <option value="3">Anak</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="">--Pilih Status--</option>
                            <option value="0">Menikah</option>
                            <option value="1">Belum Menikah</option>
                            <option value="2">Cerai Hidup</option>
                            <option value="3">Cerai Mati</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="pekerjaan">Pekerjaan</label>
                        <input type="text" name="pekerjaan" id="pekerjaan" class="form-control" placeholder="Pekerjaan" autocomplete="off" required>
                    </div>
                    <hr>
                    <div id="showAlamatKeluargaAnda" style="display:none">
                        <fieldset>
                            <legend>Data Alamat</legend>
                            <div class="container">

                                <div class="form-group">
                                    <label for="phoneKeluargaAnda">No. Handphone</label>
                                    <input type="text" name="phoneKeluargaAnda" id="phoneKeluargaAnda" class="form-control" placeholder="No. Handphone" autocomplete="off" required>
                                </div>

                                <div class="form-group">
                                    <label for="provinsiKeluargaAnda">Provinsi</label>
                                    <select name="provinsiKeluargaAnda" id="provinsiKeluargaAnda" class="form-control select2" onchange="handlerProvinsiKeluargaAndaChange(this.value)" required>
                                        <option value="">--Pilih Provinsi--</option>
                                        <?php foreach ($dataProvinsi as $key => $value) { ?>
                                            <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="kotaKeluargaAnda">Kabupaten / Kota</label>
                                    <select name="kotaKeluargaAnda" id="kotaKeluargaAnda" class="form-control select2" onchange="handlerKotaKeluargaAndaChange(this.value)" required>
                                        <option value="">--Pilih Kabupaten / Kota--</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="kecamatanKeluargaAnda">Kecamatan</label>
                                    <select name="kecamatanKeluargaAnda" id="kecamatanKeluargaAnda" class="form-control select2" onchange="handlerKecamatanKeluargaAndaChange(this.value)" required>
                                        <option value="">--Pilih Kecamatan--</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="desaKeluargaAnda">Desa</label>
                                    <select name="desaKeluargaAnda" id="desaKeluargaAnda" class="form-control select2" required>
                                        <option value="">--Pilih Desa--</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="alamatKeluargaAnda">Alamat Lengkap</label>
                                    <textarea name="alamatKeluargaAnda" id="alamatKeluargaAnda" cols="3" rows="3" class="form-control" style="white-space: normal" required></textarea>
                                </div>
                            </div>
                        </fieldset>
                        <hr>
                        <div>
                            <input type="checkbox" name="chkEmergency" style="margin-top:10px;transform: scale(1.5)" id="chkEmergency">
                            <span style="margin-left: 10px;font-size:15px;font-weight:700">Masukkan ke Emergency Contact?</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary addKeluarga" type="button" onclick="handlerAddKeluarga(event)">Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalKeluarga()">kembali</button>
            </div>
        </div>
    </div>
</div>