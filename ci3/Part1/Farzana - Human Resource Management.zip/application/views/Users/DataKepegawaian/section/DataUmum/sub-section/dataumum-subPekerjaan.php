<?php

$perusahaan = $this->db->select("*")->from('profil_perusahaan')->get()->row();

if (isset($_GET['mode'])) {
    $dataPekerjaan = where_row("tbl_pekerjaan", ['id_karyawan' => $_GET['id']]);
    $dataPenerimaan = where_row("penerimaan", ['karyawan' => $_GET['id']]);
    $dataInfoTambahan = where_row("tbl_infotambahan", ['id_karyawan' => $_GET['id']]);
    $dataUsersJabatan = $this->db->select("b.name as jabatan, c.nama as role")
        ->from('karyawan a')
        ->join('jabatan b', 'a.id_jabatan = b.id', 'left')
        ->join('role c', 'b.id_role = c.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();
    $dataUsersJabatanPlt = $this->db->select("b.name as jabatan, c.nama as role")
        ->from('karyawan a')
        ->join('jabatan b', 'a.id_plt = b.id', 'left')
        ->join('role c', 'b.id_role = c.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();
    $dataUserDivisiPlt = $this->db->select("b.nama_divisi")
        ->from('karyawan a')
        ->join('divisi b', 'a.id_plt_divisi = b.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();
    $dataUserDivisi = $this->db->select("b.nama_divisi")
        ->from('karyawan a')
        ->join('divisi b', 'a.id_divisi = b.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();
    $disabled = "disabled";

    $dataView = $this->db->query("SELECT 
                                    b.name as jabatan,
                                    c.name as jabatan_plt,
                                    e.nama_divisi as divisi,
                                    f.nama_divisi as divisi_plt,
                                    d.nama as role,
                                    i.name as statuspegawai,
                                    j.name as unit,
                                    h.date as tgl_gabung,
                                    l.nomor_sk as sk
                                from karyawan a
                                left join jabatan b on a.id_jabatan = b.id
                                left join jabatan c on a.id_plt = c.id
                                left join role d on b.id_role = d.id
                                left join divisi e on a.id_divisi = e.id
                                left join divisi f on a.id_plt_divisi = f.id
                                left join tbl_pekerjaan g on a.id = g.id_karyawan
                                left join penerimaan h on a.id = h.karyawan
                                left join statuspegawai i on g.id_statuspegawai = i.id
                                left join unit j on h.unit = j.id
                                left join tbl_pekerjaan k on a.id = k.id_karyawan
                                left join tbl_skpengangkatan l on k.id_skpengangkatan = l.id
                                where a.id = '" . $_GET['id'] . "'")->row();
} else if (isset($_GET['id'])) {
    $dataPekerjaan = where_row("tbl_pekerjaan", ['id_karyawan' => $_GET['id']]);
    $dataPenerimaan = where_row("penerimaan", ['karyawan' => $_GET['id']]);
    $dataInfoTambahan = where_row("tbl_infotambahan", ['id_karyawan' => $_GET['id']]);
    $dataUsersJabatan = $this->db->select("b.name as jabatan, c.nama as role")
        ->from('karyawan a')
        ->join('jabatan b', 'a.id_jabatan = b.id', 'left')
        ->join('role c', 'b.id_role = c.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();
    $dataUsersJabatanPlt = $this->db->select("b.name as jabatan, c.nama as role")
        ->from('karyawan a')
        ->join('jabatan b', 'a.id_plt = b.id', 'left')
        ->join('role c', 'b.id_role = c.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();
    $dataUserDivisiPlt = $this->db->select("b.nama_divisi")
        ->from('karyawan a')
        ->join('divisi b', 'a.id_plt_divisi = b.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();
    $dataUserDivisi = $this->db->select("b.nama_divisi")
        ->from('karyawan a')
        ->join('divisi b', 'a.id_divisi = b.id', 'left')
        ->where('a.id', $_GET['id'])->get()->row();



    $disabled = "";
} else {
    $disabled = "";
}

?>

<div class="container">
    <?php if (isset($_GET['mode'])) { ?>
        <div class="table-responsive">
            <h4><strong>1. Data Pekerjaan</strong></h4>
            <table class="table table-striped" width="100%">
                <tr>
                    <td width="30%">Perusahaan</td>
                    <td width="2%"> : </td>
                    <td width="68%"><?= $perusahaan->nama ? $perusahaan->nama : '-' ?></td>
                </tr>
                <tr>
                    <td>Jabatan</td>
                    <td> : </td>
                    <td><?= $dataView->jabatan ? $dataView->jabatan : '-' ?></td>
                </tr>
                <?php if ($dataView->jabatan_plt != '') { ?>
                    <tr>
                        <td>Jabatan PLT</td>
                        <td> : </td>
                        <td><?= $dataView->jabatan_plt ? $dataView->jabatan_plt : '-' ?></td>
                    </tr>
                <?php } ?>

                <tr>
                    <td>Bidang</td>
                    <td> : </td>
                    <td><?= $dataView->divisi ? $dataView->divisi : '-' ?></td>
                </tr>
                <?php if ($dataView->divisi_plt != '') { ?>
                    <tr>
                        <td>Bidang PLT</td>
                        <td> : </td>
                        <td><?= $dataView->divisi_plt ? $dataView->divisi_plt : '-' ?></td>
                    </tr>
                <?php } ?>

                <tr>
                    <td>Role</td>
                    <td> : </td>
                    <td><?= $dataView->role ? $dataView->role : '-' ?></td>
                </tr>
                <tr>
                    <td>Status Pegawai</td>
                    <td> : </td>
                    <td><?= $dataView->statuspegawai ? $dataView->statuspegawai : '-' ?></td>
                </tr>
                <tr>
                    <td>Cabang / Unit</td>
                    <td> : </td>
                    <td><?= $dataView->unit ? $dataView->unit : '-' ?></td>
                </tr>

                <tr>
                    <td>Tanggal Gabung</td>
                    <td> : </td>
                    <td><?= longdate_indo(date('Y-m-d'), strtotime($dataView->tgl_gabung)) ? longdate_indo(date('Y-m-d'), strtotime($dataView->tgl_gabung)) : '-' ?></td>
                </tr>
                <tr>
                    <td>SK Pengangkatan</td>
                    <td> : </td>
                    <td><?= $dataView->sk ? $dataView->sk : '-' ?></td>
                </tr>
            </table>
        </div>
    <?php } ?>
    <?php if (!isset($_GET['mode'])) { ?>
        <div class="table-responsive">
            <table style="width: 100%;" id="personalData">
                <form action="<?= base_url('Users/Karyawan/save_pekerjaan') ?>" method="POST" enctype="multipart/form-data">
                    <tr>
                        <td colspan="4" style="text-align: left;">
                            <h4><strong>1. Data Pekerjaan</strong></h4>
                        </td>
                        <td>
                            <input type="hidden" name="idUsers" id="idUsers" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
                            <?php if (!isset($_GET['mode'])) { ?>
                                <button type="submit" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i></button>
                            <?php } ?>
                        </td>
                    </tr>
                    <tr>
                        <td width="10%"></td>
                        <td width="10%"></td>
                        <td width="25%">Perusahaan <span class="text-danger">*</span></td>
                        <td width="30%">
                            <select name="perusahaan" id="perusahaan" disabled class="form-control">
                                <option value="<?= $perusahaan->id ?>" selected><?= $perusahaan->nama ?></option>
                            </select>
                        </td>
                        <td width="10%"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Jabatan <span class="text-danger">*</span></td>
                        <td>
                            <input type="text" class="form-control" name="teleponPersonal" id="teleponPersonal" placeholder="Telepon" value="<?= isset($dataUsersJabatan) ? $dataUsersJabatan->jabatan : ''  ?>" disabled required>
                        </td>
                        <td></td>
                    </tr>
                    <?php if (isset($dataUsersJabatanPlt) && $dataUsersJabatanPlt->jabatan != '') { ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>Jabatan PLT <span class="text-danger">*</span></td>
                            <td>
                                <input type="text" class="form-control" name="teleponPersonal" id="teleponPersonal" placeholder="-" value="<?= isset($dataUsersJabatanPlt) ? $dataUsersJabatanPlt->jabatan : '' ?>" disabled>
                            </td>
                            <td></td>
                        </tr>
                    <?php } ?>

                    <tr>
                        <td></td>
                        <td></td>
                        <td>Bidang <span class="text-danger">*</span></td>
                        <td>
                            <input type="text" class="form-control" name="organisasi" id="organisasi" value="<?= isset($dataUserDivisi) ? $dataUserDivisi->nama_divisi : '' ?>" placeholder="Organisasi" <?= $disabled ?> required disabled>
                        </td>
                        <td></td>
                    </tr>
                    <?php if (isset($dataUserDivisiPlt) && $dataUserDivisiPlt->nama_divisi != '') { ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>Bidang Plt<span class="text-danger">*</span></td>
                            <td>
                                <input type="text" class="form-control" name="organisasi" id="organisasi" value="<?= isset($dataUserDivisiPlt) ? $dataUserDivisiPlt->nama_divisi : '-' ?>" placeholder="Organisasi" <?= $disabled ?> disabled>
                            </td>
                            <td></td>
                        </tr>
                    <?php } ?>

                    <tr>
                        <td></td>
                        <td></td>
                        <td>Role <span class="text-danger">*</span></td>
                        <td>
                            <input type="email" class="form-control" name="emailPersonal" id="emailPersonal" placeholder="Email" value="<?= isset($dataUsersJabatan) ? $dataUsersJabatan->role : '' ?>" disabled required>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Status Pegawai <span class="text-danger">*</span></td>
                        <td>
                            <select name="status_pegawai" id="status_pegawai" <?= $disabled ?> class="form-control select2" required>
                                <option value="">--Pilih Status Pegawai--</option>
                                <?php foreach ($dataStatusPegawai as $value) { ?>
                                    <?php if (isset($dataPekerjaan)) { ?>
                                        <?php if ($dataPekerjaan->id_statuspegawai == $value->id) { ?>
                                            <option value="<?= $value->id ?>" selected><?= $value->name ?></option>
                                        <?php } else { ?>
                                            <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                    <?php } ?>
                                <?php } ?>
                            </select>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Cabang / Unit </td>
                        <td>
                            <select name="cabang_unit" id="cabang_unit" <?= $disabled ?> class="form-control select2" onchange="handlerGetLokasiUnit(this.value)">
                                <option value="">--Pilih Cabang / Unit--</option>
                                <?php foreach ($dataUnit as $value) { ?>
                                    <?php if (isset($dataPenerimaan)) { ?>
                                        <?php if ($dataPenerimaan->unit == $value->id) { ?>
                                            <option value="<?= $value->id ?>" selected><?= $value->name ?></option>
                                        <?php } else { ?>
                                            <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                    <?php } ?>
                                <?php } ?>
                            </select>
                        </td>
                        <td></td>
                    </tr>
                    <tr id="lokasiKantor" style="display: none;">
                        <td></td>
                        <td></td>
                        <td>Lokasi Kantor</td>
                        <td>
                            <fieldset>
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <label for="alamatKantor">Alamat</label>
                                            <textarea name="alamatKantor" id="alamatKantor" cols="3" rows="3" class="form-control" disabled></textarea>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <label for="longitudeKantor">Longitude</label>
                                            <input type="text" class="form-control" name="longitudeKantor" id="longitudeKantor" disabled>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <label for="latitudeKantor">Latitude</label>
                                            <input type="text" class="form-control" name="latitudeKantor" id="latitudeKantor" disabled>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Tanggal Gabung</td>
                        <td><input type="date" class="form-control" name="tanggal_gabung" id="tanggal_gabung" value="<?= isset($dataPenerimaan) ? $dataPenerimaan->date : '' ?>" <?= $disabled ?> placeholder="Tanggal Gabung"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>SK Pengangkatan</td>
                        <td>
                            <select name="sk_pengangkatan" id="sk_pengangkatan" <?= $disabled ?> class="form-control select2">
                                <option value="">--Pilih SK Pengangkatan--</option>
                                <?php foreach ($dataSKPengangkatan as $value) { ?>
                                    <?php if (isset($dataPekerjaan)) { ?>
                                        <?php if ($dataPekerjaan->id_skpengangkatan == $value->id) { ?>
                                            <option value="<?= $value->id ?>" selected><?= $value->nomor_sk ?></option>
                                        <?php } else { ?>
                                            <option value="<?= $value->id ?>"><?= $value->nomor_sk ?></option>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <option value="<?= $value->id ?>"><?= $value->nomor_sk ?></option>
                                    <?php } ?>
                                <?php } ?>
                            </select>
                        </td>
                        <td></td>
                    </tr>
                </form>
            </table>
        </div>
    <?php } ?>
    <hr>
    <div>
        <h4><strong>2. Approval Line</strong></h4>
        <div class="ml-4 mb-4">
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama</strong></td>
                            <td><strong>Bidang</strong></td>
                            <td><strong>Jabatan</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (isset($dataAtasan)) { ?>
                            <?php if (count($dataAtasan) > 0) { ?>
                                <?php foreach ($dataAtasan as $key => $value) { ?>
                                    <tr>
                                        <td><?= $key + 1 ?></td>
                                        <td><?= $value->karyawan ?></td>
                                        <td><?= $value->divisi ?></td>
                                        <td><?= $value->jabatan ?></td>
                                    </tr>
                                <?php } ?>
                            <?php } else { ?>
                                <tr>
                                    <td colspan="4" class="text-center text-danger">Anda tidak memiliki atasan</td>
                                </tr>
                            <?php } ?>
                        <?php } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <hr>
    <div>
        <h4><strong>3. Laporan Langsung</strong></h4>
        <div class="ml-4 mb-4">
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama</strong></td>
                            <td><strong>Bidang</strong></td>
                            <td><strong>Jabatan</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (isset($dataBawahan)) { ?>
                            <?php if (count($dataBawahan) > 0) { ?>
                                <?php foreach ($dataBawahan as $key => $value) { ?>
                                    <tr>
                                        <td><?= $key + 1 ?></td>
                                        <td><?= $value->karyawan ?></td>
                                        <td><?= $value->divisi ?></td>
                                        <td><?= $value->jabatan ?></td>
                                    </tr>
                                <?php } ?>
                            <?php } else { ?>
                                <tr>
                                    <td colspan="4" class="text-center text-danger">Anda tidak memiliki bawahan</td>
                                </tr>
                            <?php } ?>
                        <?php } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <hr>
    <div>
        <h4><strong>4. Pendidikan & Pengalaman</strong></h4>
        <div class="ml-4 mb-4">
            <div class="d-flex align-items-center justify-content-between">
                <span><strong>a. Pendidikan Formal</strong></span>
                <div>
                    <?php if (!isset($_GET['mode'])) { ?>
                        <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerAddPendidkan('1', 'insert')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tablePendidikanFormal" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Jenjang</strong></td>
                            <td><strong>Nama Sekolah</strong></td>
                            <td><strong>Jurusan</strong></td>
                            <td><strong>Tahun Masuk - Tahun Keluar</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <hr>

            <div class="d-flex align-items-center justify-content-between mt-3">
                <span><strong>b. Pendidikan Informal</strong></span>
                <div>
                    <?php if (!isset($_GET['mode'])) { ?>
                        <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerAddPendidkan('2', 'insert')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tablePendidikanInformal" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Penyelenggara</strong></td>
                            <td><strong>Nama Kursus</strong></td>
                            <td><strong>Tempat</strong></td>
                            <td><strong>Tahun</strong></td>
                            <td><strong>Keterangan</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <div class="d-flex align-items-center justify-content-between mt-3">
                <span><strong>c. Pengalaman Kerja</strong></span>
                <div>
                    <?php if (!isset($_GET['mode'])) { ?>
                        <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerAddPengalamanKerja(null,'insert')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tablePengalamanKerja" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama Pekerjaan</strong></td>
                            <td><strong>Jabatan</strong></td>
                            <td><strong>Tahun Masuk - Tahun Keluar</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <div class="d-flex align-items-center justify-content-between mt-3">
                <span><strong>d. SK Pengangkatan</strong></span>
                <div>
                    <?php if (!isset($_GET['mode'])) { ?>
                        <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerAddSKPengangkatan(null,'insert')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tableSKPengangkatan" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Tanggal SK</strong></td>
                            <td><strong>Nomor SK</strong></td>
                            <td><strong>Keterangan</strong></td>
                            <td><strong>Status</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <div class="d-flex align-items-center justify-content-between mt-3">
                <span><strong>e. Pelatihan</strong></span>
                <div>
                    <?php if (!isset($_GET['mode'])) { ?>
                        <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerAddPelatihan(null,'insert')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tablePelatihan" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama Pelatihan</strong></td>
                            <td><strong>Status</strong></td>
                            <td><strong>Tahun</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
    <div>
        <div class="d-flex align-items-center justify-content-between mt-3">
            <h4><strong>5. Info Tambahan</strong></h4>
            <div>
                <?php if (!isset($_GET['mode'])) { ?>
                    <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerAddInfoTambahan(null,'insert')"><i class="fa fa-plus"></i></button>
                <?php } ?>

            </div>
        </div>
        <div class="ml-4 mb-4">
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tableInfoTambahan" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Deskripsi</strong></td>
                            <td><strong>Value</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddPekerjaan" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div id="formPendidikanFormal" style="display: none">
                        <div class="form-group">
                            <label for="jenjangFormal">Jenjang</label>
                            <select name="jenjangFormal" id="jenjangFormal" class="form-control select2" required>
                                <option value="">--Pilih Jenjang--</option>
                                <?php foreach (show_data('pendidikan') as $key => $value) { ?>
                                    <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="namaSekolahFormal">Nama Sekolah</label>
                            <input type="text" name="namaSekolahFormal" id="namaSekolahFormal" class="form-control" placeholder="Nama Sekolah" autocomplete="off" required>
                        </div>

                        <div class="form-group">
                            <label for="jurusanFormal">Jurusan</label>
                            <input type="text" name="jurusanFormal" id="jurusanFormal" class="form-control" placeholder="Jurusan" autocomplete="off">
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tahunMasukFormal">Tahun Masuk</label>
                                    <select name="tahunMasukFormal" id="tahunMasukFormal" class="form-control select2" required>
                                        <option value="">--Pilih Tahun Masuk--</option>
                                        <?php for ($year = (int)date('Y'); 1900 <= $year; $year--) : ?>
                                            <option value="<?= $year; ?>"><?= $year; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tahunKeluarFormal">Tahun Keluar</label>
                                    <select name="tahunKeluarFormal" id="tahunKeluarFormal" class="form-control select2" required>
                                        <option value="">--Pilih Tahun Keluar--</option>
                                        <?php for ($year = (int)date('Y'); 1900 <= $year; $year--) : ?>
                                            <option value="<?= $year; ?>"><?= $year; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="formPendidikanInformal" style="display: none;">
                        <div class="form-group">
                            <label for="penyelenggaraInformal">Penyelenggara</label>
                            <input type="text" name="penyelenggaraInformal" id="penyelenggaraInformal" class="form-control" placeholder="Penyelenggara" autocomplete="off" required>
                        </div>

                        <div class="form-group">
                            <label for="namaKursusInformal">Nama Kursus</label>
                            <input type="text" name="namaKursusInformal" id="namaKursusInformal" class="form-control" placeholder="Nama Kursus" autocomplete="off" required>
                        </div>

                        <div class="form-group">
                            <label for="tempatInformal">Tempat</label>
                            <input type="text" name="tempatInformal" id="tempatInformal" class="form-control" placeholder="Nama Kursus" autocomplete="off" required>
                        </div>

                        <div class="form-group">
                            <label for="tahunInformal">Tahun</label>
                            <select name="tahunInformal" id="tahunInformal" class="form-control select2" required>
                                <option value="">--Pilih Tahun--</option>
                                <?php for ($year = (int)date('Y'); 1900 <= $year; $year--) : ?>
                                    <option value="<?= $year; ?>"><?= $year; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="keteranganInformal">Keterangan</label>
                            <textarea name="keteranganInformal" id="keteranganInformal" cols="3" rows="3" class="form-control"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary addPendidikan" type="button" onclick="handlerAddPendidikan(event)">Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalPendidikan()">kembali</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddPengalamanKerja" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="form-group">
                        <label for="namaPekerjaanPengalamanKerja">Nama Pekerjaan</label>
                        <input type="text" name="namaPekerjaanPengalamanKerja" id="namaPekerjaanPengalamanKerja" class="form-control" placeholder="Nama Pekerjaan" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="jabatanPengalamanKerja">Jabatan</label>
                        <input type="text" name="jabatanPengalamanKerja" id="jabatanPengalamanKerja" class="form-control" placeholder="Jabatan" autocomplete="off">
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="tahunMasukPengalamanKerja">Tahun Masuk</label>
                                <select name="tahunMasukPengalamanKerja" id="tahunMasukPengalamanKerja" class="form-control select2" required>
                                    <option value="">--Pilih Tahun Masuk--</option>
                                    <?php for ($year = (int)date('Y'); 1900 <= $year; $year--) : ?>
                                        <option value="<?= $year; ?>"><?= $year; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 tahunKeluarPengalamanKerja">
                            <div class="form-group">
                                <label for="tahunKeluarPengalamanKerja">Tahun Keluar</label>
                                <select name="tahunKeluarPengalamanKerja" id="tahunKeluarPengalamanKerja" class="form-control select2" required>
                                    <option value="">--Pilih Tahun Keluar--</option>
                                    <?php for ($year = (int)date('Y'); 1900 <= $year; $year--) : ?>
                                        <option value="<?= $year ?>"><?= $year ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <input type="checkbox" name="thnPngalamanNow" style="margin-top:10px;transform: scale(1.5)" onchange="handlerTahunKluarPengalamanKerja(event)" id="thnPngalamanNow">
                    <span style="margin-left: 10px;font-size:15px;font-weight:700">Sampai sekarang ?</span>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary addPengalamanKerja" type="button" onclick="handlerSavePengalamanKerja(event)">Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalPengalamanKerja()">kembali</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddPelatihan" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="form-group">
                        <label for="namaPelatihanPelatihan">Nama Pelatihan</label>
                        <input type="text" name="namaPelatihanPelatihan" id="namaPelatihanPelatihan" class="form-control" placeholder="Nama Pelatihan" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="statusPelatihan">Status</label>
                        <input type="text" name="statusPelatihan" id="statusPelatihan" class="form-control" placeholder="Status" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label for="tahunPelatihan">Tahun</label>
                        <select name="tahunPelatihan" id="tahunPelatihan" class="form-control select2" required>
                            <option value="">--Pilih Tahun--</option>
                            <?php for ($year = (int)date('Y'); 1900 <= $year; $year--) : ?>
                                <option value="<?= $year; ?>"><?= $year; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary addPelatihan" type="button" onclick="handlerSavePelatihan(event)">Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalPelatihan()">kembali</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddSKPengangkatan" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="form-group">
                        <label for="tanggalSKPengangkatan">Tanggal SK</label>
                        <input type="date" name="tanggalSKPengangkatan" id="tanggalSKPengangkatan" class="form-control" placeholder="Tanggal SK" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="nomorSKPengangkatan">Nomor SK</label>
                        <input type="text" name="nomorSKPengangkatan" id="nomorSKPengangkatan" class="form-control" placeholder="nomor SK Pengangkatan" readonly autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label for="keteranganSKPengangkatan">Keterangan</label>
                        <textarea name="keteranganSKPengangkatan" id="keteranganSKPengangkatan" cols="3" rows="3" class="form-control"></textarea>
                    </div>

                    <div class="form-group">
                        <input type="checkbox" name="chkSKaktif" style="margin-top:10px;transform: scale(1.5)" id="chkSKaktif">
                        <span style="margin-left: 10px;font-size:15px;font-weight:700">Aktif?</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary addSKPengangkatan" type="button" onclick="handlerSaveSKPengangkatan(event)">Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalSKPengangkatan()">kembali</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddInfoTambahan" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="form-group">
                        <label for="deskripsiInfoTambahan">Deskripsi</label>
                        <input type="text" name="deskripsiInfoTambahan" id="deskripsiInfoTambahan" class="form-control" placeholder="Deskripsi" autocomplete="off" required>
                    </div>

                    <div class="form-group">
                        <label for="valueInfoTambahan">Value</label>
                        <input type="text" name="valueInfoTambahan" id="valueInfoTambahan" class="form-control" placeholder="Value" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary addInfoTambahan" type="button" onclick="handlerSaveInfoTambahan(event)">Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalInfoTambahan()">kembali</button>
            </div>
        </div>
    </div>
</div>