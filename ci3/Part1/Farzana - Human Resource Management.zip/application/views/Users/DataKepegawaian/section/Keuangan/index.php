<?php

$dataJenisTransaksiKeuangan = show_data('jenis_transaksi_keuangan');

if (isset($_GET['mode'])) {
    $disabled = "disabled";
} else if (isset($_GET['id'])) {
    $disabled = "";
} else {
    $disabled = "";
}
?>

<div class="container">
    <div>
        <h4><strong>Daftar Transaksi Keuangan</strong></h4>
        <div class="ml-4 mb-4">
            <?php if (!isset($_GET['mode'])) { ?>

                <div class="row">
                    <div class="col-md-12">
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align">Jenis</label>
                            <div class="col-md-9 col-sm-9 ">
                                <input type="hidden" class="form-control" name="idTransaksiKeuangan" id="idTransaksiKeuangan">
                                <input type="hidden" name="idUsers" id="idUsers" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
                                <select name="jenisTransaksi" id="jenisTransaksi" class="form-control select2" required>
                                    <option>--Pilih Jenis--</option>
                                    <?php foreach ($dataJenisTransaksiKeuangan as $value) { ?>
                                        <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align">Nominal</label>
                            <div class="col-md-9 col-sm-9 ">
                                <input type="text" class="form-control numeric" name="nominalTransaksi" id="nominalTransaksi" placeholder="Nominal" required>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align">Tanggal</label>
                            <div class="col-md-9 col-sm-9 ">
                                <input type="date" class="form-control numeric" name="dateTransaksi" id="dateTransaksi" placeholder="Nomnimal" value="<?= date("Y-m-d") ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <label class="col-form-label col-md-3 col-sm-3 label-align"></label>
                        <div class="col-md-9 col-sm-9 ">
                            <button type="button" class="btn btn-primary transaksiKeuanganBtn" onclick="handlerSaveDataTransaksiKeuangan(event)"><i class="fa fa-save"></i> Simpan</button>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <div class="table-responsive mt-3">
                <table class="table table-striped" width="100%" style="font-size: 12px;" id="initDataTransaksiKeuangan">
                    <thead>
                        <tr class="bg-dark text-white text-center">
                            <td><strong>No.</strong></td>
                            <td><strong>Jenis Transaksi Keuangan</strong></td>
                            <td><strong>Nominal</strong></td>
                            <td><strong>Tanggal</strong></td>
                            <?php if (!isset($_GET['mode'])) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#initDataTransaksiKeuangan').DataTable();
    })
</script>