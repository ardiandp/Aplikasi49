<?php


if (isset($_GET['mode'])) {
    $disabled = "disabled";
    $idKaryawan = $_GET['id'];
} else if (isset($_GET['id'])) {
    $disabled = "";
    $idKaryawan = $_GET['id'];
} else {
    $disabled = "";
    $idKaryawan = "";
}

?>

<div class="container">
    <div>
        <h4><strong>1. Data perhitungan gaji by bulan</strong></h4>
        <div class="ml-4 mb-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                        <div class="col-md-9 col-sm-9 ">
                            <input type="hidden" name="idUsers" id="idUsers" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
                            <input type="month" id="payrollKaryawan" onchange="handlerChangePayrollInformasi(this.value)" class="form-control" name="payrollKaryawan" autocomplete="off">
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive mt-3">
                <br><br>
                <div class="clearfix"></div>
                <table id="initDataGajiKaryawan" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th rowspan="2" class="align-middle text-center">No</th>
                            <th colspan="2" class="text-center">Komponen Gaji Pokok</th>
                            <th rowspan="2" class="align-middle text-center">Pay For Person (P1)</th>
                            <th colspan="<?= count_table('tunjangan') ?>" class="align-middle text-center">Tunjangan</th>
                            <th rowspan="2" class="align-middle text-center">Pay For Person (P2)</th>
                            <th colspan="<?= count_table('bonus') ?>" class="align-middle text-center">Bonus</th>
                            <th rowspan="2" class="align-middle text-center">Pay For Person (P3)</th>
                            <th rowspan="2" class="align-middle text-center">Total</th>
                        </tr>
                        <tr>
                            <th>Grade</th>
                            <th>Masa Kerja</th>
                            <?php foreach (show_data("tunjangan") as $tunjangan) {
                                echo "<th>" . $tunjangan->name . "</th>";
                            } ?>
                            <?php foreach (show_data("bonus") as $bonus) {
                                echo "<th>" . $bonus->name . "</th>";
                            } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
    <hr>
    <div>
        <h4><strong>2. Setting data payroll pegawai 3P</strong></h4>
        <div class="ml-4 mb-4">
            <div class="row">
                <div class="col-md-12">
                    <?php

                    $cek_gaji = $this->db->like('date', date("y-m"))->get_where("gaji", ['karyawan' => $idKaryawan])->num_rows();
                    if ($cek_gaji == 0) {
                        $this->db->insert("gaji", [
                            'karyawan' => $idKaryawan,
                            'date' => date("Y-m-d"),
                        ]);
                    }

                    $tnj = $this->db->order_by('id', 'asc')->get("tunjangan")->num_rows();
                    $kry = $this->db->get_where("karyawan", ['id' => $idKaryawan])->row();
                    $pnr = $this->db->select('unit.name,penerimaan.date')->join('karyawan', 'penerimaan.karyawan=karyawan.id')->join('unit', 'penerimaan.unit=unit.id')->get_where("penerimaan", ['penerimaan.karyawan' => $idKaryawan])->row();

                    $tnjs = $this->db->order_by('id', 'asc')->get("tunjangan")->result();
                    $bn = $this->db->order_by('id', 'asc')->get("bonus")->num_rows();
                    $bns = $this->db->order_by('id', 'asc')->get("bonus")->result();
                    $skl = $this->db->query("SELECT pendidikan.name, tbl_sekolah.id_pendidikan
                                      FROM tbl_sekolah
                                      left join pendidikan ON tbl_sekolah.id_pendidikan = pendidikan.id
                                      where tbl_sekolah.id_karyawan = '$idKaryawan'
                                        AND tbl_sekolah.type = 'Formal'
                                      ORDER BY tbl_sekolah.id DESC")->row();



                    if ($skl) {
                        $grade = where_row('grade', ['level' => $skl->id_pendidikan]);
                    }

                    $tunjangan = where_row('int_tunjangan', ['karyawan' => $idKaryawan]);
                    if ($tunjangan) {
                        $show_tunjangan = json_decode($tunjangan->tunjangan);
                    }
                    $penerimaan = where_row('penerimaan', ['karyawan' => $idKaryawan]);
                    $interval = date_diff(date_create($penerimaan->date), date_create(date("Y-m-d")));

                    $bonus = where_row('int_bonus', ['karyawan' => $idKaryawan]);
                    if ($bonus) {
                        $show_bonus = json_decode($bonus->bonus);
                    }

                    $gaji = $this->db->like('date', date("Y-m"))->get_where("gaji", ['karyawan' => $idKaryawan])->row();
                    $potongan = $this->db->like('date', date("Y-m"))->get_where('potongan', ['karyawan' => $idKaryawan])->row();
                    if ($gaji->p1_1 == 0) {
                        if ($skl) {
                            $tingkat = ($grade ? $grade->amount : 0);
                        } else {
                            $tingkat = 0;
                        }
                    } else {
                        $tingkat = $gaji->p1_1;
                    }
                    if ($gaji->p1_2 == 0) {
                        $masa = $interval->y * 25000;
                    } else {
                        $masa = $gaji->p1_2;
                    }
                    $total_p1 = $tingkat + $masa;
                    ?>
                    <table cellpadding="5" cellspacing="5">
                        <tr>
                            <td>Unit Kerja</td>
                            <td>: </td>
                            <td><?= empty($pnr) ? '' : $pnr->name ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Masuk</td>
                            <td>: </td>
                            <td><?= empty($pnr) ? '' : date_indo($pnr->date) ?></td>
                        </tr>
                        <tr>
                            <td>Pendidikan Terakhir</td>
                            <td>: </td>
                            <td><?= ($skl ? $skl->name : "<span class='text-danger'>Mohon tentukan pendidikan terakhirnya</span>") ?></td>
                        </tr>
                        <tr>
                            <td>Masa Kerja</td>
                            <td>: </td>
                            <td><?= $interval->y ?> tahun</td>
                        </tr>
                    </table>
                    <hr>
                    <div class="clearfix"></div>
                    <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Pay For Person (P1)</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Pay For Person (P2)</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Pay For Person (P3)</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="potongan-tab" data-toggle="tab" href="#potongan" role="tab" aria-controls="potongan" aria-selected="false">Potongan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="preview-tab" data-toggle="tab" href="#preview" role="tab" aria-controls="preview" aria-selected="false">Preview</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <form>
                                <input type="hidden" name="karyawan" class="karyawan_p1" value="<?= $idKaryawan ?>">
                                <div class="item form-group">
                                    <label class="col-md-2">Grade</label>
                                    <div class="col-md-10">
                                        <input type="text" name="pay_grade" class="form-control p1_1" <?= $disabled ?> id="pay_grade" autocomplete="off" placeholder="Nomor Indouk Pegawai" value="<?= $tingkat ?>">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Masa Kerja</label>
                                    <div class="col-md-10">
                                        <input type="text" name="pay_masa" class="form-control p1_2" <?= $disabled ?> id="pay_masa" autocomplete="off" placeholder="Nomor Indouk Pegawai" value="<?= $masa ?>">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Total</label>
                                    <div class="col-md-10">
                                        <input type="text" name="total_p1" class="form-control total_p1" id="total_p1" readonly autocomplete="off" placeholder="Nomor Indouk Pegawai" value="<?= $total_p1 ?>">
                                    </div>
                                </div>
                                <?php if ($gaji->status == 0) { ?>
                                    <div class="item form-group">
                                        <label class="col-md-2"></label>
                                        <div class="col-md-10">
                                            <button class="btn btn-primary" onclick="handlerSavePayrolP1()" <?= $disabled ?> type="button"><i class="fa fa-save"></i> Simpan</button>
                                        </div>
                                    </div>
                                <?php } ?>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="potongan" role="tabpanel" aria-labelledby="potongan-tab">
                            <?php
                            $cek_pot = $this->db->like('date', date("Y-m"))->get_where("potongan", ['karyawan' => $idKaryawan])->num_rows();
                            $pot = $this->db->like('date', date("Y-m"))->get_where("potongan", ['karyawan' => $idKaryawan])->row();
                            ?>
                            <form>
                                <input type="hidden" name="karyawan" class="karyawan_potongan" value="<?= $idKaryawan ?>">
                                <div class="item form-group">
                                    <label class="col-md-2">Potongan DPLK</label>
                                    <div class="col-md-10">
                                        <input type="text" name="dplk" class="form-control" <?= $disabled ?> value="<?= ($cek_pot != 0 ? $pot->dplk : 0) ?>" id="dplk" autocomplete="off" placeholder="0">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Potongan Lainnya</label>
                                    <div class="col-md-10">
                                        <input type="text" name="pot_lainnya" class="form-control" <?= $disabled ?> id="pot_lainnya" value="<?= ($cek_pot != 0 ? $pot->pot_lainnya : 0) ?>" autocomplete="off" placeholder="0">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Total</label>
                                    <div class="col-md-10">
                                        <input type="text" name="total_potongan" class="form-control" id="total_potongan" value="<?= ($cek_pot != 0 ? $pot->total_potongan : 0) ?>" readonly autocomplete="off" placeholder="0">
                                    </div>
                                </div>
                                <?php if ($gaji->status == 0) { ?>
                                    <div class="item form-group">
                                        <label class="col-md-2"></label>
                                        <div class="col-md-10">
                                            <button class="btn btn-primary" <?= $disabled ?> onclick="handlerPotonganPayroll()" type="button"><i class="fa fa-save"></i> Simpan</button>
                                        </div>
                                    </div>
                                <?php } ?>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <?php if (isset($show_tunjangan)) { ?>
                                <form>
                                    <input type="hidden" name="karyawan" class="karyawan_p2" value="<?= $idKaryawan ?>">
                                    <?php
                                    $total_tunjangan = 0;
                                    foreach ($show_tunjangan as $key => $value) {
                                        if ($key != "karyawan") {
                                            $total_tunjangan += $value;
                                    ?>
                                            <div class="item form-group">
                                                <label class="col-md-2"><?= $key ?></label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control <?= $disabled ?> <?= strtolower($key) ?>_tunjangan" autocomplete="off" placeholder="0" value="<?= $value ?>">
                                                </div>
                                            </div>
                                    <?php }
                                    } ?>
                                    <input type="hidden" class="total" value="<?= $total_tunjangan ?>">
                                    <div class="item form-group">
                                        <label class="col-md-2">Total</label>
                                        <div class="col-md-10">
                                            <input type="text" name="total_tunjangan" <?= $disabled ?> class="form-control total_tunjangan" readonly autocomplete="off" placeholder="0i" value="<?= $total_tunjangan ?>">
                                        </div>
                                    </div>
                                    <?php if ($gaji->status == 0) { ?>
                                        <div class="item form-group">
                                            <label class="col-md-2"></label>
                                            <div class="col-md-10">
                                                <button class="btn btn-primary" <?= $disabled ?> onclick="handlerSavePayrolP2()" type="button"><i class="fa fa-save"></i> Simpan</button>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </form>
                            <?php } else { ?>
                                <div class="alert alert-danger">
                                    <h4>Tunjangan kosong, silahkan setting tunjangan terlebih dahulu</h4>
                                </div>
                            <?php } ?>

                        </div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <?php if (isset($show_bonus)) { ?>
                                <form>
                                    <input type="hidden" name="karyawan" class="karyawan_p3" value="<?= $idKaryawan ?>">
                                    <?php
                                    $total_bonus = 0;
                                    foreach ($show_bonus as $key => $value) {
                                        if ($key != "karyawan") {
                                            $total_bonus += $value;
                                    ?>
                                            <div class="item form-group">
                                                <label class="col-md-2"><?= $key ?></label>
                                                <div class="col-md-10">
                                                    <input type="text" <?= $disabled ?> class="form-control <?= strtolower($key) ?>_bonus" autocomplete="off" placeholder="0" value="<?= $value ?>">
                                                </div>
                                            </div>
                                    <?php }
                                    } ?>
                                    <div class="item form-group">
                                        <label class="col-md-2">Total</label>
                                        <div class="col-md-10">
                                            <input type="text" <?= $disabled ?> class="form-control total_p3" readonly autocomplete="off" placeholder="0" value="<?= $total_bonus ?>">
                                        </div>
                                    </div>
                                    <?php if ($gaji->status == 0) { ?>
                                        <div class="item form-group">
                                            <label class="col-md-2"></label>
                                            <div class="col-md-10">
                                                <button class="btn btn-primary" <?= $disabled ?> onclick="handlerSavePayrolP3()" type="button"><i class="fa fa-save"></i> Simpan</button>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </form>
                            <?php } else { ?>
                                <div class="alert alert-danger">
                                    <h4>Bonus kosong, silahkan setting bonus terlebih dahulu</h4>
                                </div>
                            <?php } ?>

                        </div>
                        <div class="tab-pane fade" id="preview" role="tabpanel" aria-labelledby="preview-tab">
                            <table cellpadding="5" cellspacing="5">
                                <tr>
                                    <td> Total Pay For Person (P1)</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->p1) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Pay For Person (P2)</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->p2) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Pay For Person (P3)</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->p3) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Potongan</td>
                                    <td>:</td>
                                    <td><?= rupiah(($potongan ? $potongan->total_potongan : 0)) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Gaji</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->total - ($potongan ? $potongan->total_potongan : 0)) ?></td>
                                </tr>
                            </table>
                            <hr>
                            <div class="clearfix"></div>
                            <?php if ($gaji->status == 0) { ?>
                                <table cellpadding="5" cellspacing="5">
                                    <tr>
                                        <td>
                                            <form>
                                                <input type="hidden" name="karyawan" class="karyawan_total" value="<?= $idKaryawan ?>">
                                                <input type="hidden" value="<?= $gaji->p1 + $gaji->p2 + $gaji->p3 ?>" class="total_gaji">
                                                <button class="btn btn-primary" <?= $disabled ?> onclick="handlerCountGaji()" type="button"><i class="fa fa-save"></i> Jumlahkan</button>
                                            </form>
                                        </td>
                                        <td>
                                            <?php if ($gaji->total != 0) { ?>
                                                <form>
                                                    <input type="hidden" name="karyawan" class="users" value="<?= $idKaryawan ?>">
                                                    <input type="hidden" value="<?= date("Y-m-d") ?>" class="tgl">
                                                    <button class="btn btn-success" <?= $disabled ?> onclick="handlerGeneratePayrolGaji()" type="button"><i class="fa fa-save"></i> Simpan</button>
                                                </form>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                </table>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#initDataGajiKaryawan').DataTable();
    })
</script>