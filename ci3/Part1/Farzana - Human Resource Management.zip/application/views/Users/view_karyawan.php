<?php if (isset($_GET['del'])) {
  $this->db->delete("karyawan", ['id' => $_GET['del']]);
  $this->session->set_flashdata("success", 'Data karyawan berhasil dihapus');
} ?>

<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?> <?= $dataUser->name ?></h3>

    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">

    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_title">
          <a href="<?= base_url('Users/Karyawan') ?>" class="btn btn-sm btn-dark pull-right"><i class="fa fa-arrow-left"></i> Kembali</a>
          <a href='#' class='btn btn-sm btn-danger pull-right' data-toggle='modal' data-target='.data<?= $dataUser->id ?>'><i class='fa fa-trash'></i> Hapus</a>
          <div class="clearfix"></div>
        </div>
        <div class="x_content table-responsive">
          <table class="table table-striped" width="100%">
            <tr>
              <td width="30%">Nama</td>
              <td width="2%"> : </td>
              <td width="68%"><?= $dataUser->name ?></td>
            </tr>
            <tr>
              <td>NIP</td>
              <td> : </td>
              <td><?= $dataUser->nip ?></td>
            </tr>
            <tr>
              <td>No. NPWP</td>
              <td> : </td>
              <td><?= $dataUser->no_npwp ?></td>
            </tr>
            <tr>
              <td>No. KTP</td>
              <td> : </td>
              <td><?= $dataUser->no_ktp ?></td>
            </tr>
            <tr>
              <td>Tempat, Tanggal Lahir</td>
              <td> : </td>
              <td><?= $dataUser->tmp_lahir ?>, <?= date_indo($dataUser->tgl_lahir) ?></td>
            </tr>
            <tr>
              <td>Email</td>
              <td> : </td>
              <td><?= $dataUser->email ?></td>
            </tr>
            <tr>
              <td>Jenis Kelamin</td>
              <td> : </td>
              <td><?= $dataUser->jenis_kelamin == 0 ? 'Laki - Laki' : 'Perempuan' ?></td>
            </tr>
            <tr>
              <td>Alamat sesuai KK</td>
              <td> : </td>
              <td>
                <p>Provinsi : <?= $dataUser->provinsi_kk == null ? '-' : $dataUser->provinsi_kk ?></p>
                <p>Kab/Kota : <?= $dataUser->kota_kk == null ? '-' : $dataUser->kota_kk ?></p>
                <p>Kecamatan : <?= $dataUser->kecamatan_kk == null ? '-' : $dataUser->kecamatan_kk ?></p>
                <p>Kelurahan/Desa : <?= $dataUser->desa_kk == null ? '-' : $dataUser->desa_kk ?></p>
                <p>Alamat : <?= $dataUser->alamat == null ? '-' : $dataUser->alamat ?></p>
              </td>
            </tr>
            <tr>
              <td>Alamat Domisili</td>
              <td> : </td>
              <td>
                <p>Provinsi : <?= $dataUser->provinsi_dom == null ? '-' : $dataUser->provinsi_dom ?></p>
                <p>Kab/Kota : <?= $dataUser->kota_dom == null ? '-' : $dataUser->kota_dom ?></p>
                <p>Kecamatan : <?= $dataUser->kecamatan_dom == null ? '-' : $dataUser->kecamatan_dom ?></p>
                <p>Kelurahan/Desa : <?= $dataUser->desa_dom == null ? '-' : $dataUser->desa_dom ?></p>
                <p>Alamat : <?= $dataUser->alamat_domisili == null ? '-' : $dataUser->alamat_domisili ?></p>
              </td>
            </tr>
            <tr>
              <td>Tanggal Daftar</td>
              <td> : </td>
              <td><?= longdate_indo(date('Y-m-d'), strtotime($dataUser->created_at)) ?></td>
            </tr>
            <tr>
              <td>Status Akun</td>
              <td> : </td>
              <td><?= $dataUser->status == 0 ? 'Nonactive' : 'Active' ?></td>
            </tr>
          </table>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>

<div class="modal fade data<?= $dataUser->id ?>" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <h6>Pastikan anda yakin akan menghapus data karyawan <strong><?= $dataUser->name ?></strong></h6>
      </div>
      <div class="modal-footer">
        <a class="btn btn-danger" href="?del=<?= $dataUser->id ?>">Hapus Data</a>
      </div>

    </div>
  </div>
</div>