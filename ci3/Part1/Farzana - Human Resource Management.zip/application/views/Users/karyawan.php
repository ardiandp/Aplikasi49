<?php if (isset($_GET['del'])) {
  $gaji = where_count('gaji', ['karyawan' => $_GET['del']]);
  if ($gaji == 0) {
    $this->db->delete("karyawan", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data karyawan berhasil dihapus');
    redirect("Users/karyawan");
  } else {
    $this->session->set_flashdata("error", 'Data tidak dapat dihapus, karena sudah terdapat history transaksi system');
    redirect("Users/karyawan");
  }
} ?>

<style>
  .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    cursor: pointer !important;
  }

  div.dt-buttons {
    clear: both;
  }
</style>

<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>

    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">

    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Data Karyawan</h2>
          <!-- <a href="<?= base_url('Users/Karyawan/form_karyawan') ?>" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Tambah Karyawan</a>
          <button type="button" class="btn btn-sm btn-info pull-right" onclick="handlerSendEmailKaryawan()"><i class="fa fa-envelope"></i> Multiple undang karyawan by email</button>
          <a href="" class="btn btn-sm btn-primary pull-right"><i class="fa fa-print"></i> Cetak Data Rekening</a>
          <button type="button" class="btn btn-sm btn-primary pull-right" onclick="handlerShowModalImport()"><i class="fa fa-upload"></i> Import Data</button> -->
          <div class="clearfix"></div>
        </div>
        <div class="x_content table-responsive">
          <table id="initDataKaryawan" class="table table-striped table-bordered" style="width:100%">
            <thead>
              <tr class="bg-dark text-white">
                <td width="5%">
                  <input type="checkbox" name="select_all" style="transform: scale(1.5)" value="1" id="example-select-all">
                </td>
                <td>NIP</td>
                <td>No. KTP</td>
                <td>Nama Lengkap</td>
                <td>No. HP</td>
                <td>Email</td>
                <td>Invited</td>
                <td>Aksi</td>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($data as $key => $value) { ?>
                <tr>
                  <td>
                    <input type="checkbox" class="form-control check-item" name="check-item" style="transform: scale(0.5)" <?= $value->is_invited == 1 ? 'disabled checked' : '' ?> id="check-item" value="<?= $value->id ?>" />
                  </td>
                  <td><?= $value->nip ?></td>
                  <td><?= $value->no_ktp ?></td>
                  <td><?= $value->name ?></td>
                  <td><?= $value->phone ?></td>
                  <td><?= $value->email ?></td>
                  <td>
                    <input type="checkbox" value="<?= $value->id ?>" class="js-switch switchBtn" <?= $value->is_invited == 1 ? 'checked' : '' ?> onchange="handlerSwitchInvited(this)" />
                  </td>
                  <td>
                    <div class="d-flex align-items-center justify-content-center">
                      <a href="<?= base_url('Users/Karyawan/form_karyawan?id=' . $value->id) ?>" class=" btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                      <a href="<?= base_url('Users/Karyawan/form_karyawan?id=' . $value->id . "&mode=view") ?>" class=" btn btn-sm btn-info"><i class="fa fa-eye"></i></a>
                      <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data<?= $value->id ?>'><i class='fa fa-trash'></i></a>
                    </div>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>

<?php $no = 0;
foreach ($data as $key) { ?>
  <div class="modal fade data<?= $key->id ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">

        <div class="modal-header">
          <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <h6>Pastikan anda yakin akan menghapus data karyawan <strong><?= $key->name ?></strong></h6>
        </div>
        <div class="modal-footer">
          <a class="btn btn-danger" href="?del=<?= $key->id ?>">Hapus Data</a>
        </div>

      </div>
    </div>
  </div>
<?php } ?>

<div class="modal fade" id="modalAddWaktu" role="dialog" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel2">Waktu undangan email</h4>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="form-group">
            <label>Waktu Batas Edit Data</label> <small class="text-danger">Default 7 hari</small>
            <input type="hidden" name="type" id="type" class="form-control" placeholder="waktu batas edit data users / karyawan">
            <input type="text" name="waktu" id="waktu" class="form-control numeric" placeholder="waktu batas edit data users / karyawan" autocomplete="off">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary sendEmail" type="button" onclick="sendEmail(event)">Send Email</button>
        <button class="btn btn-dark" type="button" onclick="closeModal()">kembali</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalImportData" role="dialog" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel2">Import Data Pegawai</h4>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="d-flex">
            <p class="mr-3">Sebelum import data, silahkan download template excel berikut</p>
            <a href="<?= base_url('assets/upload/import_template/template_import.xlsx') ?>" target="_BLANK" class="btn btn-primary btn-sm"><i class="fa fa-cloud-download"></i> Download Template</a>
          </div>

          <div class="row mt-3">
            <div class="col-8">
              <div class="item form-group">
                <label class="col-form-label col-md-3 col-sm-3 label-align" for="filterTanggal">File Import <span class="required">*</span>
                </label>
                <div class="col-md-9 col-sm-9 ">
                  <input type="file" name="importFile" id="importFile" class="form-control" required accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
                </div>
              </div>
            </div>
            <div class="col-4">
              <div class="item form-group">
                <!-- <button class="btn btn-info btn-sm" onclick="handlerPreviewImport()">Preview</button> -->
              </div>
            </div>
          </div>

          <div class="mt-3 mb-3" id="previewImport" style="display: none;"></div>

          <div class="mt-4 alert alert-warning w-75">
            <span><i class="fa fa-info"></i> Jangan merubah atau mengedit struktur template yang sudah diberikan</span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" type="button" onclick="handlerRequestImportData(event)"><i class="fa fa-upload"></i> Import Data</button>
        <button class="btn btn-dark" type="button" onclick="closeModalImport()">kembali</button>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function() {
    $(document).on("input", ".numeric", function(event) {
      this.value = this.value.replace(/[^0-9]/g, '');
    });

    // initDataTableKaryawan()
  })

  const initDataTableKaryawan = () => {
    let tableInit = $("#initDataKaryawan").DataTable({
      columnDefs: [{
        sortable: false,
        targets: [0]
      }],
      dom: 'Bfrtip',
      buttons: [{
          text: '<i class="fa fa-upload"></i> Import Data',
          className: 'btn btn-primary',
          action: function(e, dt, node, config) {
            handlerShowModalImport();
          }
        },
        {
          text: '<i class="fa fa-envelope"></i> Multiple undang karyawan by email',
          className: 'btn btn-info',
          action: function(e, dt, node, conf) {
            handlerSendEmailKaryawan()
          }
        },
        {
          text: '<i class="fa fa-user-plus"></i> Tambah Karyawan',
          className: 'btn btn-success',
          action: function(e, dt, node, conf) {
            location.href = "<?= base_url('Users/Karyawan/form_karyawan') ?>";
          }
        }
      ]
    });
  }

  let table = initDataTableKaryawan()

  // Handle click on "Select all" control
  $('#example-select-all').on('click', function() {
    // Get all rows with search applied
    let rows = table.rows({
      'search': 'applied'
    }).nodes();

    // Check/uncheck checkboxes for all rows in the table
    $('input[name*="check-item"]', rows).map(function() {
      if (this.checked == false) {
        if (!this.disabled) {
          return this.checked = true;
        }
      } else {
        if (!this.disabled) {
          return this.checked = false;
        }
      }
    });
  });

  // Handle click on checkbox to set state of "Select all" control
  $('#initDataKaryawan tbody').on('change', 'input[name*="check-item"]', function() {
    // If checkbox is not checked
    if (!this.checked && !this.disabled) {
      let el = $('#example-select-all').get(0);
      // If "Select all" control is checked and has 'indeterminate' property
      if (el && el.checked && ('indeterminate' in el)) {
        // Set visual state of "Select all" control
        // as 'indeterminate'
        el.indeterminate = true;
      }
    }
  });

  const handlerSendEmailKaryawan = () => {

    $('#modalAddWaktu').modal('show');
    $('#type').val('multiple');
  }

  const closeModal = () => {
    $('#modalAddWaktu').modal('hide');
    $('#type').val('');
    $('#waktu').val('');
  }

  function handlerSwitchInvited(event) {
    let dataChecked = event.value;
    if (event.checked == true) {
      $('#modalAddWaktu').modal('show');
      $('#type').val('single');
      $(".sendEmail").attr('data-id', dataChecked);
    } else {
      // $(this).prop('checked', true);
      sendEmailRequest(dataChecked, 'uninvited')
    }
  }

  const sendEmail = (event) => {
    if ($('#type').val() == 'multiple') {
      let rows = table.rows({
        'search': 'applied'
      }).nodes();

      const dataChecked = $('input[name*="check-item"]', rows).map(function() {
        if (this.checked == true && !this.disabled) {
          return this.value
        }
      }).get()

      if (dataChecked.length == 0) {
        new PNotify({
          text: 'pilih 1 data karyawan untuk undang by email',
          type: 'error',
          styling: 'bootstrap3',
          delay: 2000,
          history: false
        })
        return false;
      }

      sendEmailRequest(dataChecked, null)
    }

    if ($('#type').val() == 'single') {
      sendEmailRequest(event.currentTarget.getAttribute('data-id'), 'invited')
    }
  }

  const sendEmailRequest = (dataChecked, type) => {
    $.ajax({
      type: 'POST',
      url: "<?= base_url('Users/Karyawan/saveKaryawanByEmail') ?>",
      dataType: "JSON",
      data: {
        dataChecked,
        type,
        waktu: $('#waktu').val()
      },
      beforeSend: function() {
        Swal.fire({
          title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
          showConfirmButton: false,
          allowOutsideClick: false
        });
      },
      success: function(response) {
        if (response.type == 200) {
          new PNotify({
            text: response.message,
            type: 'success',
            styling: 'bootstrap3',
            delay: 2000,
            history: false
          })

          location.reload();
        }

        if (response.type == 202) {

          $.each(response.data, function(i, v) {
            new PNotify({
              text: `Email dari username <strong>${v}</strong> kosong, silahkan update data karyawan terlebih dahulu`,
              type: 'error',
              styling: 'bootstrap3',
              delay: 2000,
              history: false
            });
          })
        }

        if (response.type == 203) {
          new PNotify({
            text: response.message,
            type: 'error',
            styling: 'bootstrap3',
            delay: 2000,
            history: false
          })
        }
      },
      error: function(xhr) { // if error occured
        Swal.fire({
          title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
          showConfirmButton: false,
          allowOutsideClick: false,
          timer: 10
        });
      },
      complete: function() {
        Swal.fire({
          title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
          showConfirmButton: false,
          allowOutsideClick: false,
          timer: 10
        });
      },
    });
  }

  const handlerShowModalImport = () => {
    $('#modalImportData').modal('show');
  }
  const closeModalImport = () => {
    $('#modalImportData').modal('hide');
  }

  const handlerPreviewImport = () => {
    if ($('#importFile').val() == '') {
      showMessage('error', 'File import harus terisi')
      return false;
    }

    let formData = new FormData();
    formData.append("files", $("#importFile")[0].files[0]);

    Swal.fire({
      title: "Are you sure?",
      text: "Import data?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, Sure",
      cancelButtonText: "No, Close",
    }).then((result) => {
      if (result.value == true) {
        $.ajax({
          type: "POST",
          url: "<?= base_url('Users/Karyawan/requestPreviewImport') ?>",
          data: formData,
          contentType: false,
          processData: false,
          dataType: "json",
          beforeSend: function() {
            Swal.fire({
              title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
              showConfirmButton: false,
              allowOutsideClick: false
            });
          },
          success: function(response) {
            $('#previewImport').empty();
            $('#previewImport').show();
            if (response.length > 0) {
              let numrow = 1;
              let kosong = 0;
              $.each(response, function(i, v) {
                // $nis_td = (!empty($nis)) ? "" : " style='background: #E07171;'";
                // $nama_td = (!empty($nama)) ? "" : " style='background: #E07171;'"; 
                // $jk_td = (!empty($jenis_kelamin)) ? "" : " style='background: #E07171;'"; 
                // $telp_td = (!empty($telp)) ? "" : " style='background: #E07171;'"; 
                // $alamat_td = (!empty($alamat)) ? "" : " style='background: #E07171;'"; 
                // // Jika salah satu data ada yang kosong
                // if ($nis == ""
                //   or $nama == ""
                //   or $jenis_kelamin == ""
                //   or $telp == ""
                //   or $alamat == "") {
                //   $kosong++; // Tambah 1 variabel $kosong
                // }
              })
            }
          }
        });
      }
    });
  }

  const handlerRequestImportData = (event) => {
    if ($('#importFile').val() == '') {
      showMessage('error', 'File import harus terisi')
      return false;
    }

    let formData = new FormData();
    formData.append("files", $("#importFile")[0].files[0]);

    Swal.fire({
      title: "Are you sure?",
      text: "Import data?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, Sure",
      cancelButtonText: "No, Close",
    }).then((result) => {
      if (result.value == true) {
        $.ajax({
          type: "POST",
          url: "<?= base_url('Users/Karyawan/requestImportData') ?>",
          data: formData,
          contentType: false,
          processData: false,
          dataType: "json",
          beforeSend: function() {
            Swal.fire({
              title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
              showConfirmButton: false,
              allowOutsideClick: false
            });
          },
          success: function(response) {
            if (response.status == 201) {
              showMessage('success', response.message)
              setTimeout(() => {
                Swal.fire({
                  title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                  showConfirmButton: false,
                  timer: 1500,
                });
                location.reload()
              }, 1500);
            }
            if (response.status == 400) {
              showMessage('error', response.message)
            }
          },
          error: function(xhr) { // if error occured
            Swal.fire({
              title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
              showConfirmButton: false,
              allowOutsideClick: false,
              timer: 10
            });
          },
          complete: function() {
            Swal.fire({
              title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
              showConfirmButton: false,
              allowOutsideClick: false,
              timer: 10
            });
          },
        });
      }
    });

  }
</script>