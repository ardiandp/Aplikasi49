<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>

        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Transaksi Keuangan</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <?php if ($this->session->userdata('user') == 'admin') { ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="item form-group">
                                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Karyawan<span class="required">*</span></label>
                                    <div class="col-md-4 col-sm-4 ">
                                        <input type="hidden" class="form-control" name="idTransaksiKeuangan" id="idTransaksiKeuangan">
                                        <select class="form-control select2" name="idkaryawan" id="idkaryawan">
                                            <option value="">Pilih Karyawan</option>
                                            <?php foreach (show_data("karyawan") as $un) {
                                                echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                            } ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4 col-sm-4 ">
                                        <button type="button" class="btn btn-primary transaksiKeuanganBtn" onclick="handlerFilterDataTransaksiKeuangan()"><i class="fa fa-search"></i> Filter</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="table-responsive mt-3">
                        <table class="table table-striped" width="100%" style="font-size: 12px;" id="initDataTransaksiKeuangan">
                            <thead>
                                <tr class="bg-dark text-white text-center">
                                    <td><strong>No.</strong></td>
                                    <td><strong>Jenis Transaksi Keuangan</strong></td>
                                    <td><strong>Nominal</strong></td>
                                    <td><strong>Tanggal</strong></td>
                                    <td><strong>Action</strong></td>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddTransaksiKeuangan" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="row">
                        <input type="hidden" class="form-control" name="idTransaksiKeuangan" id="idTransaksiKeuangan">
                        <?php if ($this->session->userdata('user') == 'admin') { ?>
                            <div class="col-md-12">
                                <div class="item form-group">
                                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Karyawan<span class="required">*</span></label>
                                    <div class="col-md-9 col-sm-9 ">

                                        <select class="form-control select2" name="idkaryawanModal" id="idkaryawanModal">
                                            <option value="">Pilih Karyawan</option>
                                            <?php foreach (show_data("karyawan") as $un) {
                                                echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                            } ?>

                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="col-md-12">
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align">Jenis<span class="required">*</span></label>
                                <div class="col-md-9 col-sm-9 ">
                                    <select name="jenisTransaksi" id="jenisTransaksi" class="form-control select2" required>
                                        <option>--Pilih Jenis--</option>
                                        <?php foreach ($jenisTransaksiKeuangan as $value) { ?>
                                            <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align">Nominal<span class="required">*</span></label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input type="text" class="form-control numeric" name="nominalTransaksi" id="nominalTransaksi" placeholder="Nominal" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align">Tanggal<span class="required">*</span></label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input type="date" class="form-control numeric" name="dateTransaksi" id="dateTransaksi" placeholder="Nomnimal" value="<?= date("Y-m-d") ?>" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary transaksiKeuanganBtn" onclick="handlerSaveDataTransaksiKeuangan(event)"><i class="fa fa-save"></i> Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalTransaksiKeuangan()">kembali</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalDeleteData" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <button class="btn btn-danger deleteData" type="button" onclick="handlerDeleteData(event)">Delete Data</button>
            </div>

        </div>
    </div>
</div>

<script>
    const initConfigDatatable = {
        dom: 'Bfrtip',
        buttons: [{
                extend: "print",
                text: '<i class="fa fa-print"></i> Print',
                className: 'btn btn-warning',
                customize: function(win) {

                    var last = null;
                    var current = null;
                    var bod = [];

                    var css = '@page { size: landscape; }',
                        head = win.document.head || win.document.getElementsByTagName('head')[0],
                        style = win.document.createElement('style');

                    style.type = 'text/css';
                    style.media = 'print';

                    if (style.styleSheet) {
                        style.styleSheet.cssText = css;
                    } else {
                        style.appendChild(win.document.createTextNode(css));
                    }

                    head.appendChild(style);
                }
            },
            {
                extend: 'excelHtml5',
                text: '<i class="fa fa-file-excel-o"></i> Excel',
                className: 'btn btn-success',
            },
            {
                extend: 'csvHtml5',
                text: '<i class="fa fa-file"></i> CSV',
                className: 'btn btn-info',
            },
            {
                extend: 'pdfHtml5',
                orientation: 'landscape',
                text: '<i class="fa fa-file-pdf-o"></i> PDF',
                className: 'btn btn-danger',
                pageSize: 'LEGAL'
            }, {
                text: '<i class="fa fa-plus"></i> Tambah Transaksi Keuangan',
                className: 'btn btn-success',
                action: function(e, dt, node, conf) {
                    handlerAddTransaksikeuangan()
                }
            }
        ]
    }

    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });

        $(document).on("input", ".numeric", function(event) {
            this.value = this.value.replace(/[^\d.]+/g, '');
        });

        $('#initDataTransaksiKeuangan').DataTable(initConfigDatatable);

        <?php if ($this->session->userdata('user') == 'pegawai') { ?>
            initRequestTransaksiKeuangan("<?= $this->session->userdata('id') ?>")
        <?php } ?>
    })

    const handlerFilterDataTransaksiKeuangan = () => {
        let idKaryawan = $('#idkaryawan').val()

        if (idKaryawan == "") {
            showMessage('error', 'Karyawan harus terisi')
            return false;
        }

        initRequestTransaksiKeuangan(idKaryawan)
    }

    const initRequestTransaksiKeuangan = (idKaryawan) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataTransaksiKeuangan') ?>",
            data: {
                idUsers: idKaryawan
            },
            dataType: "JSON",
            success: function(response) {
                $('#initDataTransaksiKeuangan > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {

                        $('#initDataTransaksiKeuangan > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.name}</td>
                                <td>Rp. ${v.nominal}</td>
                                <td>${formatTanggal(v.tanggal)}</td>
                                <td>
                                    <div class="d-flex align-items-center justify-content-center">
                                        <button class="btn btn-warning btn-sm" onclick="handlerEditTransaksiKeuangan('${v.id}')"><i class="fa fa-edit"></i></button>
                                        <button class="btn btn-danger btn-sm" onclick="handlerHapusDataTransaksiKeuangan('${v.id}')"><i class="fa fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        `);

                    })
                } else {
                    $('#initDataTransaksiKeuangan > tbody').append(`<tr><td class="text-center text-danger" colspan="5">Data kosong</td></tr>`)
                }
            }
        });
    }

    const resetFormTransaksikeuangan = () => {
        $('#idTransaksiKeuangan').val('')
        $('#idkaryawanModal').prop("selectedIndex", 0).trigger('change')
        $('#jenisTransaksi').prop("selectedIndex", 0).trigger('change')
        $('#nominalTransaksi').val('')
        $('#dateTransaksi').val('')
    }

    const handlerAddTransaksikeuangan = () => {
        $("#modalAddTransaksiKeuangan").modal('show')
        $("#modalAddTransaksiKeuangan .modal-title").html('Tambah Transaksi keuangan')
        $(".transaksiKeuanganBtn").attr('data-mode', 'insert');
    }

    const handlerEditTransaksiKeuangan = (idTransaksi) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataTransaksiKeuanganById') ?>",
            data: {
                idTransaksi
            },
            dataType: "JSON",
            success: function(response) {
                $("#modalAddTransaksiKeuangan").modal('show')
                $("#modalAddTransaksiKeuangan .modal-title").html('Edit Transaksi keuangan')
                $(".transaksiKeuanganBtn").attr('data-mode', 'update');

                $('#idTransaksiKeuangan').val(response.id)
                <?php if ($this->session->userdata('user') == 'admin') { ?>
                    $('#idkaryawanModal').val(response.id_karyawan).trigger('change')
                <?php } ?>
                $('#jenisTransaksi').val(response.id_jenis_transaksi_keuangan).trigger('change')
                $('#nominalTransaksi').val(response.nominal)
                $('#dateTransaksi').val(response.tanggal)
            }
        });
    }

    const handlerHapusDataTransaksiKeuangan = (idTransaksiKeuangan) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idTransaksiKeuangan)
        $('.deleteData').attr('data-modul', 'TransaksiKeuangan')
        $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data Transaksi Keuangan</h6>`);
    }

    const closeModalTransaksiKeuangan = () => {
        $("#modalAddTransaksiKeuangan").modal('hide')
        resetFormTransaksikeuangan()
    }

    const handlerSaveDataTransaksiKeuangan = (event) => {
        let mode = event.currentTarget.getAttribute('data-mode');
        let idKaryawan = $('#idkaryawanModal').val()
        let idTransaksiKeuangan = $('#idTransaksiKeuangan').val()
        let jenisTransaksi = $('#jenisTransaksi').val()
        let nominalTransaksi = $('#nominalTransaksi').val()
        let dateTransaksi = $('#dateTransaksi').val()

        <?php if ($this->session->userdata('user') == 'admin') { ?>
            if (idKaryawan == "") {
                showMessage('error', 'Karyawan harus terisi')
                return false;
            }
        <?php } ?>

        if (jenisTransaksi == "") {
            showMessage('error', 'Jenis harus terisi')
            return false;
        }

        if (nominalTransaksi == "") {
            showMessage('error', 'Nominal harus terisi')
            return false;
        }

        if (dateTransaksi == "") {
            showMessage('error', 'Tanggal harus terisi')
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('TransaksiKeuangan/saveTransaksiKeuangan') ?>",
            dataType: "JSON",
            data: {
                idTransaksiKeuangan: mode !== null ? idTransaksiKeuangan : null,
                idUsers: "<?= $this->session->userdata('user') ?>" == 'admin' ? idkaryawan : "<?= $this->session->userdata('id') ?>",
                mode,
                jenisTransaksi,
                nominalTransaksi,
                dateTransaksi
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    setTimeout(() => window.location.reload(), 800);
                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const handlerDeleteData = (event) => {
        let id = event.currentTarget.getAttribute('data-id');
        let type = event.currentTarget.getAttribute('data-type');
        let modul = event.currentTarget.getAttribute('data-modul');

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/deleteData') ?>",
            dataType: "JSON",
            data: {
                id,
                type,
                modul
            },
            success: function(response) {
                if (response.status == 200) {
                    if (modul == 'TransaksiKeuangan') {
                        showMessage('success', response.message)
                        $('#modalDeleteData').modal('hide');
                        setTimeout(() => window.location.reload(), 800);
                    }

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });

    }
</script>