<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Filter Presensi Kehadiran</h2>
                    <div class="testButton pull-right"></div>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="container">
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="idkaryawan">Karyawan <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 ">
                                <select class="form-control select2" name="idkaryawan" id="idkaryawan">
                                    <option value="">Pilih Karyawan</option>
                                    <?php foreach (show_data("karyawan") as $un) {
                                        echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                    } ?>
                                </select>
                            </div>
                        </div>

                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="filterTanggal">Tanggal <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 ">
                                <input type="text" id="filterTanggal" class="form-control input-sm datepicker" name="filterTanggal" autocomplete="off">
                            </div>
                        </div>

                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align"></label>
                            <div class="col-md-6 col-sm-6 ">
                                <button class="btn btn-primary" onclick="handlerFilterKehadiran()"><i class="fa fa-seacrh"></i> Filter</button>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 mt-3">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover" id="initDataPresensi">
                                        <thead>
                                            <tr class="bg-dark text-white text-center">
                                                <td rowspan="2"><strong>Karyawan</strong></td>
                                                <td rowspan="2"><strong>Hari</strong></td>
                                                <td rowspan="2"><strong>Tanggal</strong></td>
                                                <td colspan="2"><strong>Jadwal Absen</strong></td>
                                                <td colspan="2"><strong>Jam Absen</strong></td>
                                                <td colspan="2"><strong>Status Absen</strong></td>
                                            </tr>
                                            <tr class="bg-dark text-center text-white">
                                                <td><strong>Jadwal Masuk</strong></td>
                                                <td><strong>Jadwal Pulang</strong></td>
                                                <td><strong>Jam Masuk</strong></td>
                                                <td><strong>Jam Pulang</strong></td>
                                                <td><strong>Status Masuk</strong></td>
                                                <td><strong>Status Pulang</strong></td>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $("#initDataPresensi").DataTable(configDatatable);
        $(".select2").select2({
            width: "100%"
        });

        $('#filterTanggal').daterangepicker({
            'applyClass': 'btn-sm btn-success',
            'cancelClass': 'btn-sm btn-default',
            locale: {
                "format": "DD/MM/YYYY",
                applyLabel: 'Apply',
                cancelLabel: 'Cancel',
            },
            'startDate': '<?= date("d-m-Y") ?>',
            'endDate': '<?= date("d-m-Y") ?>'
        });
    })

    const handlerFilterKehadiran = () => {
        let idKaryawan = $("#idkaryawan").val();
        let tanggal = $("#filterTanggal").val();

        if (idKaryawan == '') {
            showMessage('error', `Karyawan tidak boleh kosong`);
            return false;
        }

        $.ajax({
            type: "POST",
            url: '<?= base_url('Absensi/filterPresensi'); ?>',
            data: {
                idKaryawan,
                tanggal
            },
            dataType: 'json',
            success: function(response) {
                if ($.fn.DataTable.isDataTable('#initDataPresensi')) {
                    $('#initDataPresensi').DataTable().destroy();
                }
                $("#initDataPresensi > tbody").empty()
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        $("#initDataPresensi > tbody").append(`
                            <tr>
                                <td class="text-center">${v.karyawan_nama}</td>
                                <td class="text-center">${v.nama_hari}</td>
                                <td class="text-center">${formatTanggal(v.tgl)}</td>
                                <td class="text-center">${v.jadwal_masuk}:00</td>
                                <td class="text-center">${v.jadwal_pulang}:00</td>
                                <td class="text-center">${v.jam_masuk == null ? '-' : v.jam_masuk}</td>
                                <td class="text-center">${v.jam_pulang == null ? '-' : v.jam_pulang}</td>
                                <td>${v.status_masuk == '' ? '-' : v.status_masuk}</td>
                                <td>${v.status_pulang == '' ? '-' : v.status_pulang}</td>
                            </tr>`)
                    })
                } else {
                    $("#initDataPresensi > tbody").append(`<tr><td colspan="10" class="text-center text-danger">Data Kosong</td></tr>`)
                }
                $("#initDataPresensi").DataTable(configDatatable);
            }

        })
    }
</script>