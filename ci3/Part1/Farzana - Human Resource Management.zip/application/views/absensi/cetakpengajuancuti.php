<div id="divatbablecetak" style="border: 1px solid grey; padding: 10px;">
    <div class="container">
        <h3 class="alert alert-info text-center">PERMOHONAN CUTI <?= $id ?></h3>

    </div>
    <table class="table table-bordered " id="tablepengajuancuti1" style="border: 0px;" width="100%">
        <tr>
            <td style="background-color: green;">DIISI OLEH AMIL</td>

        </tr>
        <tr>
            <td style="background: transparent;">&nbsp;</td>
        </tr>
        <tr>
            <td width="10%" style="border: 0px;">Nama</td>
            <td width="1%">:</td>
            <td style="border-bottom: 1pt solid black;" colspan="3"><?= $response->nama_karyawan ?></td>
            <td style="border: 0px;">&nbsp;</td>

            <td width="10%">NIK</td>
            <td width="1%">:</td>
            <td style="border-bottom: 1pt solid black;" colspan="3"><?= $response->no_ktp ?></td>
        </tr>
        <tr>
            <td style="border: 0px;">Jabatan</td>
            <td>:</td>
            <td style="border-bottom: 1pt solid black;" colspan="3"><?= $response->nama_jabatan ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td style="border: 0px;">Bagian/Departemen</td>
            <td>:</td>
            <td style="border-bottom: 1pt solid black;" colspan="3"><?= $response->nama_divisi ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <!-- <td style="border: 0px;"></td>
            <td>:</td>
            <td width="10%" colspan="4">tgl</td>
            <td width="2%">S/D</td>
            <td width="2%" colspan="3">tgl</td>
            <td></td> -->
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>

        </tr>
        <tr>
            <td style="border: 0px;">Mengajuakan Cuti Pada</td>
            <td>:</td>
            <td width="2%" colspan="4"><?= date('d-m-Y', strtotime($response->tgl_mulai)) ?></td>
            <td width="2%">S/D</td>
            <td width="2%" colspan="3"><?= date('d-m-Y', strtotime($response->tgl_akhir)) ?></td>
            <td></td>

        </tr>
        <tr>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>

        </tr>
        <tr>
            <td style="border: 0px;"></td>
            <td></td>
            <td>Jumlah Hari Kerja</td>
            <td width="2%">:</td>
            <td><?= $response->jumlah_hari_kerja ?></td>
            <td width="2">hari</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td>JUMLAH HARI LIBUR / OFF</td>
            <td width="2%">:</td>
            <td><?= $response->jumlah_hari_libur ?></td>
            <td>hari</td>
            <td></td>
            <td>Total Cuti</td>
            <td></td>
            <td><?= $response->lama ?></td>
            <td>hari</td>
        </tr>
        <tr>
            <td style="border: 0px;">Masuk Bekerja Kembali</td>
            <td>:</td>
            <td width="2%" colspan="4"><?= date('d-m-Y', strtotime($response->tgl_masuk)) ?></td>
            <td></td>
        </tr>
        <tr>
            <td style="border: 0px;">Alasan Pengajuan Cuti</td>
            <td>:</td>
            <td colspan="3" style="border-bottom:1px solid black;"><?= $response->keterangan ?></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>

        </tr>
        <tr>
            <td style="border: 0px;">Alamat/Lokasi Selama Cuti</td>
            <td>:</td>
            <td colspan="3" style="border-bottom:1px solid black;"></td>
            <td style="border: 0px;"></td>
            <td style="border: 0px;"></td>

            <td style="border: 0px;"></td>
            <td>NoHp</td>
            <td colspan="2"></td>


        </tr>
        <tr>
            <td style="border: 0px;">Tanda Tangan Pemohon</td>
            <td>:</td>
            <td colspan="3" style="border-bottom:1px solid black;"></td>
            <td></td>
            <td></td>
            <td></td>
            <td width="2%">tgl</td>
            <td width="2%">bln</td>
            <td width="2%">thn</td>
        </tr>



    </table>
    <br>
    <br>
    <table class="table table-bordered " id="tablepengajuancuti2" style="border: 0px;" width="100%">
        <tr>
            <td style="background-color: greenyellow;">KEPUTUSAN</td>
        </tr>
        <tr>
            <td colspan="7">

            </td>

        </tr>
        <tr>
            <td>1. Diketahui</td>
            <td></td>
            <td> Permohonan Ini</td>
            <td>:</td>
            <td><input type="checkbox" class="form-control" name="cbdiketahui" id="cbdiketahui">Diketahui</td>
            <td><input type="checkbox" class="form-control" name="cbditunda" id="cbditunda">Ditunda</td>
            <td><input type="checkbox" class="form-control" name="cbditolak" id="cbditolak">Ditolak</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td> </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class="text-center" colspan="3">Atasan Langsung</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td rowspan="2" colspan="3"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>

        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td colspan="3" class="text-center">Nama</td>

        </tr>
        <tr>
            <td colspan="7">
                <hr style="border-top: 3px dotted  black;">
            </td>

        </tr>
        <tr>
            <td>2. Disetujui</td>
            <td></td>
            <td> Permohonan Ini</td>
            <td>:</td>
            <td><input type="checkbox" class="form-control" name="cbdiketahui" id="cbdiketahui">Diketahui</td>
            <td><input type="checkbox" class="form-control" name="cbditunda" id="cbditunda">Ditunda</td>
            <td><input type="checkbox" class="form-control" name="cbditolak" id="cbditolak">Ditolak</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td> </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class="text-center" colspan="3">Atasan Langsung</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td rowspan="2" colspan="3"></td>
        </tr>

        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>

        </tr>

        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td colspan="3" class="text-center">Nama</td>

        </tr>
        <tr>
            <td colspan="7">
                <hr style="border-top: 3px dotted  black;">
            </td>

        </tr>
        <tr>
            <td>3. Pengesahan</td>
            <td></td>
            <td> Permohonan Ini</td>
            <td>:</td>
            <td><input type="checkbox" class="form-control" name="cbdiketahui" id="cbdiketahui">Diketahui</td>
            <td><input type="checkbox" class="form-control" name="cbditunda" id="cbditunda">Ditunda</td>
            <td><input type="checkbox" class="form-control" name="cbditolak" id="cbditolak">Ditolak</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td> </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class="text-center" colspan="3">Atasan Langsung</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td rowspan="2" colspan="3"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>

        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td colspan="3" class="text-center">Nama</td>

        </tr>
    </table>
</div>