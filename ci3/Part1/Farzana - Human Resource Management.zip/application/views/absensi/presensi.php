<?php if (isset($_GET['del'])) {
    $this->db->delete("absensi", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data  berhasil dihapus');
    redirect("absensi/presensi");
} ?>


<div class="page-title">
    <div class="title_left">
        <h3>Form Presensi Kehadiran Dan Pulang</h3>
    </div>

</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2><small>Data Presensi Kehadiran Dan Pulang</small></h2>
                <button id="showformtambah" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Buat Presensi Kehadiran Dan Pulang</button>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <br>
                <div id="divtambah" style="display: none;">

                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="alert alert-info">
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="fa fa-info-circle mr-3" style="font-size: 30px;"></i>
                                    <h4>Tombol Absen Terbuka ketika waktu saat ini masih dibawah jam masuk atau 3 jam setalahnya </h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="alert alert-warning">
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="fa fa-info-circle mr-3" style="font-size: 30px;"></i>
                                    <h4>Tombol Pulang Terbuka ketika waktu saat ini kurang dari 2 jam sebelum jam pulang</h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="alert alert-success">
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="fa fa-info-circle mr-3" style="font-size: 30px;"></i>
                                    <h4>Tombol akan terdisable ketika waktu sekarang tidak berada dalam kondisi 2 info diatas</h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="" id="hidjamkerja">
                    <input type="hidden" name="" id="htoleransi">
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Karyawan<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <select class="form-control select2" name="idkaryawan" id="idkaryawan">
                                <option value="">Pilih Karyawan</option>
                                <?php foreach (show_data("karyawan") as $un) {
                                    echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                } ?>

                            </select>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Hari/Tanggal Absen<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" readonly disabled name="namahari" id="namahari" value=<?= $hari ?>>
                            <input type="text" id="tanggal_mulai" name="tanggal_mulai" readonly disabled required="required" class="form-control" value="<?= date('d-m-Y H:i:s') ?>" required>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Jadwal Masuk<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" readonly disabled name="jam_masuk" id="jam_masuk" value=<?= $hari ?>>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Jadwal Pulang<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" readonly disabled name="jam_pulang" id="jam_pulang" value=<?= $hari ?>>
                        </div>
                    </div>

                    <!-- <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Keterangan<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <textarea id="keterangan" name="keterangan" required="required" class="form-control" required></textarea>
                        </div>
                    </div> -->
                    <!-- <div class="item form-group">
                        <label for="statuspengajuan" class="col-form-label col-md-3 col-sm-3 label-align">Status</label>
                        <div class="col-md-3 col-sm-3 ">
                            <input id="statuspengajuan" class="form-control" type="text" name="statuspengajuan" required value="Draft" disabled readonly>
                            <input type="checkbox" name="" id="" onchange="Changecb(event)" style="transform: scale(1.75); margin-top:10px; margin-left:5px;">
                        </div>
                    </div> -->

                    <div class="ln_solid"></div>
                    <div style="float: right">

                        <button class="btn-submit btn btn-primary" id="btnkembali"><i class="fa fa-reply"></i> <span name="CAPTION-SIMPAN" style="color:white;">Kembali</span></button>

                        <button class="btn-submit btn btn-success" id="btnabsenloading" style="display:none" disabled>
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading...
                        </button>

                        <button class="btn-submit btn btn-success" id="btnabsen"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Absen Masuk</span></button>
                    </div>
                </div>
                <div id="divtablepresensi">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input type="text" id="filterTanggal" class="form-control input-sm datepicker" name="filterTanggal" autocomplete="off">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="item form-group">
                                <div class="col-md-4 col-sm-4 ">
                                    <button type="button" class="btn btn-primary" onclick="handlerFilterKehadiranKaryawan()"><i class="fa fa-search"></i> Filter</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="tablepresensi">
                            <thead>
                                <tr class="bg-dark text-white">
                                    <th style="vertical-align: middle" class="text-center" rowspan="2">No</th>
                                    <th style="vertical-align: middle" class="text-center" rowspan="2">Karyawan</th>
                                    <th style="vertical-align: middle" class="text-center" rowspan="2">Nama Hari</th>
                                    <th style="vertical-align: middle; width:15%;" class="text-center" rowspan="2">Tanggal</th>
                                    <th style="vertical-align: middle" class="text-center" rowspan="2">Jadwal Masuk</th>
                                    <th style="vertical-align: middle" class="text-center" rowspan="2">Jadwal Pulang</th>
                                    <th style="vertical-align: middle" class="text-center" colspan="2">Absen</th>
                                    <th style="vertical-align: middle" class="text-center" colspan="2">Status</th>
                                    <!-- <th style="vertical-align: middle" class="text-center" rowspan="2">Aksi</th> -->
                                </tr>
                                <tr class="bg-dark text-white">
                                    <th style="vertical-align: middle" class="text-center">Absen Masuk</th>
                                    <th style="vertical-align: middle" class="text-center">Absen Pulang</th>
                                    <th style="vertical-align: middle" class="text-center">Status Masuk</th>
                                    <th style="vertical-align: middle" class="text-center">Status Pulang</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($data) > 0) { ?>
                                    <?php foreach ($data as $key => $value) { ?>
                                        <tr class="text-center">
                                            <td><?= $key + 1 ?></td>
                                            <td><?= $value->name ?></td>
                                            <td><?= $value->nama_hari ?></td>
                                            <td><?= longdate_indo($value->tgl) ?></td>
                                            <td><?= $value->jadwal_masuk ?>:00</td>
                                            <td><?= $value->jadwal_pulang ?>:00</td>
                                            <td><?= $value->absenjam_masuk == null ? '-' : $value->absenjam_masuk ?></td>
                                            <td><?= $value->status_masuk == null ? '-' : $value->absenjam_pulang ?></td>
                                            <td><?= $value->status_masuk ?></td>
                                            <td><?= $value->status_pulang ?></td>
                                            <!-- <td><a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data<?= $value->idUtama ?>'><i class='fa fa-trash'></i></a></td> -->
                                        </tr>
                                    <?php } ?>
                                <?php } else { ?>
                                    <tr>
                                        <td class="text-center text-danger" colspan="10">Data Kosong</td>
                                    </tr>
                                <?php } ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>


<?php $no = 0;
foreach ($data as $key) { ?>
    <div class="modal fade data<?= $key->idutama ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ãƒâ€”</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Apakah anda yakin akan menghapus <strong><?= $key->name ?></strong>?</h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?del=<?= $key->idutama ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<div class="modal fade" id="form_edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ãƒâ€”</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="heditid" id="heditid">

                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Hari Awal <span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <select class="form-control select2" name="hari" id="edithari" readonly disabled>
                            <?php foreach (show_data("hariefektif") as $un) {
                                echo "<option value='" . $un->id . "'>" . $un->nama_hari . "</option>";
                            } ?>
                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jam Masuk <span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="time" id="editjam_masuk" name="jam_masuk" required="required" class="form-control" required>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jam Pulang<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="time" id="editjam_pulang" name="jam_pulang" required="required" class="form-control" required>

                    </div>
                </div>
                <div class="item form-group">
                    <label for="toleransi" class="col-form-label col-md-3 col-sm-3 label-align">Toleransi</label>
                    <div class="col-md-6 col-sm-6 ">
                        <input id="edittoleransi" class="form-control" type="text" name="toleransi" required value="0">
                    </div>
                    <label for="menit" class="col-md-3 col-sm-3">*Menit</label>
                </div>
                <div class="item form-group" style="display: none;">
                    <label for="jam_efektif " class=" col-form-label col-md-3 col-sm-3 label-align">Jam Efektif</label>
                    <div class="col-md-6 col-sm-6 ">
                        <input id="editjam_efektif" class="form-control" type="text" name="jam_efektif" required value="0">
                    </div>
                    <label for="middle-name" class=" col-md-3 col-sm-3">*Menit</label>
                </div>
                <div class="ln_solid"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
            </div>

        </div>
    </div>
</div>
<script>
    function message(msg, msgtext, msgtype) {
        Swal.fire(msg, msgtext, msgtype);
    }
    // essage("Error!", "<span name='CAPTION-ALERT-PILIHSKU'>Mohon pilih SKU</span>", "error");
    // message_topright("success", "<span name='CAPTION-ALERT-BERHASIL'>Data berhasil disimpan</span>");

    function message_topright(type, msg) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            didOpen: (toast) => {
                toast.addEventListener("mouseenter", Swal.stopTimer);
                toast.addEventListener("mouseleave", Swal.resumeTimer);
            },
        });

        Toast.fire({
            icon: type,
            title: msg,
        });
    }

    function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
        var R = 6371; // Radius of the earth in km
        var dLat = deg2rad(lat2 - lat1); // deg2rad below
        var dLon = deg2rad(lon2 - lon1);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in km
        return d;
    }

    function getDistanceFromLatLonInMeters(lat1, lon1, lat2, lon2) {
        var R = 6371000; // Radius of the earth in meters
        var dLat = deg2rad(lat2 - lat1); // deg2rad below
        var dLon = deg2rad(lon2 - lon1);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in meters
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180)
    }

    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });

        // $('#tablepresensi').DataTable(configDatatable)
        // getdataabsensi();
        getDataJam();

        $('#filterTanggal').daterangepicker({
            'applyClass': 'btn-sm btn-success',
            'cancelClass': 'btn-sm btn-default',
            locale: {
                "format": "DD/MM/YYYY",
                applyLabel: 'Apply',
                cancelLabel: 'Cancel',
            },
            'startDate': '<?= date("d-m-Y") ?>',
            'endDate': '<?= date("d-m-Y") ?>'
        });

    })

    $(document).on("input", ".numeric", function(event) {
        this.value = this.value.replace(/[^\d.]+/g, '');
    });

    function getDataJam() {
        let hari = $('#namahari').val();
        $.ajax({
            type: 'POST',
            url: '<?= base_url('absensi/getdatajam') ?>',
            async: false,
            dataType: "JSON",
            data: {
                hari: hari
            },
            success: function(response) {
                if (response != null) {
                    $("#hidjamkerja").val(response.id_jamkerja);
                    let jam_masuk = response.jam_masuk;
                    let jam_pulang = response.jam_pulang;
                    let timenow = '<?= date('H:i') ?>'
                    let splitjam_masuk = parseInt(jam_masuk.split(":")[0]) == 23 ? 2 : parseInt(jam_masuk.split(":")[0]) + 3;
                    let splitjam_pulang = parseInt(jam_pulang.split(":")[0]) - 2;
                    $("#jam_masuk").val(response.jam_masuk)
                    $("#jam_pulang").val(response.jam_pulang)
                    $("#htoleransi").val(response.toleransi)

                    const now = new Date().getHours()

                    if (now >= (parseInt(jam_masuk.split(":")[0]) - 2) && now <= splitjam_masuk) {
                        $('#btnabsen').html('Absen Masuk');
                        $('#btnabsen').prop('disabled', false);
                    } else if (now >= splitjam_pulang && now <= (parseInt(jam_pulang.split(":")[0]) + 7)) {
                        $('#btnabsen').html('Absen Pulang');
                        $('#btnabsen').prop('disabled', false);
                    } else {
                        $('#btnabsen').html('Disabled');
                        $('#btnabsen').prop('disabled', true);
                    }


                    var startDate = new Date();
                    // Do your operations
                    var endDate = new Date();
                    var seconds = (endDate.getTime() - startDate.getTime()) / 1000;
                    console.log(endDate.getTime());
                }
            }
        })
    }

    const handlerFilterKehadiranKaryawan = () => {
        let filterTanggal = $("#filterTanggal").val();
        $.ajax({
            type: 'POST',
            url: '<?= base_url('absensi/getdataabsensi') ?>',
            data: {
                filterTanggal
            },
            dataType: "JSON",
            success: function(response) {
                // if ($.fn.DataTable.isDataTable('#tablepresensi')) {
                //     $('#tablepresensi').DataTable().destroy();
                // }
                $('#tablepresensi >tbody').empty()
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        $('#tablepresensi >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.name}</td>
                            <td>${v.nama_hari}</td>
                            <td>${formatTanggal(v.tgl)}</td>
                            <td>${v.jadwal_masuk}:00</td>
                            <td>${v.jadwal_pulang}:00</td>
                            <td>${v.absenjam_masuk == null ? '-' : v.absenjam_masuk}</td>
                            <td>${v.absenjam_pulang == null ? '-' : v.absenjam_pulang}</td>
                            <td>${v.status_masuk}</td>
                            <td>${v.status_pulang} </td>
                        </tr>`);
                    })
                } else {
                    $('#tablepresensi >tbody').append(`<tr><td class="text-center text-danger" colspan="10">Data Kosong</td></tr>`);
                }

                // $('#tablepresensi').DataTable(configDatatable)
            }
        })

    }

    // function getdataabsensi() {
    //     $.ajax({
    //         type: 'GET',
    //         url: '<?= base_url('absensi/getdataabsensi') ?>',
    //         // async: false,
    //         dataType: "JSON",
    //         success: function(response) {
    //             if (response != null) {
    //                 $.each(response, function(i, v) {
    //                     $('#tablepresensi >tbody').append(`<tr id='${i}'>
    //                         <td>${i+1}</td>
    //                         <td>${v.name}</td>
    //                         <td>${v.tgl}</td>
    //                         <td>-</td>
    //                         <td>-</td>
    //                         <td>${v.absenjam_masuk}</td>
    //                         <td>${v.absenjam_pulang}</td>
    //                         <td>${v.status_masuk}</td>
    //                         <td>${v.status_pulang} </td>
    //                         <td>

    //                         <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data${v.idutama}'><i class='fa fa-trash'></i></a></td>
    //                     </tr>`);
    //                 })
    //             }
    //         }
    //     })
    // }

    $(document).on('click', '#showformtambah', function() {
        $('#divtambah').show('FadeIn');
        $('#divtablepresensi').hide('FadeOut');
        $('#title h2').html('Tambah Presensi Kehadiran Dan Pulang');
        $('#showformtambah').hide();

    })
    $(document).on('click', '#btnkembali', function() {
        $('#divtambah').hide('FadeIn');
        $('#divtablepresensi').show('FadeOut');
        $('#title h2').html('Data Presensi Kehadiran Dan Pulang');
        $('#showformtambah').show();
    })

    function diff_hours(dt2, dt1) {

        var diff = dt2.getTime() - dt1.getTime();
        return (diff / 60000);

    }

    function isValidDate(d) {
        return d instanceof Date && !isNaN(d);
    }

    function toHoursAndMinutes(totalMinutes) {
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;
        const hoursCek = hours == 0 ? '' : hours + " Jam";
        const minutesCek = minutes == 0 ? '' : minutes + " Menit";

        return hoursCek + " " + minutesCek;
    }

    const showBtnAbsen = () => {
        $("#btnabsen").show();
        $("#btnabsenloading").hide();
    }

    $(document).on('click', '#btnabsen', function() {

        $("#btnabsen").hide();
        $("#btnabsenloading").show();

        let idkaryawan = $('#idkaryawan option:selected').val();
        let hari = $('#namahari').val();
        let jam_absen = '<?= date('d-m-Y H:i:s') ?>';
        let jam_masuk = $("#jam_masuk").val()
        let jam_pulang = $("#jam_pulang").val()
        let toleransi = $("#htoleransi").val();

        if (!/^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$/.test(jam_masuk)) {
            showMessage('error', `Hari efektif pada hari ${$('#namahari').val()} belum disetting oleh admin`);
            showBtnAbsen();
            return false;
        }

        if (idkaryawan == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon Pilih Karyawan ",
                    type: "error",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            showBtnAbsen();
            return false;
        }

        //get lokasi kantor by data karyawan selection id
        $.ajax({
            type: "POST",
            url: '<?= base_url('absensi/getLokasiKantor'); ?>',
            data: {
                idkaryawan
            },
            dataType: 'json',
            success: function(response) {
                if (response == null) {
                    showMessage('error', 'Karyawan ' + $('#idkaryawan option:selected').text() + ' tidak memiliki lokasi kantor, silahkan update data lokasi pekerjaan melalui data kepegawaian atau hubungi admin');
                    showBtnAbsen();
                    return false;
                } else {
                    if (navigator.geolocation) { //check if geolocation is available
                        navigator.geolocation.getCurrentPosition(function(position) {
                            const latPositionUser = position.coords.latitude;
                            const longPositionUser = position.coords.longitude;


                            if (response.satuan == 'Km') {
                                const betweenLocation = getDistanceFromLatLonInKm(response.latitude, response.longitude, latPositionUser, longPositionUser);
                                if (parseInt(Math.round(betweenLocation)) > parseInt(response.jarak)) {
                                    showMessage('error', `Absensi gagal, anda berada di luar radius ketentuan absen kantor, radius anda <strong>${parseInt(Math.round(betweenLocation))} Km</strong>, lakukan absen berada dibawah sama dengan ${parseInt(response.jarak)} Km`);
                                    showBtnAbsen();
                                    return false;
                                }
                            }

                            if (response.satuan == 'm') {
                                const betweenLocation = getDistanceFromLatLonInMeters(response.latitude, response.longitude, latPositionUser, longPositionUser);
                                const mathRoundMeters = parseInt(Math.round(betweenLocation));
                                const mathRoundKm = betweenLocation / 1000
                                const convertDistance = mathRoundMeters < 1000 ? mathRoundMeters + " Meter" : mathRoundKm.toFixed(1) + " Km";
                                if (parseInt(Math.round(betweenLocation)) > parseInt(response.jarak)) {
                                    showMessage('error', `Absensi gagal, anda berada di luar radius ketentuan absen kantor, radius anda <strong>${convertDistance}</strong>, lakukan absen berada dibawah sama dengan ${parseInt(response.jarak)} Meter`);
                                    showBtnAbsen();
                                    return false;
                                }
                            }

                            let now = '<?= date('H:i') ?>';
                            let waktu = "";
                            let status = '';
                            let type = '';
                            let dt1 = new Date(`<?= date('Y-m-d') ?> ${now}:00`);
                            let dtmasuk = new Date(`<?= date('Y-m-d') ?> ${jam_masuk}:00`);
                            let dtpulang = new Date(`<?= date('Y-m-d') ?> ${jam_pulang}:00`);

                            if ($('#btnabsen').html() == 'Absen Masuk') {
                                // waktu = now.replace(":", "") - jam_masuk.replace(":", "")
                                waktu = diff_hours(dt1, dtmasuk)

                                type = 1;

                                if (waktu < 0) {
                                    status = `Anda absen masuk ${toHoursAndMinutes(waktu)} lebih awal dari jam yang telah ditentukan`
                                }

                                if (waktu == 0) {
                                    status = "Anda absen masuk tepat waktu"
                                }

                                if (waktu > 0) {
                                    if (waktu > toleransi) {
                                        status = `Anda absen masuk terlambat ${toHoursAndMinutes(waktu)}`
                                    } else {
                                        status = `Anda absen terlambat ${toHoursAndMinutes(waktu)} tapi masih dalam toleransi`
                                    }
                                }
                            }
                            if (($('#btnabsen').html() == 'Absen Pulang')) {
                                // waktu = now.replace(":", "") - jam_pulang.replace(":", "")

                                waktu = diff_hours(dt1, dtpulang)
                                type = 2;

                                if (waktu < 0) {
                                    status = `Anda absen pulang ${toHoursAndMinutes(waktu)} lebih awal dari jam yang telah ditentukan`
                                }
                                if (waktu == 0) {
                                    status = "Anda absen pulang tepat waktu"
                                }
                                if (waktu > 0) {
                                    status = `Anda absen pulang ${toHoursAndMinutes(waktu)} diatas dari jam yang telah ditentukan`;
                                }

                            }


                            $.ajax({
                                type: "POST",
                                url: '<?= base_url('absensi/addabsensi'); ?>',
                                data: {
                                    idkaryawan: idkaryawan,
                                    hari: hari,
                                    id_jam_kerja: $("#hidjamkerja").val(),
                                    waktu: waktu,
                                    status: status,
                                    latPositionUser,
                                    longPositionUser,
                                    type

                                },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.status == 200) {
                                        new PNotify
                                            ({
                                                title: 'Success',
                                                text: response.message,
                                                type: "success",
                                                styling: 'bootstrap3',
                                                delay: 3000,
                                                // stack: stack_center
                                            });
                                        setTimeout(() => window.location.reload(), 800);
                                        showBtnAbsen();
                                    }
                                    if (response.status == 400) {
                                        new PNotify
                                            ({
                                                title: 'Error',
                                                text: response.message,
                                                type: "error",
                                                styling: 'bootstrap3',
                                                delay: 3000,
                                                // stack: stack_center
                                            });
                                        showBtnAbsen();
                                        return false
                                        // setTimeout(() => window.location.reload(), 800);
                                    }
                                }

                            })

                        });
                    }

                }
            }
        })

    })

    function editdata(i, id, hari, jam_masuk, jam_pulang, toleransi, efektif) {

        let value = $(this).attr('efektif');
        $('#heditid').val(id);
        $('#edithari').val(hari).change();
        $('#editjam_masuk').val(jam_masuk);
        $('#editjam_pulang').val(jam_pulang);
        $('#edittoleransi').val(toleransi);
        $('#editjam_efektif').val(efektif);

        $('#form_edit').modal('show');


    }
    $(document).on('click', '#btn_editsimpan', function() {

        $.ajax({
            type: "POST",
            url: '<?= base_url('setting/edit_presensi') ?>',
            dataType: "JSON",
            data: {
                id: $('#heditid').val(),
                edithari: $('#edithari option:selected').val(),
                editjam_masuk: $('#editjam_masuk').val(),
                editjam_pulang: $('#editjam_pulang').val(),
                edittoleransi: $('#edittoleransi').val(),
                editjam_efektif: $('#editjam_efektif').val()
            },
            success: function(response) {
                if (response == 1) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil Dirubah",
                            type: "Succes",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    new PNotify({
                        text: 'Data Gagal Dirubah!',
                        type: 'Warning!',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 700);
                }
            }
        })
    })
</script>