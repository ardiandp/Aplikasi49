<?php if (isset($_GET['del'])) {
    $this->db->delete("pengajuanPayroll", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data Penagjuan payroll berhasil dihapus');
    redirect("FormPengajuan/pengajuanpayroll");
} ?>


<div class="page-title">
    <div class="title_left">
        <h3>Form Pengajuan Payroll</h3>
    </div>

</div>
<div class="clearfix"></div>
<!-- <div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2><small>Cari Data</small></h2>
                <button id="showformtambah" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Cari Pengajuan Payroll</button>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="col-md-6 col-sm-6  form-group has-feedback">
                    <input type="text" class="form-control has-feedback-left" id="inputSuccess2" placeholder="First Name">
                    <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="row">

    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2><small>Data Pengajuan Payroll</small></h2>
                <!-- <button id="showformtambah" onclick="handlerAddPengajuanPayroll()" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Buat Pengajuan Payroll</button> -->
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div id="tablepayrol">
                    <div class="ml-4 mb-4">
                        <?php if ($this->session->userdata('user') == 'admin') { ?>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idkaryawan">Karyawan <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <select class="form-control select2" name="idkaryawan" id="idkaryawan">
                                        <option value="">Pilih Karyawan</option>
                                        <?php foreach (show_data("karyawan") as $un) {
                                            echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                        } ?>
                                    </select>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                            <div class="col-md-6 col-sm-6">
                                <input type="month" id="payrollKaryawan" class="form-control" name="payrollKaryawan" value="<?= date('Y-m') ?>" autocomplete="off">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align"></label>
                            <div class="col-md-6 col-sm-6 ">
                                <button class="btn btn-primary" onclick="handlerFilterPengajuanApproval()"><i class="fa fa-seacrh"></i> Filter</button>
                            </div>
                        </div>
                        <div class="table-responsive mt-3">
                            <br><br>
                            <div class="clearfix"></div>
                            <table id="initPengajuanPayroll" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                    <tr class="bg-dark text-white">
                                        <th>No.</th>
                                        <th>Karyawan</th>
                                        <th>Jenis Validasi</th>
                                        <th>Keterangan</th>
                                        <th>Tanggal Payroll</th>
                                        <th>Tanggal Pengajuan</th>
                                        <th>Status Pengajuan</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <br>
                <div id="divtambah" style="display: none;">

                    <?php if ($this->session->userdata('user') == 'admin') { ?>
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Karyawan<span class="required">*</span>
                            </label>
                            <div class="col-md-4 col-sm-4 ">
                                <select class="form-control select2" name="idkaryawan2" id="idkaryawan2">
                                    <option value="">Pilih Karyawan</option>
                                    <?php foreach (show_data("karyawan") as $un) {
                                        echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                    } ?>

                                </select>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="hidden" name="idUsers" id="idUsers" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
                            <input type="month" id="payrolltglKaryawan" class="form-control" name="payrollKaryawan" autocomplete="off">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jenis Validasi<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <select class="form-control select2" name="jenis_validasi" id="jenis_validasi" disabled readonly>
                                <option value="">Pilih Jenis Validasi</option>
                                <?php foreach (show_data("jenis_validasi") as $un) { ?>
                                    <?php if ($un->id == '12') { ?>
                                        <option value="<?= $un->id ?>" selected><?= $un->nama_jenis_validasi ?></option>
                                    <?php } ?>
                                    <!-- echo "<option value='" . $un->id . "'>" . $un->nama_jenis_validasi . "</option>"; -->
                                <?php } ?>

                            </select>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Keterangan<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <textarea id="keterangan" name="keterangan" required="required" class="form-control" required></textarea>
                        </div>
                    </div>

                    <div class="item form-group">
                        <label for="statuspengajuan" class="col-form-label col-md-3 col-sm-3 label-align">Status</label>
                        <div class="col-md-3 col-sm-3 ">
                            <input id="statuspengajuan" class="form-control" type="text" name="statuspengajuan" required value="Draft" disabled readonly>
                            <input type="checkbox" name="" id="" onchange="Changecb(event)" style="transform: scale(1.75); margin-top:10px; margin-left:5px;">
                        </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div style="float: right">

                        <button class="btn-submit btn btn-primary" id="btnkembali"><i class="fa fa-reply"></i> <span name="CAPTION-SIMPAN" style="color:white;">Kembali</span></button>
                        <button class="btn-submit btn btn-success" id="btnsavepayroll"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                </button>
            </div>
            <div class="modal-body">
                <h6>Apakah anda yakin akan menghapus <strong></strong>?</h6>
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger" id="btnActionDeleteData">Hapus Data</a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="form_edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="heditid" id="heditid">

                <?php if ($this->session->userdata('user') == 'admin') { ?>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Karyawan<span class="required">*</span>
                        </label>
                        <div class="col-md-9 col-sm-9 ">
                            <select class="form-control select2" name="idkaryawanEdit" id="idkaryawanEdit">
                                <option value="">Pilih Karyawan</option>
                                <?php foreach (show_data("karyawan") as $un) {
                                    echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                } ?>

                            </select>
                        </div>
                    </div>
                <?php } ?>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                    <div class="col-md-9 col-sm-9 ">
                        <input type="month" id="payrolltglKaryawanEdit" class="form-control" name="payrollKaryawan" autocomplete="off">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jenis Validasi<span class="required">*</span>
                    </label>
                    <div class="col-md-9 col-sm-9 ">
                        <select class="form-control select2" name="jenis_validasiEdit" id="jenis_validasiEdit" disabled readonly>
                            <option value="">Pilih Jenis Validasi</option>
                            <?php foreach (show_data("jenis_validasi") as $un) { ?>
                                <?php if ($un->id == '12') { ?>
                                    <option value="<?= $un->id ?>" selected><?= $un->nama_jenis_validasi ?></option>
                                <?php } ?>
                                <!-- echo "<option value='" . $un->id . "'>" . $un->nama_jenis_validasi . "</option>"; -->
                            <?php } ?>

                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Keterangan<span class="required">*</span>
                    </label>
                    <div class="col-md-9 col-sm-9 ">
                        <textarea id="keteranganEdit" name="keteranganEdit" required="required" class="form-control" required></textarea>
                    </div>
                </div>

                <div class="item form-group">
                    <label for="statuspengajuanEdit" class="col-form-label col-md-3 col-sm-3 label-align">Status</label>
                    <div class="col-md-9 col-sm-9 ">
                        <input id="statuspengajuanEdit" class="form-control" type="text" name="statuspengajuanEdit" required value="Draft" disabled readonly>
                        <input type="checkbox" name="chckEdit" id="chckEdit" onchange="Changecb2(event)" style="transform: scale(1.75); margin-top:10px; margin-left:5px;">
                    </div>
                </div>
                <div class="ln_solid"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
                <button class="btn btn-dark" data-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
<script>
    const initConfigDatatable = {
        dom: 'Bfrtip',
        buttons: [{
                extend: "print",
                text: '<i class="fa fa-print"></i> Print',
                className: 'btn btn-warning',
                customize: function(win) {

                    var last = null;
                    var current = null;
                    var bod = [];

                    var css = '@page { size: landscape; }',
                        head = win.document.head || win.document.getElementsByTagName('head')[0],
                        style = win.document.createElement('style');

                    style.type = 'text/css';
                    style.media = 'print';

                    if (style.styleSheet) {
                        style.styleSheet.cssText = css;
                    } else {
                        style.appendChild(win.document.createTextNode(css));
                    }

                    head.appendChild(style);
                }
            },
            {
                extend: 'excelHtml5',
                text: '<i class="fa fa-file-excel-o"></i> Excel',
                className: 'btn btn-success',
            },
            {
                extend: 'csvHtml5',
                text: '<i class="fa fa-file"></i> CSV',
                className: 'btn btn-info',
            },
            {
                extend: 'pdfHtml5',
                orientation: 'landscape',
                text: '<i class="fa fa-file-pdf-o"></i> PDF',
                className: 'btn btn-danger',
                pageSize: 'LEGAL'
            }, {
                text: '<i class="fa fa-user-plus"></i> Buat Pengajuan Payroll',
                className: 'btn btn-success',
                action: function(e, dt, node, conf) {
                    handlerAddPengajuanPayroll()
                }
            }
        ]
    }

    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });

        $("#initPengajuanPayroll").DataTable(initConfigDatatable);
    })

    function message(msg, msgtext, msgtype) {
        Swal.fire(msg, msgtext, msgtype);
    }
    const Changecb = (e) => {
        if (e.target.checked == true) {
            $('#statuspengajuan').val('In Progres Approval');
        } else {
            $('#statuspengajuan').val('Draft');
        }
    }
    const Changecb2 = (e) => {
        if (e.target.checked == true) {
            $('#statuspengajuanEdit').val('In Progres Approval');
        } else {
            $('#statuspengajuanEdit').val('Draft');
        }
    }
    // essage("Error!", "<span name='CAPTION-ALERT-PILIHSKU'>Mohon pilih SKU</span>", "error");
    // message_topright("success", "<span name='CAPTION-ALERT-BERHASIL'>Data berhasil disimpan</span>");

    function message_topright(type, msg) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            didOpen: (toast) => {
                toast.addEventListener("mouseenter", Swal.stopTimer);
                toast.addEventListener("mouseleave", Swal.resumeTimer);
            },
        });

        Toast.fire({
            icon: type,
            title: msg,
        });
    }

    const handlerAddPengajuanPayroll = () => {
        $('#divtambah').show('FadeIn');
        $('#tablepayrol').hide('FadeOut');
        $('#title h2').html('Buat Pengajuan ');
        $('#showformtambah').hide();

    }

    $(document).on('click', '#showformedit', function() {
        $('#form_edit').modal('show');
        const id = $(this).attr('data-id');

        $.ajax({
            type: "POST",
            url: '<?= base_url('FormPengajuan/getDataPengajuanById'); ?>',
            data: {
                id
            },
            dataType: 'json',
            success: function(response) {
                $('#heditid').val(response.id)
                $('#idkaryawanEdit').val(response.id_karyawan).trigger('change')
                $('#payrolltglKaryawanEdit').val(response.bulan).trigger('change')
                $('#jenis_validasiEdit').val(response.id_jenisvalidasi).trigger('change')
                $('#keteranganEdit').val(response.keterangan)
                $('#statuspengajuanEdit').val(response.statuspengajuan == 0 ? 'Draft' : 'In Progres Approval')
                if (response.statuspengajuan == 0) {
                    $('#chckEdit').prop('checked', false).trigger('change')
                } else {
                    $('#chckEdit').prop('checked', true).trigger('change')
                }
            }

        })
    })

    $(document).on('click', '#deleteDataPengajuan', function() {
        $('#modalDelete').modal('show');
        const id = $(this).attr('data-id');

        $("#btnActionDeleteData").attr('href', `?del=${id}`);

    })

    $(document).on('click', '#showformview', function() {
        $('#form_edit').modal('show');
        $("#btn_editsimpan").hide();
        $('#form_edit .modal-title').html('Show Data');
        const id = $(this).attr('data-id');

        $.ajax({
            type: "POST",
            url: '<?= base_url('FormPengajuan/getDataPengajuanById'); ?>',
            data: {
                id
            },
            dataType: 'json',
            success: function(response) {
                $('#heditid').val(response.id)
                $('#idkaryawanEdit').val(response.id_karyawan).trigger('change')
                $('#payrolltglKaryawanEdit').val(response.bulan).trigger('change')
                $('#jenis_validasiEdit').val(response.id_jenisvalidasi).trigger('change')
                $('#keteranganEdit').val(response.keterangan)
                $('#statuspengajuanEdit').val(response.statuspengajuan == 0 ? 'Draft' : 'In Progres Approval')
                if (response.statuspengajuan == 0) {
                    $('#chckEdit').prop('checked', false).trigger('change')
                } else {
                    $('#chckEdit').prop('checked', true).trigger('change')
                }

                $('#idkaryawanEdit').prop('disabled', true)
                $('#payrolltglKaryawanEdit').prop('disabled', true)
                $('#jenis_validasiEdit').prop('disabled', true)
                $('#keteranganEdit').prop('disabled', true)
                $('#idkaryawanEdit').prop('disabled', true)
                $('#chckEdit').prop('disabled', true)
            }

        })
    })

    $(document).on('click', '#btnkembali', function() {
        $('#divtambah').hide('FadeIn');
        $('#tablepayrol').show('FadeOut');
        $('#title h2').html('Data Pengajuan');
        $('#showformtambah').show();


    })

    $(document).on("input", ".numeric", function(event) {
        this.value = this.value.replace(/[^\d.]+/g, '');
    });

    const handlerFilterPengajuanApproval = () => {
        let idKaryawan = $("#idkaryawan option:selected").val();
        let tanggal = $("#payrollKaryawan").val();

        <?php if ($this->session->userdata('user') == 'admin') { ?>
            if (idKaryawan == '') {
                showMessage('error', `Karyawan tidak boleh kosong`);
                return false;
            }
        <?php } ?>

        if (tanggal == '') {
            showMessage('error', `Tanggal tidak boleh kosong`);
            return false;
        }

        $.ajax({
            type: "POST",
            url: "<?= base_url('FormPengajuan/filterPengajuanPayroll'); ?>",
            data: {
                idKaryawan: "<?= $this->session->userdata('user') ?>" == 'admin' ? idKaryawan : "<?= $this->session->userdata('id') ?>",
                tanggal
            },
            dataType: 'JSON',
            success: function(response) {
                if (response) {
                    if ($.fn.DataTable.isDataTable('#initPengajuanPayroll')) {
                        $('#initPengajuanPayroll').DataTable().destroy();
                    }

                    $("#initPengajuanPayroll > tbody").empty()
                    $.each(response, function(i, v) {
                        let action = ""
                        if (v.status == 'Draft') {
                            action += `<button id="showformedit" class="btn btn-sm btn-warning" data-id="${v.id}"><i class="fa fa-edit"></i></button>`;
                            action += `<button id="deleteDataPengajuan" class="btn btn-sm btn-danger" data-id="${v.id}"><i class="fa fa-trash"></i></button>`;
                        } else {
                            action += `<button id="showformview" class="btn btn-sm btn-primary" data-id="${v.id}"><i class="fa fa-eye"></i></button>`;
                        }
                        $("#initPengajuanPayroll > tbody").append(`
                            <tr>
                                <td class="text-center">${i + 1}</td>
                                <td class="text-center">${v.name}</td>
                                <td class="text-center">${v.nama_jenis_validasi}</td>
                                <td class="text-center">${v.keterangan}</td>
                                <td class="text-center">${shortFormatTanggal(v.bulan)}</td>
                                <td class="text-center">${formatTanggal(v.tanggal_pengajuan)}</td>
                                <td class="text-center">${v.status}</td>
                                <td class="text-center">${action}</td>
                            </tr>`)
                    })
                    $("#initPengajuanPayroll").DataTable(initConfigDatatable);
                } else {

                    if ($.fn.DataTable.isDataTable('#initPengajuanPayroll')) {
                        $('#initPengajuanPayroll').DataTable().destroy();
                    }

                    $("#initPengajuanPayroll > tbody").empty()

                    $("#initPengajuanPayroll > tbody").append(`<tr><td colspan="8" class="text-center text-danger">Data Kosong</td></tr>`)
                    $("#initPengajuanPayroll").DataTable(initConfigDatatable);
                }
            }

        })


    }

    $(document).on('click', '#btnsavepayroll', function() {
        let idkaryawan = $('#idkaryawan2 option:selected').val();
        console.log(idkaryawan);
        let bulan = $('#payrolltglKaryawan').val();
        let keterangan = $('#keterangan').val();
        let statuspengajuan = $('#statuspengajuan').val();

        <?php if ($this->session->userdata('user') == 'admin') { ?>
            if (idkaryawan == '') {
                showMessage('warning', `Mohon lengkapi data inputan yang Kosong`);
                return false;
            }
        <?php } ?>

        if (bulan == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }


        $.ajax({
            type: "POST",
            url: '<?= base_url('absensi/addpengajuanpayroll'); ?>',
            data: {
                idkaryawan: "<?= $this->session->userdata('user') ?>" == 'admin' ? idkaryawan : "<?= $this->session->userdata('id') ?>",
                bulan: bulan,
                jenis_validasi: $('#jenis_validasi option:selected').val(),
                keterangan: keterangan,
                statuspengajuan: statuspengajuan
            },
            dataType: 'json',
            success: function(response) {
                if (response == 1) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil Ditambah",
                            type: "Success",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    new PNotify({
                        text: 'Data Gagal disimpan!',
                        type: 'Warning!',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 700);
                }
            }

        })
    })

    $(document).on('click', '#btn_editsimpan', function() {
        let id = $('#heditid').val();
        let idkaryawan = $('#idkaryawanEdit option:selected').val();
        let bulan = $('#payrolltglKaryawanEdit').val();
        let keterangan = $('#keteranganEdit').val();
        let statuspengajuan = $('#jenis_validasiEdit').val();

        <?php if ($this->session->userdata('user') == 'admin') { ?>
            if (idKaryawan == '') {
                showMessage('warning', `Mohon lengkapi data inputan yang Kosong`);
                return false;
            }
        <?php } ?>

        if (bulan == '' || statuspengajuan == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }


        $.ajax({
            type: "POST",
            url: '<?= base_url('FormPengajuan/updatepengajuanpayroll'); ?>',
            data: {
                id,
                idkaryawan: "<?= $this->session->userdata('user') ?>" == 'admin' ? idkaryawan : "<?= $this->session->userdata('id') ?>",
                bulan: bulan,
                jenis_validasi: $('#jenis_validasi option:selected').val(),
                keterangan: keterangan,
                statuspengajuan: $("#chckEdit").prop('checkec') == true ? 1 : 0
            },
            dataType: 'json',
            success: function(response) {
                if (response == 1) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil diubah",
                            type: "Success",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    new PNotify({
                        text: 'Data Gagal diubah!',
                        type: 'Warning!',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 700);
                }
            }

        })
    })
</script>