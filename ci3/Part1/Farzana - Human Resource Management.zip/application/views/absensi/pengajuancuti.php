<?php if (isset($_GET['del'])) {
    $this->db->delete("pengajuancuti", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data unit berhasil dihapus');
    redirect("absensi/pengajuancuti");
} ?>


<div class="page-title">
    <div class="title_left">
        <h3>Form Pengajuan Cuti</h3>
    </div>

</div>
<div class="clearfix"></div>
<!-- <div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2><small>Cari Data</small></h2>
                <button id="showformtambah" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Cari Pengajuan Cuti</button>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="col-md-6 col-sm-6  form-group has-feedback">
                    <input type="text" class="form-control has-feedback-left" id="inputSuccess2" placeholder="First Name">
                    <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2><small>Data Pengajuan Cuti</small></h2>
                <!-- <button id="showformtambah" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Buat Pengajuan Cuti</button> -->
                <div class="clearfix"></div>
            </div>
            <div class="x_content">

                <br>
                <div id="divtambah" style="display: none;">

                    <?php if ($this->session->userdata('user') == 'admin') { ?>
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Karyawan<span class="required">*</span>
                            </label>
                            <div class="col-md-4 col-sm-4 ">
                                <select class="form-control select2" name="idkaryawan" id="idkaryawan">
                                    <option value="">Pilih Karyawan</option>
                                    <?php foreach (show_data("karyawan") as $un) {
                                        echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                    } ?>

                                </select>
                            </div>
                        </div>

                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">No Ktp<span class="required">*</span>
                            </label>
                            <div class="col-md-4 col-sm-4 ">
                                <input type="text" class="form-control" readonly disabled name="notkp" id="noktp">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">No HP<span class="required">*</span>
                            </label>
                            <div class="col-md-4 col-sm-4 ">
                                <input type="text" class="form-control" readonly disabled name="nohp" id="nohp">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Divisi<span class="required">*</span>
                            </label>
                            <div class="col-md-4 col-sm-4 ">
                                <input type="text" class="form-control" readonly disabled name="divisi" id="divisi">
                            </div>
                        </div>
                    <?php } ?>

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Cuti<span class="required">*</span>
                        </label>
                        <div class="col-md-2 col-sm-2 ">
                            <select class="form-control select2" name="jenis_cuti" id="jenis_cuti">
                                <option value="">Pilih Cuti</option>
                                <?php foreach (show_data("jenis_cuti") as $un) {
                                    echo "<option value='" . $un->id . "'>" . $un->nama_jenis . "</option>";
                                } ?>

                            </select>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jenis Validasi<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <select class="form-control select2" name="jenis_validasi" id="jenis_validasi" disabled>
                                <option value="">Pilih Jenis Validasi</option>
                                <?php foreach (show_data("jenis_validasi") as $un) { ?>
                                    <?php if ($un->id == '10') { ?>
                                        <option value="<?= $un->id ?>" selected><?= $un->nama_jenis_validasi ?></option>
                                    <?php } ?>
                                    <!-- echo "<option value='" . $un->id . "'>" . $un->nama_jenis_validasi . "</option>"; -->
                                <?php } ?>

                            </select>
                        </div>
                    </div>

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Tanggal Mulai<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="date" id="tanggal_mulai" name="tanggal_mulai" required="required" class="form-control" value="<?= date('Y-m-d') ?>" required>

                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Lama Cuti <span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" id="lama" name="lama" required="required" onchange="handlerLamaCuti(this.value, 'insert')" class="form-control numeric" required>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Tanggal Akhir<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="date" id="tanggal_akhir" name="tanggal_akhir" required="required" class="form-control" value="<?= date('Y-m-d') ?>" disabled required>

                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Tanggal Masuk<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="date" id="tanggal_masuk" name="tanggal_masuk" required="required" class="form-control" value="<?= date('Y-m-d') ?>" disabled required>

                        </div>
                    </div>

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jumlah Hari Kerja<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" id="lamakerja" name="lama" required="required" class="form-control numeric" disabled required>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jumlah Hari Libur/Off<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" id="lamalibur" name="lamalibur" required="required" class="form-control numeric" disabled required>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Alamat Lokasi<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <textarea id="alamatlokasi" name="alamatlokasi" required="required" class="form-control" required></textarea>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Keterangan<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <textarea id="keterangan" name="keterangan" required="required" class="form-control" required></textarea>
                        </div>
                    </div>

                    <div class="item form-group">
                        <label for="statuspengajuan" class="col-form-label col-md-3 col-sm-3 label-align">Status</label>
                        <div class="col-md-3 col-sm-3 ">
                            <input id="statuspengajuan" class="form-control" type="text" name="statuspengajuan" required value="Draft" disabled readonly>
                            <input type="checkbox" name="" id="" onchange="Changecb(event)" style="transform: scale(1.75); margin-top:10px; margin-left:5px;">
                        </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div style="float: right">

                        <button class="btn-submit btn btn-primary" id="btnkembali"><i class="fa fa-reply"></i> <span name="CAPTION-SIMPAN" style="color:white;">Kembali</span></button>
                        <button class="btn-submit btn btn-success" id="btnsave"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                    </div>
                </div>
                <div id="divtablejamkerja">
                    <table class="table table-striped table-bordered table-hover" id="tabledatapengajuancuti">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Nama Karyawan</th>
                                <th>Jenis Cuti</th>
                                <th>Lama Hari</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Akhir</th>
                                <th>Keterangan</th>
                                <th>Status</th>
                                <th>Step Validasi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                    </table>
                </div>
                <div id="divatbablecetak" style="border: 1px solid grey; padding: 10px;display:none;">
                    <div class="container">
                        <h3 class="alert alert-info text-center">PERMOHONAN CUTI</h3>

                    </div>
                    <table class="table table-bordered " id="tablepengajuancuti1" style="border: 0px;" width="100%">
                        <tr>
                            <td style="background-color: green;">DIISI OLEH AMIL</td>

                        </tr>
                        <tr>
                            <td style="background: transparent;">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="10%" style="border: 0px;">Nama</td>
                            <td width="1%">:</td>
                            <td style="border-bottom: 1pt solid black;" colspan="3"></td>
                            <td style="border: 0px;">&nbsp;</td>

                            <td width="10%">NIK</td>
                            <td width="1%">:</td>
                            <td style="border-bottom: 1pt solid black;" colspan="3"></td>
                        </tr>
                        <tr>
                            <td style="border: 0px;">Jabatan</td>
                            <td>:</td>
                            <td style="border-bottom: 1pt solid black;" colspan="3"></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="border: 0px;">Bagian/Departemen</td>
                            <td>:</td>
                            <td style="border-bottom: 1pt solid black;" colspan="3"></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="border: 0px;"></td>
                            <td>:</td>
                            <td width="10%" colspan="4">tgl</td>
                            <td width="2%">S/D</td>
                            <td width="2%" colspan="3">tgl</td>
                            <td></td>

                        </tr>
                        <tr>
                            <td style="border: 0px;">Mengajuakan Cuti Pada</td>
                            <td>:</td>
                            <td width="2%" colspan="4">tgl</td>
                            <td width="2%">S/D</td>
                            <td width="2%" colspan="3">tgl</td>
                            <td></td>

                        </tr>
                        <tr>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>

                        </tr>
                        <tr>
                            <td style="border: 0px;"></td>
                            <td></td>
                            <td>Jumlah Hari Kerja</td>
                            <td width="2%">:</td>
                            <td></td>
                            <td width="2">hari</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td>JUMLAH HARI LIBUR / OFF</td>
                            <td width="2%">:</td>
                            <td></td>
                            <td>hari</td>
                            <td width="5%"></td>
                            <td width="5%">Total Cuti</td>
                            <td></td>
                            <td>hari</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="border: 0px;">Masuk Bekerja Kembali</td>
                            <td>:</td>
                            <td width="2%" colspan="4">tgl</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="border: 0px;">Alasan Pengajuan Cuti</td>
                            <td>:</td>
                            <td colspan="3" style="border-bottom:1px solid black;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>

                        </tr>
                        <tr>
                            <td style="border: 0px;">Alamat/Lokasi Selama Cuti</td>
                            <td>:</td>
                            <td colspan="3" style="border-bottom:1px solid black;"></td>
                            <td style="border: 0px;"></td>
                            <td style="border: 0px;"></td>

                            <td style="border: 0px;"></td>
                            <td>NoHp</td>
                            <td colspan="2"></td>


                        </tr>
                        <tr>
                            <td style="border: 0px;">Tanda Tangan Pemohon</td>
                            <td>:</td>
                            <td colspan="3" style="border-bottom:1px solid black;"></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td width="2%">tgl</td>
                            <td width="2%">bln</td>
                            <td width="2%">thn</td>
                        </tr>



                    </table>
                    <table class="table table-bordered " id="tablepengajuancuti2" style="border: 0px;" width="100%">
                        <tr>
                            <td style="background-color: greenyellow;">KEPUTUSAN</td>
                        </tr>
                        <tr>
                            <td colspan="7">

                            </td>

                        </tr>
                        <tr>
                            <td>1. Diketahui</td>
                            <td></td>
                            <td> Permohonan Ini</td>
                            <td>:</td>
                            <td><input type="checkbox" class="form-control" name="cbdiketahui" id="cbdiketahui">Diketahui</td>
                            <td><input type="checkbox" class="form-control" name="cbditunda" id="cbditunda">Ditunda</td>
                            <td><input type="checkbox" class="form-control" name="cbditolak" id="cbditolak">Ditolak</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td> </td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td class="text-center" colspan="3">Atasan Langsung</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td rowspan="2" colspan="3"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>

                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td colspan="3" class="text-center">Nama</td>

                        </tr>
                        <tr>
                            <td colspan="7">
                                <hr style="border-top: 3px dotted  black;">
                            </td>

                        </tr>
                        <tr>
                            <td>2. Disetujui</td>
                            <td></td>
                            <td> Permohonan Ini</td>
                            <td>:</td>
                            <td><input type="checkbox" class="form-control" name="cbdiketahui" id="cbdiketahui">Diketahui</td>
                            <td><input type="checkbox" class="form-control" name="cbditunda" id="cbditunda">Ditunda</td>
                            <td><input type="checkbox" class="form-control" name="cbditolak" id="cbditolak">Ditolak</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td> </td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td class="text-center" colspan="3">Atasan Langsung</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td rowspan="2" colspan="3"></td>
                        </tr>

                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>

                        </tr>

                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td colspan="3" class="text-center">Nama</td>

                        </tr>
                        <tr>
                            <td colspan="7">
                                <hr style="border-top: 3px dotted  black;">
                            </td>

                        </tr>
                        <tr>
                            <td>3. Pengesahan</td>
                            <td></td>
                            <td> Permohonan Ini</td>
                            <td>:</td>
                            <td><input type="checkbox" class="form-control" name="cbdiketahui" id="cbdiketahui">Diketahui</td>
                            <td><input type="checkbox" class="form-control" name="cbditunda" id="cbditunda">Ditunda</td>
                            <td><input type="checkbox" class="form-control" name="cbditolak" id="cbditolak">Ditolak</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td> </td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td class="text-center" colspan="3">Atasan Langsung</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td rowspan="2" colspan="3"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>

                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td colspan="3" class="text-center">Nama</td>

                        </tr>
                    </table>
                </div>
            </div>


        </div>
    </div>
</div>


<?php $no = 0;
foreach ($data as $key) { ?>
    <div class="modal fade data<?= $key->idutama ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Apakah anda yakin akan menghapus <strong><?= $key->nama_karyawan ?></strong>?</h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?del=<?= $key->idutama ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<div class="modal fade" id="form_edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="heditid" id="heditid">

                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Karyawan<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <select class="form-control select2" name="editidkaryawan" id="editidkaryawan" readonly disabled>
                            <option value="">Pilih Karyawan</option>
                            <?php foreach (show_data("karyawan") as $un) {
                                echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                            } ?>

                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">No Ktp<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" class="form-control" readonly disabled name="notkp" id="editnoktp">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">No HP<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" class="form-control" readonly disabled name="nohp" id="editnohp">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Divisi<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" class="form-control" readonly disabled name="divisi" id="editdivisi">
                    </div>
                </div>

                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Pilih Cuti<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <select class="form-control select2" name="jenis_cuti" id="editjenis_cuti">
                            <option value="">Pilih Cuti</option>
                            <?php foreach (show_data("jenis_cuti") as $un) {
                                echo "<option value='" . $un->id . "'>" . $un->nama_jenis . "</option>";
                            } ?>

                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Tanggal Mulai<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="date" id="edittanggal_mulai" name="tanggal_mulai" required="required" class="form-control" required>

                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Lama Cuti <span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="editlama" name="lama" required="required" onchange="handlerLamaCuti(this.value, 'edit')" class="form-control numeric" required>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Tanggal Akhir<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="date" id="edittanggal_akhir" name="tanggal_akhir" required="required" class="form-control" disabled required>

                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Tanggal Masuk<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="date" id="edittanggal_masuk" name="tanggal_masuk" required="required" class="form-control" disabled required>

                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jumlah Hari Kerja<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="editlamakerja" name="lama" required="required" class="form-control numeric" disabled required>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jumlah Hari Libur/Off<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="editlamalibur" name="lamalibur" required="required" class="form-control numeric" disabled required>
                    </div>
                </div>


                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Alamat Lokasi<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <textarea id="editalamatlokasi" name="alamatlokasi" required="required" class="form-control" required></textarea>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Keterangan<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <textarea id="editketerangan" name="keterangan" required="required" class="form-control" required></textarea>
                    </div>
                </div>
                <div class="item form-group">
                    <label for="statuspengajuan" class="col-form-label col-md-3 col-sm-3 label-align">Status</label>
                    <div class="col-md-6 col-sm-6 ">
                        <input id="editstatuspengajuan" class="form-control" type="text" name="statuspengajuan" required value="Draft" disabled readonly>
                        <input type="checkbox" name="" id="" onchange="Changecbedit(event)" style="transform: scale(1.75); margin-top:10px; margin-left:5px;">
                    </div>
                </div>
                <div class="ln_solid"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
            </div>

        </div>
    </div>
</div>
<script>
    const initConfigDatatable = {
        dom: 'Bfrtip',
        buttons: [{
                extend: "print",
                text: '<i class="fa fa-print"></i> Print',
                className: 'btn btn-warning',
                customize: function(win) {

                    var last = null;
                    var current = null;
                    var bod = [];

                    var css = '@page { size: landscape; }',
                        head = win.document.head || win.document.getElementsByTagName('head')[0],
                        style = win.document.createElement('style');

                    style.type = 'text/css';
                    style.media = 'print';

                    if (style.styleSheet) {
                        style.styleSheet.cssText = css;
                    } else {
                        style.appendChild(win.document.createTextNode(css));
                    }

                    head.appendChild(style);
                }
            },
            {
                extend: 'excelHtml5',
                text: '<i class="fa fa-file-excel-o"></i> Excel',
                className: 'btn btn-success',
            },
            {
                extend: 'csvHtml5',
                text: '<i class="fa fa-file"></i> CSV',
                className: 'btn btn-info',
            },
            {
                extend: 'pdfHtml5',
                orientation: 'landscape',
                text: '<i class="fa fa-file-pdf-o"></i> PDF',
                className: 'btn btn-danger',
                pageSize: 'LEGAL'
            }, {
                text: '<i class="fa fa-user-plus"></i> Buat Pengajuan Cuti',
                className: 'btn btn-success',
                action: function(e, dt, node, conf) {
                    handlerAddPengajuanCuti()
                }
            }
        ]
    }

    function message(msg, msgtext, msgtype) {
        Swal.fire(msg, msgtext, msgtype);
    }
    // essage("Error!", "<span name='CAPTION-ALERT-PILIHSKU'>Mohon pilih SKU</span>", "error");
    // message_topright("success", "<span name='CAPTION-ALERT-BERHASIL'>Data berhasil disimpan</span>");


    function message_topright(type, msg) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            didOpen: (toast) => {
                toast.addEventListener("mouseenter", Swal.stopTimer);
                toast.addEventListener("mouseleave", Swal.resumeTimer);
            },
        });

        Toast.fire({
            icon: type,
            title: msg,
        });
    }
    $(document).on('change', '#tanggal_mulai', function() {
        let tgl_mulai = $(this).val();
        let tgl_akhir = $('#tangal_akhir').val();
        const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
        const firstDate = new Date(tgl_mulai);
        const secondDate = new Date(tgl_akhir);

        const diffDays = Math.round(Math.abs((firstDate - secondDate) / oneDay));

        $('#lama').val(diffDays);
    })

    // This is the somewhat faster version
    const addBusinessDays2 = (date, days) => {
        var d = moment(new Date(date)).add(Math.floor(days / 5) * 7, 'd');
        var remaining = days % 5;
        while (remaining) {
            d.add(1, 'd');
            if (d.day() !== 0 && d.day() !== 6)
                remaining--;
        }
        return d;
    };

    function getBusinessDatesCount(startDate, endDate) {
        let count = 0;
        const curDate = new Date(startDate.getTime());
        while (curDate <= endDate) {
            const dayOfWeek = curDate.getDay();
            if (dayOfWeek !== 0 && dayOfWeek !== 6) count++;
            curDate.setDate(curDate.getDate() + 1);
        }
        return count;
    }

    function CalculateWeekendDays(fromDate, toDate) {
        var weekendDayCount = 0;

        while (fromDate < toDate) {
            fromDate.setDate(fromDate.getDate() + 1);
            if (fromDate.getDay() === 0 || fromDate.getDay() == 6) {
                ++weekendDayCount;
            }
        }

        return weekendDayCount;
    }

    const handlerLamaCuti = (lamaCuti, mode) => {

        if (lamaCuti == "") {
            $("#tanggal_akhir, #edittanggal_akhir").val("<?= date('Y-m-d') ?>");
            $("#tanggal_masuk, #edittanggal_masuk").val("<?= date('Y-m-d') ?>");
            $("#lamakerja, #editlamakerja").val('');
            $("#lamalibur, #editlamalibur").val('');
        } else {
            if (mode == 'insert') {
                let tanggalAkhir = addBusinessDays2($('#tanggal_mulai').val(), parseInt(lamaCuti)).format('YYYY-MM-DD')
                $("#tanggal_akhir").val(tanggalAkhir);
                $("#tanggal_masuk").val(addBusinessDays2(tanggalAkhir, 1).format('YYYY-MM-DD'));
                $("#lamakerja").val(getBusinessDatesCount(new Date($('#tanggal_mulai').val()), new Date($('#tanggal_akhir').val())));
                $("#lamalibur").val(CalculateWeekendDays(new Date($('#tanggal_mulai').val()), new Date($('#tanggal_akhir').val())));
            }
            if (mode == 'edit') {
                let tanggalAkhirEdit = addBusinessDays2($('#edittanggal_mulai').val(), parseInt(lamaCuti)).format('YYYY-MM-DD')
                $("#edittanggal_akhir").val(tanggalAkhirEdit);
                $("#edittanggal_masuk").val(addBusinessDays2(tanggalAkhirEdit, 1).format('YYYY-MM-DD'));
                $("#editlamakerja").val(getBusinessDatesCount(new Date($('#edittanggal_mulai').val()), new Date($('#edittanggal_akhir').val())));
                $("#editlamalibur").val(CalculateWeekendDays(new Date($('#edittanggal_mulai').val()), new Date($('#edittanggal_akhir').val())));
            }

        }


    }

    // $(document).on('change', '#tanggal_akhir', function() {
    //     let tgl_akhir = $(this).val();
    //     let tgl_mulai = $('#tanggal_mulai').val();
    //     const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    //     const firstDate = new Date(tgl_mulai);
    //     const secondDate = new Date(tgl_akhir);

    //     const diffDays = Math.round(Math.abs((firstDate - secondDate) / oneDay));

    //     $('#lama').val(diffDays);

    // })


    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });
        getDataPengajuanCuti();
        $('#tabledatapengajuancuti').DataTable(initConfigDatatable);
    })
    const Changecb = (e) => {
        if (e.target.checked == true) {
            $('#statuspengajuan').val('In Progres Approval');
        } else {
            $('#statuspengajuan').val('Draft');
        }
    }
    const Changecbedit = (e) => {
        if (e.target.checked == true) {
            $('#editstatuspengajuan').val('In Progres Approval');
        } else {
            $('#editstatuspengajuan').val('Draft');
        }
    }
    $(document).on("input", ".numeric", function(event) {
        this.value = this.value.replace(/[^\d.]+/g, '');
    });
    $('#idkaryawan').change(function() {
        let thisval = $(this).val();
        $.ajax({
            type: 'POST',
            url: '<?= base_url('absensi/getdatakaryawan') ?>',
            data: {
                idkaryawan: thisval
            },
            async: false,
            dataType: "JSON",
            success: function(response) {
                console.log(response.name);
                $('#jabatan').val(response.name)
                $('#noktp').val(response.no_ktp)
                $('#nohp').val(response.phone)
                $('#divisi').val(response.nama_divisi)
            }
        })
    })



    function getDataPengajuanCuti() {
        $.ajax({
            type: 'GET',
            url: '<?= base_url('absensi/getdatapengajuancuti') ?>',
            async: false,
            dataType: "JSON",
            success: function(response) {

                if (response != null) {
                    $('#tabledatapengajuancuti >tbody').empty()

                    $.each(response, function(i, v) {
                        console.log(v.statuspengajuan);
                        if (v.statuspengajuan == "Draft") {
                            $('#tabledatapengajuancuti >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.nama_karyawan}</td>
                            <td>${v.nama_jenis}</td>
                            <td>${v.lama}</td>
                            <td>${v.tgl_mulai1} </td>
                            <td>${v.tgl_akhir1} </td>
                            <td>${v.keterangan} </td>
                            <td>${v.statuspengajuan} </td>
                            <td>${v.acc_on==null?'-':v.acc_on} </td>
                            <td><button id='btn_edit' onclick="editdata('${i}','${v.idutama}','${v.id_karyawan}','${v.no_ktp}','${v.phone}','${v.nama_divisi==null?'-':v.nama_divisi}','${v.id_jeniscuti}','${v.lama}','${v.jumlah_hari_kerja}','${v.jumlah_hari_libur}','${v.tgl_mulai}','${v.tgl_akhir}','${v.tgl_masuk}','${v.keterangan}','${v.statuspengajuan}')" class='btn btn-sm btn-warning' value='${v.id}' ><i class='fa fa-edit'></i></button> 
                            <a href="<?= base_url() ?>absensi/cetakpengajuancuti?id=${v.idutama}" class="btn btn-success btn-sm "><i class="fa fa-book"></i></a>
                            <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data${v.idutama}'><i class='fa fa-trash'></i></a></td>
                        </tr>`);
                        } else {
                            $('#tabledatapengajuancuti >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.nama_karyawan}</td>
                            <td>${v.nama_jenis}</td>
                            <td>${v.lama}</td>
                            <td>${v.tgl_mulai} </td>
                            <td>${v.tgl_akhir} </td>
                            <td>${v.keterangan} </td>
                            <td>${v.statuspengajuan} </td>
                            <td>${v.acc_on==null?'-':v.acc_on} </td>
                            <td>
                            <a href="<?= base_url() ?>absensi/cetakpengajuancuti?id=${v.idutama}" class="btn btn-success btn-sm "><i class="fa fa-book"></i></a>
                            <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data${v.idutama}'><i class='fa fa-trash'></i></a></td>
                        </tr>`);
                        }

                    })
                }
            }
        })
    }

    const handlerAddPengajuanCuti = () => {
        $('#divtambah').show('FadeIn');
        $('#divtablejamkerja').hide('FadeOut');
        $('#title h2').html('Buat Pengajuan ');
        $('#showformtambah').hide();
    }

    $(document).on('click', '#btnkembali', function() {
        $('#divtambah').hide('FadeIn');
        $('#divtablejamkerja').show('FadeOut');
        $('#title h2').html('Data Pengajuan');
        $('#showformtambah').show();


    })


    $(document).on('click', '#btnsave', function() {

        let idkaryawan = $('#idkaryawan option:selected').val();
        let jenis_cuti = $('#jenis_cuti option:selected').val();
        let lama = $('#lama').val();
        let tanggal_mulai = $('#tanggal_mulai').val();
        let tanggal_akhir = $('#tanggal_akhir').val();
        let tanggal_masuk = $('#tanggal_masuk').val();
        let jumlah_hari_kerja = $('#lamakerja').val();
        let jumlah_hari_libur = $('#lamalibur').val();

        let keterangan = $('#keterangan').val();
        let statuspengajuan = $('#statuspengajuan').val();

        if (jenis_cuti == '' || lama == '' || tanggal_mulai == '' || tanggal_akhir == '' || statuspengajuan == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }


        $.ajax({
            type: "POST",
            url: '<?= base_url('absensi/addpengajuancuti'); ?>',
            data: {
                idkaryawan: "<?= $this->session->userdata('user') ?>" == 'admin' ? idkaryawan : "<?= $this->session->userdata('id') ?>",
                jenis_cuti: jenis_cuti,
                lama: lama,
                tanggal_mulai: tanggal_mulai,
                tanggal_akhir: tanggal_akhir,
                tanggal_masuk: tanggal_masuk,
                jumlah_hari_kerja: jumlah_hari_kerja,
                jumlah_hari_libur: jumlah_hari_libur,
                jenis_validasi: $('#jenis_validasi option:selected').val(),
                keterangan: keterangan,
                statuspengajuan: statuspengajuan
            },
            dataType: 'json',
            success: function(response) {
                if (response == 1) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil Ditambah",
                            type: "Success",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    new PNotify({
                        text: 'Data Gagal disimpan!',
                        type: 'Warning!',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 700);
                }
            }

        })



    })

    function editdata(
        i,
        idutama,
        id_karyawan,
        no_ktp,
        nohp,
        nama_divisi,
        id_jeniscuti,
        lama,
        jumlah_hari_kerja,
        jumlah_hari_libur,
        tgl_mulai,
        tgl_akhir,
        tgl_masuk,
        keterangan,
        statuspengajuan
    ) {

        let value = $(this).attr('efektif');
        $('#heditid').val(idutama);
        let editidkaryawan = $('#editidkaryawan').val(id_karyawan).trigger('change');
        let editjenis_cuti = $('#editjenis_cuti').val(id_jeniscuti).change();
        let editlama = $('#editlama').val(lama);
        let editnoktp = $('#editnoktp').val(no_ktp);
        let editnohp = $('#editnohp').val(nohp);
        let editdivisi = $('#editdivisi').val(nama_divisi);
        let edittanggal_mulai = $('#edittanggal_mulai').val(tgl_mulai);
        let edittanggal_akhir = $('#edittanggal_akhir').val(tgl_akhir);
        let edittanggal_masuk = $('#edittanggal_masuk').val(tgl_masuk);
        let editjumlah_hari_kerja = $('#editlamakerja').val(jumlah_hari_kerja);
        let editjumlah_hari_libur = $('#editlamalibur').val(jumlah_hari_libur);

        let editketerangan = $('#editketerangan').val(keterangan);
        let editstatuspengajuan = $('#editstatuspengajuan').val(statuspengajuan);

        $('#form_edit').modal('show');


    }
    $(document).on('click', '#btn_editsimpan', function() {

        // message("Error!", "<span name='CAPTION-ALERT-PILIHSKU'>Cooming soon</span>", "error");
        // return false;
        let editidkaryawan = $('#editidkaryawan').val();
        let editjenis_cuti = $('#editjenis_cuti').val();
        let editlama = $('#editlama').val();
        let editnoktp = $('#editnoktp').val();
        let editnohp = $('#editnohp').val();
        let editdivisi = $('#editdivisi').val();
        let edittanggal_mulai = $('#edittanggal_mulai').val();
        let edittanggal_akhir = $('#edittanggal_akhir').val();
        let edittanggal_masuk = $('#edittanggal_masuk').val();
        let editjumlah_hari_kerja = $('#editlamakerja').val();
        let editjumlah_hari_libur = $('#editlamalibur').val();

        let editketerangan = $('#editketerangan').val();
        let editstatuspengajuan = $('#editstatuspengajuan').val();
        $.ajax({
            type: "POST",
            url: '<?= base_url('absensi/editpengajuancuti'); ?>',
            data: {
                id: $('#heditid').val(),
                idkaryawan: editidkaryawan,
                jenis_cuti: editjenis_cuti,
                lama: editlama,
                tanggal_mulai: edittanggal_mulai,
                tanggal_akhir: edittanggal_akhir,
                tanggal_masuk: edittanggal_masuk,
                jumlah_hari_kerja: editjumlah_hari_kerja,
                jumlah_hari_libur: editjumlah_hari_libur,
                keterangan: editketerangan,
                statuspengajuan: editstatuspengajuan
            },
            dataType: 'json',
            success: function(response) {
                if (response == 1) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil dirubah",
                            type: "Success",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    new PNotify({
                        text: 'Data Gagal disimpan!',
                        type: 'Warning!',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 700);
                }
            }

        })

    })
</script>