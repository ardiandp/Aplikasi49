<?php
$user = where_row('karyawan', ['id' => $this->session->userdata('id')]);


if ($user->is_invited == 1) {
    $disabled = "";
} else {
    $disabled = "disabled";
}

?>


<style>
    .nav-pills .nav-link {
        background: transparent;
        border: 0px;
    }

    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        color: #007bff;
        background: transparent;
        border-bottom: 1px solid #007bff !important;
    }

    #personalData tr {
        line-height: 3.5em;
    }

    .modal-body {
        max-height: calc(100vh - 210px);
        overflow-x: auto;
        overflow-y: auto;
    }
</style>

<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Personal</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="container">
                        <div class="table-responsive">
                            <table style="width: 100%;" id="personalData">
                                <form id="saveheaderDataUmumKaryawan" action="<?= base_url('Users/Karyawan/save_karyawan') ?>" method="POST">
                                    <tr>
                                        <td colspan="4" style="text-align: left;">
                                            <h4><strong>1. Basic Info</strong></h4>
                                        </td>
                                        <td>
                                            <input type="hidden" name="idUsers" id="idUsers" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
                                            <?php if (!isset($_GET['mode'])) { ?>
                                                <button type="button" class="btn btn-info btn-sm pull-right" <?= isset($_GET['id']) && $dataUsers->is_invited == 1 ? 'disabled' : '' ?> onclick="handlerSendEmailByUser()"><i class="fa fa-envelope"></i></button>
                                                <button type="submit" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i></button>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="5%"></td>
                                        <td width="20%">
                                            <h6><strong>Data Personal</strong></h6>
                                        </td>
                                        <td width="18%">Jabatan</td>
                                        <td width="30%">
                                            <select name="jabatanPersonal" id="jabatanPersonal" <?= $disabled ?> class="form-control">
                                                <option>--Pilih Jabatan--</option>
                                                <?php foreach ($dataJabatan as $value) { ?>
                                                    <?php if (isset($dataUsers)) { ?>
                                                        <?php if ($dataUsers->id_jabatan == $value->id) { ?>
                                                            <option value="<?= $value->id ?>" selected><?= $value->name ?></option>
                                                        <?php } else { ?>
                                                            <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                                        <?php } ?>
                                                    <?php } else { ?>
                                                        <option value="<?= $value->id ?>"><?= $value->name ?></option>
                                                    <?php } ?>
                                                <?php } ?>
                                            </select>
                                        </td>
                                        <td width="10%"></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Nama</td>
                                        <td>
                                            <input type="text" class="form-control" name="namaPersonal" id="namaPersonal" placeholder="Nama" value="<?= isset($dataUsers) ? $dataUsers->name : '' ?>" <?= $disabled ?> required>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Telepon</td>
                                        <td>
                                            <input type="text" class="form-control" name="teleponPersonal" id="teleponPersonal" placeholder="Telepon" value="<?= isset($dataUsers) ? $dataUsers->phone : '' ?>" <?= $disabled ?> required>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Email</td>
                                        <td>
                                            <input type="email" class="form-control" name="emailPersonal" id="emailPersonal" placeholder="Email" value="<?= isset($dataUsers) ? $dataUsers->email : '' ?>" <?= $disabled ?> required>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Jenis kelamin</td>
                                        <td>
                                            <select name="genderPersonal" id="genderPersonal" <?= $disabled ?> class="form-control">
                                                <option value="">--Pilih Jenis Kelamin--</option>
                                                <option <?= (isset($dataUsers) && $dataUsers->jenis_kelamin == 0 ? "selected" : "") ?> value="0">Laki - Laki</option>
                                                <option <?= (isset($dataUsers) && $dataUsers->jenis_kelamin == 1 ? "selected" : "") ?> value="1">Perempuan</option>
                                            </select>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Tempat Lahir</td>
                                        <td><input type="text" class="form-control" name="tempatLahirPersonal" id="tempatLahirPersonal" placeholder="Tempat Lahir" value="<?= isset($dataUsers) ? $dataUsers->tmp_lahir : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Tanggal Lahir</td>
                                        <td><input type="date" class="form-control" name="tanggalLahirPersonal" id="tanggalLahirPersonal" placeholder="Tanggal Lahir" value="<?= isset($dataUsers) ? $dataUsers->tgl_lahir : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Suku</td>
                                        <td><input type="text" class="form-control" name="sukuPersonal" id="sukuPersonal" placeholder="Suku" value="<?= isset($dataUsers) ? $dataUsers->suku : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Agama</td>
                                        <td><input type="text" class="form-control" name="agamaPersonal" id="agamaPersonal" placeholder="Agama" value="<?= isset($dataUsers) ? $dataUsers->agama : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Golongan Darah</td>
                                        <td><input type="text" class="form-control" name="golDarahPersonal" id="golDarahPersonal" placeholder="Golongan Darah" value="<?= isset($dataUsers) ? $dataUsers->golongan_darah : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Status Pernikahan</td>
                                        <td>
                                            <select name="statusPernikahanPersonal" id="statusPernikahanPersonal" <?= $disabled ?> class="form-control">
                                                <option value="">--Pilih Status pernikahan--</option>
                                                <option <?= (isset($dataUsers) && $dataUsers->status_pernikahan == 0 ? "selected" : "") ?> value="0">Belum Nikah</option>
                                                <option <?= (isset($dataUsers) && $dataUsers->status_pernikahan == 1 ? "selected" : "") ?> value="1">Sudah Nikah</option>
                                            </select>
                                        </td>
                                        <td></td>
                                    </tr>

                                    <tr>
                                        <td></td>
                                        <td>
                                            <h6><strong>ID dan Alamat</strong></h6>
                                        </td>
                                        <td>No. KTP</td>
                                        <td><input type="text" class="form-control" name="noKTPPersonal" id="noKTPPersonal" placeholder="No. KTP" value="<?= isset($dataUsers) ? $dataUsers->no_ktp : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>

                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>No. NPWP</td>
                                        <td><input type="text" class="form-control" name="noNPWPPersonal" id="noNPWPPersonal" placeholder="No. NPWP" value="<?= isset($dataUsers) ? $dataUsers->no_npwp : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>NIP</td>
                                        <td><input type="text" class="form-control" name="nipPersonal" id="nipPersonal" placeholder="NIP" value="<?= isset($dataUsers) ? $dataUsers->nip : '' ?>" <?= $disabled ?> required></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Alamat - Sesuai KTP</td>
                                        <td>
                                            <fieldset>
                                                <div class="row">
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="provinsiKTP">Provinsi</label>
                                                            <select name="provinsiKTP" id="provinsiKTP" <?= $disabled ?> class="form-control select2" onchange="handlerProvinsiKTPChange(this.value)" required>
                                                                <option value="">--Pilih Provinsi--</option>
                                                                <?php foreach ($dataProvinsi as $key => $value) { ?>
                                                                    <?php if (isset($dataUsers)) { ?>
                                                                        <?php if ($dataUsers->provinsi == $value->id) { ?>
                                                                            <option value="<?= $value->id ?>" selected><?= $value->nama ?></option>
                                                                        <?php } else { ?>
                                                                            <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                                    <?php } ?>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="kotaKTP">Kabupaten / Kota</label>
                                                            <select name="kotaKTP" id="kotaKTP" <?= $disabled ?> class="form-control select2" onchange="handlerKotaKTPChange(this.value)" required>
                                                                <option value="">--Pilih Kabupaten / Kota--</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="kecamatanKTP">Kecamatan</label>
                                                            <select name="kecamatanKTP" id="kecamatanKTP" <?= $disabled ?> class="form-control select2" onchange="handlerKecamatanKTPChange(this.value)" required>
                                                                <option value="">--Pilih Kecamatan--</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="desaKTP">Desa</label>
                                                            <select name="desaKTP" id="desaKTP" <?= $disabled ?> class="form-control select2" required>
                                                                <option value="">--Pilih Desa--</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="alamatKTP">Alamat Lengkap</label>
                                                            <textarea name="alamatKTP" id="alamatKTP" cols="3" rows="3" <?= $disabled ?> class="form-control" style="white-space: normal" required><?= isset($dataUsers) ? $dataUsers->alamat : '' ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </fieldset>
                                        </td>
                                        <hr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td>Domisili</td>
                                        <td>
                                            <div>
                                                <input type="checkbox" name="chkDomisili" style="margin-top:10px;transform: scale(1.5)" <?= $disabled ?> id="chkDomisili" <?= isset($dataUsers) ? ($dataUsers->is_domisili_same_kk == 1 ? 'checked' : '') : 'checked' ?> onchange="handlerChkDomisili(event)">
                                                <span style="margin-left: 10px;font-size:15px;font-weight:700" name="CAPTION-PENGAJUANAPPROVAL">Alamat Sesui KK ?</span>
                                            </div>

                                            <fieldset id="showFieldDomisili" class="mt-3" style="display: <?= isset($dataUsers) ? ($dataUsers->is_domisili_same_kk == 1 ? 'none' : 'block') : 'none' ?>">
                                                <div class="row">
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="provinsiDomisili">Provinsi</label>
                                                            <select name="provinsiDomisili" id="provinsiDomisili" <?= $disabled ?> class="form-control select2" onchange="handlerProvinsiDomisiliChange(this.value)">
                                                                <option value="">--Pilih Provinsi--</option>
                                                                <?php foreach ($dataProvinsi as $key => $value) { ?>
                                                                    <?php if (isset($dataUsers)) { ?>
                                                                        <?php if ($dataUsers->provinsi_domisili == $value->id) { ?>
                                                                            <option value="<?= $value->id ?>" selected><?= $value->nama ?></option>
                                                                        <?php } else { ?>
                                                                            <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                                    <?php } ?>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="kotaDomisili">Kabupaten / Kota</label>
                                                            <select name="kotaDomisili" id="kotaDomisili" <?= $disabled ?> class="form-control select2" onchange="handlerKotaDomisiliChange(this.value)">
                                                                <option value="">--Pilih Kabupaten / Kota--</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="kecamatanDomisili">Kecamatan</label>
                                                            <select name="kecamatanDomisili" id="kecamatanDomisili" <?= $disabled ?> class="form-control select2" onchange="handlerKecamatanDomisiliChange(this.value)">
                                                                <option value="">--Pilih Kecamatan--</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="desaDomisili">Desa</label>
                                                            <select name="desaDomisili" id="desaDomisili" <?= $disabled ?> class="form-control select2">
                                                                <option value="">--Pilih Desa--</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="form-group">
                                                            <label for="alamatDomisili">Alamat Lengkap</label>
                                                            <textarea name="alamatDomisili" id="alamatDomisili" cols="3" rows="3" <?= $disabled ?> class="form-control" style="white-space: normal"><?= isset($dataUsers) ? $dataUsers->alamat_domisili : '' ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </fieldset>
                                        </td>
                                        <td></td>
                                    </tr>
                                </form>
                            </table>
                        </div>
                        <hr>
                        <div>
                            <h4><strong>2. Keluarga</strong></h4>
                            <div class="ml-4 mb-4">
                                <div class="d-flex align-items-center justify-content-between">
                                    <smll><strong>Keluarga inti bila anda sudah menikah <span class="text-danger">Keluarga Sesuai KK</span></strong></smll>
                                    <div>
                                        <?php if (!isset($_GET['mode'])) { ?>
                                            <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddKeluargaInti('1', 'insert')"><i class="fa fa-plus"></i></button>
                                            <button class="btn btn-success btn-sm pull-right" title="tambah ke emergency contact" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddEmergency('1')"><i class="fa fa-check"></i></button>
                                        <?php } ?>

                                    </div>
                                </div>
                                <div class="table-responsive mt-3">
                                    <table class="table table-striped table-bordered" width="100%" id="tablekeluargainti" style="font-size: 12px;">
                                        <thead>
                                            <tr class="bg-dark text-white">
                                                <?php if (!isset($_GET['mode'])) { ?>
                                                    <td>
                                                        <input type="checkbox" name="select-all-keluargaInti" style="transform: scale(1.2)" onchange="checkAll(this, 'keluargaInti')" id="select-all-keluargaInti">
                                                    </td>

                                                <?php } else { ?>
                                                    <td><strong>#</strong></td>
                                                <?php } ?>

                                                <td><strong>NIK</strong></td>
                                                <td><strong>Nama</strong></td>
                                                <td><strong>TTL</strong></td>
                                                <td><strong>L/P</strong></td>
                                                <td><strong>Hubungan</strong></td>
                                                <td><strong>Status</strong></td>
                                                <td><strong>Pekerjaan</strong></td>
                                                <?php if (!isset($_GET['mode'])) { ?>
                                                    <td><strong>Action</strong></td>
                                                <?php } ?>

                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="ml-4">
                                <div class="d-flex align-items-center justify-content-between">
                                    <smll><strong>Keluarga Anda (Ayah, Ibu, saudara sekandung termasuk anda) <span class="text-danger">Keluarga Anda</span></strong></smll>
                                    <div>
                                        <?php if (!isset($_GET['mode'])) { ?>
                                            <button class="btn btn-primary btn-sm pull-right" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddKeluargaAnda('2', 'insert')"><i class="fa fa-plus"></i></button>
                                            <button class="btn btn-success btn-sm pull-right" title="tambah ke emergency contact" <?= isset($_GET['id']) ? '' : 'disabled' ?> onclick="handlerBtnAddEmergency('2')"><i class="fa fa-check"></i></button>
                                        <?php } ?>

                                    </div>
                                </div>
                                <div class="table-responsive mt-3">
                                    <table class="table table-striped table-bordered" width="100%" id="tablekeluargaanda" style="font-size: 12px;">
                                        <thead>
                                            <tr class="bg-dark text-white">
                                                <?php if (!isset($_GET['mode'])) { ?>
                                                    <td>
                                                        <input type="checkbox" name="select-all-keluargaAnda" style="transform: scale(1.2)" onchange="checkAll(this, 'keluargaAnda')" id="select-all-keluargaAnda">
                                                    </td>

                                                <?php } else { ?>
                                                    <td><strong>#</strong></td>
                                                <?php } ?>

                                                <td><strong>NIK</strong></td>
                                                <td><strong>Nama</strong></td>
                                                <td><strong>TTL</strong></td>
                                                <td><strong>L/P</strong></td>
                                                <td><strong>Hubungan</strong></td>
                                                <td><strong>Status</strong></td>
                                                <td><strong>Pekerjaan</strong></td>
                                                <td><strong>Phone</strong></td>
                                                <td><strong>Provinsi</strong></td>
                                                <td><strong>Kota</strong></td>
                                                <td><strong>Kecamatan</strong></td>
                                                <td><strong>Desa</strong></td>
                                                <td><strong>Alamat</strong></td>
                                                <?php if (!isset($_GET['mode'])) { ?>
                                                    <td><strong>Action</strong></td>
                                                <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div>
                            <h4><strong>3. Emergency Contact</strong></h4>
                            <div class="ml-4 mb-4">
                                <div class="d-flex align-items-center justify-content-between">
                                    <smll><strong>Keluarga tidak serumah <span class="text-danger">Emergency Contact</span></strong></smll>
                                </div>
                                <div class="table-responsive mt-3">
                                    <table class="table table-striped table-bordered" width="100%" id="tableemergency" style="font-size: 12px;">
                                        <thead>
                                            <tr class="bg-dark text-white">
                                                <td><strong>No</strong></td>
                                                <td><strong>NIK</strong></td>
                                                <td><strong>Nama</strong></td>
                                                <td><strong>TTL</strong></td>
                                                <td><strong>L/P</strong></td>
                                                <td><strong>Hubungan</strong></td>
                                                <td><strong>Status</strong></td>
                                                <td><strong>Pekerjaan</strong></td>
                                                <td><strong>Phone</strong></td>
                                                <td><strong>Provinsi</strong></td>
                                                <td><strong>Kota</strong></td>
                                                <td><strong>Kecamatan</strong></td>
                                                <td><strong>Desa</strong></td>
                                                <td><strong>Alamat</strong></td>
                                                <?php if (!isset($_GET['mode'])) { ?>
                                                    <td><strong>Action</strong></td>
                                                <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="modalAddKeluarga" role="dialog" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="myModalLabel2"></h4>
                                </div>
                                <div class="modal-body">
                                    <div class="container">
                                        <div class="form-group">
                                            <label for="nik">NIK</label>
                                            <input type="text" name="nik" id="nik" class="form-control" placeholder="NIK" autocomplete="off" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="nama">Nama</label>
                                            <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama" autocomplete="off" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="tempat_lahir">Tempat Lahir</label>
                                            <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control" placeholder="Tempat lahir" autocomplete="off" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="tanggal_lahir">Tanggal Lahir</label>
                                            <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control" placeholder="Tanggal lahir" autocomplete="off" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="jenis_kelamin">Jenis Kelamin</label>
                                            <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                                                <option value="">--Pilih Jenis Kelamin--</option>
                                                <option value="0">Laki - Laki</option>
                                                <option value="1">Perempuan</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="hubungan">Hubungan</label>
                                            <select name="hubungan" id="hubungan" class="form-control">
                                                <option value="">--Pilih Hubungan--</option>
                                                <option value="1">Kepala Keluarga</option>
                                                <option value="2">Istri</option>
                                                <option value="3">Anak</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <select name="status" id="status" class="form-control">
                                                <option value="">--Pilih Status--</option>
                                                <option value="0">Menikah</option>
                                                <option value="1">Belum Menikah</option>
                                                <option value="2">Cerai Hidup</option>
                                                <option value="3">Cerai Mati</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="pekerjaan">Pekerjaan</label>
                                            <input type="text" name="pekerjaan" id="pekerjaan" class="form-control" placeholder="Pekerjaan" autocomplete="off" required>
                                        </div>
                                        <hr>
                                        <div id="showAlamatKeluargaAnda" style="display:none">
                                            <fieldset>
                                                <legend>Data Alamat</legend>
                                                <div class="container">

                                                    <div class="form-group">
                                                        <label for="phoneKeluargaAnda">No. Handphone</label>
                                                        <input type="text" name="phoneKeluargaAnda" id="phoneKeluargaAnda" class="form-control" placeholder="No. Handphone" autocomplete="off" required>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="provinsiKeluargaAnda">Provinsi</label>
                                                        <select name="provinsiKeluargaAnda" id="provinsiKeluargaAnda" class="form-control select2" onchange="handlerProvinsiKeluargaAndaChange(this.value)" required>
                                                            <option value="">--Pilih Provinsi--</option>
                                                            <?php foreach ($dataProvinsi as $key => $value) { ?>
                                                                <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="kotaKeluargaAnda">Kabupaten / Kota</label>
                                                        <select name="kotaKeluargaAnda" id="kotaKeluargaAnda" class="form-control select2" onchange="handlerKotaKeluargaAndaChange(this.value)" required>
                                                            <option value="">--Pilih Kabupaten / Kota--</option>
                                                        </select>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="kecamatanKeluargaAnda">Kecamatan</label>
                                                        <select name="kecamatanKeluargaAnda" id="kecamatanKeluargaAnda" class="form-control select2" onchange="handlerKecamatanKeluargaAndaChange(this.value)" required>
                                                            <option value="">--Pilih Kecamatan--</option>
                                                        </select>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="desaKeluargaAnda">Desa</label>
                                                        <select name="desaKeluargaAnda" id="desaKeluargaAnda" class="form-control select2" required>
                                                            <option value="">--Pilih Desa--</option>
                                                        </select>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="alamatKeluargaAnda">Alamat Lengkap</label>
                                                        <textarea name="alamatKeluargaAnda" id="alamatKeluargaAnda" cols="3" rows="3" class="form-control" style="white-space: normal" required></textarea>
                                                    </div>
                                                </div>
                                            </fieldset>
                                            <hr>
                                            <div>
                                                <input type="checkbox" name="chkEmergency" style="margin-top:10px;transform: scale(1.5)" id="chkEmergency">
                                                <span style="margin-left: 10px;font-size:15px;font-weight:700">Masukkan ke Emergency Contact?</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary addKeluarga" type="button" onclick="handlerAddKeluarga(event)">Simpan</button>
                                    <button class="btn btn-dark" type="button" onclick="closeModalKeluarga()">kembali</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="modalDeleteData" role="dialog" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body"></div>
                                <div class="modal-footer">
                                    <button class="btn btn-danger deleteData" type="button" onclick="handlerDeleteData(event)">Delete Data</button>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<script>
    const urlSearchParams = new URLSearchParams(window.location.search);
    const mode = Object.fromEntries(urlSearchParams.entries()).mode;


    $(document).ready(function() {
        getDataKeluargaInti();
        getDataKeluargaAnda();
        getDataKeluargaEmergency();
        $(".select2").select2({
            width: "100%"
        });

        if ('<?= isset($dataUsers) ?>') {
            $('#provinsiKTP').val('<?= $dataUsers->provinsi ?>').trigger('change');
            $('#kotaKTP').val('<?= $dataUsers->kota ?>').trigger('change');
            $('#kecamatanKTP').val('<?= $dataUsers->kecamatan ?>').trigger('change');
            $('#desaKTP').val('<?= $dataUsers->desa ?>').trigger('change');

            $('#provinsiDomisili').val('<?= $dataUsers->provinsi_domisili ?>').trigger('change');
            $('#kotaDomisili').val('<?= $dataUsers->kota_domisili ?>').trigger('change');
            $('#kecamatanDomisili').val('<?= $dataUsers->kecamatan_domisili ?>').trigger('change');
            $('#desaDomisili').val('<?= $dataUsers->desa_domisili ?>').trigger('change');
        }

        // $("#tableemergency").DataTable()
    });

    const handlerProvinsiKTPChange = (idProvinsi) => {
        ajaxRequesProvinsiChange('ktp', idProvinsi);
    }

    const handlerKotaKTPChange = (idKota) => {
        ajaxRequesKotaChange('ktp', idKota)
    }

    const handlerKecamatanKTPChange = (idKecamatan) => {
        ajaxRequesKecamatanChange('ktp', idKecamatan)
    }

    const handlerProvinsiDomisiliChange = (idProvinsi) => {
        ajaxRequesProvinsiChange('domisili', idProvinsi);
    }

    const handlerKotaDomisiliChange = (idKota) => {
        ajaxRequesKotaChange('domisili', idKota)
    }

    const handlerKecamatanDomisiliChange = (idKecamatan) => {
        ajaxRequesKecamatanChange('domisili', idKecamatan)
    }

    const handlerProvinsiKeluargaAndaChange = (idProvinsi) => {
        ajaxRequesProvinsiChange('keluargaAnda', idProvinsi);
    }

    const handlerKotaKeluargaAndaChange = (idKota) => {
        ajaxRequesKotaChange('keluargaAnda', idKota)
    }

    const handlerKecamatanKeluargaAndaChange = (idKecamatan) => {
        ajaxRequesKecamatanChange('keluargaAnda', idKecamatan)
    }

    const ajaxRequesProvinsiChange = (type, idProvinsi) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKotaByProvinsiId') ?>",
            data: {
                idProvinsi
            },
            dataType: "JSON",
            async: false,
            success: function(response) {
                if (type === 'ktp') {
                    $("#kotaKTP").empty();
                }
                if (type === 'domisili') {
                    $("#kotaDomisili").empty();
                }
                if (type === 'keluargaAnda') {
                    $("#kotaKeluargaAnda").empty();
                }

                let html = "";
                html += `<option value="">--Pilih Kabupaten / Kota--</option>`
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        html += `<option value="${v.id}">${v.nama}</option>`
                    })
                }

                if (type === 'ktp') {
                    $("#kotaKTP").append(html);
                }
                if (type === 'domisili') {
                    $("#kotaDomisili").append(html);
                }

                if (type === 'keluargaAnda') {
                    $("#kotaKeluargaAnda").append(html);
                }
            }
        });
    }

    const ajaxRequesKotaChange = (type, idKota) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKecamatanByKotaId') ?>",
            data: {
                idKota
            },
            dataType: "JSON",
            async: false,
            success: function(response) {
                if (type === 'ktp') {
                    $('#kecamatanKTP').empty();
                }
                if (type === 'domisili') {
                    $("#kecamatanDomisili").empty();
                }

                if (type === 'keluargaAnda') {
                    $("#kecamatanKeluargaAnda").empty();
                }

                let html = "";
                html += `<option value="">--Pilih Kecamatan--</option>`
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        html += `<option value="${v.id}">${v.nama}</option>`
                    })
                }

                if (type == 'ktp') {
                    $("#kecamatanKTP").append(html);
                }
                if (type == 'domisili') {
                    $("#kecamatanDomisili").append(html);
                }
                if (type === 'keluargaAnda') {
                    $("#kecamatanKeluargaAnda").append(html);
                }
            }
        });
    }

    const ajaxRequesKecamatanChange = (type, idKecamatan) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataDesaByKecamatanId') ?>",
            data: {
                idKecamatan
            },
            dataType: "JSON",
            async: false,
            success: function(response) {
                if (type === 'ktp') {
                    $('#desaKTP').empty();
                }
                if (type === 'domisili') {
                    $("#desaDomisili").empty();
                }
                if (type === 'keluargaAnda') {
                    $("#desaKeluargaAnda").empty();
                }
                let html = "";
                html += `<option value="">--Pilih Desa--</option>`
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        html += `<option value="${v.id}">${v.nama}</option>`
                    })
                }

                if (type == 'ktp') {
                    $("#desaKTP").append(html);
                }
                if (type == 'domisili') {
                    $("#desaDomisili").append(html);
                }
                if (type === 'keluargaAnda') {
                    $("#desaKeluargaAnda").append(html);
                }
            }
        });
    }

    const handlerChkDomisili = (event) => {
        if (event.currentTarget.checked) {
            event.currentTarget.value = 0;
            $("#showFieldDomisili").hide('slow');
            $("#provinsiDomisili").prop('required', false);
            $("#kotaDomisili").prop('required', false);
            $("#kecamatanDomisili").prop('required', false);
            $("#desaDomisili").prop('required', false);
            $("#alamatDomisili").prop('required', false);
        } else {
            event.currentTarget.value = 1;
            $("#showFieldDomisili").show('slow');
            $("#provinsiDomisili").prop('required', true);
            $("#kotaDomisili").prop('required', true);
            $("#kecamatanDomisili").prop('required', true);
            $("#desaDomisili").prop('required', true);
            $("#alamatDomisili").prop('required', true);
        }
    }

    const getDataKeluargaInti = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaInti') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablekeluargainti > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {
                        let disChk = v.is_emergency_contact == 1 ? 'disabled checked' : '';

                        let chk = typeof mode !== 'undefined' ? `${i + 1}` : `<input type="checkbox" class="form-control check-item-keluargaInti" ${disChk} name="check-item-keluargaInti" style="transform: scale(1.2)" id="check-item-keluargaInti" value="${v.id}" />`;

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="btn btn-warning btn-sm" onclick="handlerEditDataKeluarga('1','${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm" onclick="handlerHapusDataKeluarga('1','${v.id}', '${v.nama}')"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </td>`
                        }

                        $('#tablekeluargainti > tbody').append(`
                            <tr>
                                <td>${chk}</td>
                                <td>${v.nik}</td>
                                <td>${v.nama}</td>
                                <td>${v.tempat_lahir}, ${formatTanggal(v.tanggal_lahir)}</td>
                                <td>${v.jenis_kelamin == 0 ? 'L' : 'P'}</td>
                                <td>${v.hubungan}</td>
                                <td>${v.status == 0 ? 'Menikah' :  v.status == 1 ? 'Belum Menikah' : v.status == 2 ? 'Cerai' : 'Cerai Mati'}</td>
                                <td>${v.pekerjaan}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablekeluargainti > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode !== 'undefined' ? '8' : '9'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const getDataKeluargaAnda = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaAnda') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tablekeluargaanda > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {
                        let disChk = v.is_emergency_contact == 1 ? 'disabled checked' : '';

                        let chk = typeof mode != 'undefined' ? `${i + 1}` : `<input type="checkbox" class="form-control check-item-keluargaAnda" ${disChk} name="check-item-keluargaAnda" style="transform: scale(1.2)" id="check-item-keluargaAnda" value="${v.id}" />`;

                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="btn btn-warning btn-sm" onclick="handlerEditDataKeluarga('2','${v.id}', 'update')"><i class="fa fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm" onclick="handlerHapusDataKeluarga('2','${v.id}', '${v.nama}')"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </td>`
                        }

                        $('#tablekeluargaanda > tbody').append(`
                            <tr>
                                <td>${chk}</td>
                                <td>${v.nik}</td>
                                <td>${v.nama}</td>
                                <td>${v.tempat_lahir}, ${formatTanggal(v.tanggal_lahir)}</td>
                                <td>${v.jenis_kelamin == 0 ? 'L' : 'P'}</td>
                                <td>${v.hubungan}</td>
                                <td>${v.status == 0 ? 'Menikah' :  v.status == 1 ? 'Belum Menikah' : v.status == 2 ? 'Cerai' : 'Cerai Mati'}</td>
                                <td>${v.pekerjaan}</td>
                                <td>${v.phone == null ? '-' : v.phone}</td>
                                <td>${v.provinsiNama == null ? '-' : v.provinsiNama}</td>
                                <td>${v.kotaNama == null ? '-' : v.kotaNama}</td>
                                <td>${v.kecamatanNama == null ? '-' : v.kecamatanNama}</td>
                                <td>${v.desaNama == null ? '-' : v.desaNama}</td>
                                <td>${v.alamat == null ? '-' : v.alamat}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tablekeluargaanda > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode != 'undefined' ? '14' : '15'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const getDataKeluargaEmergency = () => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaEmergency') ?>",
            data: {
                idUsers: "<?= isset($_GET['id']) ? $_GET['id'] : null ?>"
            },
            dataType: "JSON",
            success: function(response) {
                $('#tableemergency > tbody').empty()
                if (response.length > 0) {

                    $.each(response, function(i, v) {
                        let tdLast = "";
                        if (typeof mode === 'undefined') {
                            tdLast = `<td>
                                        <button class="btn btn-danger btn-sm" onclick="handlerHapusDataKeluarga('3','${v.id}', '${v.nama}')"><i class="fa fa-trash"></i></button>
                                  </td>`
                        }
                        $('#tableemergency > tbody').append(`
                            <tr>
                                <td>${i + 1}</td>
                                <td>${v.nik}</td>
                                <td>${v.nama}</td>
                                <td>${v.tempat_lahir}, ${formatTanggal(v.tanggal_lahir)}</td>
                                <td>${v.jenis_kelamin == 0 ? 'L' : 'P'}</td>
                                <td>${v.hubungan}</td>
                                <td>${v.status == 0 ? 'Menikah' :  v.status == 1 ? 'Belum Menikah' : v.status == 2 ? 'Cerai' : 'Cerai Mati'}</td>
                                <td>${v.pekerjaan}</td>
                                <td>${v.phone == null ? '-' : v.phone}</td>
                                <td>${v.provinsiNama == null ? '-' : v.provinsiNama}</td>
                                <td>${v.kotaNama == null ? '-' : v.kotaNama}</td>
                                <td>${v.kecamatanNama == null ? '-' : v.kecamatanNama}</td>
                                <td>${v.desaNama == null ? '-' : v.desaNama}</td>
                                <td>${v.alamat == null ? '-' : v.alamat}</td>
                                ${tdLast}
                            </tr>
                        `);

                    })
                } else {
                    $('#tableemergency > tbody').append(`<tr><td class="text-center text-danger" colspan="${typeof mode != 'undefined' ? '14' : '15'}">Data kosong</td></tr>`)
                }
            }
        });
    }

    const handlerSendEmailByUser = () => {
        if ($('#idUsers').val() == '') {
            new PNotify({
                text: 'Data karyawan belum disimpan, silahkan simpan terlebih dahulu',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
            })
            return false;
        }

        $('#modalAddWaktu').modal('show');
    }

    const closeModal = () => {
        $('#modalAddWaktu').modal('hide');
        $('#type').val('');
    }

    const sendEmailE = (event) => {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveKaryawanByEmail') ?>",
            dataType: "JSON",
            data: {
                dataChecked: $('#idUsers').val(),
                type: 'invited',
                waktu: null
            },
            beforeSend: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false
                });
            },
            success: function(response) {
                if (response.type == 200) {
                    new PNotify({
                        text: response.message,
                        type: 'success',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })

                    location.reload();
                }

                if (response.type == 202) {

                    $.each(response.data, function(i, v) {
                        new PNotify({
                            text: `Email dari username <strong>${v}</strong> kosong, silahkan update data karyawan terlebih dahulu`,
                            type: 'error',
                            styling: 'bootstrap3',
                            delay: 2000,
                            history: false
                        });
                    })
                }

                if (response.type == 203) {
                    new PNotify({
                        text: response.message,
                        type: 'error',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })
                }
            },
            error: function(xhr) { // if error occured
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
            complete: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
        });
    }

    const handlerBtnAddKeluargaInti = (type, mode) => {
        resetFormKeluarga();
        $('#modalAddKeluarga').modal('show');
        $('#modalAddKeluarga .modal-title').html('Tambah Data Keluarga Inti');
        $('.addKeluarga').attr('data-type', type)
        $('.addKeluarga').attr('data-mode', mode)
        $('#showAlamatKeluargaAnda').hide('slow');
    }

    const handlerBtnAddKeluargaAnda = (type, mode) => {
        resetFormKeluarga();
        $('#modalAddKeluarga').modal('show');
        $('#modalAddKeluarga .modal-title').html('Tambah Data Keluarga Anda');
        $('.addKeluarga').attr('data-type', type)
        $('.addKeluarga').attr('data-mode', mode)
        $('#showAlamatKeluargaAnda').show('slow');
    }

    const handlerEditDataKeluarga = (type, idKeluarga, mode) => {
        resetFormKeluarga();
        $('#modalAddKeluarga').modal('show');
        if (type == '1') {
            $('#modalAddKeluarga .modal-title').html('Edit Data Keluarga Inti');
            $('#showAlamatKeluargaAnda').hide('slow');
        } else {
            $('#modalAddKeluarga .modal-title').html('Edit Data Keluarga Anda');
            $('#showAlamatKeluargaAnda').show('slow');
        }
        $('.addKeluarga').attr('data-id', idKeluarga)
        $('.addKeluarga').attr('data-type', type)
        $('.addKeluarga').attr('data-mode', mode)

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getDataKeluargaById') ?>",
            data: {
                idKeluarga
            },
            dataType: "JSON",
            success: function(response) {
                $('#nik').val(response.nik)
                $('#nama').val(response.nama)
                $('#tempat_lahir').val(response.tempat_lahir)
                $('#tanggal_lahir').val(response.tanggal_lahir)
                $('#jenis_kelamin').val(response.jenis_kelamin).trigger('change')
                $('#hubungan').val(response.hubungan).trigger('change')
                $('#status').val(response.status).trigger('change')
                $('#pekerjaan').val(response.pekerjaan)

                if (type == '2') {
                    $('#phoneKeluargaAnda').val(response.phone);
                    $('#provinsiKeluargaAnda').val(response.provinsi).trigger('change');
                    $('#kotaKeluargaAnda').val(response.kota).trigger('change');
                    $('#kecamatanKeluargaAnda').val(response.kecamatan).trigger('change');
                    $('#desaKeluargaAnda').val(response.desa).trigger('change');
                    $('#alamatKeluargaAnda').val(response.alamat);
                    response.is_emergency_contact == 1 ? $('#chkEmergency').prop('checked', true) : $('#chkEmergency').prop('checked', false);
                }
            }
        });
    }

    const handlerHapusDataKeluarga = (type, idKeluarga, nama) => {
        $('#modalDeleteData').modal('show');
        $('.deleteData').attr('data-id', idKeluarga)
        $('.deleteData').attr('data-type', type)
        if (type == '3') {
            $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data emergency contact <strong>${nama}</strong></h6>`);
        } else {
            $('#modalDeleteData .modal-body').html(`<h6>Pastikan anda yakin akan menghapus data karyawan <strong>${nama}</strong></h6>`);
        }
    }

    const handlerDeleteData = (event) => {
        let idKeluarga = event.currentTarget.getAttribute('data-id');
        let type = event.currentTarget.getAttribute('data-type');

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/deleteDataKeluarga') ?>",
            dataType: "JSON",
            data: {
                idKeluarga,
                type,
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    // location.reload();
                    if (response.type == '1') {
                        getDataKeluargaInti();
                    }

                    if (response.type == '2') {
                        getDataKeluargaAnda();
                    }

                    if (response.type == '3') {
                        getDataKeluargaInti();
                        getDataKeluargaAnda();
                    }
                    getDataKeluargaEmergency();
                    $('#modalDeleteData').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });

    }

    const handlerAddKeluarga = (event) => {
        let idKeluarga = event.currentTarget.getAttribute('data-id');
        let type = event.currentTarget.getAttribute('data-type');
        let mode = event.currentTarget.getAttribute('data-mode');
        let nik = $('#nik').val();
        let nama = $('#nama').val();
        let tempat_lahir = $('#tempat_lahir').val();
        let tanggal_lahir = $('#tanggal_lahir').val();
        let jenis_kelamin = $('#jenis_kelamin').val();
        let hubungan = $('#hubungan').val();
        let status = $('#status').val();
        let pekerjaan = $('#pekerjaan').val();

        let noPhone = $('#phoneKeluargaAnda').val();
        let provinsi = $('#provinsiKeluargaAnda').val();
        let kota = $('#kotaKeluargaAnda').val();
        let kecamatan = $('#kecamatanKeluargaAnda').val();
        let desa = $('#desaKeluargaAnda').val();
        let alamat = $('#alamatKeluargaAnda').val();

        if (nik == "") {
            showMessage('error', 'NIK harus terisi')
            return false;
        }

        if (nama == "") {
            showMessage('error', 'Nama harus terisi')
            return false;
        }

        if (tempat_lahir == "") {
            showMessage('error', 'Tempat lahir harus terisi')
            return false;
        }

        if (tanggal_lahir == "") {
            showMessage('error', 'Tanggal lahir harus terisi')
            return false;
        }

        if (jenis_kelamin == "") {
            showMessage('error', 'Jenis kelamin harus terisi')
            return false;
        }

        if (hubungan == "") {
            showMessage('error', 'Hubungan harus terisi')
            return false;
        }

        if (status == "") {
            showMessage('error', 'Status harus terisi')
            return false;
        }

        if (pekerjaan == "") {
            showMessage('error', 'Pekerjaan harus terisi')
            return false;
        }

        if (type == '2') {
            if (noPhone == "") {
                showMessage('error', 'No. Handphone harus terisi')
                return false;
            }

            if (provinsi == "") {
                showMessage('error', 'Provinsi harus terisi')
                return false;
            }

            if (kota == "") {
                showMessage('error', 'Kota harus terisi')
                return false;
            }

            if (kecamatan == "") {
                showMessage('error', 'Kecamatan harus terisi')
                return false;
            }

            if (desa == "") {
                showMessage('error', 'Desa harus terisi')
                return false;
            }

            if (alamat == "") {
                showMessage('error', 'Alamat harus terisi')
                return false;
            }
        }


        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/saveKeluargaKaryawan') ?>",
            dataType: "JSON",
            data: {
                idKeluarga: mode == 'update' ? idKeluarga : null,
                idUsers: $('#idUsers').val(),
                type,
                mode,
                nik,
                nama,
                tempat_lahir,
                tanggal_lahir,
                jenis_kelamin,
                hubungan,
                status,
                pekerjaan,
                noPhone,
                provinsi,
                kota,
                kecamatan,
                desa,
                alamat,
                isEmegercy: $('#chkEmergency').prop('checked') == true ? 1 : 0
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    // location.reload();
                    if (response.type == '1') {
                        getDataKeluargaInti();
                    }

                    if (response.type == '2') {
                        getDataKeluargaAnda();
                        getDataKeluargaEmergency();
                    }
                    resetFormKeluarga();
                    $('#modalAddKeluarga').modal('hide');

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });
    }

    const resetFormKeluarga = () => {
        $('#modalAddKeluarga .modal-title').html();
        $('#nik').val('')
        $('#nama').val('')
        $('#tempat_lahir').val('')
        $('#tanggal_lahir').val('')
        $('#jenis_kelamin').val('')
        $('#hubungan').val('')
        $('#status').val('')
        $('#pekerjaan').val('')

        $('#phoneKeluargaAnda').val('');
        $('#provinsiKeluargaAnda').val('');
        $('#kotaKeluargaAnda').val('');
        $('#kecamatanKeluargaAnda').val('');
        $('#desaKeluargaAnda').val('');
        $('#alamatKeluargaAnda').val('');
        $('#chkEmergency').prop('checked', false);
    }

    const closeModalKeluarga = () => {
        $('#modalAddKeluarga').modal('hide');
        resetFormKeluarga();
    }

    function checkAll(e, type) {
        var checkboxes = $(`input[name='check-item-${type}']`);
        if (e.checked) {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox' && !(checkboxes[i].disabled)) {
                    checkboxes[i].checked = true;
                }
            }
        } else {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox' && !(checkboxes[i].disabled)) {
                    checkboxes[i].checked = false;
                }
            }
        }
    }

    const handlerBtnAddEmergency = (type) => {
        let dataIdKeluarga = [];

        if (type == '1') {
            dataIdKeluarga = $(".check-item-keluargaInti").map(function() {
                if (this.checked == true && !(this.disabled)) {
                    return this.value;
                }
            }).get();
        }

        if (type == '2') {
            dataIdKeluarga = $(".check-item-keluargaAnda").map(function() {
                if (this.checked == true && !(this.disabled)) {
                    return this.value;
                }
            }).get();
        }

        if (dataIdKeluarga.length == 0) {
            showMessage('error', 'pilih data yang akan disimpan ke emergency contact minimal 1');
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/updateDataKeluargaToEmergemcy') ?>",
            dataType: "JSON",
            data: {
                dataIdKeluarga,
                type,
            },
            success: function(response) {
                if (response.status == 200) {
                    showMessage('success', response.message)
                    // location.reload();
                    if (response.type == '1') {
                        getDataKeluargaInti();
                    }

                    if (response.type == '2') {
                        getDataKeluargaAnda();
                    }

                    getDataKeluargaEmergency()

                }

                if (response.status == 400) {
                    showMessage('error', response.message)
                }
            }
        });

    }


    /************************************************ Form Pekerjaan ******************************************************/

    const handlerGetLokasiUnit = (value) => {
        $('#lokasiKantor').hide('slow')
        if (value == "") {
            showMessage('error', 'Cabang / Unit tidak oleh kosong');
            return false
        }

        $.ajax({
            type: 'POST',
            url: "<?= base_url('Users/Karyawan/getLokasiUnitById') ?>",
            dataType: "JSON",
            data: {
                value
            },
            success: function(response) {
                $('#lokasiKantor').show('slow')
                $('#alamatKantor').val(response.alamat)
                $('#longitudeKantor').val(response.longitude)
                $('#latitudeKantor').val(response.latitude)

            }
        });

    }

    /************************************************ Form Pekerjaan ******************************************************/
</script>