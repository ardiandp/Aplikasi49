<?php if (isset($_GET['del'])) {
    $this->db->delete("todokaryawan", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data berhasil dihapus');
    redirect("Pegawai/timesheet/pembuatanaktivitas");
} ?>


<div class="page-title">
    <div class="title_left">
        <h3>Form Pembuatan Aktivitas Karyawan</h3>
    </div>

</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2><small>Data Pengajuan Cuti</small></h2>
                <button id="showformtambah" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Buat Aktivitas</button>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">

                <br>
                <div id="divtambah" style="display: none;">

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name"> Karyawan<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="hidden" name="idkaryawan" id="idkaryawan" value="<?= $users->id ?>" readonly disabled class="form-control">
                            <input type="text" name="namakaryawan" id="namakaryawan" value="<?= $users->name ?>" readonly disabled class="form-control">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Kategori Aktivitas<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <select class="form-control select2" name="kategori" id="kategori">
                                <option value="">Pilih Kategori</option>
                                <?php foreach (show_data("kategori_aktivitas") as $un) {
                                    echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                } ?>

                            </select>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Judul Aktivitas<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="judulaktivitas" id="judulaktivitas" value="">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Tanggal Aktivitas<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="date" disabled readonly class="form-control" name="tglaktivitas" id="tglaktivitas" value="<?php echo date("Y-m-d"); ?>">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Durasi dalam jam<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control numeric" name="durasi" id="durasi">
                        </div>
                    </div>
                    <div class="item form-group" id="divlokasi" style="display: none;">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Lokasi<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" disabled readonly name="lokasi" id="lokasi">
                        </div>
                    </div>


                    <div class="ln_solid"></div>
                    <div style="float: right">

                        <button class="btn-submit btn btn-primary" id="btnkembali"><i class="fa fa-reply"></i> <span name="CAPTION-SIMPAN" style="color:white;">Kembali</span></button>
                        <button class="btn-submit btn btn-success" id="btnsave"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                    </div>
                </div>
                <div id="divtablejamkerja">
                    <table class="table table-striped table-bordered table-hover" id="tabledatapembuatanaktivitas">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Nama Karyawan</th>
                                <th>Kategori Aktivitas</th>
                                <th>Judul Aktivitas</th>
                                <th>Durasi</th>
                                <th>Lokasi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $no = 0;
foreach ($data as $key) { ?>
    <div class="modal fade data<?= $key->idutama ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Apakah anda yakin akan menghapus <strong><?= $key->name_karyawan ?></strong>?</h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?del=<?= $key->idutama ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<div class="modal fade" id="form_edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="heditid" id="heditid">

                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name"> Karyawan<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="hidden" name="idkaryawan" id="editidkaryawan" value="<?= $users->id ?>" readonly disabled class="form-control">
                        <input type="text" name="namakaryawan" id="editnamakaryawan" value="<?= $users->name ?>" readonly disabled class="form-control">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Kategori Aktivitas<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <select class="form-control select2" name="editkategori" id="editkategori">
                            <option value="">Pilih Kategori</option>
                            <?php foreach (show_data("kategori_aktivitas") as $un) {
                                echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                            } ?>

                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Judul Aktivitas<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" class="form-control" name="editjudulaktivitas" id="editjudulaktivitas" value="">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Durasi dalam jam<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" class="form-control" name="editdurasi" id="editdurasi">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Lokasi<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" class="form-control" name="editlokasi" id="editlokasi">
                    </div>
                </div>

                <div class="ln_solid"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
            </div>

        </div>
    </div>
</div>
<script>
    function message(msg, msgtext, msgtype) {
        Swal.fire(msg, msgtext, msgtype);
    }
    // essage("Error!", "<span name='CAPTION-ALERT-PILIHSKU'>Mohon pilih SKU</span>", "error");
    // message_topright("success", "<span name='CAPTION-ALERT-BERHASIL'>Data berhasil disimpan</span>");

    function message_topright(type, msg) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            didOpen: (toast) => {
                toast.addEventListener("mouseenter", Swal.stopTimer);
                toast.addEventListener("mouseleave", Swal.resumeTimer);
            },
        });

        Toast.fire({
            icon: type,
            title: msg,
        });
    }
    $(document).on('change', '#tanggal_mulai', function() {
        let tgl_mulai = $(this).val();
        let tgl_akhir = $('#tangal_akhir').val();
        const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
        const firstDate = new Date(tgl_mulai);
        const secondDate = new Date(tgl_akhir);

        const diffDays = Math.round(Math.abs((firstDate - secondDate) / oneDay));

        $('#lama').val(diffDays);
    })
    $(document).on('change', '#tanggal_akhir', function() {
        let tgl_akhir = $(this).val();
        let tgl_mulai = $('#tanggal_mulai').val();
        const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
        const firstDate = new Date(tgl_mulai);
        const secondDate = new Date(tgl_akhir);

        const diffDays = Math.round(Math.abs((firstDate - secondDate) / oneDay));

        $('#lama').val(diffDays);

    })


    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });
        getPembuatanAktivitas();
    })
    const Changecb = (e) => {
        if (e.target.checked == true) {
            $('#statuspengajuan').val('In Progres Approval');
        } else {
            $('#statuspengajuan').val('Draft');
        }
    }
    const Changecbedit = (e) => {
        if (e.target.checked == true) {
            $('#editstatuspengajuan').val('In Progres Approval');
        } else {
            $('#editstatuspengajuan').val('Draft');
        }
    }
    $(document).on("input", ".numeric", function(event) {
        this.value = this.value.replace(/[^\d.]+/g, '');
    });
    $('#idkaryawan').change(function() {
        let thisval = $(this).val();
        $.ajax({
            type: 'POST',
            url: '<?= base_url('Pegawai/absensi/getdatakaryawan') ?>',
            data: {
                idkaryawan: thisval
            },
            async: false,
            dataType: "JSON",
            success: function(response) {
                console.log(response.name);
                $('#jabatan').val(response.name)
                $('#noktp').val(response.no_ktp)
                $('#nohp').val(response.phone)
                $('#divisi').val(response.nama_divisi)
            }
        })
    })



    function getPembuatanAktivitas() {
        $.ajax({
            type: 'GET',
            url: '<?= base_url('Pegawai/Timesheet/getPembuatanAktivitas') ?>',
            async: false,
            dataType: "JSON",
            success: function(response) {

                if (response != null) {
                    $('#lokasi >tbody').empty()

                    $.each(response, function(i, v) {

                        $('#tabledatapembuatanaktivitas >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.name_karyawan}</td>
                            <td>${v.name_kategori}</td>
                            <td>${v.judul_aktivitas}</td>
                            <td>${v.durasi} jam</td>
                            <td>${v.lokasi} </td>
                         
                            <td><button id='btn_edit' onclick="editdata('${i}','${v.idutama}','${v.id_karyawan}','${v.id_kategori}','${v.judul_aktivitas}','${v.durasi}','${v.lokasi}')" class='btn btn-sm btn-warning' value='${v.id}' ><i class='fa fa-edit'></i></button> 
                           
                            <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data${v.idutama}'><i class='fa fa-trash'></i></a></td>
                        </tr>`);


                    })
                }
            }
        })
    }

    $(document).on('click', '#showformtambah', function() {
        $('#idkaryawan').val("");
        $('#kategori').val("");
        $('#judulaktivitas').val("");
        $('#tglaktivitas').val("");
        $('#durasi').val("");
        $('#lokasi').val("");
        $('#divtambah').show('FadeIn');
        $('#divtablejamkerja').hide('FadeOut');
        $('#title h2').html('Tambah Jam Kerja');
        $('#showformtambah').hide();

    })
    $(document).on('click', '#btnkembali', function() {
        $('#divtambah').hide('FadeIn');
        $('#divtablejamkerja').show('FadeOut');
        $('#title h2').html('Data Jam Kerja');
        $('#showformtambah').show();


    })
    $(document).on('change', '#kategori', function() {
        let ini = $(this).val();
        let initext = $(this).children("option").filter(":selected").text();
        if (initext == "Dinas") {


            $('#lokasi').val("");
            $('#lokasi').attr('disabled', false);
            $('#lokasi').attr('readonly', false);
            $('#divlokasi').show('FadeOut');
        } else {
            $('#lokasi').val("");
            $('#lokasi').attr('disabled', true);
            $('#lokasi').attr('readonly', true);
            $('#divlokasi').hide('FadeOut');
        }

    })



    $(document).on('click', '#btnsave', function() {

        let idkaryawan = $('#idkaryawan').val();
        let kategori = $('#kategori option:selected').val();
        let judulaktivitas = $('#judulaktivitas').val();
        let tglaktivitas = $('#tglaktivitas').val();
        let durasi = $('#durasi').val();
        let lokasi = $('#lokasi').val();
        let initext = $('#kategori').children("option").filter(":selected").text();


        if (kategori == '' || judulaktivitas == '' || durasi == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }
        if (initext.toLocaleLowerCase == "dinas") {
            new PNotify
                ({
                    title: 'Error',
                    text: "Lokasi Masih Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }
        $.ajax({
            type: "POST",
            url: '<?= base_url('Pegawai/Timesheet/getAktivitasToday'); ?>',
            data: {
                idkaryawan,
                tglaktivitas
            },
            dataType: 'json',
            success: function(response) {

                if (parseInt(response.durasi) + parseInt(durasi) >= 8) {
                    alert(`Durasi Melebihi Jam Kerja`)
                }

                if (response.durasi >= 8) {
                    new PNotify
                        ({
                            title: 'Warning',
                            text: "AKtivitas Hari Ini sudah 8 Jam",
                            type: "warning",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    return false;
                } else {
                    $.ajax({
                        type: "POST",
                        url: '<?= base_url('Pegawai/Timesheet/addpembuatanaktivitas'); ?>',
                        data: {
                            idkaryawan: idkaryawan,
                            kategori: kategori,
                            judulaktivitas: judulaktivitas,
                            durasi: durasi,
                            lokasi: lokasi,
                            tglaktivitas: tglaktivitas

                        },
                        dataType: 'json',
                        success: function(response) {

                            if (response == 1) {
                                new PNotify
                                    ({
                                        title: 'Succes',
                                        text: "Data Berhasil Ditambah",
                                        type: "Success",
                                        styling: 'bootstrap3',
                                        delay: 3000,
                                        // stack: stack_center
                                    });
                                setTimeout(() => window.location.reload(), 800);
                            } else {
                                new PNotify({
                                    text: 'Data Gagal disimpan!',
                                    type: 'Warning!',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 700);
                            }
                        }

                    })
                }

            }
        })






    })

    function editdata(
        i,
        idutama,
        id_karyawan,
        id_kategori,
        judul_aktivitas,
        durasi,
        lokasi
    ) {

        let value = $(this).attr('efektif');
        $('#heditid').val(idutama);
        let editidkaryawan = $('#editidkaryawan').val(id_karyawan).trigger('change');
        let editkategori = $('#editkategori').val(id_kategori).change();
        let editjudulaktivitas = $('#editjudulaktivitas').val(judul_aktivitas);
        let editdurasi = $('#editdurasi').val(durasi);
        let editlokasi = $('#editlokasi').val(lokasi);
        $('#form_edit').modal('show');


    }
    $(document).on('click', '#btn_editsimpan', function() {

        // message("Error!", "<span name='CAPTION-ALERT-PILIHSKU'>Cooming soon</span>", "error");
        // return false;
        let editidkaryawan = $('#editidkaryawan').val()
        let editkategori = $('#editkategori option:selected').val()
        let editjudulaktivitas = $('#editjudulaktivitas').val();
        let editdurasi = $('#editdurasi').val();
        let editlokasi = $('#editlokasi').val();
        $.ajax({
            type: "POST",
            url: '<?= base_url('Pegawai/Timesheet/editpembuatanaktivitas'); ?>',
            data: {
                id: $('#heditid').val(),
                idkaryawan: editidkaryawan,
                kategori: editkategori,
                judulaktivitas: editjudulaktivitas,
                durasi: editdurasi,
                lokasi: editlokasi,

            },
            dataType: 'json',
            success: function(response) {
                if (response == 1) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil dirubah",
                            type: "Success",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    new PNotify({
                        text: 'Data Gagal disimpan!',
                        type: 'Warning!',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 700);
                }
            }

        })

    })

    function getAktivitasToday(idkaryawan, tglaktivitas) {
        $.ajax({
            type: "POST",
            url: '<?= base_url('Pegawai/Timesheet/getAktivitasToday'); ?>',
            data: {
                idkaryawan,
                tglaktivitas
            },
            dataType: 'json',
            success: function(response) {
                console.log(response.durasi);

            }
        })
    }
</script>