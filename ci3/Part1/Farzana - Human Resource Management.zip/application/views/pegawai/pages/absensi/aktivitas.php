<?php

$dataAbsensi = $this->db->query("select * from absensi where id_karyawan ='" . $this->session->userdata('id') . "' and DATE_FORMAT(tgl, '%Y-%m-%d') ='" . date('Y-m-d') . "'")->row();


?>


<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-8">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Absensi</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Hari Absen</label>
                                    <input type="hidden" name="" id="hidjamkerja">
                                    <input type="hidden" name="" id="htoleransi">
                                    <input type="text" class="form-control" readonly disabled name="namahari" id="namahari" value="<?= $hari ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Jadwal Masuk</label>
                                    <input type="text" class="form-control" readonly disabled name="jam_masuk" id="jam_masuk" value="<?= $hari ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Jadwal Pulang</label>
                                    <input type="text" class="form-control" readonly disabled name="jam_pulang" id="jam_pulang" value="<?= $hari ?>">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button class="btn-submit btn btn-success" id="btnabsenloading" style="display:none" disabled>
                                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading...
                                </button>
                                <?php if (empty($dataAbsensi)) { ?>
                                    <button class="btn-submit btn btn-success" id="btnabsen">Absen Masuk</button>
                                <?php } else { ?>
                                    <?php if ($dataAbsensi->jam_masuk == '' && $dataAbsensi->jam_pulang == '') { ?>
                                        <button class="btn-submit btn btn-success" id="btnabsen">Absen Masuk</button>
                                    <?php } else if ($dataAbsensi->jam_masuk != '' && $dataAbsensi->jam_pulang == '') { ?>
                                        <button class="btn-submit btn btn-success" id="btnabsen">Absen Pulang</button>
                                    <?php } else { ?>
                                        <button class="btn-submit btn btn-success" id="btnabsen" disabled>Anda telah absen keduanya</button>
                                    <?php } ?>
                                <?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>

</div>

<script>
    function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
        var R = 6371; // Radius of the earth in km
        var dLat = deg2rad(lat2 - lat1); // deg2rad below
        var dLon = deg2rad(lon2 - lon1);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in km
        return d;
    }

    function getDistanceFromLatLonInMeters(lat1, lon1, lat2, lon2) {
        var R = 6371000; // Radius of the earth in meters
        var dLat = deg2rad(lat2 - lat1); // deg2rad below
        var dLon = deg2rad(lon2 - lon1);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in meters
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180)
    }

    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });

        $(document).on("input", ".numeric", function(event) {
            this.value = this.value.replace(/[^\d.]+/g, '');
        });

        // getdataabsensi();
        getDataJam();


    })


    function getDataJam() {
        let hari = $('#namahari').val();
        console.log(hari);
        $.ajax({
            type: 'POST',
            url: '<?= base_url('absensi/getdatajam') ?>',
            async: false,
            dataType: "JSON",
            data: {
                hari
            },
            success: function(response) {
                if (response !== null) {
                    $("#hidjamkerja").val(response.id_jamkerja);
                    let jam_masuk = response.jam_masuk;
                    let jam_pulang = response.jam_pulang;
                    let timenow = '<?= date('H:i') ?>'
                    let splitjam_masuk = parseInt(jam_masuk.split(":")[0]) == 23 ? 2 : parseInt(jam_masuk.split(":")[0]) + 3;
                    let splitjam_pulang = parseInt(jam_pulang.split(":")[0]) - 2;
                    $("#jam_masuk").val(response.jam_masuk)
                    $("#jam_pulang").val(response.jam_pulang)
                    $("#htoleransi").val(response.toleransi)

                    const now = new Date().getHours()

                    // if (now >= (parseInt(jam_masuk.split(":")[0]) - 2) && now <= splitjam_masuk) {
                    //   $('#btnabsen').html('Absen Masuk');
                    //   $('#btnabsen').prop('disabled', false);
                    // } else if (now >= splitjam_pulang && now <= (parseInt(jam_pulang.split(":")[0]) + 7)) {
                    //   $('#btnabsen').html('Absen Pulang');
                    //   $('#btnabsen').prop('disabled', false);
                    // } else {
                    //   $('#btnabsen').html('Disabled');
                    //   $('#btnabsen').prop('disabled', true);
                    // }


                    var startDate = new Date();
                    // Do your operations
                    var endDate = new Date();
                    var seconds = (endDate.getTime() - startDate.getTime()) / 1000;
                    console.log(endDate.getTime());
                }
            }
        })
    }

    function diff_hours(dt2, dt1) {

        var diff = dt2.getTime() - dt1.getTime();
        return (diff / 60000);

    }

    function isValidDate(d) {
        return d instanceof Date && !isNaN(d);
    }

    function toHoursAndMinutes(totalMinutes) {
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;
        const hoursCek = hours == 0 ? '' : Math.abs(hours) + " Jam";
        const minutesCek = minutes == 0 ? '' : Math.abs(minutes) + " Menit";

        return hoursCek + " " + minutesCek;
    }

    const showBtnAbsen = () => {
        $("#btnabsen").show();
        $("#btnabsenloading").hide();
    }

    $(document).on('click', '#btnabsen', function() {
        $("#btnabsen").hide();
        $("#btnabsenloading").show();

        let hari = $('#namahari').val();
        let jam_absen = '<?= date('d-m-Y H:i:s') ?>';
        let jam_masuk = $("#jam_masuk").val()
        let jam_pulang = $("#jam_pulang").val()
        let toleransi = $("#htoleransi").val();

        if (!/^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$/.test(jam_masuk)) {
            showMessage('error', `Hari efektif pada hari ${$('#namahari').val()} belum disetting oleh admin`);
            showBtnAbsen();
            return false;
        }

        //get lokasi kantor by data karyawan selection id
        $.ajax({
            type: "POST",
            url: '<?= base_url('absensi/getLokasiKantor'); ?>',
            data: {
                idkaryawan: "<?= $this->session->userdata('id') ?>"
            },
            dataType: 'json',
            success: function(response) {
                if (response == null) {
                    showMessage('error', 'Karyawan ' + $('#idkaryawan option:selected').text() + ' tidak memiliki lokasi kantor, silahkan update data lokasi pekerjaan melalui data kepegawaian atau hubungi admin');
                    showBtnAbsen();
                    return false;
                } else {
                    if (navigator.geolocation) { //check if geolocation is available
                        navigator.geolocation.getCurrentPosition(function(position) {
                            const latPositionUser = position.coords.latitude;
                            const longPositionUser = position.coords.longitude;


                            if (response.satuan == 'Km') {
                                const betweenLocation = getDistanceFromLatLonInKm(response.latitude, response.longitude, latPositionUser, longPositionUser);
                                if (parseInt(Math.round(betweenLocation)) > parseInt(response.jarak)) {
                                    showMessage('error', `Absensi gagal, anda berada di luar radius ketentuan absen kantor, radius anda <strong>${parseInt(Math.round(betweenLocation))} Km</strong>, lakukan absen berada dibawah sama dengan ${parseInt(response.jarak)} Km`);
                                    showBtnAbsen();
                                    return false;
                                }
                            }

                            if (response.satuan == 'm') {
                                const betweenLocation = getDistanceFromLatLonInMeters(response.latitude, response.longitude, latPositionUser, longPositionUser);
                                const mathRoundMeters = parseInt(Math.round(betweenLocation));
                                const mathRoundKm = betweenLocation / 1000
                                const convertDistance = mathRoundMeters < 1000 ? mathRoundMeters + " Meter" : mathRoundKm.toFixed(1) + " Km";
                                if (parseInt(Math.round(betweenLocation)) > parseInt(response.jarak)) {
                                    showMessage('error', `Absensi gagal, anda berada di luar radius ketentuan absen kantor, radius anda <strong>${convertDistance}</strong>, lakukan absen berada dibawah sama dengan ${parseInt(response.jarak)} Meter`);
                                    showBtnAbsen();
                                    return false;
                                }
                            }


                            let now = '<?= date('H:i') ?>';
                            let waktu = "";
                            let status = '';
                            let type = '';
                            let dt1 = new Date(`<?= date('Y-m-d') ?> ${now}:00`);
                            let dtmasuk = new Date(`<?= date('Y-m-d') ?> ${jam_masuk}:00`);
                            let dtpulang = new Date(`<?= date('Y-m-d') ?> ${jam_pulang}:00`);

                            if ($('#btnabsen').html() == 'Absen Masuk') {
                                // waktu = now.replace(":", "") - jam_masuk.replace(":", "")
                                waktu = diff_hours(dt1, dtmasuk)

                                type = 1;

                                if (waktu < 0) {
                                    status = `Anda absen masuk ${toHoursAndMinutes(waktu)} lebih awal dari jam yang telah ditentukan`
                                }

                                if (waktu == 0) {
                                    status = "Anda absen masuk tepat waktu"
                                }

                                if (waktu > 0) {
                                    if (waktu > toleransi) {
                                        status = `Anda absen masuk terlambat ${toHoursAndMinutes(waktu)}`
                                    } else {
                                        status = `Anda absen terlambat ${toHoursAndMinutes(waktu)} tapi masih dalam toleransi`
                                    }
                                }
                            }
                            if (($('#btnabsen').html() == 'Absen Pulang')) {
                                // waktu = now.replace(":", "") - jam_pulang.replace(":", "")

                                waktu = diff_hours(dt1, dtpulang)
                                type = 2;

                                if (waktu < 0) {
                                    status = `Anda absen pulang ${toHoursAndMinutes(waktu)} lebih awal dari jam yang telah ditentukan`
                                }
                                if (waktu == 0) {
                                    status = "Anda absen pulang tepat waktu"
                                }
                                if (waktu > 0) {
                                    status = `Anda absen pulang ${toHoursAndMinutes(waktu)} diatas dari jam yang telah ditentukan`;
                                }

                            }

                            $.ajax({
                                type: "POST",
                                url: '<?= base_url('absensi/addabsensi'); ?>',
                                data: {
                                    idkaryawan: "<?= $this->session->userdata('id') ?>",
                                    hari: hari,
                                    id_jam_kerja: $("#hidjamkerja").val(),
                                    waktu: waktu,
                                    status: status,
                                    latPositionUser,
                                    longPositionUser,
                                    type

                                },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.status == 200) {
                                        showMessage('success', response.message);
                                        setTimeout(() => window.location.reload(), 800);
                                        showBtnAbsen();
                                    }
                                    if (response.status == 400) {
                                        showMessage('error', response.message);
                                        showBtnAbsen();
                                        return false;
                                        // setTimeout(() => window.location.reload(), 800);
                                    }
                                }

                            })

                        });
                    }

                }
            }
        })

    })
</script>