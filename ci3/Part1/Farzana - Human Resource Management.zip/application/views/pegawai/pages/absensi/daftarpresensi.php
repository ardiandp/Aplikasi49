<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Filter Presensi Kehadiran</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="item form-group">
                                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                                            <div class="col-md-9 col-sm-9 ">
                                                <input type="text" id="filterTanggal" class="form-control input-sm datepicker" name="filterTanggal" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="item form-group">
                                            <div class="col-md-4 col-sm-4 ">
                                                <button type="button" class="btn btn-primary" onclick="handlerFilterPresensi()"><i class="fa fa-search"></i> Filter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-md-4">
                                <div class="form-group">
                                    <label>Hari Absen</label>
                                    <input type="month" class="form-control" name="filterPresensi" id="filterPresensi" value="<?= date('Y-m') ?>" onchange="handlerFilterPresensi(this.value)">
                                </div>
                            </div> -->

                            <div class="col-md-12 mt-3">
                                <div class="table-responsive">
                                    <table class="table table-striped" id="initDataPresensi">
                                        <thead>
                                            <tr class="bg-dark text-white text-center">
                                                <td rowspan="2"><strong>Hari</strong></td>
                                                <td rowspan="2"><strong>Tanggal</strong></td>
                                                <td colspan="2"><strong>Jadwal Absen</strong></td>
                                                <td colspan="2"><strong>Jam Absen</strong></td>
                                                <td colspan="2"><strong>Status Absen</strong></td>
                                            </tr>
                                            <tr class="bg-dark text-center text-white">
                                                <td><strong>Jadwal Masuk</strong></td>
                                                <td><strong>Jadwal Pulang</strong></td>
                                                <td><strong>Jam Masuk</strong></td>
                                                <td><strong>Jam Pulang</strong></td>
                                                <td><strong>Status Masuk</strong></td>
                                                <td><strong>Status Pulang</strong></td>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $("#initDataPresensi").DataTable();


        $('#filterTanggal').daterangepicker({
            'applyClass': 'btn-sm btn-success',
            'cancelClass': 'btn-sm btn-default',
            locale: {
                "format": "DD/MM/YYYY",
                applyLabel: 'Apply',
                cancelLabel: 'Cancel',
            },
            'startDate': '<?= date("d-m-Y") ?>',
            'endDate': '<?= date("d-m-Y") ?>'
        });
        handlerFilterPresensi();
    })

    const handlerFilterPresensi = () => {
        let filterTanggal = $("#filterTanggal").val();
        $.ajax({
            type: "POST",
            url: '<?= base_url('Pegawai/Absensi/filterPresensi'); ?>',
            data: {
                filterTanggal
            },
            dataType: 'json',
            success: function(response) {
                $("#initDataPresensi > tbody").empty()
                if (response.length > 0) {
                    $.each(response, function(i, v) {
                        $("#initDataPresensi > tbody").append(`
                            <tr>
                                <td class="text-center">${v.nama_hari}</td>
                                <td class="text-center">${formatTanggal(v.tgl)}</td>
                                <td class="text-center">${v.jadwal_masuk}:00</td>
                                <td class="text-center">${v.jadwal_pulang}:00</td>
                                <td class="text-center">${v.jam_masuk == null ? '-' : v.jam_masuk}</td>
                                <td class="text-center">${v.jam_pulang == null ? '-' : v.jam_pulang}</td>
                                <td>${v.status_masuk == '' ? '-' : v.status_masuk}</td>
                                <td>${v.status_pulang == '' ? '-' : v.status_pulang}</td>
                            </tr>`)
                    })
                } else {
                    $("#initDataPresensi > tbody").append(`<tr><td colspan="8" class="text-center text-danger">Data Kosong</td></tr>`)
                }
                $("#initDataPresensi").DataTable();
            }

        })
    }
</script>