<div class="container">
    <div>
        <h4><strong>1. Data perhitungan gaji by bulan</strong></h4>
        <div class="ml-4 mb-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                        <div class="col-md-9 col-sm-9 ">
                            <input type="hidden" name="idUsers" id="idUsers" value="<?= $this->session->userdata('id') ?>">
                            <input type="month" id="payrollKaryawan" onchange="handlerChangePayrollInformasi(this.value)" class="form-control" name="payrollKaryawan" autocomplete="off">
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive mt-3">
                <br><br>
                <div class="clearfix"></div>
                <table id="initDataGajiKaryawan" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th rowspan="2" class="align-middle text-center">No</th>
                            <th colspan="2" class="text-center">Komponen Gaji Pokok</th>
                            <th rowspan="2" class="align-middle text-center">Pay For Person (P1)</th>
                            <th colspan="<?= count_table('tunjangan') ?>" class="align-middle text-center">Tunjangan</th>
                            <th rowspan="2" class="align-middle text-center">Pay For Person (P2)</th>
                            <th colspan="<?= count_table('bonus') ?>" class="align-middle text-center">Bonus</th>
                            <th rowspan="2" class="align-middle text-center">Pay For Person (P3)</th>
                            <th rowspan="2" class="align-middle text-center">Total</th>
                        </tr>
                        <tr>
                            <th>Grade</th>
                            <th>Masa Kerja</th>
                            <?php foreach (show_data("tunjangan") as $tunjangan) {
                                echo "<th>" . $tunjangan->name . "</th>";
                            } ?>
                            <?php foreach (show_data("bonus") as $bonus) {
                                echo "<th>" . $bonus->name . "</th>";
                            } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
    <hr>
    <div>
        <h4><strong>2. Payroll pegawai 3P</strong></h4>
        <div class="ml-4 mb-4">
            <div class="row">
                <div class="col-md-12">
                    <?php
                    $tnj = $this->db->order_by('id', 'asc')->get("tunjangan")->num_rows();
                    $kry = $this->db->get_where("karyawan", ['id' => $this->session->userdata('id')])->row();
                    $pnr = $this->db->select('unit.name,penerimaan.date')->join('karyawan', 'penerimaan.karyawan=karyawan.id')->join('unit', 'penerimaan.unit=unit.id')->get_where("penerimaan", ['penerimaan.karyawan' => $this->session->userdata('id')])->row();
                    $tnjs = $this->db->order_by('id', 'asc')->get("tunjangan")->result();
                    $bn = $this->db->order_by('id', 'asc')->get("bonus")->num_rows();
                    $bns = $this->db->order_by('id', 'asc')->get("bonus")->result();
                    $skl = $this->db->query("SELECT pendidikan.name, tbl_sekolah.id_pendidikan
                                      FROM tbl_sekolah
                                      left join pendidikan ON tbl_sekolah.id_pendidikan = pendidikan.id
                                      where tbl_sekolah.id_karyawan = '" . $this->session->userdata('id') . "'
                                        AND tbl_sekolah.type = 'Formal'
                                      ORDER BY tbl_sekolah.id DESC")->row();



                    if ($skl) {
                        $grade = where_row('grade', ['level' => $skl->id_pendidikan]);
                    }

                    $tunjangan = where_row('int_tunjangan', ['karyawan' => $this->session->userdata('id')]);
                    if ($tunjangan) {
                        $show_tunjangan = json_decode($tunjangan->tunjangan);
                    }
                    $penerimaan = where_row('penerimaan', ['karyawan' => $this->session->userdata('id')]);
                    $interval = date_diff(date_create($penerimaan->date), date_create(date("Y-m-d")));

                    $bonus = where_row('int_bonus', ['karyawan' => $this->session->userdata('id')]);
                    if ($bonus) {
                        $show_bonus = json_decode($bonus->bonus);
                    }

                    $gaji = $this->db->like('date', date("Y-m"))->get_where("gaji", ['karyawan' => $this->session->userdata('id')])->row();
                    $potongan = $this->db->like('date', date("Y-m"))->get_where('potongan', ['karyawan' => $this->session->userdata('id')])->row();
                    if ($gaji->p1_1 == 0) {
                        if ($skl) {
                            $tingkat = ($grade ? $grade->amount : 0);
                        } else {
                            $tingkat = 0;
                        }
                    } else {
                        $tingkat = $gaji->p1_1;
                    }
                    if ($gaji->p1_2 == 0) {
                        $masa = $interval->y * 25000;
                    } else {
                        $masa = $gaji->p1_2;
                    }
                    $total_p1 = $tingkat + $masa;
                    ?>
                    <div class="clearfix"></div>
                    <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="preview-tab" data-toggle="tab" href="#preview" role="tab" aria-controls="preview" aria-selected="false">Preview</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="preview" role="tabpanel" aria-labelledby="preview-tab">
                            <table cellpadding="5" cellspacing="5">
                                <tr>
                                    <td> Total Pay For Person (P1)</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->p1) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Pay For Person (P2)</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->p2) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Pay For Person (P3)</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->p3) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Potongan</td>
                                    <td>:</td>
                                    <td><?= rupiah(($potongan ? $potongan->total_potongan : 0)) ?></td>
                                </tr>
                                <tr>
                                    <td> Total Gaji</td>
                                    <td>:</td>
                                    <td><?= rupiah($gaji->total - ($potongan ? $potongan->total_potongan : 0)) ?></td>
                                </tr>
                            </table>
                            <hr>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#initDataGajiKaryawan').DataTable();
    })
</script>