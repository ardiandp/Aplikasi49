<?php

$dokumenPersonal = where_row('tbl_dokumen_personal', ['id_karyawan' => $this->session->userdata('id')]);
$dokumenSKPengangkatan = where_result('tbl_dokumen_pekerjaan', ['id_karyawan' => $this->session->userdata('id'), 'type' => 1]);
$dokumenIjazah = where_result('tbl_dokumen_pekerjaan', ['id_karyawan' => $this->session->userdata('id'), 'type' => 2]);
$dokumenSertifikat = where_result('tbl_dokumen_pekerjaan', ['id_karyawan' => $this->session->userdata('id'), 'type' => 3]);
$dokumenSuratReferensi = where_result('tbl_dokumen_pekerjaan', ['id_karyawan' => $this->session->userdata('id'), 'type' => 4]);

$user = where_row('karyawan', ['id' => $this->session->userdata('id')]);

?>

<div class="container">
    <div>
        <form action="<?= base_url('Users/Karyawan/saveDokumenPersonal') ?>" method="post" enctype="multipart/form-data">
            <h4><strong>1. Jenis Dokumen Data Personal</strong></h4>

            <div class="ml-4 mb-4">
                <div class="row align-items-center justify-content-start">
                    <input type="hidden" name="idUsers" id="idUsers" value="<?= $this->session->userdata('id') ?>">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-3">
                        <span><strong>KTP</strong></span><br>
                        <div style="min-height: 300px;">
                            <img src="<?= isset($dokumenPersonal) || empty($dokumenPersonal) ? base_url('assets/no-image.png') : base_url('assets/upload/kepegawaian/dokumen/' . $dokumenPersonal->file_ktp) ?>" alt="" class="img-fluid img-reponsive">
                        </div>
                        <?php if ($user->is_invited == 1) { ?>
                            <input type="file" name="fileKTP" id="fileKTP" class="form-control" accept="image/jpeg, image/jpg, image/png, image/gif, image/JPG, image/JPEG, image/GIF">
                        <?php } ?>

                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-3">
                        <span><strong>NPWP</strong></span><br>
                        <div style="min-height: 300px;">
                            <img src="<?= isset($dokumenPersonal) || empty($dokumenPersonal) ? base_url('assets/no-image.png') : base_url('assets/upload/kepegawaian/dokumen/' . $dokumenPersonal->file_npwp) ?>" alt="" class="img-fluid img-reponsive">
                        </div>
                        <?php if ($user->is_invited == 1) { ?>
                            <input type="file" name="fileNPWP" id="fileNPWP" class="form-control" accept="image/jpeg, image/jpg, image/png, image/gif, image/JPG, image/JPEG, image/GIF">
                        <?php } ?>

                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <span><strong>KK</strong></span><br>
                        <div style="min-height: 300px;">
                            <img src="<?= isset($dokumenPersonal) || empty($dokumenPersonal) ? base_url('assets/no-image.png') : base_url('assets/upload/kepegawaian/dokumen/' . $dokumenPersonal->file_kk) ?>" alt="" class="img-fluid img-reponsive">
                        </div>
                        <?php if ($user->is_invited == 1) { ?>
                            <input type="file" name="fileKK" id="fileKK" class="form-control" accept="image/jpeg, image/jpg, image/png, image/gif, image/JPG, image/JPEG, image/GIF">
                        <?php } ?>

                    </div>
                </div>
            </div>
            <?php if ($user->is_invited == 1) { ?>
                <button type="submit" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i></button>
            <?php } ?>
        </form>
    </div>
    <hr>
    <div>
        <h4><strong>2. Jenis Data Dokumen Pekerjaan</strong></h4>
        <div class="ml-4 mb-4">
            <div class="d-flex align-items-center justify-content-between">
                <span><strong>a. SK Pengangkatan</strong></span>
                <div>
                    <?php if ($user->is_invited == 1) { ?>
                        <button class="btn btn-primary btn-sm pull-right" onclick="handlerAddDokumenPekerjaan('1')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tableDokumenSKPengangkatan" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama Dokumen</strong></td>
                            <td><strong>Dokumen</strong></td>
                            <?php if ($user->is_invited == 1) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($dokumenSKPengangkatan)) { ?>
                            <?php foreach ($dokumenSKPengangkatan as $key => $value) { ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $value->nama ?></td>
                                    <td>
                                        <a href="<?= base_url('assets/upload/kepegawaian/dokumen/' . $value->file) ?>" target="_BLANK" class="btn btn-primary btn-sm"><i class="fa fa-download"></i> Dokumen</a>
                                    </td>
                                    <?php if ($user->is_invited == 1) { ?>
                                        <td>
                                            <a href="<?= base_url('Users/Karyawan/deleteDokumenPekerjaan?id=' . $value->id . "&idUser=" . $value->id_karyawan) ?>" class="btn btn-danger btn-sm" onclick="return  confirm('do you want to delete Y/N')"><i class="fa fa-trash"></i></a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td class="text-center text-danger" colspan="<?= $user->is_invited == 1 ? '4' : '3' ?>">Data Kosong</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <hr>

            <div class="d-flex align-items-center justify-content-between">
                <span><strong>b. Ijazah</strong></span>
                <div>
                    <?php if ($user->is_invited == 1) { ?>
                        <button class="btn btn-primary btn-sm pull-right" onclick="handlerAddDokumenPekerjaan('2')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tableDokumenIjazah" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama Dokumen</strong></td>
                            <td><strong>Dokumen</strong></td>
                            <?php if ($user->is_invited == 1) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($dokumenIjazah)) { ?>
                            <?php foreach ($dokumenIjazah as $key => $value) { ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $value->nama ?></td>
                                    <td>
                                        <a href="<?= base_url('assets/upload/kepegawaian/dokumen/' . $value->file) ?>" target="_BLANK" class="btn btn-primary btn-sm"><i class="fa fa-download"></i> Dokumen</a>
                                    </td>
                                    <?php if ($user->is_invited == 1) { ?>
                                        <td>
                                            <a href="<?= base_url('Users/Karyawan/deleteDokumenPekerjaan?id=' . $value->id . "&idUser=" . $value->id_karyawan) ?>" class="btn btn-danger btn-sm" onclick="return  confirm('do you want to delete Y/N')"><i class="fa fa-trash"></i></a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td class="text-center text-danger" colspan="<?= $user->is_invited == 1 ? '4' : '3' ?>">Data Kosong</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex align-items-center justify-content-between">
                <span><strong>c. Sertifikat</strong></span>
                <div>
                    <?php if ($user->is_invited == 1) { ?>
                        <button class="btn btn-primary btn-sm pull-right" onclick="handlerAddDokumenPekerjaan('3')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tableDokumenSertifikat" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama Dokumen</strong></td>
                            <td><strong>Dokumen</strong></td>
                            <?php if ($user->is_invited == 1) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($dokumenSertifikat)) { ?>
                            <?php foreach ($dokumenSertifikat as $key => $value) { ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $value->nama ?></td>
                                    <td>
                                        <a href="<?= base_url('assets/upload/kepegawaian/dokumen/' . $value->file) ?>" target="_BLANK" class="btn btn-primary btn-sm"><i class="fa fa-download"></i> Dokumen</a>
                                    </td>
                                    <?php if ($user->is_invited == 1) { ?>
                                        <td>
                                            <a href="<?= base_url('Users/Karyawan/deleteDokumenPekerjaan?id=' . $value->id . "&idUser=" . $value->id_karyawan) ?>" class="btn btn-danger btn-sm" onclick="return  confirm('do you want to delete Y/N')"><i class="fa fa-trash"></i></a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td class="text-center text-danger" colspan="<?= $user->is_invited == 1 ? '4' : '3' ?>">Data Kosong</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex align-items-center justify-content-between">
                <span><strong>d. Surat referensi</strong></span>
                <div>
                    <?php if ($user->is_invited == 1) { ?>
                        <button class="btn btn-primary btn-sm pull-right" onclick="handlerAddDokumenPekerjaan('4')"><i class="fa fa-plus"></i></button>
                    <?php } ?>

                </div>
            </div>

            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" id="tableDokumenSuratReferensi" style="font-size: 12px;">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Nama Dokumen</strong></td>
                            <td><strong>Dokumen</strong></td>
                            <?php if ($user->is_invited == 1) { ?>
                                <td><strong>Action</strong></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($dokumenSuratReferensi)) { ?>
                            <?php foreach ($dokumenSuratReferensi as $key => $value) { ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $value->nama ?></td>
                                    <td>
                                        <a href="<?= base_url('assets/upload/kepegawaian/dokumen/' . $value->file) ?>" target="_BLANK" class="btn btn-primary btn-sm"><i class="fa fa-download"></i> Dokumen</a>
                                    </td>
                                    <?php if ($user->is_invited == 1) { ?>
                                        <td>
                                            <a href="<?= base_url('Users/Karyawan/deleteDokumenPekerjaan?id=' . $value->id . "&idUser=" . $value->id_karyawan) ?>" class="btn btn-danger btn-sm" onclick="return  confirm('do you want to delete Y/N')"><i class="fa fa-trash"></i></a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td class="text-center text-danger" colspan="<?= $user->is_invited == 1 ? '4' : '3' ?>">Data Kosong</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAddDokumenPekerjaan" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2"></h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="form-group">
                        <label for="namaDokumen">Nama Dokumen</label>
                        <input type="text" name="namaDokumen" id="namaDokumen" class="form-control" placeholder="Nama Dokumen" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <label for="file">Upload Dokumen</label>
                        <input type="file" name="file" id="file" class="form-control" autocomplete="off" accept="image/jpeg, image/jpg, image/png, image/gif, image/JPG, image/JPEG, image/GIF, application/pdf,.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary addDokumenPekerjaan" type="button" onclick="handlerSaveDokumenPekerjaan(event)">Simpan</button>
                <button class="btn btn-dark" type="button" onclick="closeModalDokumenPekerjaan()">kembali</button>
            </div>
        </div>
    </div>
</div>