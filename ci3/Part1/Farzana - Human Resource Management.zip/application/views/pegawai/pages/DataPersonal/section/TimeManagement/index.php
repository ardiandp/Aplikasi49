<?php

$dataAbsen = $this->db->get_where('absensi', ['id_karyawan' => $this->session->userdata('id')])->result();
$dataLibur = show_data('libur');

?>

<div class="container">
    <div>
        <h4><strong>1. Daftar Kehadiran</strong></h4>
        <div class="ml-4 mb-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="nama-hari">Tanggal</label>
                        <div class="col-md-9 col-sm-9 ">
                            <input type="text" id="filterTanggal" class="form-control input-sm datepicker" name="filterTanggal" autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <button type="button" class="btn btn-primary" onclick="handlerFilterKehadiranKaryawan()"><i class="fa fa-search"></i> Filter</button>
                </div>
            </div>
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" style="font-size: 12px;" id="initDataPresensiKaryawan">
                    <thead>
                        <tr class="bg-dark text-white text-center">
                            <td rowspan="2" style="vertical-align: middle;"><strong>No.</strong></td>
                            <td rowspan="2" style="vertical-align: middle;"><strong>Tanggal</strong></td>
                            <td colspan="2" style="vertical-align: middle;"><strong>Absen</strong></td>
                            <td colspan="2" style="vertical-align: middle;"><strong>Status</strong></td>
                        </tr>
                        <tr class="bg-dark text-white text-center">
                            <td><strong>Absen Masuk</strong></td>
                            <td><strong>Absen Pulang</strong></td>
                            <td><strong>Status Masuk</strong></td>
                            <td><strong>Status Pulang</strong></td>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
    <hr>
    <div>
        <h4><strong>2. Daftar Hari Libur / Cuti</strong></h4>
        <div class="ml-4 mb-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="filterTanggalCuti">Tanggal</label>
                        <div class="col-md-9 col-sm-9 ">
                            <input type="text" id="filterTanggalCuti" class="form-control input-sm datepicker" name="filterTanggalCuti" autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <button type="button" class="btn btn-primary" onclick="handlerFilterCutiKaryawan()"><i class="fa fa-search"></i> Filter</button>
                </div>
            </div>
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered" width="100%" style="font-size: 12px;" id="initDataHariCutiKaryawan">
                    <thead>
                        <tr class="bg-dark text-white">
                            <td><strong>No.</strong></td>
                            <td><strong>Tanggal Mulai</strong></td>
                            <td><strong>Tanggal Akhir</strong></td>
                            <td><strong>Lama Hari</strong></td>
                            <td><strong>Status</strong></td>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#initDataPresensiKaryawan').DataTable();
        $('#initDataHariCutiKaryawan').DataTable();

        $('#filterTanggal, #filterTanggalCuti').daterangepicker({
            'applyClass': 'btn-sm btn-success',
            'cancelClass': 'btn-sm btn-default',
            locale: {
                "format": "DD/MM/YYYY",
                applyLabel: 'Apply',
                cancelLabel: 'Cancel',
            },
            'startDate': '<?= date("d-m-Y") ?>',
            'endDate': '<?= date("d-m-Y") ?>'
        });

        handlerFilterKehadiranKaryawan();
        handlerFilterCutiKaryawan();
    })

    const handlerFilterKehadiranKaryawan = (month) => {
        let filterTanggal = $("#filterTanggal").val();
        $.ajax({
            type: "POST",
            url: '<?= base_url('Users/Karyawan/filterPresensi'); ?>',
            data: {
                idKaryawan: "<?= $this->session->userdata('id') ?>",
                filterTanggal
            },
            dataType: 'json',
            success: function(response) {
                if (response.length > 0) {
                    $("#initDataPresensiKaryawan > tbody").empty()
                    $.each(response, function(i, v) {
                        $("#initDataPresensiKaryawan > tbody").append(`
                            <tr>
                                <td class="text-center">${i+1}</td>
                                <td class="text-center">${formatTanggal(v.tgl)}</td>
                                <td class="text-center">${v.jam_masuk == null ? '-' : v.jam_masuk}</td>
                                <td class="text-center">${v.jam_pulang == null ? '-' : v.jam_pulang}</td>
                                <td>${v.status_masuk == '' ? '-' : v.status_masuk}</td>
                                <td>${v.status_pulang == '' ? '-' : v.status_pulang}</td>
                            </tr>`)
                    })
                }
            }

        })
    }

    const handlerFilterCutiKaryawan = () => {
        let filterTanggal = $("#filterTanggalCuti").val();
        $.ajax({
            type: "POST",
            url: '<?= base_url('Users/Karyawan/filterCuti'); ?>',
            data: {
                idKaryawan: "<?= $this->session->userdata('id') ?>",
                filterTanggal
            },
            dataType: 'json',
            success: function(response) {
                if (response.length > 0) {
                    $("#initDataHariCutiKaryawan > tbody").empty()
                    $.each(response, function(i, v) {
                        $("#initDataHariCutiKaryawan > tbody").append(`
                            <tr>
                                <td class="text-center">${i+1}</td>
                                <td class="text-center">${formatTanggal(v.tgl_mulai)}</td>
                                <td class="text-center">${formatTanggal(v.tgl_akhir)}</td>
                                <td class="text-center">${v.lama} Hari</td>
                                <td>${v.statuspengajuan}</td>
                            </tr>`)
                    })
                }
                // $('#initDataHariCutiKaryawan').DataTable();
            }

        })
    }
</script>