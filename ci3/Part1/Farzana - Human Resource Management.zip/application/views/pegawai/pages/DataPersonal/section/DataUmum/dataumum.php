<?php
$user = where_row('karyawan', ['id' => $this->session->userdata('id')]);


if ($user->is_invited == 1) {
    $disabled = "";
} else {
    $disabled = "disabled";
}

?>

<div>
    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-personal-tab" data-toggle="pill" data-target="#pills-personal" type="button" role="tab" aria-controls="pills-personal" aria-selected="true">Data Personal</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link " id="pills-pekerjaan-tab" data-toggle="pill" data-target="#pills-pekerjaan" type="button" role="tab" aria-controls="pills-pekerjaan" aria-selected="false">Pekerjaan</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link " id="pills-dokuemnt-tab" data-toggle="pill" data-target="#pills-dokuemnt" type="button" role="tab" aria-controls="pills-dokuemnt" aria-selected="false">Dokumen</button>
        </li>
    </ul>
    <hr>
    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-personal" role="tabpanel" aria-labelledby="pills-personal-tab">
            <?php $this->load->view('pegawai/pages/DataPersonal/section/DataUmum/sub-section/dataumum-subPersonal') ?>
        </div>

        <div class="tab-pane fade " id="pills-pekerjaan" role="tabpanel" aria-labelledby="pills-pekerjaan-tab">
            <?php $this->load->view('pegawai/pages/DataPersonal/section/DataUmum/sub-section/dataumum-subPekerjaan') ?>
        </div>

        <div class="tab-pane fade " id="pills-dokuemnt" role="tabpanel" aria-labelledby="pills-dokuemnt-tab">
            <?php $this->load->view('pegawai/pages/DataPersonal/section/DataUmum/sub-section/dataumum-subDokumen') ?>
        </div>
    </div>
</div>