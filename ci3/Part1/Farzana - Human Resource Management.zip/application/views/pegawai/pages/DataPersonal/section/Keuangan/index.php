<?php

$dataTransaksi = $this->db->select('a.*, b.name')
    ->from('transaksi_keuangan a')
    ->join('jenis_transaksi_keuangan b', 'a.id_jenis_transaksi_keuangan = b.id', 'left')
    ->where('a.id_karyawan', $this->session->userdata('id'))->order_by('id', 'DESC')->get()->result()
?>

<div class="container">
    <div>
        <h4><strong>Daftar Transaksi Keuangan</strong></h4>
        <div class="ml-4 mb-4">
            <div class="table-responsive mt-3">
                <table class="table table-striped" width="100%" style="font-size: 12px;" id="initDataTransaksiKeuangan">
                    <thead>
                        <tr class="bg-dark text-white text-center">
                            <td><strong>No.</strong></td>
                            <td><strong>Jenis Transaksi Keuangan</strong></td>
                            <td><strong>Nominal</strong></td>
                            <td><strong>Tanggal</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($dataTransaksi) > 0) { ?>
                            <?php foreach ($dataTransaksi as $key => $value) { ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $value->name ?></td>
                                    <td>Rp. <?= $value->nominal ?></td>
                                    <td><?= date_indo($value->tanggal) ?></td>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td class="text-center text-danger" colspan="4">Data Kosong</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#initDataTransaksiKeuangan').DataTable();
    })
</script>