<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Setting User</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form class="form-horizontal" method="post" action="<?= base_url('Pegawai/Setting/SettingUser/updateData') ?>">
                        <input type="hidden" name="id" value="<?= $users->id ?>">
                        <div class="item form-group">

                            <label class="col-md-3">Email</label>
                            <div class="col-md-9">
                                <input type="text" name="email" value="<?= $users->email ?>" class="form-control" required autocomplete="off" placeholder="Email">
                            </div>
                        </div>

                        <div class="item form-group">
                            <label class="col-md-3">Password &nbsp;<small class="text-danger">abaikan jika tidak dirubah</small> </label>
                            <div class="col-md-9">
                                <input type="password" name="password" class="form-control" autocomplete="off" placeholder="********" required>
                            </div>
                        </div>

                        <div class="item form-group">
                            <label class="col-md-3">No. Handphone</label>
                            <div class="col-md-9">
                                <input type="text" name="phone" value="<?= $users->phone ?>" class="form-control" required autocomplete="off" placeholder="Nomor Handphone">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="col-md-3"></label>
                            <div class="col-md-9">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>