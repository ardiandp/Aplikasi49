<?php

$dataAbsensi = $this->db->query("select * from absensi where id_karyawan ='" . $this->session->userdata('id') . "' and DATE_FORMAT(tgl, '%Y-%m-%d') ='" . date('Y-m-d') . "'")->row();


?>


<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>
    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-8">
      <div class="x_panel">
        <div class="x_title">
          <h2>Absensi</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <div class="container">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Hari Absen</label>
                  <input type="hidden" name="" id="hidjamkerja">
                  <input type="hidden" name="" id="htoleransi">
                  <input type="text" class="form-control" readonly disabled name="namahari" id="namahari" value="<?= $hari ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Jadwal Masuk</label>
                  <input type="text" class="form-control" readonly disabled name="jam_masuk" id="jam_masuk" value="<?= $hari ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Jadwal Pulang</label>
                  <input type="text" class="form-control" readonly disabled name="jam_pulang" id="jam_pulang" value="<?= $hari ?>">
                </div>
              </div>
              <div class="col-md-12">
                <button class="btn-submit btn btn-success" id="btnabsenloading" style="display:none" disabled>
                  <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading...
                </button>
                <?php if (empty($dataAbsensi)) { ?>
                  <button class="btn-submit btn btn-success" id="btnabsen">Absen Masuk</button>
                <?php } else { ?>
                  <?php if ($dataAbsensi->jam_masuk == '' && $dataAbsensi->jam_pulang == '') { ?>
                    <button class="btn-submit btn btn-success" id="btnabsen">Absen Masuk</button>
                  <?php } else if ($dataAbsensi->jam_masuk != '' && $dataAbsensi->jam_pulang == '') { ?>
                    <button class="btn-submit btn btn-success" id="btnabsen">Absen Pulang</button>
                  <?php } else { ?>
                    <button class="btn-submit btn btn-success" id="btnabsen" disabled>Anda telah absen keduanya</button>
                  <?php } ?>
                <?php } ?>

              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
  <div class="col-md-12 col-sm-12 " id="divapproval" style="display: none;">
    <div class="x_panel">
      <div class="x_title">
        <h2>Approval Pengajuan</h2>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <div class="row">
          <div class="col-lg-6 col-md-4 col-sm-4">

            <div class="item form-group">
              <label class="col-form-label col-md-6 col-sm-6 " name="CAPTION-PERUSAHAAN">Jenis Validasi</label>
              <div class="col-md-6 col-sm-6">
                <select class="form-control select2" name="filter_jenisvalidasipegawai" id="filter_jenisvalidasipegawai" required>
                  <option value="">Pilih Jenis Validasi</option>
                  <?php foreach (show_data("jenis_validasi") as $un) : ?>
                    <option value="<?= $un->id ?>">
                      <?= $un->nama_jenis_validasi ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
          </div>


          <div class="item form-group">
            <div class="col-md-12 col-sm-12 text-left">
              <!-- <a class="btn btn-md btn-primary btn-submit-filter" onclick="getOutstandingApprovalKaryawan()" name="CAPTION-CARI">Cari</a> -->
            </div>
          </div>


        </div>
        <div class="row">
          <div class="table-responsive">
            <table id="tableApproval" width="100%" class="table table-striped table-bordered">
              <thead>
                <tr class="bg-dark text-white">
                  <th name="CAPTION-NO">No</th>
                  <th name="">Nama Aktivitas</th>
                  <th name="">Jumlah</th>
                </tr>
              </thead>
              <tbody>

              </tbody>
            </table>
          </div>
        </div>



      </div>
    </div>
    <!-- content -->
  </div>
</div>
<!-- modal view approval-->
<div class="modal fade" id="modalApproval" role="dialog" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-xl" style="width: 100%;">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header ">
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
        <h4 class="modal-title"><label name="CAPTION-CAPTION-LISTAPPROVAL" style="background-color: white;">List Approval</label></h4>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="row">
            <h4 class="modal-title">Step <label id="lbnamastep" style="background-color: white;"></label></h4>
          </div>
          <div class="table-responsive">
            <table id="tableDetailApproval" style="width:100%" class="table table-striped table-bordered">
              <thead>
                <tr class="bg-dark text-white">
                  <th style="text-align: center;" name="CAPTION-NO"></th>
                  <th style="text-align: center;" name="CAPTION-NO">No</th>
                  <th style="text-align: center;">Tgl Pengajuan</th>
                  <th style="text-align: center;">Diajukan Oleh</th>
                  <!-- <th style="text-align: center;" name="CAPTION-NODOKUMEN">No Dokumen</th> -->
                  <th style="text-align: center;">Step 1</th>
                  <th style="text-align: center;">Step 2</th>
                  <th style="text-align: center;">Step 3</th>
                  <th style="text-align: center;">Step 4</th>
                  <th style="text-align: center;">Step 5</th>
                  <th style="text-align: center;">Disetujui</th>
                  <th style="text-align: center;">Ditolak</th>
                  <th style="text-align: center;">Ditunda</th>
                </tr>
              </thead>
              <tbody>

              </tbody>
            </table>
          </div>

        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" id="saveApprovalPegawai"><i class="fas fa-floppy-disk"></i>
          <label name="CAPTION-SAVE">Simpan</label></button>
        <button type="button" class="btn btn-dark btnclosemodalbuatpackingdo" data-dismiss="modal"><i class="fas fa-xmark"></i> <label name="CAPTION-TUTUP">Tutup</label></button>

      </div>




    </div>
  </div>
</div>
<script>
  function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2 - lat1); // deg2rad below
    var dLon = deg2rad(lon2 - lon1);
    var a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c; // Distance in km
    return d;
  }

  function getDistanceFromLatLonInMeters(lat1, lon1, lat2, lon2) {
    var R = 6371000; // Radius of the earth in meters
    var dLat = deg2rad(lat2 - lat1); // deg2rad below
    var dLon = deg2rad(lon2 - lon1);
    var a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c; // Distance in meters
    return d;
  }

  function deg2rad(deg) {
    return deg * (Math.PI / 180)
  }

  $(document).ready(function() {
    console.log('<?= $this->session->userdata('id') ?>');
    getDataIfValidator();
    $(".select2").select2({
      width: "100%"
    });

    $(document).on("input", ".numeric", function(event) {
      this.value = this.value.replace(/[^\d.]+/g, '');
    });

    // getdataabsensi();
    getDataJam();


  })


  function getDataJam() {
    let hari = $('#namahari').val();
    console.log(hari);
    $.ajax({
      type: 'POST',
      url: '<?= base_url('absensi/getdatajam') ?>',
      async: false,
      dataType: "JSON",
      data: {
        hari
      },
      success: function(response) {
        if (response !== null) {
          $("#hidjamkerja").val(response.id_jamkerja);
          let jam_masuk = response.jam_masuk;
          let jam_pulang = response.jam_pulang;
          let timenow = '<?= date('H:i') ?>'
          let splitjam_masuk = parseInt(jam_masuk.split(":")[0]) == 23 ? 2 : parseInt(jam_masuk.split(":")[0]) + 3;
          let splitjam_pulang = parseInt(jam_pulang.split(":")[0]) - 2;
          $("#jam_masuk").val(response.jam_masuk)
          $("#jam_pulang").val(response.jam_pulang)
          $("#htoleransi").val(response.toleransi)

          const now = new Date().getHours()

          // if (now >= (parseInt(jam_masuk.split(":")[0]) - 2) && now <= splitjam_masuk) {
          //   $('#btnabsen').html('Absen Masuk');
          //   $('#btnabsen').prop('disabled', false);
          // } else if (now >= splitjam_pulang && now <= (parseInt(jam_pulang.split(":")[0]) + 7)) {
          //   $('#btnabsen').html('Absen Pulang');
          //   $('#btnabsen').prop('disabled', false);
          // } else {
          //   $('#btnabsen').html('Disabled');
          //   $('#btnabsen').prop('disabled', true);
          // }


          var startDate = new Date();
          // Do your operations
          var endDate = new Date();
          var seconds = (endDate.getTime() - startDate.getTime()) / 1000;
          console.log(endDate.getTime());
        }
      }
    })
  }

  function diff_hours(dt2, dt1) {

    var diff = dt2.getTime() - dt1.getTime();
    return (diff / 60000);

  }

  function isValidDate(d) {
    return d instanceof Date && !isNaN(d);
  }

  function toHoursAndMinutes(totalMinutes) {
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    const hoursCek = hours == 0 ? '' : Math.abs(hours) + " Jam";
    const minutesCek = minutes == 0 ? '' : Math.abs(minutes) + " Menit";

    return hoursCek + " " + minutesCek;
  }

  const showBtnAbsen = () => {
    $("#btnabsen").show();
    $("#btnabsenloading").hide();
  }

  $(document).on('click', '#btnabsen', function() {
    $("#btnabsen").hide();
    $("#btnabsenloading").show();

    let hari = $('#namahari').val();
    let jam_absen = '<?= date('d-m-Y H:i:s') ?>';
    let jam_masuk = $("#jam_masuk").val()
    let jam_pulang = $("#jam_pulang").val()
    let toleransi = $("#htoleransi").val();

    if (!/^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$/.test(jam_masuk)) {
      showMessage('error', `Hari efektif pada hari ${$('#namahari').val()} belum disetting oleh admin`);
      showBtnAbsen();
      return false;
    }

    //get lokasi kantor by data karyawan selection id
    $.ajax({
      type: "POST",
      url: '<?= base_url('absensi/getLokasiKantor'); ?>',
      data: {
        idkaryawan: "<?= $this->session->userdata('id') ?>"
      },
      dataType: 'json',
      success: function(response) {
        if (response == null) {
          showMessage('error', 'Karyawan ' + $('#idkaryawan option:selected').text() + ' tidak memiliki lokasi kantor, silahkan update data lokasi pekerjaan melalui data kepegawaian atau hubungi admin');
          showBtnAbsen();
          return false;
        } else {
          if (navigator.geolocation) { //check if geolocation is available
            navigator.geolocation.getCurrentPosition(function(position) {
              const latPositionUser = position.coords.latitude;
              const longPositionUser = position.coords.longitude;


              if (response.satuan == 'Km') {
                const betweenLocation = getDistanceFromLatLonInKm(response.latitude, response.longitude, latPositionUser, longPositionUser);
                if (parseInt(Math.round(betweenLocation)) > parseInt(response.jarak)) {
                  showMessage('error', `Absensi gagal, anda berada di luar radius ketentuan absen kantor, radius anda <strong>${parseInt(Math.round(betweenLocation))} Km</strong>, lakukan absen berada dibawah sama dengan ${parseInt(response.jarak)} Km`);
                  showBtnAbsen();
                  return false;
                }
              }

              if (response.satuan == 'm') {
                const betweenLocation = getDistanceFromLatLonInMeters(response.latitude, response.longitude, latPositionUser, longPositionUser);
                const mathRoundMeters = parseInt(Math.round(betweenLocation));
                const mathRoundKm = betweenLocation / 1000
                const convertDistance = mathRoundMeters < 1000 ? mathRoundMeters + " Meter" : mathRoundKm.toFixed(1) + " Km";
                if (parseInt(Math.round(betweenLocation)) > parseInt(response.jarak)) {
                  showMessage('error', `Absensi gagal, anda berada di luar radius ketentuan absen kantor, radius anda <strong>${convertDistance}</strong>, lakukan absen berada dibawah sama dengan ${parseInt(response.jarak)} Meter`);
                  showBtnAbsen();
                  return false;
                }
              }


              let now = '<?= date('H:i') ?>';
              let waktu = "";
              let status = '';
              let type = '';
              let dt1 = new Date(`<?= date('Y-m-d') ?> ${now}:00`);
              let dtmasuk = new Date(`<?= date('Y-m-d') ?> ${jam_masuk}:00`);
              let dtpulang = new Date(`<?= date('Y-m-d') ?> ${jam_pulang}:00`);

              if ($('#btnabsen').html() == 'Absen Masuk') {
                // waktu = now.replace(":", "") - jam_masuk.replace(":", "")
                waktu = diff_hours(dt1, dtmasuk)

                type = 1;

                if (waktu < 0) {
                  status = `Anda absen masuk ${toHoursAndMinutes(waktu)} lebih awal dari jam yang telah ditentukan`
                }

                if (waktu == 0) {
                  status = "Anda absen masuk tepat waktu"
                }

                if (waktu > 0) {
                  if (waktu > toleransi) {
                    status = `Anda absen masuk terlambat ${toHoursAndMinutes(waktu)}`
                  } else {
                    status = `Anda absen terlambat ${toHoursAndMinutes(waktu)} tapi masih dalam toleransi`
                  }
                }
              }
              if (($('#btnabsen').html() == 'Absen Pulang')) {
                // waktu = now.replace(":", "") - jam_pulang.replace(":", "")

                waktu = diff_hours(dt1, dtpulang)
                type = 2;

                if (waktu < 0) {
                  status = `Anda absen pulang ${toHoursAndMinutes(waktu)} lebih awal dari jam yang telah ditentukan`
                }
                if (waktu == 0) {
                  status = "Anda absen pulang tepat waktu"
                }
                if (waktu > 0) {
                  status = `Anda absen pulang ${toHoursAndMinutes(waktu)} diatas dari jam yang telah ditentukan`;
                }

              }

              $.ajax({
                type: "POST",
                url: '<?= base_url('absensi/addabsensi'); ?>',
                data: {
                  idkaryawan: "<?= $this->session->userdata('id') ?>",
                  hari: hari,
                  id_jam_kerja: $("#hidjamkerja").val(),
                  waktu: waktu,
                  status: status,
                  latPositionUser,
                  longPositionUser,
                  type

                },
                dataType: 'json',
                success: function(response) {
                  if (response.status == 200) {
                    showMessage('success', response.message);
                    setTimeout(() => window.location.reload(), 800);
                    showBtnAbsen();
                  }
                  if (response.status == 400) {
                    showMessage('error', response.message);
                    showBtnAbsen();
                    return false;
                    // setTimeout(() => window.location.reload(), 800);
                  }
                }

              })

            });
          }

        }
      }
    })

  })

  function getDataIfValidator() {
    $.ajax({
      type: 'POST',
      url: '<?= base_url('ApprovalbyKaryawan/getDataIfValidator') ?>',

      async: false,
      dataType: "JSON",
      success: function(response) {
        if (response != null) {
          if (response.nama_jabatan != "Staff") {
            $('#divapproval').show();
          } else {
            $.ajax({
              type: 'POST',
              url: '<?= base_url('ApprovalbyKaryawan/getDataIfValidator2') ?>',

              async: false,
              dataType: "JSON",
              success: function(response) {
                if (response != null) {

                  $('#divapproval').show();

                }

              }
            })
          }
        }
      }
    })
  }
  $(document).on('change', '#filter_jenisvalidasipegawai', function() {
    let val = $(this).val()
    $.ajax({
      type: 'POST',
      url: '<?= base_url('ApprovalbyKaryawan/getdataapprovalbyjenisForPegawai') ?>',
      // url: '<?= base_url('ApprovalbyKaryawan/dataApprovalbawahan') ?>',
      async: false,
      data: {
        id: val
      },
      dataType: "JSON",
      success: function(response) {
        console.log(response);

        if (response != null) {
          $('#tableApproval >tbody').empty()

          $.each(response, function(i, v) {
            // if (v.details == "bawahan") {

            $('#tableApproval >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.nama_aktivitas}</td>
                            
                            <td> 
                              <a class="btn btn-primary" onclick="detailApprovalForPegawai('${val}','${v.id}','${v.nama_aktivitas}')">${this.jumlah}</a>
                            </td>
                        </tr>`);
          })
        }
      }
    })
  })

  function detailApprovalForPegawai(approval_id, aktifitas, nm_aktifitas) {
    if (nm_aktifitas == "Approval Payroll") {
      $('#modalApproval').modal("show");
      getApprovalPayroll(approval_id, aktifitas, nm_aktifitas)
      return false;
    }

    $('#modalApproval').modal("show");
    // select * FROM karyawan left join jabatan on jabatan.id = karyawan.id_jabatan LEFT JOIN role on role.id = jabatan.id_role where karyawan.id =110;
    $.ajax({
      type: 'POST',

      url: '<?= base_url('ApprovalbyKaryawan/getSettingValidator') ?>',
      async: false,
      data: {
        idjenisvalidasi: approval_id,
        idvalidasi: aktifitas
      },
      dataType: "JSON",
      success: function(response) {
        $.each(response, function(i, v) {

          if (v.urut == 1) {
            if (v.nama_step.toLowerCase() == "atasan" || v.nama_step.toLowerCase() == "atasan langsung") {
              // getBawahan(approval_id, v.urut);
              // if (getBawahan(approval_id, v.urut) == 1) {
              //   return false
              // }
              getdatadetailapprovalurut(approval_id, 1, aktifitas)

              if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
                return false;
              }
            } else if (v.nama_step.toLowerCase() == "hrd" || v.nama_step.toLowerCase() == "staff") {
              getdatadetailapprovalurut(approval_id, 1, aktifitas)

              if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
                return false;
              }
            } else if (v.nama_step.toLowerCase() == "pengurus yayasan" || v.nama_step.toLowerCase() == "sekertaris" || v.nama_step.toLowerCase() == "pengesahan") {
              getdatadetailapprovalurut(approval_id, 1, aktifitas)
              if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
                return false;
              }
            }
            // if (v.nama_step.toLowerCase() == "atasan" || v.nama_step.toLowerCase() == "atasan langsung") {
            //   getBawahan(approval_id, v.urut);
            //   if (getBawahan(approval_id) == 1) {
            //     return false
            //   }
            // } else if (v.nama_step.toLowerCase() == "hrd" || v.nama_step.toLowerCase() == "staff") {
            //   alert("1")
            //   getdatadetailapprovalurut(approval_id, 1, aktifitas)
            // } else if (v.nama_step.toLowerCase() == "pengurus yayasan" || v.nama_step.toLowerCase() == "sekertaris" || v.nama_step.toLowerCase() == "pengesahan") {
            //   alert("2")
            //   // getdatadetailapproval(approval_id)
            // }
          } else if (v.urut == 2) {
            if (v.nama_step.toLowerCase() == "atasan" || v.nama_step.toLowerCase() == "atasan langsung") {
              getBawahan(approval_id, v.urut);

              if (getBawahan(approval_id, v.urut) == 1) {
                return false
              }
            } else if (v.nama_step.toLowerCase() == "hrd" || v.nama_step.toLowerCase() == "staff") {
              getdatadetailapprovalurut(approval_id, 2, aktifitas)

              if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
                return false;
              }
            } else if (v.nama_step.toLowerCase() == "pengurus yayasan" || v.nama_step.toLowerCase() == "sekertaris" || v.nama_step.toLowerCase() == "pengesahan") {
              getdatadetailapprovalurut(approval_id, 2, aktifitas)
              if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
                return false;
              }
            }
            // if (v.nama_step.toLowerCase() == "atasan") {
            //   getBawahan(approval_id);
            //   if (getBawahan(approval_id) == 1) {
            //     return false
            //   }
            // } else if (v.nama_step.toLowerCase() == "hrd" || v.nama_step.toLowerCase() == "staff") {
            //   getdatadetailapprovalurut(approval_id, 2, aktifitas)
            //   if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
            //     return false;
            //   }
            // } else if (v.nama_step.toLowerCase() == "pengurus yayasan" || v.nama_step.toLowerCase() == "sekertaris" || v.nama_step.toLowerCase() == "pengesahan") {
            //   getdatadetailapprovalurut(approval_id, 3, aktifitas)
            // }
          } else if (v.urut == 3) {

            if (v.nama_step.toLowerCase() == "atasan" || v.nama_step.toLowerCase() == "atasan langsung") {
              getBawahan(approval_id, v.urut);

              if (getBawahan(approval_id, v.urut) == 1) {
                return false
              }
            } else if (v.nama_step.toLowerCase() == "hrd" || v.nama_step.toLowerCase() == "staff") {
              getdatadetailapprovalurut(approval_id, 3, aktifitas)

              if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
                return false;
              }
            } else if (v.nama_step.toLowerCase() == "pengurus yayasan" || v.nama_step.toLowerCase() == "sekertaris" || v.nama_step.toLowerCase() == "pengesahan") {
              getdatadetailapprovalurut(approval_id, 3, aktifitas)
              if (getApprovalbyurut(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
                return false;
              }
            }
          }
        })
      }
    })
    return false;
  }

  function getApprovalPayroll(approval_id, aktifitas, nm_aktifitas) {
    $.ajax({
      type: 'POST',

      url: '<?= base_url('ApprovalbyKaryawan/getSettingValidator') ?>',
      async: false,
      data: {
        idjenisvalidasi: approval_id,
        idvalidasi: aktifitas
      },
      dataType: "JSON",
      success: function(response) {
        $.each(response, function(i, v) {

          if (v.urut == 1) {

            getdatadetailapprovalurutPayroll(approval_id, 1, aktifitas, nm_aktifitas)

            // if (getApprovalbyurutPayroll(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
            if (getdatadetailapprovalurutPayroll(approval_id, 1, aktifitas, nm_aktifitas) == 1) {
              alert('bendahara1')
              return false;
            }

          }
          if (v.urut == 2) {
            // if (v.nama_step.toLowerCase() == "bendahara") {
            getdatadetailapprovalurutPayroll(approval_id, 2, aktifitas, nm_aktifitas)
            // if (getApprovalbyurutPayroll(v.urut, v.id_jabatan, v.id_bidang, v.id_karyawan, approval_id) == 1) {
            if (getdatadetailapprovalurutPayroll(approval_id, 2, aktifitas, nm_aktifitas) == 1) {
              return false;
            }

          } else {

          }
        })
      }
    })
  }

  function detailApproval(approval_id) {
    $('#modalApproval').modal("show");

    // select * FROM karyawan left join jabatan on jabatan.id = karyawan.id_jabatan LEFT JOIN role on role.id = jabatan.id_role where karyawan.id =110;
    $.ajax({
      type: 'POST',
      url: '<?= base_url('Approval/getdatadetailapproval') ?>',
      async: false,
      data: {
        id: approval_id
      },
      dataType: "JSON",
      success: function(response) {
        if (response != null) {
          $('#tableDetailApproval >tbody').empty()

          let step = '';
          $.each(response, function(i, v) {


            $('#tableDetailApproval >tbody').append(`
              <tr id='${i}'>
               <td><input type='checkbox' id='cbpilihapproval' name='cbpilihapproval' onchange="handlerCB(event,${i})"></td>
                                <td class="id_approval" style="display:none;">${v.id_approval}</td>
                                <td class="id_approval" style="display:none;">${v.id_karyawan}</td>
                                <td class="idx_approval" style="display:none;">${i}</td>
                                <td class="">${i+1}</td>
                                <td class="tgl_pengajuan">${v.tgl_pengajuan}</td>
                                <td class="nama_karyawan_${i}"><span id="nama_karyawan_${i}">${v.nama_karyawan}</span></td>
                                <td class="step1">${v.step1==null?'':v.step1}</td>
                                <td class="step2">${v.step2==null?'':v.step2}</td>
                                <td class="step3">${v.step3==null?'':v.step3}</td>
                                <td class="step4">${v.step4==null?'':v.step4}</td>
                                <td class="step5">${v.step5==null?'':v.step5  }</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovaldisetujui${i}' name='radioapproval${i}' disabled readonly value="disetujui">Disetujui</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovalditolak${i}' name='radioapproval${i}' disabled readonly value ="ditolak">Ditolak</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovalditunda${i}' name='radioapproval${i}' disabled readonly value="ditunda">Ditunda</td>
                            </tr>`);

            // <td> 
            //   <a class="btn btn-primary" onclick="detailApproval('${this.approval_setting_id}','${this.approval_setting_jenis}')">${this.jumlah}</a>
            //           </td>

          })
        }
      }
    })

  }
  const handlerCB = (e, i) => {
    if (e.currentTarget.checked == true) {
      $(`input[name="radioapproval${i}"]`).each(function() {
        $(this).prop('disabled', false);
        $(this).prop('checked', false);
      });
    } else {
      $(`input[name="radioapproval${i}"]`).each(function() {
        $(this).prop('disabled', true);
        $(this).prop('checked', false);

      });
    }
    // event.currentTarget.value
  }

  $(document).on('click', '#cbpilihapproval', function() {

  })
  $(document).on('click', '#saveApprovalPegawai', function() {
    let arratemp = [];
    let table = $('#tableDetailApproval >tbody >tr').length;

    $('#tableDetailApproval >tbody >tr').each(function(i, v) {

      $(`input[name="radioapproval${i}"]:radio:checked`).each(function() {
        let step1 = $(this).closest("tr").find("td:nth-child(8)").text()
        let step2 = $(this).closest("tr").find("td:nth-child(9)").text()
        let step3 = $(this).closest("tr").find("td:nth-child(10)").text()
        let step4 = $(this).closest("tr").find("td:nth-child(11)").text()
        let step5 = $(this).closest("tr").find("td:nth-child(12)").text()

        if ($('#lbnamastep').text() == 1) {


        }
        if ($('#lbnamastep').text() == 2) {
          alert('awu')
          if (step1 == '') {
            alert(`Permohonan ke ${i+1} Belum Di Acc, Mohon Menunggu`);
            return false;
          }
          if (step2 != '') {
            alert(`Permohonan ke ${i+1} Sudah Diisi`);
            return false;
          }

        }
        if ($('#lbnamastep').text() == 3) {
          if (step2 == '') {
            alert(`Permohonan ke ${i+1} Belum Di Acc, Mohon Menunggu`);
            return false;
          }
          if (step2 != '') {
            alert(`Permohonan ke ${i+1} Sudah Diisi`);
            return false;
          }
        }
        if (step1 == 'Ditolak' || step2 == 'Ditolak' || step3 == 'Ditolak' || step4 == 'Ditolak' || step5 == 'Ditolak') {
          alert(`Permohonan ke ${i+1} Telah ditolak, Mohon Tidak Di Pilih`);
          return false;
        }
        arratemp.push({
          'id': $(this).closest("tr").find("td:nth-child(2)").text(),
          'id_karyawan': $(this).closest("tr").find("td:nth-child(3)").text(),
          'status': $(this).parent().text()
        })
      });

    })
    if (arratemp.length == 0) {
      alert("Mohon Pilih Data")
      return false;
    }
    Swal.fire({
      title: "Pastikan Data Benar!!!",
      text: "Data Tidak Akan Bisa DIrubah!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Ya, Simpan",
      cancelButtonText: "Tidak, Tutup"
    }).then((result) => {
      if (result.value == true) {


        $.ajax({
          type: 'POST',
          url: '<?= base_url('ApprovalbyKaryawan/SaveApproval') ?>',
          async: false,
          data: {
            arr: arratemp
          },
          dataType: "JSON",
          success: function(response) {
            if (response == true) {
              new PNotify({
                text: 'Succes!',
                type: 'success',
                styling: 'bootstrap3',
                delay: 3000,
                history: false
              })
              setTimeout(() => window.location.reload(), 800);
              return false;
            } else {
              if (response) {
                new PNotify({
                  text: 'Gagal!',
                  type: 'error',
                  styling: 'bootstrap3',
                  delay: 3000,
                  history: false
                })
                setTimeout(() => window.location.reload(), 800);
                return false;
              }
            }
          }
        })
      }
    })
  })

  function getBawahan(approval_id, urut) {
    let ret = null;
    $.ajax({
      type: 'POST',

      url: '<?= base_url('ApprovalbyKaryawan/dataApprovalbawahan') ?>',
      async: false,
      data: {
        id: approval_id
      },
      dataType: "JSON",
      success: function(response) {
        if (response != null) {
          ret = 1
          $('#tableDetailApproval >tbody').empty()

          let step = '';
          $('#lbnamastep').text(urut)
          $.each(response, function(i, v) {

            $('#tableDetailApproval >tbody').append(`
                            <tr id='${i}'>
                            <td><input type='checkbox' id='cbpilihapproval' name='cbpilihapproval' onchange="handlerCB(event,${i})"></td>
                                <td class="id_approval" style="display:none;">${v.id_approval}</td>
                                <td class="id_approval" style="display:none;">${v.id_karyawan}</td>
                                <td class="idx_approval" style="display:none;">${i}</td>
                                <td class="">${i+1}</td>
                                <td class="tgl_pengajuan">${v.tgl_pengajuan}</td>
                                <td class="nama_karyawan_${i}"><span id="nama_karyawan_${i}">${v.nama_karyawan}</span></td>
                                <td class="step1">${v.step1==null?'':v.step1}</td>
                                <td class="step2">${v.step2==null?'':v.step2}</td>
                                <td class="step3">${v.step3==null?'':v.step3}</td>
                                <td class="step4">${v.step4==null?'':v.step4}</td>
                                <td class="step5">${v.step5==null?'':v.step5  }</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovaldisetujui${i}' name='radioapproval${i}' disabled readonly value="disetujui">Disetujui</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovalditolak${i}' name='radioapproval${i}' disabled readonly value ="ditolak">Ditolak</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovalditunda${i}' name='radioapproval${i}' disabled readonly value="ditunda">Ditunda</td>
                            </tr>`);

            // <td> 
            //   <a class="btn btn-primary" onclick="detailApproval('${this.approval_setting_id}','${this.approval_setting_jenis}')">${this.jumlah}</a>
            //           </td>

          })
          // $.ajax({
          //   type: 'POST',

          //   url: '<?= base_url('ApprovalbyKaryawan/getAksesValidasi') ?>',
          //   async: false,
          //   data: {
          //     id: approval_id
          //   },
          //   dataType: "JSON",
          //   success: function(response) {
          //     $.each(response, function(i, v) {
          //       if (v.nama_step)

          //         $("#lbnamastep").val()
          //     })

          //   }
          // })
        }
        if (response == null || response == 'null') {
          ret = 0;
        }
        // alert(response)
      }
    })
    return ret;
  }

  function getdatadetailapprovalurut(approval_id, urut, aktifitas, nm_aktifitas) {
    let ret = null;
    $.ajax({
      type: 'POST',
      url: '<?= base_url('ApprovalbyKaryawan/getAksesValidasiByUrut') ?>',

      async: false,
      data: {
        id: approval_id,
        urut: urut,
        aktifitas: aktifitas,
      },
      dataType: "JSON",
      success: function(response) {

        if (response != null) {
          $('#lbnamastep').text(urut)
          ret = 1
          getApprovalbyurut(response.urut, response.id_jabatan, response.id_bidang, response.id_karyawan, approval_id, aktifitas, nm_aktifitas)
        }
        if (response.length == 0 || response == null) {
          ret = 0;
        }

      }
    })
    return ret;
  }

  function getdatadetailapprovalurutPayroll(approval_id, urut, aktifitas, nm_aktifitas) {
    let ret = null;
    let sess_idkar = '<?= $this->session->userdata('id') ?>';
    $.ajax({
      type: 'POST',
      url: '<?= base_url('ApprovalbyKaryawan/getAksesValidasiByUrut') ?>',

      async: false,
      data: {
        id: approval_id,
        urut: urut,
        aktifitas: aktifitas,
      },
      dataType: "JSON",
      success: function(response) {


        if (response != null) {
          if (response.id_karyawan != sess_idkar) {
            ret = 0
          } else {

            console.log("asuuu");
            $('#lbnamastep').text(urut)
            ret = 1
            getApprovalbyurutPayroll(response.urut, response.id_jabatan, response.id_bidang, response.id_karyawan, approval_id, aktifitas, nm_aktifitas)
          }
        }
        if (response.length == 0 || response == null || response == "null") {
          console.log("patek");
          ret = 0;
        }

      }
    })
    return ret;
  }

  function getApprovalbyurutPayroll(urut, jabatan, bidang, karyawan, approval_id, aktifitas, nm_aktifitas) {
    let ret = null;

    $.ajax({
      type: 'POST',
      url: '<?= base_url('ApprovalbyKaryawan/getSettingvalidatorByUrutIsPayroll') ?>',

      async: false,
      data: {
        urut: urut,
        jabatan: jabatan,
        bidang: bidang,
        karyawan: karyawan,
        aktifitas: aktifitas

      },
      dataType: "JSON",
      success: function(response) {
        console.log("response", response);
        if (response != null) {
          ret = 1;
          $('#lbnamastep').text(urut)
          detailApproval(approval_id)
        }
        if (response == "null" || response == null) {
          ret = 0;
        }

      }
    })
    return ret

  }

  function getApprovalbyurut(urut, jabatan, bidang, karyawan, approval_id, aktifitas, nm_aktifitas) {

    $.ajax({
      type: 'POST',
      url: '<?= base_url('ApprovalbyKaryawan/getSettingvalidatorByUrut') ?>',

      async: false,
      data: {
        urut: urut,
        jabatan: jabatan,
        bidang: bidang,
        karyawan: karyawan,

      },
      dataType: "JSON",
      success: function(response) {
        console.log("response", response);
        if (response != null) {
          ret = 1;
          $('#lbnamastep').text(urut)
          detailApproval(approval_id)
        }
        if (response == "null" || response == null) {
          ret = 0;
        }

      }
    })
    return ret

  }
</script>