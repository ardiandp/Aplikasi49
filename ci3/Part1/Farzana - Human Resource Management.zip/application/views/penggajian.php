<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>
    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12">
      <div class="x_panel">

        <div class="x_content">
          <div class="row" <?= (isset($_GET['jenis']) ? "style='display:none'" : "") ?>>
            <div class="col-md-12">
              <p>Genrate per Karyawan</p>
              <?php
              $sudah = $this->db->like('date', date("Y-m"))->get_where("gaji", ['status' => 1])->num_rows();
              $semua = $this->db->get("karyawan")->num_rows();
              if ($sudah < $semua) { ?>
                <form class="form-horizontal">
                  <input type="hidden" name="jenis" value="1">
                  <div class="item form-group">
                    <div class="col-md-5">
                      <select class="form-control select_unit">
                        <option>Pilih Unit</option>
                        <?php foreach (show_data("unit") as $k) {
                          echo "<option value='" . $k->id . "'>" . $k->name . "</option>";
                        } ?>
                      </select>
                    </div>
                    <div class="col-md-12 show_users"></div>
                  </div>
                </form>
              <?php } else {
                echo "<div class='alert alert-info'>Pencatatan Gaji sudah tersimpan untuk semua karyawan</div>";
              } ?>
            </div>

          </div>
        </div>
        <?php if (isset($_GET['jenis']) && $_GET['jenis'] == 1) {
          $cek_gaji = $this->db->like('date', date("y-m"))->get_where("gaji", ['karyawan' => $_GET['user']])->num_rows();
          if ($cek_gaji == 0) {
            $this->db->insert("gaji", [
              'karyawan' => $_GET['user'],
              'date' => date("Y-m-d"),
            ]);
          }
        ?>

          <div class="row">
            <div class="col-md-12">
              <?php
              $tnj = $this->db->order_by('id', 'asc')->get("tunjangan")->num_rows();
              $kry = $this->db->get_where("karyawan", ['id' => $_GET['user']])->row();
              $pnr = $this->db->select('unit.name,penerimaan.date')->join('karyawan', 'penerimaan.karyawan=karyawan.id')->join('unit', 'penerimaan.unit=unit.id')->get_where("penerimaan", ['penerimaan.karyawan' => $_GET['user']])->row();
              $tnjs = $this->db->order_by('id', 'asc')->get("tunjangan")->result();
              $bn = $this->db->order_by('id', 'asc')->get("bonus")->num_rows();
              $bns = $this->db->order_by('id', 'asc')->get("bonus")->result();
              $skl = $this->db->query("SELECT pendidikan.name, tbl_sekolah.id_pendidikan
                                      FROM tbl_sekolah
                                      left join pendidikan ON tbl_sekolah.id_pendidikan = pendidikan.id
                                      where tbl_sekolah.id_karyawan = '" . $_GET['user'] . "'
                                        AND tbl_sekolah.type = 'Formal'
                                      ORDER BY tbl_sekolah.id DESC")->row();
              if ($skl) {
                $grade = where_row('grade', ['level' => $skl->id_pendidikan]);
              }

              $tunjangan = where_row('int_tunjangan', ['karyawan' => $_GET['user']]);
              if ($tunjangan) {
                $show_tunjangan = json_decode($tunjangan->tunjangan);
              }
              $penerimaan = where_row('penerimaan', ['karyawan' => $_GET['user']]);
              $interval = date_diff(date_create($penerimaan->date), date_create(date("Y-m-d")));

              $bonus = where_row('int_bonus', ['karyawan' => $_GET['user']]);
              if ($bonus) {
                $show_bonus = json_decode($bonus->bonus);
              }

              $gaji = $this->db->like('date', date("Y-m"))->get_where("gaji", ['karyawan' => $_GET['user']])->row();
              $potongan = $this->db->like('date', date("Y-m"))->get_where('potongan', ['karyawan' => $_GET['user']])->row();
              if ($gaji->p1_1 == 0) {
                if ($skl) {
                  $tingkat = ($grade ? $grade->amount : 0);
                } else {
                  $tingkat = 0;
                }
              } else {
                $tingkat = $gaji->p1_1;
              }
              if ($gaji->p1_2 == 0) {
                $masa = $interval->y * 25000;
              } else {
                $masa = $gaji->p1_2;
              }
              $total_p1 = $tingkat + $masa;
              ?>
              <table cellpadding="5" cellspacing="5">
                <tr>
                  <td>Nama</td>
                  <td>: </td>
                  <td><?= $kry->name ?></td>
                </tr>
                <tr>
                  <td>Email</td>
                  <td>: </td>
                  <td><?= $kry->email ?></td>
                </tr>
                <tr>
                  <td>No. Tlp</td>
                  <td>: </td>
                  <td><?= $kry->phone ?></td>
                </tr>
                <tr>
                  <td>Unit Kerja</td>
                  <td>: </td>
                  <td><?= $pnr->name ?></td>
                </tr>
                <tr>
                  <td>Tanggal Masuk</td>
                  <td>: </td>
                  <td><?= date_indo($pnr->date) ?></td>
                </tr>
                <tr>
                  <td>Pendidikan Terakhir</td>
                  <td>: </td>
                  <td><?= ($skl ? $skl->name : "<span class='text-danger'>Mohon tentukan pendidikan terakhirnya</span>") ?></td>
                </tr>
                <tr>
                  <td>Masa Kerja</td>
                  <td>: </td>
                  <td><?= $interval->y ?> tahun</td>
                </tr>
              </table>
              <hr>
              <div class="clearfix"></div>
              <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Pay For Person (P1)</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Pay For Person (P2)</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Pay For Person (P3)</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="potongan-tab" data-toggle="tab" href="#potongan" role="tab" aria-controls="potongan" aria-selected="false">Potongan</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="preview-tab" data-toggle="tab" href="#preview" role="tab" aria-controls="preview" aria-selected="false">Preview</a>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                  <form>
                    <input type="hidden" name="karyawan" class="karyawan_p1" value="<?= $_GET['user'] ?>">
                    <div class="item form-group">
                      <label class="col-md-2">Grade</label>
                      <div class="col-md-10">
                        <input type="text" name="pay_grade" class="form-control p1_1" id="pay_grade" autocomplete="off" placeholder="Nomor Indouk Pegawai" value="<?= $tingkat ?>">
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-md-2">Masa Kerja</label>
                      <div class="col-md-10">
                        <input type="text" name="pay_masa" class="form-control p1_2" id="pay_masa" autocomplete="off" placeholder="Nomor Indouk Pegawai" value="<?= $masa ?>">
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-md-2">Total</label>
                      <div class="col-md-10">
                        <input type="text" name="total_p1" class="form-control total_p1" id="total_p1" readonly autocomplete="off" placeholder="Nomor Indouk Pegawai" value="<?= $total_p1 ?>">
                      </div>
                    </div>
                    <?php if ($gaji->status == 0) { ?>
                      <div class="item form-group">
                        <label class="col-md-2"></label>
                        <div class="col-md-10">
                          <button class="btn btn-primary save_p1" type="button"><i class="fa fa-save"></i> Simpan</button>
                        </div>
                      </div>
                    <?php } ?>
                  </form>
                </div>
                <div class="tab-pane fade" id="potongan" role="tabpanel" aria-labelledby="potongan-tab">
                  <?php
                  $cek_pot = $this->db->like('date', date("Y-m"))->get_where("potongan", ['karyawan' => $_GET['user']])->num_rows();
                  $pot = $this->db->like('date', date("Y-m"))->get_where("potongan", ['karyawan' => $_GET['user']])->row();
                  ?>
                  <form>
                    <input type="hidden" name="karyawan" class="karyawan_potongan" value="<?= $_GET['user'] ?>">
                    <div class="item form-group">
                      <label class="col-md-2">Potongan DPLK</label>
                      <div class="col-md-10">
                        <input type="text" name="dplk" class="form-control" value="<?= ($cek_pot != 0 ? $pot->dplk : 0) ?>" id="dplk" autocomplete="off" placeholder="0">
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-md-2">Potongan Lainnya</label>
                      <div class="col-md-10">
                        <input type="text" name="pot_lainnya" class="form-control" id="pot_lainnya" value="<?= ($cek_pot != 0 ? $pot->pot_lainnya : 0) ?>" autocomplete="off" placeholder="0">
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-md-2">Total</label>
                      <div class="col-md-10">
                        <input type="text" name="total_potongan" class="form-control" id="total_potongan" value="<?= ($cek_pot != 0 ? $pot->total_potongan : 0) ?>" readonly autocomplete="off" placeholder="0">
                      </div>
                    </div>
                    <?php if ($gaji->status == 0) { ?>
                      <div class="item form-group">
                        <label class="col-md-2"></label>
                        <div class="col-md-10">
                          <button class="btn btn-primary save_potongan" type="button"><i class="fa fa-save"></i> Simpan</button>
                        </div>
                      </div>
                    <?php } ?>
                  </form>
                </div>
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                  <?php if (isset($show_tunjangan)) { ?>
                    <form>
                      <input type="hidden" name="karyawan" class="karyawan_p2" value="<?= $_GET['user'] ?>">
                      <?php
                      $total_tunjangan = 0;
                      foreach ($show_tunjangan as $key => $value) {
                        if ($key != "karyawan") {
                          $total_tunjangan += $value;
                      ?>
                          <div class="item form-group">
                            <label class="col-md-2"><?= $key ?></label>
                            <div class="col-md-10">
                              <input type="text" class="form-control <?= strtolower($key) ?>_tunjangan" autocomplete="off" placeholder="0" value="<?= $value ?>">
                            </div>
                          </div>
                      <?php }
                      } ?>
                      <input type="hidden" class="total" value="<?= $total_tunjangan ?>">
                      <div class="item form-group">
                        <label class="col-md-2">Total</label>
                        <div class="col-md-10">
                          <input type="text" name="total_tunjangan" class="form-control total_tunjangan" readonly autocomplete="off" placeholder="0i" value="<?= $total_tunjangan ?>">
                        </div>
                      </div>
                      <?php if ($gaji->status == 0) { ?>
                        <div class="item form-group">
                          <label class="col-md-2"></label>
                          <div class="col-md-10">
                            <button class="btn btn-primary save_p2" type="button"><i class="fa fa-save"></i> Simpan</button>
                          </div>
                        </div>
                      <?php } ?>
                    </form>
                  <?php } else { ?>
                    <div class="alert alert-danger">
                      <h4>Tunjangan kosong, silahkan setting tunjangan terlebih dahulu</h4>
                    </div>
                  <?php } ?>

                </div>
                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                  <?php if (isset($show_bonus)) { ?>
                    <form>
                      <input type="hidden" name="karyawan" class="karyawan_p3" value="<?= $_GET['user'] ?>">
                      <?php
                      $total_bonus = 0;
                      foreach ($show_bonus as $key => $value) {
                        if ($key != "karyawan") {
                          $total_bonus += $value;
                      ?>
                          <div class="item form-group">
                            <label class="col-md-2"><?= $key ?></label>
                            <div class="col-md-10">
                              <input type="text" class="form-control <?= strtolower($key) ?>_bonus" autocomplete="off" placeholder="0" value="<?= $value ?>">
                            </div>
                          </div>
                      <?php }
                      } ?>
                      <div class="item form-group">
                        <label class="col-md-2">Total</label>
                        <div class="col-md-10">
                          <input type="text" class="form-control total_p3" readonly autocomplete="off" placeholder="0" value="<?= $total_bonus ?>">
                        </div>
                      </div>
                      <?php if ($gaji->status == 0) { ?>
                        <div class="item form-group">
                          <label class="col-md-2"></label>
                          <div class="col-md-10">
                            <button class="btn btn-primary save_p3" type="button"><i class="fa fa-save"></i> Simpan</button>
                          </div>
                        </div>
                      <?php } ?>
                    </form>
                  <?php } else { ?>
                    <div class="alert alert-danger">
                      <h4>Bonus kosong, silahkan setting bonus terlebih dahulu</h4>
                    </div>
                  <?php } ?>

                </div>
                <div class="tab-pane fade" id="preview" role="tabpanel" aria-labelledby="preview-tab">
                  <table cellpadding="5" cellspacing="5">
                    <tr>
                      <td> Total Pay For Person (P1)</td>
                      <td>:</td>
                      <td><?= rupiah($gaji->p1) ?></td>
                    </tr>
                    <tr>
                      <td> Total Pay For Person (P2)</td>
                      <td>:</td>
                      <td><?= rupiah($gaji->p2) ?></td>
                    </tr>
                    <tr>
                      <td> Total Pay For Person (P3)</td>
                      <td>:</td>
                      <td><?= rupiah($gaji->p3) ?></td>
                    </tr>
                    <tr>
                      <td> Total Potongan</td>
                      <td>:</td>
                      <td><?= rupiah(($potongan ? $potongan->total_potongan : 0)) ?></td>
                    </tr>
                    <tr>
                      <td> Total Gaji</td>
                      <td>:</td>
                      <td><?= rupiah($gaji->total - ($potongan ? $potongan->total_potongan : 0)) ?></td>
                    </tr>
                  </table>
                  <hr>
                  <div class="clearfix"></div>
                  <?php if ($gaji->status == 0) { ?>
                    <table cellpadding="5" cellspacing="5">
                      <tr>
                        <td>
                          <form>
                            <input type="hidden" name="karyawan" class="karyawan_total" value="<?= $_GET['user'] ?>">
                            <input type="hidden" value="<?= $gaji->p1 + $gaji->p2 + $gaji->p3 ?>" class="total_gaji">
                            <button class="btn btn-primary hitung_gaji" type="button"><i class="fa fa-save"></i> Jumlahkan</button>
                          </form>
                        </td>
                        <td>
                          <?php if ($gaji->total != 0) { ?>
                            <form>
                              <input type="hidden" name="karyawan" class="users" value="<?= $_GET['user'] ?>">
                              <input type="hidden" value="<?= date("Y-m-d") ?>" class="tgl">
                              <button class="btn btn-success genrate" type="button"><i class="fa fa-save"></i> Simpan</button>
                            </form>
                          <?php } ?>
                        </td>
                      </tr>
                    </table>
                  <?php } ?>
                </div>
              </div>
            </div>
          </div>
        <?php } ?>

      </div>
      <!-- content -->
    </div>

  </div>
</div>