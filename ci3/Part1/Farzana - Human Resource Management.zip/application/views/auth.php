<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="<?= base_url('assets/ybn.png') ?>" type="image/png" />

  <title>Login - Aplikasi HRM YBM </title>

  <!-- Bootstrap -->
  <link href="<?= base_url('assets/') ?>vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="<?= base_url('assets/') ?>vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- NProgress -->
  <link href="<?= base_url('assets/') ?>vendors/nprogress/nprogress.css" rel="stylesheet">
  <!-- Animate.css -->
  <link href="<?= base_url('assets/') ?>vendors/animate.css/animate.min.css" rel="stylesheet">

  <!-- Custom Theme Style -->
  <link href="<?= base_url('assets/') ?>build/css/custom.min.css" rel="stylesheet">
  <!-- PNotify -->
  <link href="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.css" rel="stylesheet">
  <link href="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
  <link href="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">

  <style>
    .wrapper {
      display: inline-flex;
      margin-top: 10px;
      height: 40px;
      width: 30%;
      align-items: center;
      justify-content: space-evenly;
      border-radius: 5px;
    }

    .wrapper .option {
      background: #fff;
      height: 100%;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-evenly;
      margin: 0 10px;
      border-radius: 5px;
      cursor: pointer;
      padding: 0 10px;
      border: 2px solid lightgrey;
      transition: all 0.3s ease;
    }

    .wrapper .option .dot {
      height: 20px;
      width: 20px;
      background: #d9d9d9;
      border-radius: 50%;
      position: relative;
    }

    .wrapper .option .dot::before {
      position: absolute;
      content: "";
      top: 4px;
      left: 4px;
      width: 12px;
      height: 12px;
      background: #0069d9;
      border-radius: 50%;
      opacity: 0;
      transform: scale(1.5);
      transition: all 0.3s ease;
    }

    input[type="radio"] {
      display: none;
    }

    #option-1:checked:checked~.option-1,
    #option-2:checked:checked~.option-2 {
      border-color: #0069d9;
      background: #0069d9;
    }

    #option-1:checked:checked~.option-1 .dot,
    #option-2:checked:checked~.option-2 .dot {
      background: #fff;
    }

    #option-1:checked:checked~.option-1 .dot::before,
    #option-2:checked:checked~.option-2 .dot::before {
      opacity: 1;
      transform: scale(1);
    }

    .wrapper .option span {
      font-size: 16px;
      color: #808080;
    }

    #option-1:checked:checked~.option-1 span,
    #option-2:checked:checked~.option-2 span {
      color: #fff;
    }
  </style>

</head>

<body class="login">
  <div>
    <a class="hiddenanchor" id="signup"></a>
    <a class="hiddenanchor" id="signin"></a>

    <div class="login_wrapper">
      <div class="animate form login_form">
        <section class="login_content">
          <h1>Login Form</h1>
          <div class="wrapper">
            <input type="radio" name="selectSplit" id="option-1" value="0" class="chkCompareOrApproval" onchange="chkCompareOrApproval(event)" checked>
            <input type="radio" name="selectSplit" id="option-2" value="1" class="chkCompareOrApproval" onchange="chkCompareOrApproval(event)">
            <label for="option-1" class="option option-1">
              <span>Admin</span>
            </label>
            <label for="option-2" class="option option-2">
              <span>Pegawai</span>
            </label>
          </div>

          <div id="showApproval" style="margin-top: 20px; width: 100%;position:relative;max-height:100%; display: none">
            <div>
              <input type="text" class="form-control" placeholder="Username" autocomplete="off" id="username" />
            </div>
            <div>
              <input type="password" class="form-control password" placeholder="Password" autocomplete="off" id="passwordAdmin" />
            </div>
          </div>

          <div id="showCompare" style="margin-top: 20px; width: 100%;position:relative;max-height:100%; display: none">
            <div>
              <input type="email" class="form-control" placeholder="Email" autocomplete="off" id="email" />
            </div>
            <div>
              <input type="password" class="form-control password" placeholder="Password" autocomplete="off" id="passwordPegawai" />
            </div>
          </div>

          <div class="mt-4">
            <button type="button" class="btn btn-success" onclick="handlerLogin()">Masuk Aplikasi</button>
            <a class="reset_pass" href="<?= base_url('Auth/lupa_password') ?>">Lupa Password ?</a>
          </div>

          <div class="clearfix"></div>

          <div class="clearfix"></div>
          <br />

          <div>
            <h1><i class="fa fa-desktop"></i> HRM YBM PLN</h1>
            <p>Copyright <?= date("Y") ?> &copy; All Rights Reserved.</p>
          </div>
      </div>

      </section>
    </div>


  </div>
  </div>
  <!-- jQuery -->
  <script src="<?= base_url('assets/') ?>vendors/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?= base_url('assets/') ?>vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FastClick -->
  <script src="<?= base_url('assets/') ?>vendors/fastclick/lib/fastclick.js"></script>
  <!-- NProgress -->
  <script src="<?= base_url('assets/') ?>vendors/nprogress/nprogress.js"></script>
  <!-- bootstrap-progressbar -->
  <script src="<?= base_url('assets/') ?>vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
  <!-- iCheck -->
  <script src="<?= base_url('assets/') ?>vendors/iCheck/icheck.min.js"></script>
  <!-- PNotify -->
  <script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.js"></script>
  <script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.buttons.js"></script>
  <script src="<?= base_url('assets/') ?>vendors/pnotify/dist/pnotify.nonblock.js"></script>
  <!-- Login -->
  <script>
    const base_url = "<?= base_url('') ?>";
  </script>

  <?php if ($this->session->flashdata('error')) { ?>
    <script type="text/javascript">
      new PNotify({
        text: '<?= $this->session->flashdata('error') ?>',
        type: 'error',
        styling: 'bootstrap3',
        delay: 2000,
        history: false
      })
    </script>
  <?php } else if ($this->session->flashdata('success')) { ?>
    <script type="text/javascript">
      new PNotify({
        text: '<?= $this->session->flashdata('success') ?>',
        type: 'success',
        styling: 'bootstrap3',
        delay: 2000,
        history: false
      })
    </script>
  <?php } else if ($this->session->flashdata('info')) { ?>
    <script type="text/javascript">
      new PNotify({
        text: '<?= $this->session->flashdata('info') ?>',
        type: 'success',
        styling: 'bootstrap3',
        delay: 2000,
        history: false
      })
    </script>
  <?php } ?>
  <script src="<?= base_url('assets/') ?>src/js/login.js"></script>

</body>

</html>