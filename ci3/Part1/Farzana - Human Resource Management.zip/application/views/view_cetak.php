<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Struk Gaji</title>
	<link rel="icon" type="image/png" href="<?=base_url('assets/logo_ybm.png') ?>">
	<!-- Bootstrap -->
    <link href="<?=base_url('assets/') ?>vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?=base_url('assets/') ?>vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/css">
    	.garis{
    		width: 100%;
    		height: 1.5px;
    		margin: 0px;
    		color: black;
    		background: black;
    	}
    </style>
</head>
	<body>
		<?php 
		$data = $this->db->get_where("gaji",['nomor'=>$this->uri->segment(2)])->row();
		$potongan = $this->db->like('date',date("Y-m"))->get_where("potongan",['karyawan'=>$data->karyawan])->row();
		$k = where_row("karyawan",['id'=>$data->karyawan]);
		$k2 = $this->db->select('karyawan.name as nama,unit.name as bagian,penerimaan.date as tanggal')->join('unit','penerimaan.unit=unit.id')->join('karyawan','penerimaan.karyawan=karyawan.id')->get_where("penerimaan",['penerimaan.karyawan'=>$data->karyawan])->row();
		$no = explode(" ", $data->created_at);
		$satu = str_replace(":", "", $no[1]);
		$dua = str_replace("-", "", $no[0]);
		$nomor = $satu.$dua;
		?>
	<table width="100%" style="margin:0px auto;">
		<tr>
			<td width="30%" class="align-middle text-center" ><img src="<?=base_url('assets/logo_2.png') ?>" width='100%'></td>
			<td class="align-middle text-center"><h3>YBM PLN Kantor Pusat</h3>
			<p>Jl. Trunojoyo Blok M I/135 Kebayoran Baru - Jakarta Selatan
				<br>021-7261122 ext 1574
				<br>email : ybm@pln.co.id<p></td>
		</tr>
	</table>
	<div class="garis"></div>
	<br>
	<table>
		<tr><td>Nomor</td><td>:</td><td><?=$nomor ?></td></tr>
		<tr><td>Nama</td><td>:</td><td><?=$k->name ?></td></tr>
		<tr><td>Jabatan</td><td>:</td><td><?=$k2->bagian ?></td></tr>
	</table>
	<div class="pull-right">
		<?=strtoupper(bulan(date("m",strtotime($data->date)))) ?>
	</div>
	<br><br>
	<table class="table table-bordered" width="100%">
		<thead>
			<tr>
				<th class="text-center">Penerimaan</th>
				<th class="text-center">Potongan</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td width="50%">
					<table width="100%" style="border:none;">
						<tr>
							<td style="border:none;">P1</td>
							<td style="border:none;">:</td>
							<td style="border:none;" class="text-right"><?=rupiah($data->p1) ?></td>
						</tr>
						<tr>
							<td style="border:none;">P2</td>
							<td style="border:none;">:</td>
							<td style="border:none;" class="text-right"><?=rupiah($data->p2) ?></td>
						</tr>
						<tr>
							<td style="border:none;">P3</td>
							<td style="border:none;">:</td>
							<td style="border:none;" class="text-right"><?=rupiah($data->p3) ?></td>
						</tr>
					</table>
				</td>
				<td>
					<table width="100%" style="border:none;">
						<tr>
							<td style="border:none;">Potongan DLHK</td>
							<td style="border:none;">:</td>
							<td style="border:none;" class="text-right"><?=rupiah($potongan->dplk) ?></td>
						</tr>
						<tr>
							<td style="border:none;">Tidak Masuk</td>
							<td style="border:none;">:</td>
							<td style="border:none;" class="text-right"><?=rupiah(0) ?></td>
						</tr>
						<tr>
							<td style="border:none;">Potongan</td>
							<td style="border:none;">:</td>
							<td style="border:none;" class="text-right"><?=rupiah($potongan->pot_lainnya) ?></td>
						</tr>
					</table>
				</td>
			</tr>
		</tbody>
		<tfoot>
			<tr>
				<th><table width="100%" style="border:none;">
						<tr>
							<td style="border:none;">Total Penerimaan</td>
							
							<td style="border:none;" class="text-right"><?=rupiah($data->total) ?></td>
						</tr>
					</table></th>
				<th><table width="100%" style="border:none;">
						<tr>
							<td style="border:none;">Total Potongan</td>
							
							<td style="border:none;" class="text-right"><?=rupiah($potongan->total_potongan) ?></td>
						</tr>
					</table></th>
			</tr>
		</tfoot>
	</table>
	<p>Gaji Bersih <b><?=rupiah($data->total-$potongan->total_potongan) ?></b></p>
	<table width="100%">
		<tr>
			<td width="50%" class="text-center">
				<br>
				Dibuat Oleh <br><br><br><br>
				<?=$data->pembuat ?>
			</td>
			<td class="text-center">
				Jakarta,    <?=bulan(date("m"))." ".date("Y") ?><br>
				Diterima oleh<br><br><br><br>
				<b><u><?=$k->name ?></u></b>
			</td>
		</tr>
	</table>
	
</body>
</html>