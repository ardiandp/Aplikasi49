<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>
    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-4">
      <div class="x_panel">
        <div class="x_title">
          <h2>Setting <?= $title ?></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <form data-parsley-validate method="post" action="<?= base_url('setting/save_bonus') ?>">
            <div class="form-group">
              <label for="first-name">Karyawan<span class="text-danger">*</span>
              </label>
              <select name="karyawan" class="form-control">
                <option>Pilih Karyawan</option>
                <?php foreach (show_data("karyawan") as $k) {
                  echo "<option value='" . $k->id . "'>" . $k->name . "</option>";
                } ?>
              </select>
            </div>
            <?php foreach (show_data("bonus") as $t) { ?>
              <div class="form-group">
                <label for="first-name"><?= $t->name ?><span class="text-danger">*</span>
                </label>
                <input type="text" placeholder="0" required="required" class="form-control" name="<?= strtolower($t->name) ?>" autocomplete="off">
              </div>
            <?php } ?>
            <div class="form-group">
              <button class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
            </div>
          </form>
        </div>
      </div>
      <!-- content -->
    </div>
    <div class="col-md-8">
      <div class="x_panel">
        <div class="x_title">
          <h2>Data <?= $title ?></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content table-responsive">
          <table id="datatable" class="table table-striped table-bordered" style="width:100%">
            <thead>
              <tr class="bg-dark text-white">
                <th>No</th>
                <th>Karyawan</th>
                <?php foreach ($tunjangan as $t) {
                  echo "<th>" . $t->name . "</th>";
                } ?>
              </tr>
            </thead>
            <tbody>
              <?php $no = 0;
              foreach ($data as $key) {
                $no++;
                echo "<tr>
                  <td>" . $no . "</td>
                  <td>" . $key->nama_karyawan . "</td>";
                $tnj = json_decode($key->bonus);
                foreach ($tnj as $keys => $value) {
                  if ($keys != "karyawan") {
                    echo  "<td>" . rupiah((int)$value) . "</td>";
                  }
                }
                echo "</tr>";
              } ?>
            </tbody>
          </table>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>