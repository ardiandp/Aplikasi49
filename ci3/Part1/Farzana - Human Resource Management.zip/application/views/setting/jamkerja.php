<?php if (isset($_GET['del'])) {
    $this->db->delete("jam_kerja", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data unit berhasil dihapus');
    redirect("setting/jamkerja");
} ?>


<div class="page-title">
    <div class="title_left">
        <h3>Form Setting Jam Kerja</h3>
    </div>

</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title" id="title">
                <h2>Data Jam Kerja<small></small></h2>
                <button id="showformtambah" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Tambah Jam Kerja</button>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">

                <br>
                <div id="divtambah" style="display: none;">

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Hari Awal <span class="required">*</span>
                        </label>
                        <div class="col-md-2 col-sm-2 ">
                            <select class="form-control select2" name="hari" id="hari">
                                <option value="">Pilih Hari</option>
                                <?php foreach (show_data("hariefektif") as $un) {
                                    echo "<option value='" . $un->id . "'>" . $un->nama_hari . "</option>";
                                } ?>

                            </select>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jam Masuk <span class="required">*</span>
                        </label>
                        <div class="col-md-2 col-sm-2 ">
                            <input type="time" id="jam_masuk" name="jam_masuk" required="required" class="form-control" required>
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jam Pulang<span class="required">*</span>
                        </label>
                        <div class="col-md-2 col-sm-2 ">
                            <input type="time" id="jam_pulang" name="jam_pulang" required="required" class="form-control" required>

                        </div>
                    </div>
                    <div class="item form-group">
                        <label for="toleransi" class="col-form-label col-md-3 col-sm-3 label-align">Toleransi</label>
                        <div class="col-md-3 col-sm-3 ">
                            <input id="toleransi" class="form-control" type="text" name="toleransi" required value="0">
                        </div>
                        <label for="menit" class="col-md-3 col-sm-3">*Menit</label>
                    </div>
                    <div class="item form-group" style="display: none;">
                        <label for="jam_efektif " class=" col-form-label col-md-3 col-sm-3 label-align">Jam Efektif</label>
                        <div class="col-md-3 col-sm-3 ">
                            <input id="jam_efektif" class="form-control" type="text" name="jam_efektif" required value="0">
                        </div>
                        <label for="middle-name" class=" col-md-3 col-sm-3">*Menit</label>
                    </div>
                    <div class="ln_solid"></div>
                    <div style="float: right">

                        <button class="btn-submit btn btn-primary" id="btnkembali"><i class="fa fa-reply"></i> <span name="CAPTION-SIMPAN" style="color:white;">Kembali</span></button>
                        <button class="btn-submit btn btn-success" id="btnsave"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                    </div>
                </div>
                <div id="divtablejamkerja">
                    <table class="table table-striped table-bordered table-hover" id="tablejamkerja">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Nama Hari</th>
                                <th>Jam Masuk</th>
                                <th>Jam Pulang</th>
                                <th>Toleransi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                    </table>
                </div>
            </div>


        </div>
    </div>
</div>


<?php $no = 0;
foreach ($data as $key) { ?>
    <div class="modal fade data<?= $key->id ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">-</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Apakah anda yakin akan menghapus <strong><?= $key->hari ?></strong>?</h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?del=<?= $key->id ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<div class="modal fade" id="form_edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="heditid" id="heditid">

                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Hari Awal <span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <select class="form-control select2" name="hari" id="edithari" readonly disabled>
                            <?php foreach (show_data("hariefektif") as $un) {
                                echo "<option value='" . $un->id . "'>" . $un->nama_hari . "</option>";
                            } ?>
                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jam Masuk <span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="time" id="editjam_masuk" name="jam_masuk" required="required" class="form-control" required>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Jam Pulang<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="time" id="editjam_pulang" name="jam_pulang" required="required" class="form-control" required>

                    </div>
                </div>
                <div class="item form-group">
                    <label for="toleransi" class="col-form-label col-md-3 col-sm-3 label-align">Toleransi</label>
                    <div class="col-md-6 col-sm-6 ">
                        <input id="edittoleransi" class="form-control" type="text" name="toleransi" required value="0">
                    </div>
                    <label for="menit" class="col-md-3 col-sm-3">*Menit</label>
                </div>
                <div class="item form-group" style="display: none;">
                    <label for="jam_efektif " class=" col-form-label col-md-3 col-sm-3 label-align">Jam Efektif</label>
                    <div class="col-md-6 col-sm-6 ">
                        <input id="editjam_efektif" class="form-control" type="text" name="jam_efektif" required value="0">
                    </div>
                    <label for="middle-name" class=" col-md-3 col-sm-3">*Menit</label>
                </div>
                <div class="ln_solid"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
            </div>

        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".select2").select2({
            width: "100%"
        });
        getDataJamKerja();
    })

    function getDataJamKerja() {
        $.ajax({
            type: 'GET',
            url: '<?= base_url('setting/getdatajamkerja') ?>',
            async: false,
            dataType: "JSON",
            success: function(response) {
                if (response != null) {

                    $.each(response, function(i, v) {
                        $('#tablejamkerja >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.nama_hari}</td>
                            <td>${v.jam_masuk}</td>
                            <td>${v.jam_pulang}</td>
                            <td>${v.toleransi} Menit</td>
                            <td><button id='btn_edit' onclick="editdata('${i}','${v.id_jamkerja}','${v.hari}','${v.jam_masuk}','${v.jam_pulang}','${v.toleransi}','${v.efektif}')" class='btn btn-sm btn-warning' value='${v.id}' ><i class='fa fa-edit'></i></button> 
                            <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data${v.id_jamkerja}'><i class='fa fa-trash'></i></a></td>
                        </tr>`);
                    })
                }
            }
        })
    }

    $(document).on('click', '#showformtambah', function() {
        $('#divtambah').show('FadeIn');
        $('#divtablejamkerja').hide('FadeOut');
        $('#title h2').html('Tambah Jam Kerja');
        $('#showformtambah').hide();

    })
    $(document).on('click', '#btnkembali', function() {
        $('#divtambah').hide('FadeIn');
        $('#divtablejamkerja').show('FadeOut');
        $('#title h2').html('Data Jam Kerja');
        $('#showformtambah').show();


    })


    $(document).on('click', '#btnsave', function() {

        let hari = $('#hari option:selected').val();
        let jam_masuk = $('#jam_masuk').val();
        let jam_pulang = $('#jam_pulang').val();
        let toleransi = $('#toleransi').val();
        let jam_efektif = $('#jam_efektif').val();

        if (hari == '' || jam_masuk == '' || jam_pulang == '' || toleransi == '' || jam_efektif == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }
        $.ajax({
            type: "POST",
            url: '<?= base_url('setting/cek_namajamkerja') ?>',
            dataType: "JSON",
            data: {
                like: hari
            },
            success: function(response) {
                if (response > 0) {
                    new PNotify({
                        text: 'Hari Sudah Ada, Mohon Rubah Data!',
                        type: 'warning',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    return false;
                } else {

                    $.ajax({
                        type: "POST",
                        url: '<?= base_url('setting/tambah_jamkerja'); ?>',
                        data: {
                            hari: hari,
                            jam_masuk: jam_masuk,
                            jam_pulang: jam_pulang,
                            toleransi: toleransi,
                            jam_efektif: jam_efektif
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response == 1) {
                                new PNotify
                                    ({
                                        title: 'Succes',
                                        text: "Data Berhasil Ditambah",
                                        type: "Succes",
                                        styling: 'bootstrap3',
                                        delay: 3000,
                                        // stack: stack_center
                                    });
                                setTimeout(() => window.location.reload(), 800);
                            } else {
                                new PNotify({
                                    text: 'Data Gagal disimpan!',
                                    type: 'Warning!',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 700);
                            }
                        }

                    })

                }
            }
        })
    })

    function editdata(i, id, hari, jam_masuk, jam_pulang, toleransi, efektif) {

        let value = $(this).attr('efektif');
        $('#heditid').val(id);
        $('#edithari').val(hari).change();
        $('#editjam_masuk').val(jam_masuk);
        $('#editjam_pulang').val(jam_pulang);
        $('#edittoleransi').val(toleransi);
        $('#editjam_efektif').val(efektif);

        $('#form_edit').modal('show');


    }
    $(document).on('click', '#btn_editsimpan', function() {

        $.ajax({
            type: "POST",
            url: '<?= base_url('setting/edit_jamkerja') ?>',
            dataType: "JSON",
            data: {
                id: $('#heditid').val(),
                edithari: $('#edithari option:selected').val(),
                editjam_masuk: $('#editjam_masuk').val(),
                editjam_pulang: $('#editjam_pulang').val(),
                edittoleransi: $('#edittoleransi').val(),
                editjam_efektif: $('#editjam_efektif').val()
            },
            success: function(response) {
                if (response == 1) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil Dirubah",
                            type: "Succes",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    new PNotify({
                        text: 'Data Gagal Dirubah!',
                        type: 'Warning!',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 700);
                }
            }
        })
    })
</script>