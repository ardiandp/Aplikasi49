<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?=$title ?></h3>
    </div>  
  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-4">
      <div class="x_panel">
        <div class="x_title">
          <h2>Input <?=$title ?></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <form data-parsley-validate method="post" action="<?=base_url('setting/penerimaan') ?>">
              <div class="form-group">
                <label for="first-name">Unit Kerja<span class="text-danger">*</span>
                </label>
                <select class="form-control" name="karyawan" required="required">
                  <option>Pilih Karyawan</option>
                  <?php foreach (show_data("karyawan") as $kr) {
                    echo "<option value='".$kr->id."'>".$kr->name."</option>";
                  }
                  ?>
                </select>
              </div>
              <div class="form-group">
                <label for="first-name">Unit Kerja<span class="text-danger">*</span>
                </label>
                <select class="form-control" name="unit" required="required">
                  <option>Pilih Unit Kerja</option>
                  <?php foreach (show_data("unit") as $un) {
                    echo "<option value='".$un->id."'>".$un->name."</option>";
                  }
                  ?>
                </select>
              </div>
              <div class="form-group">
                <label for="first-name">Tanggal Masuk<span class="text-danger">*</span>
                </label>
                <input type="text" placeholder="Tanggal Masuk" required="required" class="form-control" name="date" id="tgl" autocomplete="off">
              </div>
              <div class="form-group">
                <button class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
              </div>
            </form>
        </div>
      </div>
      <!-- content -->
    </div>
    <div class="col-md-8">
      <div class="x_panel">
        <div class="x_title">
          <h2>Data <?=$title ?></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <table id="datatable" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Karyawan</th>
                  <th>Unit Kerja</th>
                  <th>Tanggal Penerimaan</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=0; foreach ($data as $key) {
                  $no++;
                  echo "<tr>
                  <td>".$no."</td>
                  <td>".$key->nama_karyawan."</td>
                  <td>".$key->nama_unit."</td>
                  <td>".$key->date."</td>
                  </tr>";
                } ?>
              </tbody>
            </table>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>