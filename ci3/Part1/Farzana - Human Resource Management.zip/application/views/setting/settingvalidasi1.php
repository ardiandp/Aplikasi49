<?php if (isset($_GET['delvalidasi'])) {
    $this->db->delete("validasi", ['id' => $_GET['delvalidasi']]);
    $this->db->delete("nama_step_validasi", ['id_validasi' => $_GET['delvalidasi']]);
    $this->db->delete("validator", ['id_aktivitasvalidasi' => $_GET['delvalidasi']]);
    $this->session->set_flashdata("success", 'Data berhasil dihapus');
    redirect("setting/settingvalidasi");
} ?>
<?php if (isset($_GET['delvalidator'])) {
    $this->db->delete("validator", ['id' => $_GET['delvalidator']]);
    $this->session->set_flashdata("success", 'Data berhasil dihapus');
    redirect("setting/settingvalidasi");
} ?>
<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>

        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Setting Perusahaan</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <?php
                    if (isset($_GET['id'])) {
                        $row = where_row("karyawan", ['id' => $_GET['id']]);
                        $job = where_row("penerimaan", ['karyawan' => $_GET['id']]);
                    } ?>
                    <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link <?= (isset($_GET['step']) && $_GET['step'] == 0 ? "active" : "") ?>" data-active='active' id="perusahaan-tab" data-toggle="tab" href="#perusahaan" role="tab" aria-controls="perusahaan" aria-selected="true">Buat Validasi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= (isset($_GET['step']) && $_GET['step'] == 1 ? "active" : "") ?>" id="organisasi-tab" data-toggle="tab" href="#organisasi" role="tab" aria-controls="organisasi" aria-selected="false">Setting Validator</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 0 ? "show active" : "") ?>" id="perusahaan" role="tabpanel" aria-labelledby="perusahaan-tab">
                            <div class="table-toolbar" align="right">
                                <button class="btn btn-warning" title="Edit Profil RS" id="btn-edit"><i class="fa fa-cog pull-left"></i></button>
                            </div>
                            <div id="divtablevalidasi">
                                <table class="table table-striped table-bordered table-hover" id="tablevalidasi">
                                    <thead>
                                        <tr class="bg-dark text-white">
                                            <th>No</th>
                                            <th>Nama Aktivitas</th>
                                            <th>Jenis Cuti</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>

                                </table>
                            </div>
                            <div id="formvalidasi" style="display: none;">

                                <div class="item form-group">
                                    <label class="col-md-2">Nama Aktivitas<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <input type="text" name="nama" id="addnamavalidasi" class="form-control" autocomplete="off" placeholder="Nama Aktivitas" value="">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Jenis Validasi<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="unit" id="addjenisvalidasi">
                                            <option value="">Pilih Jenis Validasi</option>
                                            <?php foreach (show_data("jenis_validasi") as $un) {
                                                echo "<option value='" . $un->id . "'>" . $un->nama_jenis_validasi . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div style=" float: right">
                                    <button class="btn-submit btn btn-primary" id="btntambahrowstepvalidasi"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Tambah Step Validasi</span></button>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Masukkan Step Validasi</label>
                                    <div class="col-md-10">

                                    </div>
                                </div>
                                <div class="item form-group">
                                    <table class="table table-striped table-bordered table-hover" id="tablestepvalidasi">
                                        <thead>
                                            <tr class="bg-dark text-white">
                                                <th>Urutan Step Validasi </th>
                                                <th>Nama Step</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>

                                    </table>
                                </div>


                                <br>
                                <br>
                                <br>
                                <div style=" float: right">

                                    <button class="btn-submit btn btn-success" id="btnkembalivalidasi"><i class="fa fa-reply"></i> <span name="CAPTION-KEMBALI" style="color:white;">Kembali</span></button>
                                    <button class="btn-submit btn btn-primary" id="btnsavevalidasi"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                                </div>


                            </div>
                        </div>
                        <!-- Home -->
                        <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 1 ? "show active" : "") ?>" id="organisasi" role="tabpanel" aria-labelledby="organisasi-tab">
                            <div class="table-toolbar" align="right" style="display: none;">
                                <button class="btn btn-warning" title="Edit Profil RS" id="btn-editsettingvalidator"><i class="fa fa-cog pull-left"></i></button>
                            </div>
                            <div id="divtablesettingvalidator">
                                <table class="table table-striped table-bordered table-hover" id="tablesettingvalidator">
                                    <thead>
                                        <tr class="bg-dark text-white">
                                            <th>No</th>
                                            <th>Nama Atasan/validator</th>
                                            <th>Jenis Cuti</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>

                                </table>
                            </div>
                            <div id="formsettingvalidator" style="display: none;">
                                <div class="item form-group">
                                    <label class="col-md-2">Jenis Validasi<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="unit" id="jenisvalidasivalidator">
                                            <option value="">Pilih Jenis Cuti</option>
                                            <?php foreach (show_data("jenis_validasi") as $un) {
                                                echo "<option value='" . $un->id . "'>" . $un->nama_jenis_validasi . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Nama Aktivitas<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="unit" id="nmaktivitasvalidator">
                                            <option value="">Pilih Nama Aktivitas</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Step Validasi<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="unit" id="stepvalidasivalidator">
                                            <option value="">Pilih Step</option>

                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Pilih Jabatan<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="unit" id="nmjabatanvalidator">
                                            <option value="">Pilih Jabatan</option>
                                            <?php foreach (show_data("jabatan") as $un) {
                                                echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <br>
                                <br>
                                <br>
                                <div style=" float: right">

                                    <button class="btn-submit btn btn-success" id="btnkembalivalidator"><i class="fa fa-reply"></i> <span name="CAPTION-KEMBALI" style="color:white;">Kembali</span></button>
                                    <button class="btn-submit btn btn-primary" id="btnsavevalidator"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                                </div>


                            </div>
                        </div>
                        <!-- Rek -->
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>
<div class="modal fade" id="form_editvalidasi" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="idvalidasi" id="idvalidasi">

                <div class="item form-group">
                    <label class="col-md-2">Nama Aktivitas<span class="text-danger">*</span></label>
                    <div class="col-md-10">
                        <input type="text" name="nama" id="editnamavalidasi" class="form-control" autocomplete="off" placeholder="Nama Aktivitas" value="">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-md-2">Jenis Validasi<span class="text-danger">*</span></label>
                    <div class="col-md-10">
                        <select class="form-control select2" name="unit" id="editjenisvalidasi">
                            <option value="">Pilih Jenis Validasi</option>
                            <?php foreach (show_data("jenis_validasi") as $un) {
                                echo "<option value='" . $un->id . "'>" . $un->nama_jenis_validasi . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div style=" float: right">
                    <button class="btn-submit btn btn-primary" id="editbtntambahrowstepvalidasi"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Tambah Step Validasi</span></button>
                </div>
                <div class="item form-group">
                    <label class="col-md-2">Masukkan Step Validasi</label>
                    <div class="col-md-10">
                    </div>
                </div>
                <div class="item form-group">
                    <table class="table table-striped table-bordered table-hover" id="edittablestepvalidasi">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>Urutan Step Validasi </th>
                                <th>Nama Step</th>
                                <!-- <th>Aksi</th> -->
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                    </table>
                </div>

                <div class="ln_solid"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
                <button class="btn btn-primary" id="btn_close">Close</button>
            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="form_editvalidator" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">-</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="idvalidator" id="idvalidator" value="">
                <input type="hidden" name="id_aktivitas_validator" id="id_aktivitas_validator" value="">
                <div class="item form-group">
                    <label class="col-md-2">Jenis Validasi<span class="text-danger">*</span></label>
                    <div class="col-md-10">
                        <select class="form-control select2" name="validator_idjenisvalidasi" id="validator_idjenisvalidasi">
                            <option value="">Pilih Jenis Cuti</option>
                            <?php foreach (show_data("jenis_validasi") as $un) {
                                echo "<option value='" . $un->id . "'>" . $un->nama_jenis_validasi . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-md-2">Nama Aktivitas<span class="text-danger">*</span></label>
                    <div class="col-md-10">
                        <input type="text" class="form-control" name="validator_nama_aktivitas" id="validator_nama_aktivitas">
                    </div>
                </div>

                <div class="item form-group">
                    <table class="table table-striped table-bordered table-hover" id="table_validatorbyvalidasi">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>Urutan Step Validasi </th>
                                <th>Nama Step</th>
                                <th>Jabatan</th>
                                <!-- <th>Aksi</th> -->
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>

                    </table>
                </div>
                <br>
                <br>
                <br>
                <div class="ln_solid"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpanvalidator">Edit Data</button>
            </div>

        </div>
    </div>
</div>

<?php $no = 0;
foreach ($datavalidasi as $key) { ?>
    <div class="modal fade data<?= $key->id ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">-</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Pastikan anda yakin akan menghapus data <strong><?= $key->nama_aktivitas ?></strong></h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?delvalidasi=<?= $key->id ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>
<?php $no = 0;
foreach ($datavalidator as $key) { ?>
    <div class="modal fade datavalidator<?= $key->id_aktivitasvalidasi ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Pastikan anda yakin akan menghapus data </strong></h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?delvalidasi=<?= $key->id ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>


<script type="text/javascript">
    let arrtempchart = [];
    let arrinsertchart = [];
    $(document).ready(function() {
        $('.nav-tabs a[href="#perusahaan"]').tab('show');
        $(".select2").select2({
            width: "100%"
        });
        getDataValidasi();
        getDataValidator();
    })
    $(document).on("input", ".numeric", function(event) {
        this.value = this.value.replace(/[^\d.]+/g, '');
    });
    $(document).on('click', '#btntambahrowstepvalidasi', function() {

        var tab_owner = $('#tablestepvalidasi');
        var iRow = $('tbody tr:last', tab_owner).index() + 1;
        console.log(iRow);
        $('#tablestepvalidasi >tbody').append(`
        <tr id='${iRow}'>
            <td><input id="urut_${iRow}" class="form-control numeric" type="text" value='${iRow+1}' readonly disabled></td>
            <td><input id="nama_${iRow}" class="form-control" type="text"></td>
            <td><button class="btn-submit btn btn-danger HapusItemPaketAddValidasi" id="btndelete"><i class="fa fa-trash"></i> <span  style="color:white;"></span></button></td>
        </tr>
        `);

    })
    $(document).on('click', '#editbtntambahrowstepvalidasi', function() {

        var tab_owner = $('#edittablestepvalidasi');
        var iRow = $('tbody tr:last', tab_owner).index() + 1;
        console.log(iRow);
        $('#edittablestepvalidasi >tbody').append(`
        <tr id='${iRow}'>
            <td><input id="editurut_${iRow}" class="form-control numeric" type="text" value='${iRow+1}' readonly disabled></td>
            <td><input id="editnama_${iRow}" class="form-control" type="text"></td>
            <td><button class="btn-submit btn btn-danger HapusItemPaketAddValidasi" id="btndelete"><i class="fa fa-trash"></i> <span  style="color:white;"></span></button></td>
        </tr>
        `);

    })
    $(document).on('click', '.HapusItemPaketAddValidasi', function() {
        $(this).parent().parent().remove();
        $("#tablestepvalidasi tbody tr").each(function(i, v) {
            let sku = $(this).find("td:eq(0) input[type='text']")
            let qty = $(this).find("td:eq(1) input[type='text']")

            sku.attr('id', `urut_${i}`)
            qty.attr('id', `nama_${i}`)
            sku.val(`${i+ 1}`)

        });

    });
    $(document).on('click', '.HapusItemPaketEditValidasi', function() {
        $(this).parent().parent().remove();
        $("#edittablestepvalidasi tbody tr").each(function(i, v) {
            let sku = $(this).find("td:eq(0) input[type='text']")
            let qty = $(this).find("td:eq(1) input[type='text']")

            sku.attr('id', `editurut_${i}`)
            qty.attr('id', `editnama_${i}`)
            sku.val(`${i+ 1}`)

        });

    });

    $('#jenisvalidasivalidator').change(function() {
        let value = $(this).val();

        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getdataaktivitasbyidjenis') ?>',

            data: {
                id: value
            },
            dataType: "JSON",
            success: function(response) {
                $('#nmaktivitasvalidator').empty();
                $("#nmaktivitasvalidator").append('<option value="">Pilih Nama Aktivitas</option>');
                $.each(response, function(i, c) {

                    $("#nmaktivitasvalidator").append('<option value="' + c.id + '">' + c.nama_aktivitas + '</option>');
                })
            }
        })
    })
    $('#nmaktivitasvalidator').change(function() {
        let value = $(this).val();

        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getdatastepbyidaktivitas') ?>',
            data: {
                id: value
            },
            dataType: "JSON",
            success: function(response) {

                $.each(response, function(i, c) {
                    $("#stepvalidasivalidator").append('<option value="' + c.id + '">' + c.nama_step + '</option>');
                })
            }
        })
    })


    function editdata(i, id, hari, jam_masuk, jam_pulang, toleransi, efektif) {
        let value = $(this).attr('efektif');

        $('#edithari').val(hari).change();
        $('#editjam_masuk').val(jam_masuk);
        $('#editjam_pulang').val(jam_pulang);
        $('#edittoleransi').val(toleransi);
        $('#editjam_efektif').val(efektif);
        $('#form_editvalidator').modal('show');
    }

    function getDataValidasi() {
        $.ajax({
            type: 'GET',
            url: '<?= base_url('setting/getdataaktivitas') ?>',
            async: false,
            dataType: "JSON",
            success: function(response) {
                if (response != null) {
                    $.each(response, function(i, v) {
                        $('#tablevalidasi >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.nama_aktivitas}</td>
                            <td>${v.nama_jenis_validasi}</td>
                            <td><button id='btn_viewvalidasi' onclick="viewdatavalidasi('${i}','${v.id_val}','${v.id_jenis}','${v.nama_aktivitas}')" class='btn btn-sm btn-primary' value='${v.id}' ><i class='fa fa-eye'></i></button>
                            <button id='btn_editvalidasi' onclick="editdatavalidasi('${i}','${v.id_val}','${v.id_jenis}','${v.nama_aktivitas}')" class='btn btn-sm btn-warning' value='${v.id}' ><i class='fa fa-pencil'></i></button>&nbsp;
                            <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data${v.id_val}'><i class='fa fa-trash'></i> </a>
                            </td>
                        </tr>`);
                    })
                }
            }
        })
    }

    function getDataValidator() {

        $.ajax({
            type: 'GET',
            url: '<?= base_url('setting/getdataaktivitas') ?>',
            async: false,
            dataType: "JSON",
            success: function(response) {
                if (response != null) {

                    $.each(response, function(i, v) {
                        $('#tablesettingvalidator >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.nama_aktivitas}</td>
                            <td>${v.nama_jenis_validasi}</td>
                            <td><button id='btnaddvalidator' onclick="addvalidator('${i}','${v.id_val}','${v.id_jenis}','${v.nama_aktivitas}')" class='btn btn-sm btn-primary' value='${v.id}' ><i class='fa fa-cog'></i></button>
                            <button id='btn_viewvalidasi' onclick="viewaddvalidator('${i}','${v.id_val}','${v.id_jenis}','${v.nama_aktivitas}')" class='btn btn-sm btn-primary' value='${v.id}' ><i class='fa fa-eye'></i></button>
                            <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.datavalidator${v.id_val}'><i class='fa fa-trash'></i> </a>
                            </td>
                        </tr>`);
                    })
                }
            }
        })
    }

    function addvalidator(i, id, id_jenis, nama_aktivitas) {
        let arrJabatanid = [];
        $('#id_aktivitas_validator').val(id);
        $('#validator_idjenisvalidasi').val(id_jenis).change();
        $('#validator_idjenisvalidasi').prop('disabled', true);
        $('#validator_idjenisvalidasi').prop('readonly', true);
        $('#validator_nama_aktivitas').prop('readonly', true);
        $('#validator_nama_aktivitas').val(nama_aktivitas);
        $('#btn_editsimpanvalidator').show();
        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getdetailnamastepjabatanbyidvalidasi') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                $('#table_validatorbyvalidasi >tbody').empty()
                if (response != null) {
                    $.each(response, function(i, v) {

                        $('#table_validatorbyvalidasi > tbody').append(`<tr id='${i}'>
                            <td width='10%'><input id="editurut_${i}" class="form-control numeric" type="text" value='${i+1}' readonly disabled></td>
                            <td><input id="editnama_${i}" class="form-control" disabled readonly type="text" value='${v.nama_step}'></td>
                            <td><select class="form-control select2 validator_nmjabatan" name="unit" id="validator_nmjabatan_${i}">
                                <option value="">Pilih Jabatan</option>
                                </select></td>
                            <td style='display:none;'><button class="btn-submit btn btn-danger HapusItemPaketEditValidasi" id="btndelete"><i class="fa fa-trash"></i> <span  style="color:white;"></span></button></td>
                        </tr>`);
                    })
                }
            }
        })

        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getvalidatorbyid') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                if (response != null) {
                    $.each(response, function(i, v) {
                        arrJabatanid.push(v.id_jabatan);
                    })
                } else {
                    arrJabatanid = [];
                }
            }
        })
        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getjabatanbyvalidator') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                let str = '';
                $.each(response, function(i, all) {
                    $(`.validator_nmjabatan`).append('<option value="' + all.id + '" data-name="' + all.name + '">' + all.name + '</option>');
                });
            }
        })
        var lcb = $(".validator_nmjabatan").length;


        for (i = 0; i < lcb; i++) {
            $(".validator_nmjabatan").eq(i).val(arrJabatanid[i]).trigger('change.select2');
        }
        $('#form_editvalidator').modal('show');
    }

    function viewaddvalidator(i, id, id_jenis, nama_aktivitas) {
        let arrJabatanid = [];
        $('#id_aktivitas_validator').val(id);
        $('#validator_idjenisvalidasi').val(id_jenis).change();
        $('#validator_idjenisvalidasi').prop('disabled', true);
        $('#validator_idjenisvalidasi').prop('readonly', true);
        $('#validator_nama_aktivitas').prop('readonly', true);
        $('#validator_nama_aktivitas').val(nama_aktivitas);
        $('#btn_editsimpanvalidator').hide();

        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getdetailnamastepjabatanbyidvalidasi') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                $('#table_validatorbyvalidasi >tbody').empty()
                if (response != null) {
                    $.each(response, function(i, v) {

                        $('#table_validatorbyvalidasi > tbody').append(`<tr id='${i}'>
                            <td width='10%'><input id="editurut_${i}" class="form-control numeric" type="text" value='${i+1}' readonly disabled></td>
                            <td><input id="editnama_${i}" class="form-control" disabled readonly type="text" value='${v.nama_step}' disabled readonly></td>
                            <td><select class="form-control select2 validator_nmjabatan" name="unit" id="validator_nmjabatan_${i}" disabled readonly>
                                <option value="">Pilih Jabatan</option>
                                </select></td>
                            <td style='display:none;'><button class="btn-submit btn btn-danger HapusItemPaketEditValidasi" id="btndelete"><i class="fa fa-trash"></i> <span  style="color:white;"></span></button></td>
                        </tr>`);
                    })
                }
            }
        })

        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getvalidatorbyid') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                if (response != null) {
                    $.each(response, function(i, v) {
                        arrJabatanid.push(v.id_jabatan);
                    })
                } else {
                    arrJabatanid = [];
                }
            }
        })

        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getalljabatan') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                let str = '';
                $.each(response, function(i, all) {
                    $(`.validator_nmjabatan`).append('<option value="' + all.id + '" data-name="' + all.name + '">' + all.name + '</option>');
                });
            }
        })

        var lcb = $(".validator_nmjabatan").length;


        for (i = 0; i < lcb; i++) {
            $(".validator_nmjabatan").eq(i).val(arrJabatanid[i]).trigger('change.select2');
        }
        $('#form_editvalidator').modal('show');
    }

    function viewdatavalidasi(i, id, idjenis, nama_aktivitas) {
        $('#btn_editsimpan').hide();
        $('#edittablestepvalidasi >tbody').empty();

        $('#editnamavalidasi').val(nama_aktivitas);
        $('#editjenisvalidasi').val(idjenis).change();
        $('#editnamavalidasi').prop('disabled', true);
        $('#editjenisvalidasi').prop('disabled', true);
        $('#editjenisvalidasi').prop('readonly', true);
        $('#editbtntambahrowstepvalidasi').hide();

        $('edittablestepvalidasi');
        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getdetailnamastepbyidvalidasi') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                if (response != null) {
                    $.each(response, function(i, v) {
                        $('#edittablestepvalidasi > tbody').append(`<tr id='${i}'>
                            <td><input id="editurut_${i}" class="form-control numeric" type="text" value='${i+1}' readonly disabled></td>
                            <td><input id="editnama_${i}" class="form-control" disabled readonly type="text" value='${v.nama_step}'></td>
                            <td style='display:none;'><button class="btn-submit btn btn-danger HapusItemPaketEditValidasi" id="btndelete"><i class="fa fa-trash"></i> <span  style="color:white;"></span></button></td>
                        </tr>`);
                    })
                }
            }
        })
        $('#form_editvalidasi').modal('show');

    }
    $('#btn_close').click(function() {
        $('#form_editvalidasi').modal('hide');
    })

    function editdatavalidasi(i, id, idjenis, nama_aktivitas) {
        $('#btn_editsimpan').show();
        $('#idvalidasi').val(id);
        $('#editbtntambahrowstepvalidasi').show();
        $('#editnamavalidasi').val(nama_aktivitas);
        $('#editjenisvalidasi').val(idjenis).change();
        $('#edittablestepvalidasi >tbody').empty();

        $.ajax({
            type: 'POST',
            url: '<?= base_url('setting/getdetailnamastepbyidvalidasi') ?>',
            async: false,
            data: {
                id: id
            },
            dataType: "JSON",
            success: function(response) {
                if (response != null) {
                    $.each(response, function(i, v) {
                        $('#edittablestepvalidasi > tbody').append(`<tr id='${i}'>
                            <td><input id="editurut_${i}" class="form-control numeric" type="text" value='${i+1}' readonly disabled></td>
                            <td><input id="editnama_${i}" class="form-control" type="text" value='${v.nama_step}'></td>
                            <td><button class="btn-submit btn btn-danger HapusItemPaketEditValidasi" id="btndelete"><i class="fa fa-trash"></i> <span  style="color:white;"></span></button></td>
                        </tr>`);
                    })
                }
            }
        })
        $('#form_editvalidasi').modal('show');
    }
    $('#btn_editsimpan').click(function() {
        let idx = 0;
        let arr_chk = [];
        let issErr = 0;


        $("#edittablestepvalidasi > tbody tr").each(function() {

            let urut = $("#editurut_" + idx).val();
            let nm = $("#editnama_" + idx).val();

            if (nm == '') {
                var msg = 'Mohon Isi Nama Step.';
                var msgtype = 'Warning';
                //if (!window.__cfRLUnblockHandlers) return false;
                new PNotify
                    ({
                        title: 'Gagal',
                        text: msg,
                        type: msgtype,
                        styling: 'bootstrap3',
                        delay: 3000,
                        stack: stack_center
                    });
                issErr = 1;
                return false;
            }
            if (issErr != 1) {
                issErr = 0;
                arr_chk.push({
                    urut: urut,
                    nama_step: nm,
                });
            }
            idx++;
        })

        console.log(arr_chk);
        if ($('#editnamavalidasi').val() == '' || $('#editjenisvalidasi').val() == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }

        $.ajax({
            type: "POST",
            data: {
                id: $('#idvalidasi').val(),
                nama_aktivitas: $('#editnamavalidasi').val(),
                jenis_validasi: $('#editjenisvalidasi').val(),
                detail: arr_chk,
            },
            url: "<?= base_url('setting/edit_aktivitas'); ?>",
            dataType: "JSON",
            success: function(response) {
                if (response == 1) {
                    new PNotify({
                        text: 'Succes!',
                        type: 'Succes',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 800);
                    return false;
                } else {
                    if (response) {
                        new PNotify({
                            text: 'Gagal!',
                            type: 'Error',
                            styling: 'bootstrap3',
                            delay: 3000,
                            history: false
                        })
                        setTimeout(() => window.location.reload(), 800);
                        return false;
                    }
                }

            }

        })

    })
    $('#btn_editsimpanvalidator').click(function() {
        let idx = 0;
        let arr_chk = [];
        let issErr = 0;


        $("#table_validatorbyvalidasi > tbody tr").each(function() {

            let urut = $("#editurut_" + idx).val();
            let nm = $("#editnama_" + idx).val();
            let vnm = $("#validator_nmjabatan_" + idx).val();

            if (nm == '') {
                var msg = 'Mohon Isi Nama Step.';
                var msgtype = 'Warning';
                //if (!window.__cfRLUnblockHandlers) return false;
                new PNotify
                    ({
                        title: 'Gagal',
                        text: msg,
                        type: msgtype,
                        styling: 'bootstrap3',
                        delay: 3000,
                        stack: stack_center
                    });
                issErr = 1;
                return false;
            }
            if (issErr != 1) {
                issErr = 0;
                arr_chk.push({
                    urut: urut,
                    nama_step: nm,
                    id_jabatan: vnm,
                });
            }
            idx++;
        })

        console.log(arr_chk);
        // return false;


        $.ajax({
            type: "POST",
            data: {
                id_jenis_validasi: $('#validator_idjenisvalidasi').val(),
                id_aktivitas: $('#id_aktivitas_validator').val(),
                detail: arr_chk,
            },
            url: "<?= base_url('setting/edit_validator'); ?>",
            dataType: "JSON",
            success: function(response) {
                if (response == 1) {
                    new PNotify({
                        text: 'Succes!',
                        type: 'Succes',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 800);
                    return false;
                } else {
                    if (response) {
                        new PNotify({
                            text: 'Gagal!',
                            type: 'Error',
                            styling: 'bootstrap3',
                            delay: 3000,
                            history: false
                        })
                        setTimeout(() => window.location.reload(), 800);
                        return false;
                    }
                }

            }

        })

    })


    $(document).on('click', '#btn-get', function() {
        for (let index = 0; index < arrtempchart.length; index++) {
            console.log(chart.get(index + 1));
        }
        // return false;
        $('#tableorganisasi').hide('FadeIn');
        $('#formorganisasi').show('FadeIn');
    })

    /////////////////////////////// 
    $(document).on('click', '#btn-edit', function() {
        $("#divtablevalidasi").hide("fadeOut");
        // $("#formeditperusahaan").fadeOut();
        $("#formvalidasi").show("fadeIn");

    })
    $(document).on('click', '#btn-editsettingvalidator', function() {
        $("#divtablesettingvalidator").hide("fadeOut");

        // $("#formeditperusahaan").fadeOut();
        $("#formsettingvalidator").show("fadeIn");

    })
    $(document).on('click', '#btnkembalivalidasi', function() {
        $("#divtablevalidasi").show("fadeOut");
        // $("#formeditperusahaan").fadeOut();
        $("#formvalidasi").hide("fadeIn");

    })
    $(document).on('click', '#btnkembalivalidator', function() {
        $("#divtablesettingvalidator").show("fadeOut");
        // $("#formeditperusahaan").fadeOut();
        $("#formsettingvalidator").hide("fadeIn");

    })

    $(document).on('click', '#btnsavevalidasi', function() {

        let idx = 0;
        let arr_chk = [];
        let issErr = 0;


        $("#tablestepvalidasi > tbody tr").each(function() {

            let urut = $("#urut_" + idx).val();
            let nm = $("#nama_" + idx).val();

            if (nm == '') {
                var msg = 'Mohon Isi Nama Step.';
                var msgtype = 'Warning';
                //if (!window.__cfRLUnblockHandlers) return false;
                new PNotify
                    ({
                        title: 'Gagal',
                        text: msg,
                        type: msgtype,
                        styling: 'bootstrap3',
                        delay: 3000,
                        stack: stack_center
                    });
                issErr = 1;
                return false;
            }
            if (issErr != 1) {
                issErr = 0;
                arr_chk.push({
                    urut: urut,
                    nama_step: nm,
                });
            }
            idx++;
        })

        if ($('#addnamavalidasi').val() == '' || $('#addjenisvalidasi').val() == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }

        $.ajax({
            type: "POST",
            data: {
                nama_aktivitas: $('#addnamavalidasi').val(),
                jenis_validasi: $('#addjenisvalidasi').val(),
                detail: arr_chk,
            },
            url: "<?= base_url('setting/tambah_aktivitas'); ?>",
            dataType: "JSON",
            success: function(response) {
                if (response == 1) {
                    new PNotify({
                        text: 'Succes!',
                        type: 'Succes',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 800);
                    return false;
                } else {
                    if (response) {
                        new PNotify({
                            text: 'Gagal!',
                            type: 'Error',
                            styling: 'bootstrap3',
                            delay: 3000,
                            history: false
                        })
                        setTimeout(() => window.location.reload(), 800);
                        return false;
                    }
                }

            }

        })
    })

    $(document).on('click', '#btnsavevalidator', function() {
        let nmaktivitasvalidator = $("#nmaktivitasvalidator option:selected").val();
        let jenisvalidasivalidator = $("#jenisvalidasivalidator option:selected").val()
        let stepvalidasivalidator = $("#stepvalidasivalidator option:selected").val();
        let nmjabatanvalidator = $("#nmjabatanvalidator option:selected").val();
        console.log(nmaktivitasvalidator);
        return false;

        if (nmaktivitasvalidator == '' || jenisvalidasivalidator == '' || stepvalidasivalidator == '' || nmjabatanvalidator == '') {
            new PNotify({
                text: 'Mohon Lengkapi Data!',
                type: 'error',
                styling: 'bootstrap3',
                delay: 3000,
                history: false
            })
            return false;
        }

        $.ajax({
            type: "POST",
            data: ({
                nmatasansv: nmatasansv,
                jenisvalidasisv: jenisvalidasisv,
                stepvalidasisv: stepvalidasisv
            }),
            async: false,
            dataType: "JSON",
            url: '<?= base_url('setting/tambahvalidator') ?>',
            success: function(response) {
                console.log(response);
                if (response == true) {
                    new PNotify({
                        text: 'Succes!',
                        type: 'success',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    setTimeout(() => window.location.reload(), 800);
                    return false;
                } else {
                    if (response) {
                        new PNotify({
                            text: 'Gagal!',
                            type: 'error',
                            styling: 'bootstrap3',
                            delay: 3000,
                            history: false
                        })
                        setTimeout(() => window.location.reload(), 800);
                        return false;
                    }
                }

            }
        })
    })
</script>