<div class="">
    <div class="page-title">
        <div class="title_left">
            <h4><?= $title ?></h4>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-4">
            <div class="x_panel">
                <div class="x_title">
                    <h3>Tambah Banner</h3>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form data-parsley-validate method="post" action="<?= base_url('setting/save_banner') ?>" enctype="multipart/form-data">
                        <?php if (isset($_GET['del'])) {
                            $this->db->delete("banner", ['id' => $_GET['del']]);
                            $this->session->set_flashdata("success", 'Data Banner berhasil dihapus');
                            redirect("master/grade");
                        } ?>

                        <!-- <div class="form-group">
                            <label for="first-name">Nama Banner<span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="namabanner" id="namabanner">
                        </div> -->
                        <div class="form-group">
                            <label for="first-name">*Upload Foto<span class="text-danger">*</span>
                            </label>
                            <input type="file" placeholder="Klik disini" required="required" class="form-control" name="imgfoto" autocomplete="off">
                        </div>

                        <div class="form-group">
                            <button class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- content -->
        </div>
        <div class="col-md-8">
            <div class="x_panel">
                <div class="x_title">
                    <h3>Data <?= $title ?></h3>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Img Url</th>
                                <th>Tgl Created</th>
                                <th>Update At</th>
                                <th>Update At</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php foreach ($data as $i => $key) : ?>

                                <tr>
                                    <td>
                                        <?= $i + 1 ?></td>
                                    <td>
                                        <?= $key->img_url ?>
                                    </td>
                                    <td>
                                        <?= date('d-m-Y', strtotime($key->created_at)) ?>
                                    </td>
                                    <td>
                                        <?= date('d-m-Y', strtotime($key->update_at)) ?>
                                    </td>
                                    <td><img class="img-fluid img-responsive" src="<?= base_url('assets/upload/banner/' . $key->img_url) ?>"></td>
                                    <td><button onclick="EditBanner('<?= $key->img_url ?>','<?= $key->id ?>')" class='btn btn-warning'>Edit</button><br><button onclick="HapusBanner('<?= $key->img_url ?>','<?= $key->id ?>')" class='btn btn-danger'>Hapus</button></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<div class="modal fade" id="modal-editbanner" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" style="width: 80%;">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h4 class="modal-title" style="color:black;"><label name="CAPTION-CARI">Edit</label>
                    <label>Supplier</label>
                </h4>
            </div>
            <div class="modal-body">
                <div class="x_content">
                    <form data-parsley-validate method="post" action="<?= base_url('setting/edit_banner') ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <input type="hidden" name="hidbanner" value="">
                            <label for="first-name">*Upload Foto<span class="text-danger">*</span>
                            </label>
                            <input type="file" name="imgfotoupdate" id="imgfotoupdate" class="form-control" onchange="previewFile(this)" accept="image/jpeg, image/jpg, image/png, image/gif, image/JPG, image/JPEG, image/GIF">
                        </div>
                        <div class="bannerimg form-group text-center">
                        </div>
                </div>

                <div class="modal-footer">
                    <div class="form-group">
                        <button class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                    </div>
                    <div class="form-group">
                        <button type="button" data-dismiss="modal" class="btn btn-danger"><span name="CAPTION-CLOSE">Tutup</span></button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade data" id="modal-deletebanner" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <h6>Pastikan anda yakin akan menghapus data Banner <span id="span_delbanner"><strong></strong></span>
                </h6>
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger" href="?del=<?= $key->id ?>">Hapus Data</a>
            </div>

        </div>
    </div>
</div>

<script>
    function EditBanner(namafoto, id) {
        $("input[name='hidbanner']").val(id);
        $("#modal-editbanner").modal('show');
        $(".bannerimg").append(`<img class="img - fluid img - responsive " width="
            200 " src="
            <?= base_url('assets/upload/banner/') ?>${namafoto}">`)
    }

    function previewFile(e) {

        const file = e.files[0];
        const reader = new FileReader();

        $('.bannerimg').empty()
        reader.addEventListener("load", function() {
            let result = reader.result;
            console.log(result);

            $('.bannerimg').append(`
        <img class=" img - fluid img - responsive " width="
            200 " src="${result}">
        `);
            // preview.src = reader.result;
        }, false);

        if (file) {
            reader.readAsDataURL(file);
        }
    }

    function HapusBanner(namafoto, id) {
        $("#span_delbanner").text(namafoto);
        $("#modal-deletebanner").modal("show");



    }
</script>