<?php if (isset($_GET['del'])) {
    $this->db->delete("libur", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data berhasil dihapus');
    redirect("setting/libur");
} ?>

<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>

        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row" id="divformview">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Libur</h2>
                    <button id="btn_add" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Tambah Libur</button>


                    <div class="clearfix"></div>
                </div>
                <div class="x_content table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Tanggal libur</th>
                                <th>Keterangan</th>
                                <th>Terakhir di Update</th>
                                <th>Dibuat Oleh</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0;
                            foreach ($data as $key) {
                                $no++;
                                echo "<tr>
                                <td>" . $no . "</td>
                                <td>" . date('d-m-Y', strtotime($key->tgl_libur)) . "</td>
                                <td>" . $key->keterangan . "</td>
                                <td>" . date('d-m-Y', strtotime($key->update_at)) . "</td>
                                <td>" . $key->create_who . "</td>
                                <td><button id='btn_edit' class='btn btn-sm btn-warning' value='$key->id' data-kode='$key->keterangan' data-tgl='$key->tgl_libur'><i class='fa fa-edit'></i></button> <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data" . $key->id . "'><i class='fa fa-trash'></i></a></td>
                                </tr>";
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
    <div class="row" style="display: none;" id="divforminsert">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Libur</h2>

                    <div class="clearfix"></div>
                </div>
                <div class="x_content ">

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Tanggal<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="date" id="tanggallibur" required="required" class="form-control " value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                    <div class=" item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Keterangan<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="text" id="keterangan" required="required" class="form-control ">
                        </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                        <div class="col-md-6 col-sm-6 offset-md-3">
                            <button class="btn btn-primary" id="btn_cancel" type="button">Cancel</button>
                            <button type="submit" id="btn_savelibur" class="btn btn-success pull-right">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<?php $no = 0;
foreach ($data as $key) { ?>
    <div class="modal fade data<?= $key->id ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Apakah anda yakin akan menghapus <strong><?= $key->tgl_libur ?></strong>?</h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?del=<?= $key->id ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<div class="modal fade" id="form_edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Ã—</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Tanggal Libur<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="hidden" id="heditid" class="form-control ">
                        <input type="date" id="edittgllibur" required="required" class="form-control ">
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Keterangan<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="hidden" id="heditid" class="form-control ">
                        <input type="text" id="editketerangan" required="required" class="form-control ">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
            </div>

        </div>
    </div>
</div>


<script>
    $(document).ready(function() {

    })
    $("#btn_add").click(function() {
        $("#divformview").hide("FadeIn");
        $("#divforminsert").show("FadeOut");
    })
    $("#btn_cancel").click(function() {
        $("#divformview").show("FadeIn");
        $("#divforminsert").hide("FadeOut");
    })

    $(document).on('click', '#btn_savelibur', function() {
        let jenis_cuti = $('#tanggallibur').val();
        if (jenis_cuti == '') {
            new PNotify({
                text: 'Mohon Isi data Terlebih Dahulu!',
                type: 'error',
                styling: 'bootstrap3',
                delay: 3000,
                history: false
            })
            return false;
        }
        $.ajax({
            type: "POST",
            url: '<?= base_url('master/cek_tgllibur') ?>',
            dataType: "JSON",
            data: {

                like: $('#tanggallibur').val()
            },
            success: function(response) {
                if (response > 0) {
                    new PNotify({
                        text: 'Tanggal Sudah Ada, Mohon Ganti Tanggal libur!',
                        type: 'warning',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    return false;
                } else {
                    $.ajax({
                        type: "POST",
                        url: '<?= base_url('master/tambah_libur') ?>',
                        dataType: "JSON",
                        data: {
                            tgllibur: $('#tanggallibur').val(),
                            keterangan: $('#keterangan').val()
                        },
                        success: function(response) {
                            if (response == 1) {
                                new PNotify({
                                    text: 'Data Telah disimpan!',
                                    type: 'succes',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 700);
                            } else {
                                new PNotify({
                                    text: 'Data Gagal disimpan!',
                                    type: 'Warning!',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 700);
                            }
                        }
                    })
                }
            }
        })

    })
    $(document).on('click', '#btn_edit', function() {
        let id = $(this).val();
        let value = $(this).attr('data-kode');
        let valuetgl = $(this).attr('data-tgl');
        console.log(valuetgl, value);
        $('#edittgllibur').val(valuetgl.split(' ')[0]);
        $('#editketerangan').val(value);
        $('#heditid').val(id);
        $('#form_edit').modal('show');
    })
    $(document).on('click', '#btn_editsimpan', function() {
        let jenis_cuti = $('#tanggallibur').val();
        if (jenis_cuti == '') {
            new PNotify({
                text: 'Mohon Isi data Terlebih Dahulu!',
                type: 'error',
                styling: 'bootstrap3',
                delay: 3000,
                history: false
            })
            return false;
        }
        $.ajax({
            type: "POST",
            url: '<?= base_url('master/cek_tgllibur') ?>',
            dataType: "JSON",
            data: {
                id: $('#heditid').val(),
                like: $('#edittgllibur').val()
            },
            success: function(response) {
                if (response > 0) {
                    new PNotify({
                        text: 'Tanggal Sudah Ada, Anda Yakin Tanggal Sudah Benar!',
                        type: 'warning',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    //return false;
                } else {
                    $.ajax({
                        type: "POST",
                        url: '<?= base_url('master/edit_libur') ?>',
                        dataType: "JSON",
                        data: {
                            id: $('#heditid').val(),
                            tgllibur: $('#edittgllibur').val(),
                            keterangan: $('#editketerangan').val()
                        },
                        success: function(response) {
                            if (response == 1) {
                                new PNotify({
                                    text: 'Data Telah disimpan!',
                                    type: 'succes',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 700);
                            } else {
                                new PNotify({
                                    text: 'Data Gagal disimpan!',
                                    type: 'Warning!',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 700);
                            }
                        }
                    })
                }
            }
        })

    })
</script>