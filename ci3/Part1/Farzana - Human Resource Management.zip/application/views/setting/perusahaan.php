<?php if (isset($_GET['del'])) {
    $this->db->delete("karyawan", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data karyawan berhasil dihapus');
    redirect("master/karyawan");
} ?>
<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>

        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Setting Perusahaan</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <?php
                    if (isset($_GET['id'])) {
                        $row = where_row("karyawan", ['id' => $_GET['id']]);
                        $job = where_row("penerimaan", ['karyawan' => $_GET['id']]);
                    } ?>
                    <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link <?= (isset($_GET['step']) && $_GET['step'] == 0 ? "active" : "") ?>" data-active='active' id="perusahaan-tab" data-toggle="tab" href="#perusahaan" role="tab" aria-controls="perusahaan" aria-selected="true">Perusahaan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= (isset($_GET['step']) && $_GET['step'] == 1 ? "active" : "") ?>" id="organisasi-tab" data-toggle="tab" href="#organisasi" role="tab" aria-controls="organisasi" aria-selected="false">Organisasi</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 0 ? "show active" : "") ?>" id="perusahaan" role="tabpanel" aria-labelledby="perusahaan-tab">
                            <div class="table-toolbar" align="right">
                                <button class="btn btn-warning" title="Edit Profil RS" id="btn-edit"><i class="fa fa-cog pull-left"></i></button>
                            </div>
                            <div id="tableperusahaan">
                                <table class="table table-striped table-bordered table-hover">

                                    <tr>
                                        <td width="20%">Nama Perusahaan</td>
                                        <td width="2%">:</td>
                                        <td><?php if (isset($perusahaan->nama)) echo $perusahaan->nama ?></td>
                                    </tr>
                                    <tr>
                                        <td>Alamat Perusahaan</td>
                                        <td>:</td>
                                        <td><?php if (isset($perusahaan->alamat)) echo $perusahaan->alamat ?></td>
                                        <!-- <td><?php echo date('d-m-Y', strtotime($data['hsp_tglreg'])); ?></td> -->
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td>:</td>
                                        <td><?php if (isset($perusahaan->email)) echo $perusahaan->email ?></td>
                                    </tr>
                                    <tr>
                                        <td>Telepon</td>
                                        <td>:</td>
                                        <td><?php if (isset($perusahaan->no_hp)) echo $perusahaan->no_hp ?></td>
                                    </tr>
                                    <!-- <tr>
                                        <td>Luas Perusahaan</td>
                                        <td>:</td>
                                        <td><?php echo "-" ?></td>
                                    </tr> -->
                                    <!-- <tr>
                                        <td>Nama Direktur Perusahaan</td>
                                        <td>:</td>
                                        <td><?php echo "-" ?></td>

                                    </tr> -->
                                    <tr>
                                        <td>Nama Cabang Yang Di Miliki*</td>
                                        <td>:</td>
                                        <td><?php foreach (show_data_order_by("tipe", "unit") as $value) { ?>
                                                <?= $value->name ?><br>
                                            <?php } ?>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>Logo Perusahaan</td>
                                        <td>:</td>
                                        <td><img class="img-fluid img-responsive " width="200" src="<?= isset($perusahaan->logo) ? base_url('assets/upload/' . $perusahaan->logo) : "" ?>"></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>

                                    <!-- <tr>
                                        <td>Alamat Lokasi RS</td>
                                        <td>:</td>
                                        <td><?php if (!empty($data['hsp_address'])) echo $data['hsp_address'];
                                            echo ' Kecamatan ';
                                            if (!empty($data['hsp_district'])) echo $data['hsp_district'];
                                            echo ' Kabupaten ';
                                            if (!empty($data['hsp_city'])) echo $data['hsp_city'];
                                            echo ' Provinsi ';
                                            if (!empty($data['hsp_prov'])) echo $data['hsp_prov']; ?></td>
                                    </tr> -->

                                </table>
                            </div>
                            <div id="formeditperusahaan" style="display: none;">
                                <form action=""></form>

                                <input type="hidden" name="id" id="id" value="<?= isset($perusahaan->id) ? $perusahaan->id : "" ?>">
                                <div class="item form-group">
                                    <label class="col-md-2">Nama Perusahaan<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <input type="text" name="nama" id="nama" class="form-control" autocomplete="off" placeholder="Nama Perusahaan" value="<?= (isset($perusahaan->nama) ? $perusahaan->nama : "") ?>">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Alamat Perusahaan<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <input type="textarea" name="alamat" id="alamat" class="form-control" autocomplete="off" placeholder="Alamat Perusahaan" value="<?= (isset($perusahaan->alamat) ? $perusahaan->alamat : "") ?>">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Email <span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <input type="text" name="email" id="email" value="<?= (isset($perusahaan->email) ? $perusahaan->email : "") ?>" class="form-control" autocomplete="off" placeholder="Email">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Telepon<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <input type="text" name="telepon" id="telepon" value="<?= (isset($perusahaan->no_hp) ? $perusahaan->no_hp : "") ?>" class="form-control" autocomplete="off" placeholder="Telepon">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Logo<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <div class="perusahaanimg form-group text-center">
                                            <img class="img-fluid img-responsive " width="200" src="<?= isset($perusahaan->logo) ? base_url('assets/upload/' . $perusahaan->logo) : ""  ?>">
                                        </div>
                                        <input type="file" name="imgfotoupdate" id="imgfotoupdate" class="form-control" onchange="previewFile(this)" accept="image/jpeg, image/jpg, image/png, image/gif, image/JPG, image/JPEG, image/GIF">
                                    </div>
                                </div>

                                <br>
                                <br>
                                <br>
                                <div style="float: right">

                                    <button class="btn-submit btn btn-success" id="btnkembalipt"><i class="fa fa-reply"></i> <span name="CAPTION-KEMBALI" style="color:white;">Kembali</span></button>
                                    <button class="btn-submit btn btn-primary" id="btnsavepr"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                                </div>


                            </div>
                        </div>
                        <!-- Home -->
                        <div class="tab-pane fade <?= (isset($_GET['step']) && $_GET['step'] == 1 ? "show active" : "") ?>" id="organisasi" role="tabpanel" aria-labelledby="organisasi-tab">
                            <div id="tableorganisasi">
                                <div class="table-toolbar" align="right">
                                    <button class="btn btn-warning" title="Add" id="btn-get"><i class="fa fa-cog pull-left"></i></button>
                                </div>
                                <div class="table-toolbar" align="right">
                                    <button class="btn btn-primary" title="Simpan" id="btn-edittree">Update<i class="fa fa-save pull-left"></i></button>
                                </div>

                                <div id="editForm" style="display:none; text-align:center; position:absolute; border: 1px solid #aeaeae;width:300px;background-color:#F57C00;z-index:10000; ">
                                    <div style="padding: 10px 0 10px 0; background-color:#039BE5; color: #ffffff;">Edit Form</div>
                                    <div>
                                        <input type="hidden" id="idorganisasidetail">
                                        <input type="hidden" id="idutama">
                                        <!-- <input type="hidden" id="id_karyawan"> -->
                                        <!-- <input type="hidden" id="id_jabatan"> -->
                                        <!-- <input type="hidden" id="id_divisi"> -->
                                        <input type="hidden" id="name">
                                        <input type="hidden" id="jabatan">
                                        <div style="padding: 10px 0 5px 0;margin:15px;">
                                            <label style="color:#ffffff; width:50px; display:inline-block;" for="name">Name</label>
                                            <select style="background-color:#FFCA28" id="id_karyawan" class="form-control">
                                                <?php foreach (show_data("karyawan") as $un) {
                                                    echo "<option  value='" . $un->id . "' >" . $un->name . "</option>";
                                                } ?>
                                            </select>
                                        </div>
                                        <div style="padding: 5px 0 10px 0;margin:15px;">
                                            <label style="color:#ffffff; width:50px; display:inline-block;" for="jabatan">Jabatan</label>
                                            <select style="background-color:#FFCA28" id="id_jabatan" class="form-control">
                                                <?php foreach (show_data("jabatan") as $un) {
                                                    echo "<option  value='" . $un->id . "' >" . $un->name . "</option>";
                                                } ?>
                                            </select>
                                        </div>
                                        <div style="padding: 5px 0 10px 0;margin:15px;">
                                            <label style="color:#ffffff; width:50px; display:inline-block;" for="title">Divisi</label>
                                            <select style="background-color:#FFCA28" id="id_divisi" class="form-control">
                                                <?php foreach (show_data("divisi") as $un) {
                                                    echo "<option  value='" . $un->id . "' >" . $un->nama_divisi . "</option>";
                                                } ?>
                                            </select>
                                        </div>
                                        <div style="padding: 5px 0 15px 0;">
                                            <button style="width:108px;" id="cancel">Cancel</button>
                                            <button style="width:108px;" id="save">Save</button>
                                        </div>
                                    </div>
                                </div>

                                <div style="width:100%; height:700px;" id="tree"></div>

                            </div>
                            <div id="formorganisasi" style="display: none;">
                                <!-- <input type="hidden" name="karyawan" value="<?= (isset($_GET['id']) ? $_GET['id'] : "") ?>"> -->
                                <input type="hidden" name="iduniq" id="iduniq" value="">
                                <div class="item form-group">
                                    <label class="col-md-2">Nama Anggota<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="unit" id="namaanggota">
                                            <option>Pilih Anggota</option>
                                            <?php foreach (show_data("karyawan") as $un) {
                                                echo "<option value='" . $un->id . "'>" . $un->name . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Divisi<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="divisi" id="cbdivisi">
                                            <option value="">-----Pilih Divisi----</option>
                                            <?php foreach ($divisi as $un) {
                                                echo "<option  value='" . $un->id . "'>" . $un->nama_divisi . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="col-md-2">Jabatan<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="jabatan" id="cbjabatan">
                                            <option value="">-----Pilih Jabatan----</option>
                                            <?php foreach ($organisasi as $un) {
                                                echo "<option  value='" . $un->id . "'>" . $un->name . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="item form-group">
                                    <label class="col-md-2">Parent Jabatan<span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="parent jabatan" id="cbparentjabatan">
                                            <option value="">-----Pilih Jabatan----</option>
                                            <?php foreach ($organisasiparent as $un) {
                                                echo "<option  value='" . $un->id . "'>" . $un->name . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group" style="display:none;" id="divnamaatasanbyjabatan">
                                    <label class=" col-md-2">Nama Atasan By Jabatan <span class="text-danger">*</span></label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" name="parent jabatan" id="cbparentnamaatasanbyjabatan">
                                            <option value="">-----Pilih Nama Atasan----</option>

                                        </select>
                                    </div>
                                </div>

                                <br>
                                <br>
                                <br>
                                <div style="float: right">

                                    <button class="btn-submit btn btn-success" id="btnkembaliorganisasi"><i class="fa fa-reply"></i> <span name="CAPTION-KEMBALI" style="color:white;">Kembali</span></button>
                                    <button class="btn-submit btn btn-primary" id="btnsaveorganisasi"><i class="fa fa-save"></i> <span name="CAPTION-SIMPAN" style="color:white;">Simpan</span></button>
                                </div>

                            </div>
                        </div>
                        <!-- Rek -->
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>



<script>
    let arrtempchart = [];
    let arrinsertchart = [];
    var arra = [];
    $(document).ready(function() {
        $('.nav-tabs a[href="#perusahaan"]').tab('show');
        $(".select2").select2({
            width: "100%"
        });

    })
    $.ajax({
        type: "POST",
        url: "<?= base_url('setting/getorganisasi') ?>",
        async: false,
        dataType: "JSON",
        success: function(response) {
            let num = 0;

            $.each(response, function(key, value) {
                console.log(value.organisasi_nama);
                let param = '';
                let valueparam = '';
                if (value.pid == 0) {
                    param += 'title'
                    valueparam += value.organisasi_nama;
                } else {
                    param += 'pid'
                    // valueparam += value.pid
                    valueparam += value.pid_uniq
                }

                arrtempchart.push({
                    'idold': value.idjabatanutama,
                    'id': value.id_uniqjabatan,
                    'name': value.karyawan_nama,
                    'jabatan': value.organisasi_nama,
                    'id_karyawan': value.id_karyawanutama,
                    'id_jabatan': value.idjabatanutama,
                    'id_divisi': value.id_divisiutama,
                    'idutama': value.id_organisasidetailutama,
                    'divisi': (value.nama_divisi == null ? '' : value.nama_divisi) + " " + value.organisasi_nama,
                    [param]: valueparam
                })
                num++
            })
        }
    })
    console.log(arrtempchart);

    // var chart = new OrgChart(document.getElementById("tree"), {
    //     mouseScrool: OrgChart.action.none,
    //     nodeBinding: {
    //         field_0: "name",
    //         field_1: "divisi",
    //         field_2: "jabatan"
    //     },
    //     enableDragDrop: true,
    //     nodes: arrtempchart,
    //     toolbar: {
    //         fullScreen: true,
    //         zoom: true,
    //         fit: true,
    //         expandAll: true
    //     },

    // });
    var editForm = function() {
        this.nodeId = null;
    };

    editForm.prototype.init = function(obj) {

        var that = this;
        this.obj = obj;
        this.editForm = document.getElementById("editForm");
        this.nameInput = document.getElementById("name");
        this.ogdetail = document.getElementById("idorganisasidetail");
        this.idutama = document.getElementById("idutama");
        this.titleInput = document.getElementById("jabatan");
        this.id_divisi = document.getElementById("id_divisi");
        this.id_karyawan = document.getElementById("id_karyawan");
        this.id_jabatan = document.getElementById("id_jabatan");
        this.cancelButton = document.getElementById("cancel");
        this.saveButton = document.getElementById("save");

        this.cancelButton.addEventListener("click", function() {
            that.hide();
        });

        this.saveButton.addEventListener("click", function() {
            arra = [];
            var node = chart.get(that.nodeId);
            var selectedOption = id_karyawan.options[id_karyawan.selectedIndex]
            // node.name = that.nameInput.value;
            node.name = selectedOption.text;
            node.jabatan = that.titleInput.value;
            node.id = that.ogdetail.value;
            node.id_karyawan = that.id_karyawan.value;

            node.id_divisi = that.id_divisi.value;
            node.id_jabatan = that.id_jabatan.value;
            arra.push({
                'nama_pegawai': selectedOption.text,
                'nama_jabatan': node.jabatan,
                'id_karyawan': node.id_karyawan,
                'id_divisi': node.id_divisi,
                'id_jabatan': node.id_jabatan,
                'id': node.id,
                'idutama': node.idutama
            });

            $.ajax({
                type: "POST",
                url: '<?= base_url() ?>/setting/editorganisasidetail',
                async: false,
                dataType: "JSON",
                data: {
                    detail: arra
                },
                beforeSend: function() {

                    Swal.fire({
                        title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                        showConfirmButton: false,
                        allowOutsideClick: false
                    });

                },

                success: function(response) {
                    if (response == 1) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil',
                            showConfirmButton: false,
                            timer: 1500
                        })
                    } else {
                        Swal.fire(
                            'Error!',
                            'Gagal',
                            'warning'
                        )
                    }
                },
                error: function(xhr) { // if error occured
                    Swal.fire({
                        title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                        showConfirmButton: false,
                        allowOutsideClick: false,
                        timer: 10
                    });
                }
            })
            chart.updateNode(node);
            that.hide();
        });
    };

    editForm.prototype.show = function(nodeId) {
        this.hide();
        this.nodeId = nodeId;

        var left = document.body.offsetWidth / 2 - 150;
        this.editForm.style.display = "block";
        // this.editForm.style.display = "contents";
        // this.editForm.style.left = left + "px";
        var node = chart.get(nodeId);
        this.nameInput.value = node.name;
        this.titleInput.value = node.jabatan;
        this.ogdetail.value = node.id;
        this.idutama.value = node.idutama;
        this.id_divisi.value = node.id_divisi;
        this.id_karyawan.value = node.id_karyawan;
        this.id_jabatan.value = node.id_jabatan;
    };

    editForm.prototype.hide = function(showldUpdateTheNode) {
        this.editForm.style.display = "none";
    };


    var chart = new OrgChart(document.getElementById("tree"), {
        mouseScrool: OrgChart.action.none,
        toolbar: {
            fullScreen: true,
            zoom: true,
            fit: true,
            expandAll: true
        },

        enableDragDrop: true,
        nodeMenu: {
            edit: {
                text: "Edit"
            },
            // add: {
            //     text: "Add"
            // },
            //remove: {
            //    text: "Remove"
            //}
        },
        editUI: new editForm(),
        nodeBinding: {
            field_0: "name",
            // field_1: "title",
            field_1: "divisi",
            field_2: "jabatan",
            field_3: "id_karyawan",
            field_4: "id_jabatan",
            field_5: "id_divisi"
        },
        // nodes: [
        //     { id: 1, name: "Amber McKenzie", title: "CEO" },
        //     { id: 2, pid: 1, name: "Ava Field", title: "IT Manager" },
        //     { id: 3, pid: 1, name: "Peter Stevens", title: "HR Manager" }
        // ]
        nodes: arrtempchart
    });

    $(document).on('click', '#btn-get', function() {
        for (let index = 0; index < arrtempchart.length; index++) {
            console.log(chart.get(index + 1));
        }
        // return false;
        $('#tableorganisasi').hide('FadeIn');
        $('#formorganisasi').show('FadeIn');

        return false;

    })
    $('#btnkembaliorganisasi').click(function() {
        $("#namaanggota").val('');
        $("#cbjabatan").val('')
        $("#cbdivisi").val('')
        $("#cbparentjabatan").val('');
        $("#iduniq").val('');
        $('#tableorganisasi').show('FadeOut');
        $('#formorganisasi').hide('FadeIn');

    })

    $('#btn-edittree').click(function() {
        let arrupdatetree = [];

        $.each(arrtempchart, function(i, v) {
            arrupdatetree.push(v)
            // console.log(chart.get(v.id))

        })

        console.log(arrupdatetree);
        // return false;
        if (arrupdatetree.length == 0) {
            Swal.fire('Data Kosong!<br>Mohon isi', '', 'error')
            return false;
        }


        Swal.fire({
            title: 'Apa Anda Yakin?',
            // showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: 'Simpan',
            // denyButtonText: `Cancel`,
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    data: {
                        detail: arrupdatetree
                    },
                    url: "<?= base_url('setting/updateorganisasidetail'); ?>",
                    dataType: "JSON",
                    success: function(response) {
                        console.log(response);
                        // return false;
                        if (response == 1 || response == true) {
                            Swal.fire('Simpan!', '', 'success')
                            setTimeout(() => location.reload(), 800);
                        } else {

                            Swal.fire('Gagal!', '', 'warning')
                            setTimeout(() => location.reload(), 800);
                        }

                    }

                })

            } else {
                Swal.fire('Dibatalkan!', '', 'warning')
            }
        })

    })

    /////////////////////////////// PERUSAHAAN
    $(document).on('click', '#btn-edit', function() {
        $("#tableperusahaan").hide("fadeOut");
        // $("#formeditperusahaan").fadeOut();
        $("#formeditperusahaan").show("fadeIn");

    })
    $(document).on('click', '#btnkembalipt', function() {
        $("#tableperusahaan").show("fadeOut");
        // $("#formeditperusahaan").fadeOut();
        $("#formeditperusahaan").hide("fadeIn");

    })

    function previewFile(e) {

        const file = e.files[0];
        const reader = new FileReader();

        $('.perusahaanimg').empty()
        reader.addEventListener("load", function() {
            let result = reader.result;
            $('.perusahaanimg').append(`
                <img class=" img-fluid img-responsive " width="
                    200 " src="${result}">
            `);
            // preview.src = reader.result;
        }, false);

        if (file) {
            reader.readAsDataURL(file);
        }
    }
    $(document).on('click', '#btnsavepr', function() {
        if ($('#nama').val() == '' || $('#alamat').val() == '' || $('#email').val() == '' || $('#telepon').val() == '') {
            new PNotify
                ({
                    title: 'Error',
                    text: "Mohon lengkapi data inputan yang Kosong",
                    type: "warning",
                    styling: 'bootstrap3',
                    delay: 3000,
                    // stack: stack_center
                });
            return false;
        }
        let newform = new FormData();
        newform.append('file', $('#imgfotoupdate')[0].files[0]);
        newform.append('nama', $('#nama').val());
        newform.append('id', $('#id').val());
        newform.append('alamat', $('#alamat').val());
        newform.append('email', $('#email').val());
        newform.append('telepon', $('#telepon').val());


        $.ajax({
            type: "POST",
            data: newform,
            enctype: 'multipart/form-data',
            contentType: false,
            processData: false,
            url: "<?= base_url('setting/save_perusahaan'); ?>",
            dataType: "JSON",
            success: function(response) {
                console.log(response);
                if (response == 1 || response == true) {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil Ditambah",
                            type: "Succes",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => location.reload(), 800);
                } else {
                    new PNotify
                        ({
                            title: 'Gagal',
                            text: "Data Gagal Ditambah",
                            type: "Warning",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => location.reload(), 800);
                }

            }

        })
    })
    $(document).on('change', '#cbparentjabatan', function() {
        let val = $('#cbparentjabatan option:selected').val()

        $.ajax({
            type: "POST",
            data: {
                id: val,
            },
            async: false,
            dataType: "JSON",
            url: '<?= base_url('setting/cekorganisasidetail') ?>',
            success: function(response) {
                if (response.length != 0) {
                    $('#divnamaatasanbyjabatan').show();
                    $("#cbparentnamaatasanbyjabatan").empty();
                    $("#cbparentnamaatasanbyjabatan").append('<option value="">Pilih Nama Atasan By Jabatan</option>');
                    $.each(response, function(i, c) {
                        $("#cbparentnamaatasanbyjabatan").append('<option value="' + c.id + '">' + c.name + '</option>');
                    })
                }
            }
        })
    })
    $(document).on('change', '#cbparentnamaatasanbyjabatan', function() {
        let val = $(this).val();
        $.ajax({
            type: "POST",
            data: {
                id: val,
            },
            async: false,
            dataType: "JSON",
            url: '<?= base_url('setting/getiduniqbynamaatasan') ?>',
            success: function(response) {
                $('#iduniq').val(response.id_uniqjabatan);
            }
        })
    })

    $(document).on('click', '#btnsaveorganisasi', function() {
        let nama_anggota = $("#namaanggota option:selected").val();
        let jabatan = $("#cbjabatan option:selected").val()
        let divisi = $("#cbdivisi option:selected").val()
        let parentjabatan = $("#cbparentjabatan option:selected").val();
        let piduniq = $("#iduniq").val();

        $.ajax({
            type: "POST",
            data: ({
                nama_anggota: nama_anggota,
                jabatan: jabatan,
                divisi: divisi,
                parentjabatan: parentjabatan,
                pid_uniq: piduniq == "" ? "0" : piduniq
            }),
            async: false,
            dataType: "JSON",
            url: '<?= base_url('setting/tambahorganisasidetail') ?>',
            success: function(response) {
                console.log(response);
                if (response == 1 || response == true || response == "1") {
                    new PNotify
                        ({
                            title: 'Succes',
                            text: "Data Berhasil Ditambah",
                            type: "Succes",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => location.reload(), 800);

                } else {
                    new PNotify
                        ({
                            title: 'Gagal',
                            text: "Data Gagal Ditambah",
                            type: "Warning",
                            styling: 'bootstrap3',
                            delay: 3000,
                            // stack: stack_center
                        });
                    setTimeout(() => location.reload(), 800);
                }


            }
        })
    })
</script>