<style>
    .modal-body {
        max-height: calc(100vh - 210px);
        overflow-x: auto;
        overflow-y: auto;
    }

    .wrapper {
        display: inline-flex;
        margin-top: 10px;
        height: 40px;
        width: 30%;
        align-items: center;
        justify-content: space-evenly;
        border-radius: 5px;
    }

    .wrapper .option {
        background: #fff;
        height: 100%;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-evenly;
        margin: 0 10px;
        border-radius: 5px;
        cursor: pointer;
        padding: 0 10px;
        border: 2px solid lightgrey;
        transition: all 0.3s ease;
    }

    .wrapper .option .dot {
        height: 20px;
        width: 20px;
        background: #d9d9d9;
        border-radius: 50%;
        position: relative;
    }

    .wrapper .option .dot::before {
        position: absolute;
        content: "";
        top: 4px;
        left: 4px;
        width: 12px;
        height: 12px;
        background: #0069d9;
        border-radius: 50%;
        opacity: 0;
        transform: scale(1.5);
        transition: all 0.3s ease;
    }

    input[type="radio"] {
        display: none;
    }

    #option-1:checked:checked~.option-1,
    #option-2:checked:checked~.option-2 {
        border-color: #0069d9;
        background: #0069d9;
    }

    #option-1:checked:checked~.option-1 .dot,
    #option-2:checked:checked~.option-2 .dot {
        background: #fff;
    }

    #option-1:checked:checked~.option-1 .dot::before,
    #option-2:checked:checked~.option-2 .dot::before {
        opacity: 1;
        transform: scale(1);
    }

    .wrapper .option span {
        font-size: 16px;
        color: #808080;
    }

    #option-1:checked:checked~.option-1 span,
    #option-2:checked:checked~.option-2 span {
        color: #fff;
    }
</style>

<?php if (isset($_GET['del'])) {
    $gaji = where_count('gaji', ['karyawan' => $_GET['del']]);
    if ($gaji == 0) {
        $this->db->delete("karyawan", ['id' => $_GET['del']]);
        $this->session->set_flashdata("success", 'Data karyawan berhasil dihapus');
        redirect("master/karyawan");
    } else {
        $this->session->set_flashdata("error", 'Data tidak dapat dihapus, karena sudah terdapat history transaksi system');
        redirect("master/karyawan");
    }
} ?>
<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>

        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Role</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content table-responsive">
                    <table id="datatableAdmin" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Role</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dataAdmin as $key => $value) { ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= $value->nama ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info" onclick="handlerManageHakAkses(' <?= $value->id ?>')"><i class="fa fa-lock"></i></button>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<div class="modal fade" id="modalHakAkses" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h4 class="modal-title text-white">Manage Hak Akses</h4>
            </div>
            <div class="modal-body">
                <div class="x_content">
                    <div class="x_content table-responsive mt-4">
                        <table id="tabledetailareaopname">
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="form-group">
                    <button class="btn btn-primary btnSaveHakAkses" onclick="handlerSaveDataHakAkses(event)"><i class="fa fa-save"></i> Simpan</button>
                </div>
                <div class="form-group">
                    <button type="button" data-dismiss="modal" class="btn btn-danger"><span name="CAPTION-CLOSE">Tutup</span></button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let arrHakAkses = [];

    $(document).ready(function() {
        // $("#showAdmin").show("slow");
        getMenuHakAkses();
    });

    // const chkDataUsers = (event) => {
    //     if (event.currentTarget.value == "0") {
    //         $("#showAdmin").show("slow");
    //         $("#showPegawai").hide("slow");
    //     } else {
    //         $("#showAdmin").hide("slow");
    //         $("#showPegawai").show("slow");
    //     }
    // };

    const getMenuHakAkses = () => {
        $.ajax({
            url: "<?= base_url('Setting/getMenuHakAkses'); ?>",
            type: "GET",
            dataType: "JSON",
            async: false,
            success: function(response) {
                // console.log(response);
                arrHakAkses = [];
                arrHakAkses.push(response)
                // Object.assign(response, arrHakAkses);
            }
        });
    }

    const handlerManageHakAkses = (idRole) => {

        let id = idRole.replace(/\s/g, '');

        $('#modalHakAkses').modal('show');
        $('#tabledetailareaopname').empty();
        $(".btnSaveHakAkses").attr('data-id-user', id);

        let arrHakAksesUser = [];

        $.ajax({
            url: "<?= base_url('Setting/getMenuHakAksesById'); ?>",
            type: "POST",
            data: {
                idRole: id,
            },
            dataType: "JSON",
            async: false,
            success: function(response) {
                arrHakAksesUser = [];
                arrHakAksesUser.push(response);
            }
        });
        const newDataAksesByUser = Object.assign({}, ...arrHakAksesUser);


        const newDataAllAkses = Object.assign({}, ...arrHakAkses);
        let strcontent = "";

        strcontent = strcontent + `<tr>
                                <td class="text-left" width="5%">
                                  <input type="checkbox" id="check-all-pilih-sj" class="cball-all" style="transform: scale(1.5)" onchange="checkAll(this, 'all')" />
                                </td>
                                <td colspan="4"><h4><strong>All</strong></h4></td>
                              </tr>`;

        $.each(newDataAllAkses.parentMenu, function(index, value) {
            var k = 0;
            var random = Math.random() * 10000000000000000000;
            strcontent = strcontent + '<tr id="tr_' + random + '">';

            // let namaParentMenu = value.nama;
            // var KeyVal = v.rak_lajur_detail_nama + ` ${i}`;
            let namaParentMenu = value.nama.replace(/\s/g, '');
            let str = "";

            let chkParentMenu = "";

            if (newDataAksesByUser.parentMenu.length > 0) {
                if (newDataAksesByUser.parentMenu.some(item => item.id_parent_menu === value.id)) {
                    chkParentMenu = "checked";
                } else {
                    chkParentMenu = "";
                }
            } else {
                chkParentMenu = "";
            }


            str += `<input type='checkbox' class='cball-all getValueParentMenu' style='transform: scale(1.5)' ${chkParentMenu}  name='chkParentMenu-${namaParentMenu}' id='chk-utama'  onchange="checkAllParentMenu(this,'${namaParentMenu}',)" value='${value.id}'/>`;
            if (value.url == "") {
                strcontent = strcontent + ` <td width="5%" onclick="hshow('${namaParentMenu}','${index}')"><span>
                                        <button type="button" class="btn btn-primary btn-sm btnParentMenu btnParentMenu_${index}" style="border-radius: 100%;"><i class="fa fa-minus"></i></button></span></td>`;
            } else {
                strcontent = strcontent + ` <td width="5%"></td>`;
            }

            strcontent = strcontent + ` <td width="5%" class="text-center" >${str}</td>`;
            strcontent = strcontent + ` <td colspan="3"><h4 class="fs-3"><strong>${value.nama}</strong></h4></td>`;
            strcontent = strcontent + '</tr>';

            $.each(newDataAllAkses.mainMenu, function(idx, val) {
                let namaMainMenu = val.nama.replace(/\s/g, '');
                let namaMainMenu2 = namaMainMenu.replaceAll("/", "");
                if (value.id == val.id_parent_menu) {

                    let chkMainMenu = "";

                    if (newDataAksesByUser.mainMenu.length > 0) {
                        if (newDataAksesByUser.mainMenu.some(item => item.id_main_menu === val.id)) {
                            chkMainMenu = "checked";
                        } else {
                            chkMainMenu = "";
                        }
                    } else {
                        chkMainMenu = "";
                    }


                    cbapp = `<input type='checkbox' class='cball-all getValueMainMenu chkMainMenu-${namaMainMenu2}' ${chkMainMenu} style='transform: scale(1.5)' name='chkMainMenu-${namaParentMenu}' id='${val.id}' value="${val.id}" onchange="checkAllMainMenu(this,'${namaMainMenu2}', '${namaParentMenu}')"/>`;

                    strcontent = strcontent + `<tr class="hideShowParent-${namaParentMenu}">`;
                    strcontent = strcontent + ` <td><?php echo "&nbsp"; ?></td>`;
                    if (val.url == "") {
                        strcontent = strcontent + ` <td onclick="hshow2('${namaMainMenu2}','${idx}', '${namaParentMenu}')"><span>
                                        <button type="button" class="btn btn-primary btn-sm btnMainMenu btnMainMenu-${idx}" style="border-radius: 100%;"><i class="fa fa-minus"></i></button></span></td>`;
                    } else {
                        strcontent = strcontent + ` <td><?php echo "&nbsp"; ?></td>`;
                    }

                    strcontent = strcontent + ` <td width="5%" style="text-align:left">${cbapp}</td>`;
                    strcontent = strcontent + ` <td colspan="2"><strong>${val.nama}</strong></td>`;
                    strcontent = strcontent + '</tr>';
                }

                $.each(newDataAllAkses.subMenu, function(i, v) {
                    if ((value.id == v.id_parent_menu) && (val.id == v.id_main_menu)) {

                        let chkSubMenu = "";

                        if (newDataAksesByUser.subMenu.length > 0) {
                            if (newDataAksesByUser.subMenu.some(item => item.id_sub_menu === v.id)) {
                                chkSubMenu = "checked";
                            } else {
                                chkSubMenu = "";
                            }
                        } else {
                            chkSubMenu = "";
                        }


                        cbapp = `<input type='checkbox' class='cball-all getValueSubMenu chkSubMenu-${namaMainMenu2}' ${chkSubMenu} style='transform: scale(1.5)' name_rak='${namaParentMenu}' name='chkMainMenu-${namaParentMenu}' id='${v.id}' value="${v.id}" onchange="checkAllSubMenu(this,'${namaParentMenu}', '${namaMainMenu2}')"/>`

                        strcontent = strcontent + `<tr class="hideShowParent-${namaParentMenu} hideShowMain-${namaMainMenu2}">`;
                        strcontent = strcontent + ` <td><?php echo "&nbsp"; ?></td>`;
                        strcontent = strcontent + ` <td><?php echo "&nbsp"; ?></td>`;
                        strcontent = strcontent + ` <td><?php echo "&nbsp"; ?></td>`;
                        strcontent = strcontent + ` <td width="5%" style="text-align:left">${cbapp}</td>`;
                        strcontent = strcontent + ` <td><strong>${v.nama}</strong></td>`;
                        strcontent = strcontent + '</tr>';
                    }
                });
            });

            // $('#edittabledetailareaopname > tbody').append(strcontent);

            k++;
        })
        $('#tabledetailareaopname').append(strcontent);
    }

    function checkAll(e, all) {

        var checkboxes = $(`.cball-${all}`);
        if (e.checked) {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = true;
                }
            }
        } else {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = false;
                }
            }
        }
    }

    function checkAllParentMenu(e, namaParentMenu) {

        var checkboxes = $(`input[name='chkMainMenu-${namaParentMenu}']`);
        if (e.checked) {
            for (var i = 0; i < checkboxes.length; i++) {

                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = true;
                }
            }
        } else {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = false;
                }
            }
        }
    }

    function checkAllMainMenu(e, namaMainMenu2, namaParentMenu) {

        var checkboxes = $(`.chkSubMenu-${namaMainMenu2}`);
        var checkboxes2 = $(`input[name='chkParentMenu-${namaParentMenu}']`);
        if (e.checked) {
            for (var i = 0; i < checkboxes.length; i++) {

                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = true;
                }
            }

            for (var i = 0; i < checkboxes2.length; i++) {

                if (checkboxes2[i].type == 'checkbox') {
                    checkboxes2[i].checked = true;
                }
            }
        } else {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = false;
                }
            }

            for (var i = 0; i < checkboxes2.length; i++) {
                if (checkboxes2[i].type == 'checkbox') {
                    checkboxes2[i].checked = false;
                }
            }
        }
    }

    function checkAllSubMenu(e, namaParentMenu, namaMainMenu2) {

        var checkboxes = $(`input[name='chkParentMenu-${namaParentMenu}']`);
        var checkboxes2 = $(`.chkMainMenu-${namaMainMenu2}`);
        if (e.checked) {
            for (var i = 0; i < checkboxes.length; i++) {

                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = true;
                }

                if (checkboxes2[i].type == 'checkbox') {
                    checkboxes2[i].checked = true;
                }
            }

        } else {
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].type == 'checkbox') {
                    checkboxes[i].checked = false;
                }
                if (checkboxes2[i].type == 'checkbox') {
                    checkboxes2[i].checked = false;
                }
            }
        }
    }

    function hshow(namaParentMenu, index) {
        let fafa = $(`.btnParentMenu_${index}`).html();
        if (fafa == '<i class="fa fa-minus"></i>') {
            $(`.hideShowParent-${namaParentMenu}`).hide();
            $(`.btnParentMenu_${index}`).html('<i class="fa fa-plus"></i>');
        }

        if (fafa == '<i class="fa fa-plus"></i>') {
            $(`.hideShowParent-${namaParentMenu}`).show();
            $(`.btnParentMenu_${index}`).html('<i class="fa fa-minus"></i>');
        }
    }

    function hshow2(namaMainMenu2, index) {
        let fafa = $(`.btnMainMenu-${index}`).html();
        if (fafa == '<i class="fa fa-minus"></i>') {
            $(`.hideShowMain-${namaMainMenu2}`).hide();
            $(`.btnMainMenu-${index}`).html('<i class="fa fa-plus"></i>');
        }

        if (fafa == '<i class="fa fa-plus"></i>') {
            $(`.hideShowMain-${namaMainMenu2}`).show();
            $(`.btnMainMenu-${index}`).html('<i class="fa fa-minus"></i>');
        }
    }

    const handlerSaveDataHakAkses = (event) => {
        let idRole = event.currentTarget.getAttribute('data-id-user');

        const arrParentMenu = $(".getValueParentMenu").map(function() {
            if (this.checked == true && !(this.disabled)) {
                return this.value;
            }
        }).get();

        const arrMainMenu = $(".getValueMainMenu").map(function() {
            if (this.checked == true && !(this.disabled)) {
                return this.value;
            }
        }).get();

        const arrSubMenu = $(".getValueSubMenu").map(function() {
            if (this.checked == true && !(this.disabled)) {
                return this.value;
            }
        }).get();

        if (arrParentMenu.length == 0) {
            new PNotify({
                text: 'Gagal simpan, parent menu minimal 1 data yang terpilih',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
            })

            return false;
        }

        if (arrMainMenu.length == 0) {
            new PNotify({
                text: 'Gagal simpan, main menu minimal 1 data yang terpilih',
                type: 'error',
                styling: 'bootstrap3',
                delay: 2000,
                history: false
            })

            return false;
        }

        $.ajax({
            url: "<?= base_url('Setting/saveDataMenuHakAkses'); ?>",
            type: "POST",
            data: {
                idRole,
                arrParentMenu,
                arrMainMenu,
                arrSubMenu
            },
            beforeSend: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false
                });
            },
            dataType: "JSON",
            success: function(response) {
                if (response.status == 201) {
                    new PNotify({
                        text: response.message,
                        type: 'success',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })

                    $('#modalHakAkses').modal('hide');
                    location.reload();
                }

                if (response.status == 400) {
                    new PNotify({
                        text: response.message,
                        type: 'error',
                        styling: 'bootstrap3',
                        delay: 2000,
                        history: false
                    })
                }
            },
            error: function(xhr) { // if error occured
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
            complete: function() {
                Swal.fire({
                    title: '<span ><i class="fa fa-spinner fa-spin"></i> Loading...</span>',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    timer: 10
                });
            },
        });

        // console.log(arr_chk);
    }
</script>