<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>
    </div>
  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-6">
      <div class="x_panel">
        <div class="x_title">
          <h2><?= $title1 ?></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content table-responsive">
          <table id="datatable" class="table table-striped table-bordered" width="100%">
            <thead>
              <tr class="bg-dark text-white">
                <th>No</th>
                <th>Unit Kerja</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($dataUnit != null) { ?>
                <?php foreach ($dataUnit as $key => $value) { ?>
                  <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $value->name ?></td>
                    <td><button type="button" class="btn btn-sm btn-warning" onclick="handlerSettingLokasi('<?= $value->id ?>')"><i class="fa fa-edit"></i> Setting</button></td>
                  </tr>
                <?php } ?>
              <?php } else { ?>
                <tr>
                  <td colspan="3">Data Kosong</td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
      <!-- content -->
    </div>
    <div class="col-md-6">
      <div class="x_panel showDataUnitSetting" style="display: none;">
        <div class="x_content">
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-12 col-sm-12 col-xs-12">
              <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="hidden" name="id" id="id" class="form-control" placeholder="Longitude">
                <input type="hidden" name="type" id="type" class="form-control" placeholder="Longitude">
                <textarea name="alamat" id="alamat" class="form-control" cols="3" rows="3" placeholder="Alamat"></textarea>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-6 col-sm-12 col-xs-12">
              <div class="form-group">
                <label for="latitude">Latitude</label>
                <input type="text" name="latitude" id="latitude" class="form-control" placeholder="Latitude">
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-6 col-sm-12 col-xs-12">
              <div class="form-group">
                <label for="longitude">Longitude</label>
                <input type="text" name="longitude" id="longitude" class="form-control" placeholder="Longitude">
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-6 col-sm-12 col-xs-12">
              <div class="form-group">
                <label for="satuan">Satuan</label>
                <select name="satuan" id="satuan" class="form-control" required>
                  <option value="">--Pilih Satuan--</option>
                  <option value="1">Kilometer</option>
                  <option value="2">Meter</option>
                </select>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-6 col-sm-12 col-xs-12">
              <div class="form-group">
                <label for="jarak">Jarak</label>
                <input type="text" name="jarak" id="jarak" class="form-control numeric" placeholder="Jarak">
              </div>
            </div>
            <div class="col-xl-12 col-lg-12 col-12 col-sm-12 col-xs-12">
              <button type="button" class="btn btn-primary" onclick="btnSaveSettingLokasi()"><i class="fa fa-save"></i> Simpan Data</button>
            </div>
          </div>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>

<script>
  $(document).on("input", ".numeric", function(event) {
    this.value = this.value.replace(/[^\d.]+/g, '');
  });

  const handlerSettingLokasi = (id) => {
    $('.showDataUnitSetting').hide('slow');
    $('.showDataUnitSetting').show('slow');

    $.ajax({
      url: "<?= base_url('Setting/getSettingLokasiByid'); ?>",
      type: "POST",
      data: {
        id
      },
      dataType: "JSON",
      success: function(response) {
        console.log(response);

        $('#id').val(response == null ? id : response.id)
        $('#type').val(response == null ? 'insert' : 'update')
        if (response != null) {
          $('#alamat').val(response.alamat);
          $('#longitude').val(response.longitude)
          $('#latitude').val(response.latitude)
          $('#satuan').val(response.satuan == 'Km' ? 1 : response.satuan == 'm' ? 2 : '').trigger('change')
          $('#jarak').val(response.jarak)
        } else {
          $('#alamat').val("");
          $('#longitude').val("")
          $('#latitude').val("")
          $('#satuan').val("")
          $('#jarak').val("")
        }
      },
    });
  }

  const btnSaveSettingLokasi = () => {
    if ($('#alamat').val() == "") {
      showMessage('error', `Alamat wajib diisi`);
      return false;
    }

    if ($('#latitude').val() == "") {
      showMessage('error', `Latitude wajib diisi`);
      return false;
    }

    if ($('#longitude').val() == "") {
      showMessage('error', `Logitude wajib diisi`);
      return false;
    }

    if ($('#satuan').val() == "") {
      showMessage('error', `Satuan wajib diisi`);
      return false;
    }

    if ($('#jarak').val() == "") {
      showMessage('error', `Jarak wajib diisi`);
      return false;
    }

    $.ajax({
      url: "<?= base_url('Setting/save_lokasi'); ?>",
      type: "POST",
      data: {
        id: $('#id').val(),
        type: $('#type').val(),
        alamat: $('#alamat').val(),
        longitude: $('#longitude').val(),
        latitude: $('#latitude').val(),
        satuan: $('#satuan').val(),
        jarak: $('#jarak').val(),
      },
      dataType: "JSON",
      success: function(response) {
        if (response.status == 200) {
          showMessage('success', response.message);
          location.reload();
        } else {
          showMessage('error', response.message);
          return false;
        }
      },
    });
  }
</script>