<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?=$title ?></h3>
    </div>  
  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Data Penggajian</h2>
          <div class="row pull-right">
            <div class="col-md-6">
              <select class="form-control lap-bulan" name="bulan">
                <option value="0">Pilih Bulan</option>
                <?php
                $month = strtotime(date('Y').'-'.date('m').'-'.date('j').' - 8 months');
                $end = strtotime(date('Y').'-'.date('m').'-'.date('j').' + 8 months');
                while($month < $end){
                    echo '<option value="'.date('m', $month).'">'.bulan(date('m', $month)).'</option>'."\n";
                    $month = strtotime("+1 month", $month);
                }
                ?>
              </select>
            </div>
            <div class="col-md-6">
              <select class="form-control lap-thn" name="thn">
                <option value="0">Pilih Tahun</option>
                <?php
                for($i=date('Y'); $i<=2050; $i++){
                    echo '<option value="'.$i.'">'.$i.'</option>'."\n";
                }
                ?>
              </select>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
        <div class="x_content table-responsive">
          <?php if (isset($_GET['bulan']) && isset($_GET['tahun'])) { 
            $date = $_GET['tahun']."-".$_GET['bulan'];
            $gaji = $this->db->like('date',$date)->get_where("gaji",['status'=>1])->result();
            $gaji_row = $this->db->like('date',$date)->get_where("gaji",['status'=>1])->row();
            $num_kar = $this->db->get("penerimaan")->num_rows();
            $sudah = $this->db->like('date',date("Y-m"))->get_where("gaji",['status'=>1])->num_rows();
            $sudah_transfer = $this->db->like('date',date("Y-m"))->get_where("gaji",['transfer !='=>NULL])->num_rows();
            $semua = $this->db->get("karyawan")->num_rows();
            $sen_sek = $this->db->like('date',date("Y-m"))->get_where("gaji",['status'=>1,'send_sekretaris'=>NULL])->num_rows();
            $app_sek = $this->db->like('date',date("Y-m"))->get_where("gaji",['status'=>1,'send_sekretaris !='=>NULL,'approve_sekretaris'=>NULL])->num_rows();
            if ($gaji_row) {
              if ($gaji_row->send_sekretaris == NULL && $gaji_row->approve_sekretaris == NULL) {
                $sekretaris = "Proses penginputan";
              }else if ($gaji_row->send_sekretaris != NULL && $gaji_row->approve_sekretaris == NULL) {
                $sekretaris = "Review Sekretatis";
              }else{
                $sekretaris = $gaji_row->approve_sekretaris;
              }
              if ($gaji_row->approve_sekretaris == NULL && $gaji_row->send_bendahara == NULL) {
                $bendahara = "Review Sekretaris";
              }else if ($gaji_row->approve_sekretaris != NULL && $gaji_row->send_bendahara == NULL) {
                $bendahara = "Belum dikirim oleh Sekretaris";
              }else{
                $bendahara = $gaji_row->send_bendahara;
              }
            }

            ?>
            <p>
              Bulan : <strong><?=bulan($_GET['bulan']) ?> - <?=$_GET['tahun'] ?></strong><br>
              Terkirim ke Sekretaris : <?=($gaji_row ? ($gaji_row->send_sekretaris == NULL ? "Masih proses penginputan" : $gaji_row->send_sekretaris) : "" ) ?><br>
              diterima Sekretaris : <?=($gaji_row ? $sekretaris : "") ?><br>
              Terkirim ke Bendahara : <?=($gaji_row ? $bendahara : "") ?><br>
              Transfer ke masing-masing karyawan : <?=($gaji_row && $sudah_transfer == $semua ? ($gaji_row->transfer == NULL ? "Masih proses" : $gaji_row->send_sekretaris) : "") ?><br>
            </p>
              <?php if ($gaji_row && $gaji_row->send_sekretaris == NULL && $users->level == 2 && $sudah == $semua) {
                echo '<a class="btn btn-sm btn-success" href="'.base_url('laporan/kirim_sekretaris').'">Kirim ke Sekretaris</a>';
              } else if($gaji_row && $gaji_row->send_sekretaris != NULL && $gaji_row->approve_sekretaris == NULL && $users->level == 3  && $sudah == $semua) {
                echo '<a class="btn btn-sm btn-primary" href="'.base_url('laporan/terima_sekretaris').'">Terima</a>';
                if ($gaji_row->approve_sekretaris == NULL) {
                  echo '<a class="btn btn-sm btn-danger" href="'.base_url('laporan/tolak_sekretaris').'">Tolak Sekretaris</a>';
                }
                
              } else if($gaji_row && $gaji_row->approve_sekretaris != NULL && $gaji_row->send_bendahara == NULL && $users->level == 3  && $sudah == $semua) {
                echo '<a class="btn btn-sm btn-success" href="'.base_url('laporan/kirim_bendahara').'">Kirim ke Bendahara</a>';
                if ($gaji_row->approve_bendahara == NULL && $gaji_row->approve_sekretaris == NULL) {
                  echo '<a class="btn btn-sm btn-danger" href="'.base_url('laporan/tolak_bendahara').'">Tolak</a>';
                }
              } else if($gaji_row && $gaji_row->send_bendahara != NULL && $gaji_row->approve_bendahara == NULL && $users->level == 4  && $sudah == $semua) {
                echo '<a class="btn btn-sm btn-primary" href="'.base_url('laporan/terima_bendahara').'">Terima</a>';
              }
              ?>
              <br><br>
            <div class="clearfix"></div>
            <table id="datatable" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th rowspan="2" class="align-middle text-center">No</th>
                  <th rowspan="2" class="align-middle text-center">Nama</th>
                  <th rowspan="2" class="align-middle text-center">Bidang</th>
                  <th colspan="2" class="text-center">Komponen Gaji Pokok</th>
                  <th rowspan="2" class="align-middle text-center">Pay For Person (P1)</th>
                  <th colspan="<?=count_table('tunjangan') ?>" class="align-middle text-center">Tunjangan</th>
                  <th rowspan="2" class="align-middle text-center">Pay For Person (P2)</th>
                  <th colspan="<?=count_table('bonus') ?>" class="align-middle text-center">Bonus</th>
                  <th rowspan="2" class="align-middle text-center">Pay For Person (P3)</th>
                  <th rowspan="2" class="align-middle text-center">Total</th>
                  <th rowspan="2" class="align-middle text-center">Status</th>
                </tr>
                <tr>
                  <th>Grade</th>
                  <th>Masa Kerja</th>
                  <?php foreach (show_data("tunjangan") as $tunjangan) {
                    echo "<th>".$tunjangan->name."</th>";
                  } ?>
                  <?php foreach (show_data("bonus") as $bonus) {
                    echo "<th>".$bonus->name."</th>";
                  } ?>
                </tr>
              </thead>
              <tbody>
               <?php $no=0; foreach ($gaji as $g) { $no++; 
                $k = $this->db->select('karyawan.name as nama,unit.name as bagian,penerimaan.date as tanggal')->join('unit','penerimaan.unit=unit.id')->join('karyawan','penerimaan.karyawan=karyawan.id')->get_where("penerimaan",['penerimaan.karyawan'=>$g->karyawan])->row();
                $interval = date_diff(date_create($k->tanggal), date_create($g->date));
                $masa = $interval->y*25000;
                $skl = $this->db->select('pendidikan.name,int_sekolah.sekolah')->join('karyawan','int_sekolah.karyawan=karyawan.id')->join('pendidikan','int_sekolah.sekolah=pendidikan.id')->get_where("int_sekolah",['int_sekolah.karyawan'=>$g->karyawan])->row();
                $grade = where_row('grade',['level'=>$skl->sekolah]);
                $tunjangan = where_row('int_tunjangan',['karyawan'=>$g->karyawan]);
                $show_tunjangan = json_decode($tunjangan->tunjangan);
                $bonus = where_row('int_bonus',['karyawan'=>$g->karyawan]);
                $show_bonus = json_decode($bonus->bonus);
                ?>
                 <tr>
                   <td><?=$no ?></td>
                   <td><?=$k->nama ?></td>
                   <td><?=$k->bagian ?></td>
                   <td><?=rupiah($g->p1_1) ?></td>
                   <td><?=rupiah($g->p1_2) ?></td>
                   <td><?=rupiah($g->p1) ?></td>
                   <?php foreach ($show_tunjangan as $key => $value) {
                    if ($key != "karyawan") {
                      echo "<td>".rupiah($value)."</td>";
                    }
                   } ?>
                   <td><?=rupiah($g->p2) ?></td>
                   <?php foreach ($show_bonus as $keys => $values) {
                    if ($keys != "karyawan") {
                      echo "<td>".rupiah($values)."</td>";
                    }
                   } ?>
                   <td><?=rupiah($g->p3) ?></td>
                   <td><?=rupiah($g->total) ?></td>
                   <td>
                     <?php
                     if ($users->level != 2) {
                       echo ($g->transfer == NULL ? "Dalam Proses" : "Sudah diterima");
                     }else{
                      if ($g->approve_bendahara != NULL && $g->transfer == NULL) {
                        echo "<a href='".base_url('laporan/cetak/'.$g->id)."' target='_blank' class='btn btn-sm btn-success'><i class='fa fa-check'></i></a>";
                      }else if ($g->approve_bendahara != NULL && $g->transfer != NULL) {
                        echo "<a href='".base_url('slip-gaji/').$g->nomor."' target='_blank' class='btn btn-sm btn-primary'><i class='fa fa-file'></i></a>";
                      }else{
                         echo "Proses";
                      }
                      
                     }
                     
                     ?>
                   </td>
                 </tr>
               <?php } ?>
              </tbody>
            </table>
          <?php } ?>
        </div>
      </div>
      <!-- content -->
    </div>
  </div>
</div>
