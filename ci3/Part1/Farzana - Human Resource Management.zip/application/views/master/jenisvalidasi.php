<?php if (isset($_GET['del'])) {
    $this->db->delete("jenis_validasi", ['id' => $_GET['del']]);
    $this->session->set_flashdata("success", 'Data unit berhasil dihapus');
    redirect("master/jenisvalidasi");
} ?>

<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>

        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row" id="divformview">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Karyawan</h2>
                    <button id="btn_add" class="btn btn-sm btn-success pull-right"><i class="fa fa-user-plus"></i> Tambah Validasi</button>


                    <div class="clearfix"></div>
                </div>
                <div class="x_content table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Jenis validasi</th>
                                <th>Tanggal Dibuat</th>
                                <th>Terakhir di Update</th>
                                <!-- <th>Dibuat Oleh</th> -->
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0;
                            foreach ($data as $key) {
                                $no++;
                                echo "<tr>
                                <td>" . $no . "</td>
                                <td>" . $key->nama_jenis_validasi . "</td>
                                <td>" . date('d-m-Y', strtotime($key->created_at)) . "</td>
                                <td>" . date('d-m-Y', strtotime($key->update_at)) . "</td>
                                
                                <td><button id='btn_edit' class='btn btn-sm btn-warning' value='$key->id' data-kode='$key->nama_jenis_validasi'><i class='fa fa-edit'></i></button> <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data" . $key->id . "'><i class='fa fa-trash'></i></a></td>
                                </tr>";
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
    <div class="row" style="display: none;" id="divforminsert">

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Karyawan</h2>

                    <div class="clearfix"></div>
                </div>
                <div class="x_content ">

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Nama Jenis validasi<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="text" id="jenis_validasi" required="required" class="form-control ">
                        </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                        <div class="col-md-6 col-sm-6 offset-md-3">
                            <button class="btn btn-primary" type="button">Cancel</button>
                            <button type="submit" id="btn_savejenisvalidasi" class="btn btn-success pull-right">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<?php $no = 0;
foreach ($data as $key) { ?>
    <div class="modal fade data<?= $key->id ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Apakah anda yakin akan menghapus <strong><?= $key->nama_jenis_validasi ?></strong>?</h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?del=<?= $key->id ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<div class="modal fade" id="form_edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Nama Jenis validasi<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="hidden" id="heditid" class="form-control ">
                        <input type="text" id="editjenis_validasi" required="required" class="form-control ">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="btn_editsimpan">Edit Data</button>
            </div>

        </div>
    </div>
</div>


<script>
    $(document).ready(function() {

    })
    $("#btn_add").click(function() {
        $("#divformview").hide("FadeIn");
        $("#divforminsert").show("FadeOut");
    })

    $(document).on('click', '#btn_savejenisvalidasi', function() {
        let jenis_validasi = $('#jenis_validasi').val();
        if (jenis_validasi == '') {
            new PNotify({
                text: 'Mohon Isi Jenis validasi Terlebih Dahulu!',
                type: 'error',
                styling: 'bootstrap3',
                delay: 3000,
                history: false
            })
            return false;
        }
        $.ajax({
            type: "POST",
            url: '<?= base_url('master/cek_namavalidasi') ?>',
            dataType: "JSON",
            data: {

                like: $('#jenis_validasi').val()
            },
            success: function(response) {
                if (response > 0) {
                    new PNotify({
                        text: 'Nama Jenis Sudah Ada, Mohon Ganti Lebih Spesifik!',
                        type: 'warning',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    return false;
                } else {
                    $.ajax({
                        type: "POST",
                        url: '<?= base_url('master/tambah_jenisvalidasi') ?>',
                        dataType: "JSON",
                        data: {
                            jenis_validasi: jenis_validasi
                        },
                        success: function(response) {
                            if (response) {
                                new PNotify({
                                    text: 'Data Telah disimpan!',
                                    type: 'succes',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 700);
                            }
                        }
                    })
                }
            }
        })

    })
    $(document).on('click', '#btn_edit', function() {
        let id = $(this).val();
        let value = $(this).attr('data-kode');
        $('#editjenis_validasi').val(value);
        $('#heditid').val(id);
        $('#form_edit').modal('show');
    })
    $(document).on('click', '#btn_editsimpan', function() {
        $.ajax({
            type: "POST",
            url: '<?= base_url('master/cek_namavalidasi') ?>',
            dataType: "JSON",
            data: {
                id: $('#heditid').val(),
                like: $('#editjenis_validasi').val()
            },
            success: function(response) {
                if (response > 0) {
                    new PNotify({
                        text: 'Nama Jenis Sudah Ada, Mohon Ganti Lebih Spesifik!',
                        type: 'warning',
                        styling: 'bootstrap3',
                        delay: 3000,
                        history: false
                    })
                    return false;
                } else {
                    $.ajax({
                        type: "POST",
                        url: '<?= base_url('master/edit_jenisvalidasi') ?>',
                        dataType: "JSON",
                        data: {
                            id: $('#heditid').val(),
                            jenisvalidasi: $('#editjenis_validasi').val()
                        },
                        success: function(response) {
                            if (response) {
                                new PNotify({
                                    text: 'Data Telah diubah!',
                                    type: 'succes',
                                    styling: 'bootstrap3',
                                    delay: 3000,
                                    history: false
                                })
                                setTimeout(() => window.location.reload(), 1000);
                            }
                        }
                    })
                }
            }
        })

    })
</script>