<div class="">
    <div class="page-title">
        <div class="title_left">
            <h3><?= $title ?></h3>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-4">
            <div class="x_panel">
                <div class="x_title">
                    <h2><?= $title1 ?></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form data-parsley-validate method="post" action="<?= base_url('master/save_statuspegawai') ?>">
                        <?php if (isset($_GET['id'])) {
                            $rows = where_row("statuspegawai", ['id' => $_GET['id']]);
                        } ?>
                        <?php if (isset($_GET['del'])) {
                            $this->db->delete("statuspegawai", ['id' => $_GET['del']]);
                            $this->session->set_flashdata("success", 'Data berhasil dihapus');
                            redirect("master/statuspegawai");
                        } ?>
                        <input type="hidden" name="id" value="<?= (isset($_GET['id']) ? $rows->id : "") ?>">
                        <div class="form-group">
                            <label for="first-name">Nama Status<span class="text-danger">*</span>
                            </label>
                            <input type="text" placeholder="Nama Status" required="required" class="form-control" name="name" autocomplete="off" value="<?= (isset($_GET['id']) ? $rows->name : "") ?>">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success"><i class="fa fa-save"></i> <?= (isset($_GET['id']) ? "Update" : "Simpan") ?></button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- content -->
        </div>
        <div class="col-md-8">
            <div class="x_panel">
                <div class="x_title">
                    <h2><?= $title2 ?></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr class="bg-dark text-white">
                                <th>No</th>
                                <th>Nama Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0;
                            if ($data != null) {
                                foreach ($data as $key) {
                                    $no++;
                                    echo "<tr>
                  <td>" . $no . "</td>
                  <td>" . $key->name . "</td>
                  <td><a href='?id=" . $key->id . "' class='btn btn-sm btn-warning'><i class='fa fa-edit'></i> Ubah</a> <a href='#' class='btn btn-sm btn-danger' data-toggle='modal' data-target='.data" . $key->id . "'><i class='fa fa-trash'></i> Hapus</a></td>
                  </tr>";
                                }
                            } else {
                                echo `<td colspan ="3">Data Kosong</td>`;
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- content -->
        </div>
    </div>
</div>

<?php $no = 0;
foreach ($data as $key) { ?>
    <div class="modal fade data<?= $key->id ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Penghapusan Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Pastikan anda yakin akan menghapus data <strong><?= $key->name ?></strong></h6>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-danger" href="?del=<?= $key->id ?>">Hapus Data</a>
                </div>

            </div>
        </div>
    </div>
<?php } ?>