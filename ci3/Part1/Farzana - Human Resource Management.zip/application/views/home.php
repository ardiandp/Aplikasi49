<style>
  .custom-checkbox-input {
    position: relative;
    z-index: 1;
    display: block;
    min-height: 1.5rem;
    padding-left: 1.5rem;
  }

  .custom-checkbox-input .form-check-input {
    width: 20px;
    height: 20px;
  }

  .custom-checkbox-input .form-check-input::after {
    content: '';
    display: inline-block;
    width: 20px;
    height: 20px;
    border: solid 1px grey;
    border-radius: 2px;
  }

  .custom-checkbox-input .form-check-input-acc {
    width: 20px;
    height: 20px;
  }

  .custom-checkbox-input .form-check-input-acc::after {
    content: '';
    display: inline-block;
    width: 20px;
    height: 20px;
    border: solid 1px grey;
    border-radius: 2px;
  }

  .custom-checkbox-input .form-check-input:checked::after {
    width: 20px;
    height: 20px;
    border: solid 1px red;
    content: 'X';
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    background-color: red;
    color: white;
    text-align: center;
    font-size: 13px;
    position: relative;
    top: 0px;

  }

  .custom-checkbox-input .form-check-input-acc:checked::after {
    width: 20px;
    height: 20px;
    border: solid 1px lightgreen;
    content: '\f00c';
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    background-color: lightgreen;
    color: white;
    text-align: center;
    font-size: 13px;
    position: relative;
    top: 0px;

  }

  .custom-checkbox-input .form-check-input .custom-color-grey::after {
    background-color: grey;
  }

  .custom-checkbox-input .form-check-input .custom-color-white::after {
    background-color: white;
  }

  .custom-checkbox-input .form-check-input-acc .custom-color-white::after {
    background-color: white;
  }

  a:not([href]):not([tabindex]) {
    color: white !important;
  }
</style>

<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3><?= $title ?></h3>
    </div>


  </div>

  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-4">
      <div class="x_panel">
        <div class="x_title">
          <h2>Server Whatsapp</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <div class="whatsapp"></div>
        </div>
      </div>
      <!-- content -->
    </div>
    <div class="col-md-4">
      <div class="x_panel">
        <div class="x_title">
          <h2>Request ke Sekretaris</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">

          </ul>
        </div>
      </div>
      <!-- content -->
    </div>
    <div class="col-md-4">
      <div class="x_panel">
        <div class="x_title">
          <h2>Distribusi Gaji</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">

          </ul>
        </div>
      </div>
      <!-- content -->
    </div>
    <div class="col-md-12 col-sm-12 ">
      <div class="x_panel">
        <div class="x_title">
          <h2>Approval Pengajuan</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-lg-6 col-md-4 col-sm-4">

              <div class="item form-group">
                <label class="col-form-label col-md-6 col-sm-6 " name="CAPTION-PERUSAHAAN">Jenis Validasi</label>
                <div class="col-md-6 col-sm-6">
                  <select class="form-control select2" name="filter_jenisvalidasi" id="filter_jenisvalidasi" required>
                    <option value="">Pilih Jenis Validasi</option>
                    <?php foreach (show_data("jenis_validasi") as $un) : ?>
                      <option value="<?= $un->id ?>">
                        <?= $un->nama_jenis_validasi ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
            </div>


            <div class="item form-group">
              <div class="col-md-12 col-sm-12 text-left">
                <a class="btn btn-md btn-primary btn-submit-filter" onclick="getOutstandingApproval()" name="CAPTION-CARI">Cari</a>
              </div>
            </div>


          </div>
          <div class="row">
            <div class="table-responsive">
              <table id="tableApproval" width="100%" class="table table-striped table-bordered">
                <thead>
                  <tr class="bg-dark text-white">
                    <th name="CAPTION-NO">No</th>
                    <th name="">Nama Aktivitas</th>
                    <th name="">Jumlah</th>
                  </tr>
                </thead>
                <tbody>

                </tbody>
              </table>
            </div>
          </div>



        </div>
      </div>
      <!-- content -->
    </div>
  </div>


</div>

<!-- modal view approval-->
<div class="modal fade" id="modalApproval" role="dialog" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-xl" style="width: 100%;">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header ">
        <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
        <h4 class="modal-title"><label name="CAPTION-CAPTION-LISTAPPROVAL" style="background-color: white;">List Approval</label></h4>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="table-responsive">
            <table id="tableDetailApproval" style="width:100%" class="table table-striped table-bordered">
              <thead>
                <tr class="bg-dark text-white">
                  <th style="text-align: center;" name="CAPTION-NO"></th>
                  <th style="text-align: center;" name="CAPTION-NO">No</th>
                  <th style="text-align: center;">Tgl Pengajuan</th>
                  <th style="text-align: center;">Diajukan Oleh</th>
                  <!-- <th style="text-align: center;" name="CAPTION-NODOKUMEN">No Dokumen</th> -->
                  <th style="text-align: center;">Step 1</th>
                  <th style="text-align: center;">Step 2</th>
                  <th style="text-align: center;">Step 3</th>
                  <th style="text-align: center;">Step 4</th>
                  <th style="text-align: center;">Step 5</th>
                  <th style="text-align: center;">Disetujui</th>
                  <th style="text-align: center;">Ditolak</th>
                  <th style="text-align: center;">Ditunda</th>


                </tr>
              </thead>
              <tbody>

              </tbody>
            </table>
          </div>

        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" id="saveApproval"><i class="fas fa-floppy-disk"></i>
          <label name="CAPTION-SAVE">Simpan</label></button>
        <button type="button" class="btn btn-dark btnclosemodalbuatpackingdo" data-dismiss="modal"><i class="fas fa-xmark"></i> <label name="CAPTION-TUTUP">Tutup</label></button>

      </div>




    </div>
  </div>
</div>
<script>
  $(document).on('change', '#filter_jenisvalidasi', function() {
    let val = $(this).val()
    $.ajax({
      type: 'POST',
      url: '<?= base_url('Approval/getdataapprovalbyjenis') ?>',
      async: false,
      data: {
        id: val
      },
      dataType: "JSON",
      success: function(response) {

        if (response != null) {
          $('#tableApproval >tbody').empty()

          $.each(response, function(i, v) {


            $('#tableApproval >tbody').append(`<tr id='${i}'>
                            <td>${i+1}</td>
                            <td>${v.nama_aktivitas}</td>
                            
                            <td> 
                              <a class="btn btn-primary" onclick="detailApproval('${val}')">${this.jumlah}</a>
                            </td>
                        </tr>`);

          })
        }
      }
    })
  })

  function detailApproval(approval_id) {
    $('#modalApproval').modal("show");
    console.log(approval_id);
    // select * FROM karyawan left join jabatan on jabatan.id = karyawan.id_jabatan LEFT JOIN role on role.id = jabatan.id_role where karyawan.id =110;
    $.ajax({
      type: 'POST',
      url: '<?= base_url('Approval/getdatadetailapproval') ?>',
      async: false,
      data: {
        id: approval_id
      },
      dataType: "JSON",
      success: function(response) {
        if (response != null) {
          $('#tableDetailApproval >tbody').empty()

          let step = '';
          $.each(response, function(i, v) {

            // if (v.step1 != null) {
            //   step += v.step1
            // } else if (v.step1 != null && (v.step2 == null || v.step3 != null)) {
            //   step += v.step2
            // } else if (v.step2 != null && (v.step3 == null == v.step3 != null)) {
            //   step += v.step3
            // } else if (v.step3 != null && (v.step4 == null || v.step4 != null)) {
            //   step += v.step4
            // } else if (v.step4 != null && (v.step5 == null || v.step5 != null)) {
            //   step += v.step5
            // }

            $('#tableDetailApproval >tbody').append(`
              <tr id='${i}'>
               <td><input type='checkbox' id='cbpilihapproval' name='cbpilihapproval' onchange="handler(event,${i})"></td>
                                <td class="id_approval" style="display:none;">${v.id_approval}</td>
                                <td class="idx_approval" style="display:none;">${i}</td>
                                <td class="">${i+1}</td>
                                <td class="tgl_pengajuan">${v.tgl_pengajuan}</td>
                                <td class="nama_karyawan_${i}"><span id="nama_karyawan_${i}">${v.nama_karyawan}</span></td>
                                <td class="step1">${v.step1==null?'':v.step1}</td>
                                <td class="step2">${v.step2==null?'':v.step2}</td>
                                <td class="step3">${v.step3==null?'':v.step3}</td>
                                <td class="step4">${v.step4==null?'':v.step4}</td>
                                <td class="step5">${v.step5==null?'':v.step5  }</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovaldisetujui${i}' name='radioapproval${i}' disabled readonly value="disetujui">Disetujui</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovalditolak${i}' name='radioapproval${i}' disabled readonly value ="ditolak">Ditolak</td>
                                <td class="radioapproval_${i}"><input type='radio' id='radioapprovalditunda${i}' name='radioapproval${i}' disabled readonly value="ditunda">Ditunda</td>
                            </tr>`);

            // <td> 
            //   <a class="btn btn-primary" onclick="detailApproval('${this.approval_setting_id}','${this.approval_setting_jenis}')">${this.jumlah}</a>
            //           </td>

          })
        }
      }
    })

  }
  const handler = (e, i) => {
    if (e.currentTarget.checked == true) {
      $(`input[name="radioapproval${i}"]`).each(function() {
        $(this).prop('disabled', false);
        $(this).prop('checked', false);
      });
    } else {
      $(`input[name="radioapproval${i}"]`).each(function() {
        $(this).prop('disabled', true);
        $(this).prop('checked', false);
      });
    }
    // event.currentTarget.value
  }


  $(document).on('click', '#cbpilihapproval', function() {

  })
  $(document).on('click', '#saveApproval', function() {
    let arratemp = [];
    let table = $('#tableDetailApproval >tbody >tr').length;

    $('#tableDetailApproval >tbody >tr').each(function(i, v) {

      $(`input[name="radioapproval${i}"]:radio:checked`).each(function() {
        let step1 = $(this).closest("tr").find("td:nth-child(6)").text()
        let step2 = $(this).closest("tr").find("td:nth-child(7)").text()
        let step3 = $(this).closest("tr").find("td:nth-child(8)").text()
        let step4 = $(this).closest("tr").find("td:nth-child(9)").text()
        let step5 = $(this).closest("tr").find("td:nth-child(10)").text()
        if (step1 == 'Ditolak' || step2 == 'Ditolak' || step3 == 'Ditolak' || step4 == 'Ditolak' || step5 == 'Ditolak') {
          alert(`Permohonan ke ${i+1} Telah ditolak, Mohon Tidak Di Pilih`);
          return false;
        }
        arratemp.push({
          'id': $(this).closest("tr").find("td:nth-child(2)").text(),
          'id_karyawan': $(this).closest("tr").find("td:nth-child(3)").text(),
          'status': $(this).parent().text()
        })
      });

    })
    if (arratemp.length == 0) {
      alert("Mohon Pilih Data")
      return false;
    }
    return false;
    $.ajax({
      type: 'POST',
      url: '<?= base_url('Approval/SaveApproval') ?>',
      async: false,
      data: {
        arr: arratemp
      },
      dataType: "JSON",
      success: function(response) {
        console.log(response);
      }
    })

  })
</script>