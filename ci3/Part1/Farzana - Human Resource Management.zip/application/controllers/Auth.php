<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 * 
 */
class Auth extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_Login', 'login');
	}
	public function index()
	{
		$this->load->view("auth");
	}

	public function lupa_password()
	{
		$this->load->view("lupa_password");
	}
	public function action()
	{
		echo json_encode($this->login->cek_login(post("username"), post("password"), post("type")));
	}

	public function lupa_password_action()
	{
		$dataPost = $this->input->post();

		$users = where_row('karyawan', ['email' => $dataPost['email']]);
		if (!empty($users)) {
			if ($users->status != 0) {
				$token = random_string('alnum', 15);
				$dataToken = [
					'email' => $dataPost['email'],
					'token' => $token,
					'type' => 1,
					'created_at' => date('Y-m-d H:i:s')
				];
				insert_table('verify_token', $dataToken);
				insert_logAktivitas('Permintaan untuk lupa password');
				$this->_sendEmail($token, $dataPost['email']);

				$response = [
					'type' => 200,
					'message' => 'Permintan reset password telah terkirim, silahkan cek email anda'
				];
			} else {
				$response = [
					'type' => 203,
					'message' => 'Permintan reset password gagal, email belum diaktivasi'
				];
			}
		} else {
			$response = [
				'type' => 203,
				'message' => 'Permintan reset password gagal, email tidak ditemukan'
			];
		}

		echo json_encode($response);
	}

	private function _sendEmail($token, $email)
	{

		$config = [
			'mailtype'  => 'html',
			'charset'   => 'utf-8',
			'protocol'  => 'smtp',
			'smtp_host' => 'smtp.gmail.com',
			'smtp_user' => 'akbaraisyah000@gmail.com',  // Email gmail
			'smtp_pass'   => 'jngvwzwxosmldgqv',  // Password gmail
			'smtp_crypto' => 'ssl',
			'smtp_port'   => 465,
			'crlf'    => "\r\n",
			'newline' => "\r\n"
		];

		// Load library email dan konfigurasinya
		$this->load->library('email');
		$this->email->initialize($config);

		// Email dan nama pengirim
		$this->email->from('support@ekitir.com', 'YBN');

		// Email penerima
		$this->email->to($email); // Ganti dengan email tujuan


		// Isi email
		$this->email->subject("Reset Your Password");
		$message = "";
		$href = base_url('Auth') . "/reset_password?email=" . $email . "&token=" . $token;
		$message .= '<div class="email" style="border: 1px solid gray;border-radius: 10px;padding: 15px;min-height: 15vh;position: relative;margin: auto;width: 70%;text-align: center;">
						<h3 style="font-weight: 800;">Permintan Reset Password</h3>
						<h6 style="font-weight: 200;margin-top: 10px;">Permintaan reset password terpenuhi, silahkan klik button dibawah untuk reset password</h6>

						<a href="' . $href . '" style="padding: 15px;font-size: 20px;background: #0e7490;border-radius: 10px;font-weight: 700;color: white;font-family: monospace;">Reset Password</a>
					</div>';
		$this->email->message($message);

		// Tampilkan pesan sukses atau error
		if ($this->email->send()) {
			return true;
		} else {
			echo $this->email->print_debugger();
			die;
		}
	}


	public function verify()
	{
		$email = $this->input->get('email');
		// $token = $this->input->get('token');

		$user = where_row('karyawan', ['email' => $email]);
		//cek apakah email ada di bird_farm
		if (!empty($user)) {
			if ($user->status == 0) {
				$this->db->set('status', 1);
				$this->db->where('email', $email);
				$this->db->update('karyawan');

				insert_logAktivitas('Melakukan aktivasi akun');

				// $this->db->delete('verify_token', ['email' => $email]);

				$this->session->set_flashdata("success", $email . 'telah aktif! silahkan login');
				redirect('Auth');
			} else {
				$this->session->set_flashdata("info", $email . 'email telah terverifikasi');
				redirect('Auth');
			}
		} else {
			$this->session->set_flashdata("error", $email . 'gagal verifikasi! email tidak cocok');
			redirect('Auth');
		}
	}

	public function reset_password()
	{
		$email = $this->input->get('email');
		$token = $this->input->get('token');

		$user = where_row('karyawan', ['email' => $email]);
		//cek apakah email ada di bird_farm
		if (!empty($user)) {
			if ($user->status != 0) {
				$userToken = where_row('verify_token', ['email' => $email, 'token' => $token, 'type' => 1]);
				if (!empty($userToken)) {
					$this->load->view("reset_password");
				} else {
					$this->session->set_flashdata("error", $email . 'gagal reset password! token tidak cocok');
					redirect('Auth');
				}
			} else {
				$this->session->set_flashdata("error", $email . 'gagal reset password! email belum diaktivasi');
				redirect('Auth');
			}
		} else {
			$this->session->set_flashdata("error", $email . 'gagal reset password! email tidak cocok');
			redirect('Auth');
		}
	}

	public function reset_password_action()
	{
		$dataPost = $this->input->post();
		$user = where_row('karyawan', ['email' => $dataPost['email']]);
		//cek apakah email ada di bird_farm
		if (!empty($user)) {
			if ($user->status != 0) {
				$userToken = where_row('verify_token', ['email' => $dataPost['email'], 'token' => $dataPost['token'], 'type' => 1]);
				if (!empty($userToken)) {
					$this->db->set('password', create_pass($dataPost['password']));
					$this->db->where('email', $dataPost['email']);
					$result = $this->db->update('karyawan');
					if ($result) {
						$this->db->delete('verify_token', ['email' => $dataPost['email'], 'token' => $dataPost['token'], 'type' => 1]);

						insert_logAktivitas('Reset password akun');

						$response = [
							'type' => 200,
							'message' => 'Reset password berhasil, silahkan login kembali'
						];
					} else {
						$response = [
							'type' => 203,
							'message' => 'Kesalahan server, silahkan coba lagi'
						];
					}
				} else {
					$response = [
						'type' => 203,
						'message' => 'Permintan reset password gagal, token tidak cocok'
					];
				}
			} else {
				$response = [
					'type' => 203,
					'message' => 'Permintan reset password gagal, email belum diaktivasi'
				];
			}
		} else {
			$response = [
				'type' => 203,
				'message' => 'Permintan reset password gagal, email tidak cocok'
			];
		}

		echo json_encode($response);
	}


	public function logout()
	{
		$this->session->sess_destroy();
		redirect('home', 'refresh');
	}
}
