<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Laporan extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_Login', 'login');
		$this->load->model('M_MenuAkses', 'akses');
		cek_session();
	}
	public function index()
	{
		$login = $this->login->session();
		$users = where_row('users', ['username' => $login['username']]);
		$data = [
			'users' => $users,
			'title' => 'Laporan Penggajian',
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'laporan', $data);
	}
	public function kirim_sekretaris()
	{
		$inv = "PAY/YBM/" . date("ym");
		$this->db->like("date", date("Y-m"))->update("gaji", ['send_sekretaris' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s")]);
		$cek_log = $this->db->get_where('log_gaji', ['inv' => $inv])->num_rows();
		if ($cek_log == 0) {
			$this->db->insert('log_gaji', [
				'inv' => $inv,
				'date' => date("Y-m-d"),
				'send_sekretaris' => date("Y-m-d H:i:s")
			]);
		} else {
			$this->db->update('log_gaji', [
				'date' => date("Y-m-d"),
				'send_sekretaris' => date("Y-m-d H:i:s")
			], ['inv' => $inv]);
		}
		redirect("laporan?bulan=" . date('m') . "&tahun=" . date("Y"));
	}
	public function terima_sekretaris()
	{

		$this->db->query("UPDATE `gaji` SET `approve_sekretaris`=" . date("Y-m-d H:i:s") . " WHERE date LIKE '%" . date('Y-m') . "%'");
		$inv = "PAY/YBM/" . date("ym");
		$cek_log = $this->db->get_where('log_gaji', ['inv' => $inv])->num_rows();
		if ($cek_log == 0) {
			$this->db->insert('log_gaji', [
				'inv' => $inv,
				'date' => date("Y-m-d"),
				'approve_sekretaris' => date("Y-m-d H:i:s")
			]);
		} else {
			$this->db->update('log_gaji', [
				'date' => date("Y-m-d"),
				'approve_sekretaris' => date("Y-m-d H:i:s")
			], ['inv' => $inv]);
		}
		redirect("laporan?bulan=" . date('m') . "&tahun=" . date("Y"));
	}
	public function tolak_sekretaris()
	{

		$this->db->query("UPDATE `gaji` SET `send_sekretaris`=NULL,`status`=0 WHERE date LIKE '%" . date('Y-m') . "%'");
		$inv = "PAY/YBM/" . date("ym");
		$cek_log = $this->db->get_where('log_gaji', ['inv' => $inv])->num_rows();
		if ($cek_log == 0) {
			$this->db->insert('log_gaji', [
				'inv' => $inv,
				'date' => date("Y-m-d"),
				'approve_sekretaris' => date("Y-m-d H:i:s")
			]);
		} else {
			$this->db->update('log_gaji', [
				'date' => date("Y-m-d"),
				'approve_sekretaris' => date("Y-m-d H:i:s")
			], ['inv' => $inv]);
		}
		redirect("laporan?bulan=" . date('m') . "&tahun=" . date("Y"));
	}
	public function kirim_bendahara()
	{
		$this->db->query("UPDATE `gaji` SET `send_bendahara`='" . date("Y-m-d H:i:s") . "' WHERE date LIKE '%" . date('Y-m') . "%'");
		$inv = "PAY/YBM/" . date("ym");
		$cek_log = $this->db->get_where('log_gaji', ['inv' => $inv])->num_rows();
		if ($cek_log == 0) {
			$this->db->insert('log_gaji', [
				'inv' => $inv,
				'date' => date("Y-m-d"),
				'send_bendahara' => date("Y-m-d H:i:s")
			]);
		} else {
			$this->db->update('log_gaji', [
				'date' => date("Y-m-d"),
				'send_bendahara' => date("Y-m-d H:i:s")
			], ['inv' => $inv]);
		}
		redirect("laporan?bulan=" . date('m') . "&tahun=" . date("Y"));
	}
	public function terima_bendahara()
	{
		$this->db->query("UPDATE `gaji` SET `approve_bendahara`='" . date("Y-m-d H:i:s") . "' WHERE date LIKE '%" . date('Y-m') . "%'");
		$inv = "PAY/YBM/" . date("ym");
		$cek_log = $this->db->get_where('log_gaji', ['inv' => $inv])->num_rows();
		if ($cek_log == 0) {
			$this->db->insert('log_gaji', [
				'inv' => $inv,
				'date' => date("Y-m-d"),
				'approve_bendahara' => date("Y-m-d H:i:s")
			]);
		} else {
			$this->db->update('log_gaji', [
				'date' => date("Y-m-d"),
				'approve_bendahara' => date("Y-m-d H:i:s")
			], ['inv' => $inv]);
		}
		redirect("laporan?bulan=" . date('m') . "&tahun=" . date("Y"));
	}
	public function tolak_bendahara()
	{
		//$this->db->like("date",date("Y-m"))->update("gaji",['approve_bendahara'=>NULL,'updated_at'=>NULL,'status'=>1]);
		$this->db->query("UPDATE `gaji` SET `approve_bendahara`=NULL WHERE date LIKE '%" . date('Y-m') . "%'");
		$inv = "PAY/YBM/" . date("ym");
		$cek_log = $this->db->get_where('log_gaji', ['inv' => $inv])->num_rows();
		if ($cek_log == 0) {
			$this->db->insert('log_gaji', [
				'inv' => $inv,
				'date' => date("Y-m-d"),
				'approve_bendahara' => date("Y-m-d H:i:s")
			]);
		} else {
			$this->db->update('log_gaji', [
				'date' => date("Y-m-d"),
				'approve_bendahara' => date("Y-m-d H:i:s")
			], ['inv' => $inv]);
		}
		redirect("laporan?bulan=" . date('m') . "&tahun=" . date("Y"));
	}
	public function cetak($id)
	{
		$inv = "PAY/YBM/" . date("ym");
		$cek_log = $this->db->get_where('log_gaji', ['inv' => $inv])->num_rows();
		if ($cek_log == 0) {
			$this->db->insert('log_gaji', [
				'inv' => $inv,
				'date' => date("Y-m-d"),
				'transfer' => date("Y-m-d H:i:s")
			]);
		} else {
			$this->db->update('log_gaji', [
				'date' => date("Y-m-d"),
				'transfer' => date("Y-m-d H:i:s")
			], ['inv' => $inv]);
		}
		$this->pdf->setPaper('A4', 'potrait');
		$this->pdf->filename = "laporan-petanikode.pdf";
		$options = $this->pdf->getOptions();
		$options->set(array('isRemoteEnabled' => true));
		$this->pdf->setOptions($options);
		$login = $this->login->session();
		$users = where_row('users', ['username' => $login['username']]);
		$data = [
			'users' => $users,
			'title' => 'Laporan Penggajian',
		];
		$this->pdf->load_view('cetak', $data);
		//$this->load->view('cetak');
	}
}
