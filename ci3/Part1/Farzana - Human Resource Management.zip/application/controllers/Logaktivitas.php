<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Logaktivitas extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }
    public function index()
    {
        $login = $this->login->session();

        $dataLog = $this->db->query("SELECT a.id, b.name, a.deskripsi, a.created_at, c.name as jabatan, d.nama as role
                                     FROM log_aktivitas a
                                     LEFT JOIN users b ON a.id_users = b.id
                                     LEFT JOIN jabatan c ON b.id_jabatan = c.id
                                     LEFT JOIN role d ON c.id_role = d.id
                                     WHERE b.name is not null

                                     UNION ALL

                                     SELECT a.id, b.name, a.deskripsi, a.created_at, c.name as jabatan, d.nama as role
                                     FROM log_aktivitas a
                                     LEFT JOIN karyawan b ON a.id_karyawan = b.id
                                     LEFT JOIN jabatan c ON b.id_jabatan = c.id
                                     LEFT JOIN role d ON c.id_role = d.id
                                     WHERE b.name is not null")->result();


        $users = where_row('users', ['username' => $login['username']]);
        $data = [
            'users' => $users,
            'dataLog' => $dataLog,
            'title' => 'Data Log Aktivitas',
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'logaktivitas', $data);
    }
}
