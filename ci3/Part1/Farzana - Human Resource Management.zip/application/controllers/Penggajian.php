<?php

/**
 * 
 */
class Penggajian extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_Login', 'login');
		$this->load->model('M_MenuAkses', 'akses');
		cek_session();
	}
	public function index()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Penggajian',
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'penggajian', $data);
	}
	public function save_pay_one()
	{
		$data = $this->input->post();
		$cek = $this->db->like('date', date("Y-m"))->get_where("gaji", ['karyawan' => post('karyawan')])->num_rows();
		if ($cek == 0) {
			$this->db->insert("gaji", [
				'karyawan' => $data['karyawan'],
				'p1' => $data['total_p1'],
				'p1_1' => $data['p1_1'],
				'p1_2' => $data['p1_2'],
				'date' => date("Y-m-d")
			]);
		} else {
			$this->db->like('date', date("Y-m"))->update("gaji", ['p1' => post('total_p1'), 'p1_1' => post('p1_1'), 'p1_2' => post('p1_2')], ['karyawan' => post('karyawan')]);
		}
		echo "success";
	}
	public function save_pay_two()
	{
		$data = $this->input->post();
		$tunjangan = where_row("int_tunjangan", ['karyawan' => post("karyawan")]);
		$amount = json_decode($tunjangan->tunjangan);
		foreach ($amount as $key => $value) {
			if ($key == "lainnya") {
				$json[] = ["lainnya" => post("lainnya")];
			} else {
				$json[] = [
					"cuti" => post("cuti"),
					"kemahalan" => post("kemahalan"),
					"sertifukasi" => post("sertifukasi"),
					"khusus" => post("khusus"),
					"perumahan" => post("perumahan"),
					"komunikasi" => post("komunikasi"),
					"posisi" => post("posisi"),
					"lainnya" => post("lainnya")
				];
			}
		}
		$data = json_encode($json);
		$hasil = str_replace("[", "", $data);
		$hasils = str_replace("]", "", $hasil);
		$h = str_replace("{", "", $hasils);
		$hl = str_replace("}", "", $h);
		$h2 = "{" . $hl . "}";
		$this->db->update("int_tunjangan", ['tunjangan' => $h2], ['karyawan' => post("karyawan")]);
		$cek = $this->db->like('date', date("Y-m"))->get_where("gaji", ['karyawan' => post('karyawan')])->num_rows();
		if ($cek == 0) {
			$this->db->insert("gaji", [
				'karyawan' => $data['karyawan'],
				'p2' => $data['total_p2'],
				'date' => date("Y-m-d")
			]);
		} else {
			$this->db->update("gaji", ['p2' => post('total_p2')], ['karyawan' => post('karyawan')]);
		}
		echo "success";
	}
	public function save_pay_three()
	{
		$data = $this->input->post();
		$bonus = where_row("int_bonus", ['karyawan' => post("karyawan")]);
		$amounts = json_decode($bonus->bonus);
		foreach ($amounts as $keys => $values) {
			if ($keys == "lainnya") {
				$jsons[] = [
					"karyawan" => post("karyawan"),
					"lainnya" => post("lainnya")
				];
			} else {
				$jsons[] = [
					"insentif_ramadhan" => post("ramadhan"),
					"thr" => post("thr"),
					"iks_i_2022" => post("iks_i_2022"),
					"lainnya" => post("lainnya")
				];
			}
		}
		$datas = json_encode($jsons);
		$hasils = str_replace("[", "", $datas);
		$hasilss = str_replace("]", "", $hasils);
		$hs = str_replace("{", "", $hasilss);
		$hls = str_replace("}", "", $hs);
		$h2s = "{" . $hls . "}";
		$this->db->update("int_bonus", ['bonus' => $h2s], ['karyawan' => post("karyawan")]);
		$cek = $this->db->like('date', date("Y-m"))->get_where("gaji", ['karyawan' => post('karyawan')])->num_rows();
		if ($cek == 0) {
			$this->db->insert("gaji", [
				'karyawan' => $data['karyawan'],
				'p3' => $data['total_p3'],
				'date' => date("Y-m-d")
			]);
		} else {
			$this->db->update("gaji", ['p3' => post('total_p3')], ['karyawan' => post('karyawan')]);
		}
		echo "success";
	}
	public function hitung_gaji()
	{
		$data = $this->input->post();
		$cek = $this->db->like('date', date("Y-m"))->get_where("gaji", ['karyawan' => post('karyawan')])->num_rows();
		if ($cek == 0) {
			$this->db->insert("gaji", [
				'karyawan' => $data['karyawan'],
				'total' => $data['total_gaji'],
				'date' => date("Y-m-d")
			]);
		} else {
			$this->db->update("gaji", ['total' => post('total_gaji')], ['karyawan' => post('karyawan')]);
		}
		echo "success";
	}
	public function hitung_potongan()
	{
		$data = $this->input->post();
		$cek = $this->db->like('date', date("Y-m"))->get_where("potongan", ['karyawan' => post('karyawan')])->num_rows();
		if ($cek == 0) {
			$this->db->insert("potongan", [
				'karyawan' => $data['karyawan'],
				'dplk' => $data['dplk'],
				'pot_lainnya' => $data['pot_lainnya'],
				'total_potongan' => $data['total_potongan'],
				'date' => date("Y-m-d")
			]);
		} else {
			$this->db->update("potongan", [
				'dplk' => $data['dplk'],
				'pot_lainnya' => $data['pot_lainnya'],
				'total_potongan' => $data['total_potongan'],
			], ['karyawan' => post('karyawan')]);
		}
		echo "success";
	}
	public function genrate_gaji()
	{
		$this->db->like('date', date("Y-m"))->update("gaji", ['status' => 1], ['karyawan' => post('karyawan')]);
		$data = $this->db->like('date', date("Y-m"))->get_where("gaji", ['status' => 1], ['karyawan' => post('karyawan')])->row();
		echo "success";
	}
	public function karyawan($id)
	{
		echo '<div class="col-md-5">';
		$data = where_result("penerimaan", ['unit' => $id]);
		echo "<select class='form-control' name='user'>";
		echo "<option>Pilih Karyawan</option>";
		foreach ($data as $key) {
			$k = where_row("karyawan", ['id' => $key->karyawan]);
			$cek_gaji = $this->db->like('date', date("y-m"))->get_where("gaji", ['karyawan' => $key->karyawan, 'status' => 1])->num_rows();
			if ($cek_gaji == 0) {
				echo "<option value='" . $k->id . "'>" . $k->name . "</option>";
			}
		}
		echo "</select>";
		echo '</div>
            <div class="col-md-2">
              <button class="btn btn-primary"><i class="fa fa-eye"></i> Munculkan</button>
            </div>';
	}
}
