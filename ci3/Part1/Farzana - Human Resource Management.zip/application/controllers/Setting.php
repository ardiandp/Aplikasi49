<?php

/**
 * 
 */
class Setting extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_Login', 'login');
		$this->load->model('M_MenuAkses', 'akses');
		cek_session();
	}
	public function karyawan()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Penerimaan Karyawan',
			'data' => $this->db->select('karyawan.name as nama_karyawan,unit.name as nama_unit, penerimaan.*')->join('unit', 'unit.id=penerimaan.unit')->join('karyawan', 'karyawan.id=penerimaan.karyawan')->get('penerimaan')->result(),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/karyawan', $data);
	}
	public function gaji()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Pengaturan Gaji',
			'data' => $this->db->select('karyawan.name as nama_karyawan,int_tunjangan.*')->join('karyawan', 'karyawan.id=int_tunjangan.karyawan')->get('int_tunjangan')->result(),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/gaji', $data);
	}
	public function tunjangan()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Pengaturan Tunjangan',
			'tunjangan' => show_data('tunjangan'),
			'data' => $this->db->select('karyawan.name as nama_karyawan,int_tunjangan.*')->join('karyawan', 'karyawan.id=int_tunjangan.karyawan')->get('int_tunjangan')->result(),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/tunjangan', $data);
	}
	public function bonus()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Pengaturan Bonus',
			'tunjangan' => show_data('bonus'),
			'data' => $this->db->select('karyawan.name as nama_karyawan,int_bonus.*')->join('karyawan', 'karyawan.id=int_bonus.karyawan')->get('int_bonus')->result(),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/bonus', $data);
	}
	public function penerimaan()
	{
		$data = $this->input->post();
		if (where_count('penerimaan', ['karyawan' => $data['karyawan']]) != 0) {
			$this->session->set_flashdata("error", 'Data penerimaan karyawan gagal disimpan');
			redirect("setting/karyawan");
		} else {
			$data['created_at'] = date("Y-m-d H:i:s");
			$save = insert_table('penerimaan', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data penerimaan karyawan berhasil disimpan');
				redirect("setting/karyawan");
			} else {
				$this->session->set_flashdata("error", 'Data penerimaan karyawan gagal disimpan');
				redirect("setting/karyawan");
			}
		}
	}
	public function save_tunjangan()
	{
		$data = $this->input->post();
		$insert = [
			'karyawan' => $data['karyawan'],
			'tunjangan' => json_encode($data),
		];
		$cek = where_count("int_tunjangan", ['karyawan' => $data['karyawan']]);
		if ($cek == 0) {
			$save = insert_table('int_tunjangan', $insert);
			insert_table('log_tunjangan', $insert);
		} else {
			$save = update_table('int_tunjangan', $insert, ['karyawan' => $data['karyawan']]);
			insert_table('log_tunjangan', $insert);
		}

		if ($save) {
			$this->session->set_flashdata("success", 'Data pengaturan tunjangan berhasil disimpan');
			redirect("setting/tunjangan");
		} else {
			$this->session->set_flashdata("error", 'Data pengaturan tunjangan karyawan gagal disimpan');
			redirect("setting/tunjangan");
		}
	}
	public function save_bonus()
	{
		$data = $this->input->post();
		$insert = [
			'karyawan' => $data['karyawan'],
			'bonus' => json_encode($data),
		];
		$cek = where_count("int_bonus", ['karyawan' => $data['karyawan']]);
		if ($cek == 0) {
			$save = insert_table('int_bonus', $insert);
			insert_table('log_bonus', $insert);
		} else {
			$save = update_table('int_bonus', $insert, ['karyawan' => $data['karyawan']]);
			insert_table('log_bonus', $insert);
		}
		if ($save) {
			$this->session->set_flashdata("success", 'Data pengaturan bonus berhasil disimpan');
			redirect("setting/bonus");
		} else {
			$this->session->set_flashdata("error", 'Data pengaturan bonus karyawan gagal disimpan');
			redirect("setting/bonus");
		}
	}

	public function banner()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Pengaturan Banner',
			// 'banner' => show_data('banner'),
			'data' => show_data('banner'),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/banner', $data);
	}
	public function save_banner()
	{
		$data = $this->input->post();

		$uploadDirectory = "assets/upload/banner/";
		$fileExtensionsAllowed = ['jpeg', 'jpg', 'png', 'gif', 'JPG', 'JPEG', 'GIF']; // Allowed file extensions
		$fileName = $_FILES['imgfoto']['name'];
		$fileSize = $_FILES['imgfoto']['size'];

		$fileTmpName  = $_FILES['imgfoto']['tmp_name'];
		$fileType = $_FILES['imgfoto']['type'];
		$files = explode(".", $fileName);
		$name_file = $files[0] . '-' . time() . '.' . strtolower(end($files));
		// 

		if (empty($fileName)) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! File Attactment tidak boleh kosong');
			redirect("Setting/banner");
		} else {
			if ($fileSize > 1024000) {

				$this->session->set_flashdata("error", 'Data gagal disimpan! Ukuran file maks 1mb');
				redirect("Setting/banner");
			} else {
				if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
					$this->session->set_flashdata("error", 'Data gagal disimpan! ekstensi tidak sesuai');
					redirect("Setting/banner");
				} else {
					$uploadPath = $uploadDirectory . $name_file;
					$didUpload = move_uploaded_file($fileTmpName, $uploadPath);
					if (!$didUpload) {
						$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
						redirect("Setting/banner");
					} else {
						insert_table('banner', ['img_url' => $name_file]);
						$this->session->set_flashdata("success", 'Data berhasil disimpan!');
						redirect("Setting/banner");
					}
				}
			}
		}
	}
	public function edit_banner()
	{
		$data = $this->input->post();

		//get name file in db
		$nameFile = $this->db->select('img_url as file')->from('banner')->where('id', $data['hidbanner'])->get()->row();
		unlink('assets/upload/banner/' . $nameFile->file);


		$uploadDirectory = "assets/upload/banner/";
		$fileExtensionsAllowed = ['jpeg', 'jpg', 'png', 'gif', 'JPG', 'JPEG', 'GIF']; // Allowed file extensions
		$fileName = $_FILES['imgfotoupdate']['name'];
		$fileSize = $_FILES['imgfotoupdate']['size'];
		$fileTmpName  = $_FILES['imgfotoupdate']['tmp_name'];
		$fileType = $_FILES['imgfotoupdate']['type'];
		$files = explode(".", $fileName);
		$name_file = $files[0] . '-' . time() . '.' . strtolower(end($files));

		if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Ukuran file maks 1mb');
			redirect("Setting/banner");
		} else {
			$uploadPath = $uploadDirectory . $name_file;
			$didUpload = move_uploaded_file($fileTmpName, $uploadPath);
			if (!$didUpload) {
				$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
				redirect("Setting/banner");
			} else {
				update_table('banner', ['img_url' => $name_file], ['id' => $data['hidbanner']]);
				redirect("setting/banner");
			}
		}
	}
	public function delete_banner()
	{
		$data = $this->input->post();

		//get name file in db
		$nameFile = $this->db->select('img_url as file')->from('banner')->where('id', $data['hidbanner'])->get()->row();
		unlink('assets/upload/banner/' . $nameFile->file);
		$this->db->delete("banner", ['id' => $data['hidbanner']]);
		$this->session->set_flashdata("success", 'Data grade berhasil dihapus');
	}

	public function perusahaan()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Setting Perusahaan',
			'perusahaan' => $this->db->select("*")->from('profil_perusahaan')->get()->row(),
			'data' => show_data('profil_perusahaan'),
			'organisasi' => $this->db->query("select * from jabatan ")->result(),
			// 'organisasi' => $this->db->query("select * from jabatan where jabatan.id not in (select organisasi_detail.id_jabatan from organisasi_detail)")->result(),
			'divisi' => $this->db->query("select * from divisi")->result(),
			'organisasiparent' => $this->db->query("select * from jabatan ")->result(),
			// 'organisasiparent' => $this->db->query("select * from jabatan where jabatan.id in (select organisasi_detail.id_jabatan from organisasi_detail)")->result(),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		// echo json_encode($data['perusahaan']->nama);
		// die;

		$this->template->load("template", 'setting/perusahaan', $data);
	}
	public function getperusahaan()
	{
		$data = show_data("profil_perusahaan");
		echo json_encode($data);
	}
	public function tambah_perusahaan()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Perusahaan',
			'data' => show_data('profil_perusahaan'),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];

		$this->template->load("template", 'setting/perusahaan', $data);
	}

	public function save_perusahaan()
	{
		$nama = $this->input->post('nama') == '' ? '' : $this->input->post('nama');
		$alamat = $this->input->post('alamat') == '' ? '' : $this->input->post('alamat');
		$email = $this->input->post('email') == '' ? '' : $this->input->post('email');
		$telepon = $this->input->post('telepon') == '' ? '' : $this->input->post('telepon');

		$id = $this->input->post('id');

		if (empty($_FILES['file'])) {
			if ($id == '') {
				$data = insert_table('profil_perusahaan', [
					'nama' => $nama,
					'alamat' => $alamat,
					'email' => $email,
					'no_hp' => $telepon
				],);
			} else {
				$data = update_table('profil_perusahaan', [
					'nama' => $nama,
					'alamat' => $alamat,
					'email' => $email,
					'no_hp' => $telepon
				], ['id' => $id]);
				// redirect("setting/perusahaan");
			}
			if ($data != true) {
				echo json_encode(0);
			} else {
				echo json_encode(1);
			}
		} else {

			$nameFile = $this->db->select('logo as file')->from('profil_perusahaan')->where('id', $id)->get()->row();

			if (!empty($nameFile)) {
				unlink('assets/upload/' . $nameFile->file);
			}

			$uploadDirectory = "assets/upload/";
			$fileExtensionsAllowed = ['jpeg', 'jpg', 'png', 'gif', 'JPG', 'JPEG', 'GIF']; // Allowed file extensions
			$fileName = $_FILES['file']['name'];
			$fileSize = $_FILES['file']['size'];
			$fileTmpName  = $_FILES['file']['tmp_name'];
			$fileType = $_FILES['file']['type'];
			$files = explode(".", $fileName);
			$name_file = $files[0] . '-' . time() . '.' . strtolower(end($files));



			if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
				$this->session->set_flashdata("error", 'Data gagal disimpan! Ukuran file maks 1mb');
				echo json_encode(false);
			} else {

				$uploadPath = $uploadDirectory . $name_file;
				$didUpload = move_uploaded_file($fileTmpName, $uploadPath);
				if (!$didUpload) {
					$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
					echo json_encode(false);
				} else {
					if ($id == '') {
						$data = insert_table('profil_perusahaan', [
							'nama' => $nama,
							'alamat' => $alamat,
							'email' => $email,
							'no_hp' => $telepon,
							'logo' => $name_file
						],);
					} else {
						$data = update_table('profil_perusahaan', [
							'nama' => $nama,
							'alamat' => $alamat,
							'email' => $email,
							'no_hp' => $telepon,
							'logo' => $name_file
						], ['id' => $id]);
						redirect("setting/perusahaan");
					}
					if ($data != true) {
						echo json_encode(0);
					} else {
						echo json_encode(1);
					}
				}
			}
		}
	}
	public function cekorganisasidetail()
	{
		$id_jabatan = $this->input->post('id');
		$data = $this->db->query("select * from karyawan where id_jabatan='$id_jabatan'")->result();
		echo json_encode($data);
	}
	public function getiduniqbynamaatasan()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("select * from organisasi_detail where id_karyawan='$id'")->row();
		echo json_encode($data);
	}
	public function tambahorganisasidetail()
	{
		$nama_anngota = $this->input->post('nama_anggota');
		$jabatan = $this->input->post('jabatan');
		$divisi = $this->input->post('divisi');
		$parentjabatan = $this->input->post('parentjabatan');
		$pid_uniq = $this->input->post('pid_uniq');
		if ($parentjabatan == '30') {
			$pid_uniq = 1;
		}
		if ($parentjabatan == '27') {

			$id_plt = 27;
			$is_plt = 1;
			$data = update_table('karyawan', [

				// 'id_jabatan' => $jabatan,
				// 'id_divisi' => $divisi,
				'id_plt_divisi' => $divisi,
				'id_plt' => $id_plt,
				'is_plt' => $is_plt

			], ['id' => $nama_anngota]);
		} else {
			$id_plt = null;
			$is_plt = 0;
			$data = update_table('karyawan', [

				'id_jabatan' => $jabatan,
				'id_divisi' => $divisi,
				// 'id_plt' => $id_plt,
				// 'id_plt_divisi' => null,
				// 'is_plt' => $is_plt

			], ['id' => $nama_anngota]);
		}
		// die;
		$increment = $this->db->select('id_uniqjabatan')
			->order_by('id', 'desc')
			->limit(1)
			->get('organisasi_detail')->row();

		if ($increment == NULL) {
			$idincrement = 1;
		} else {
			$idincrement = $increment->id_uniqjabatan + 1;
		}
		// die;
		insert_logAktivitas('Insert data Organisasi');
		$data = insert_table('organisasi_detail', [
			'id_karyawan' => $nama_anngota,
			'id_jabatan' => $jabatan,
			'id_divisi' => $divisi,
			'pid' => $parentjabatan,
			'id_uniqjabatan' => $idincrement,
			'pid_uniq' => $pid_uniq,

		]);

		if ($data != true) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode(0);
		} else {
			echo json_encode(1);
		}
	}
	public function updateorganisasidetail()
	{
		// die;
		$detail = $this->input->post('detail');
		$this->db->trans_begin();
		insert_logAktivitas('Update data Organisasi');
		// $this->db->empty_table("organisasi_detail");
		foreach ($detail as $key => $value) {
			// var_dump(isset($value['pid']) ? 'onok' : "ywes");
			// $this->db->delete("organisasi_detail", ['id' => $value['idutama']]);
			$data = update_table('organisasi_detail', [
				'id_karyawan' => $value['id_karyawan'],
				'id_jabatan' => $value['id_jabatan'],
				'id_divisi' => $value['id_divisi'],
				'pid' => isset($value['pid']) ? $value['pid'] : 0,
				'pid_uniq' => isset($value['pid']) ? $value['pid'] : 0,
				'id_uniqjabatan' => $value['id'],
			], ['id' => $value['idutama']]);
		}

		if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			echo json_encode(0);
		} else {
			$this->db->trans_commit();
			echo json_encode(1);
		}
	}
	public function getjabatan()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("select * FROM karyawan left JOIN jabatan on jabatan.id = karyawan.id_jabatan where karyawan.id = '$id'")->result();
		echo json_encode($data);
	}
	public function getdatavalidasi()
	{
		$id = $this->input->post('id');
		$data = show_data_order_by("id_jenis", "validasi");
		echo json_encode($data);
	}
	public function getdatavalidator()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("SELECT validator.*, karyawan.name, jenis_validasi.nama_jenis_validasi FROM validator left join karyawan on karyawan.id =validator.id_karyawan LEFT join jenis_validasi on jenis_validasi.id = validator.id_jenisvalidasi")->result();
		echo json_encode($data);
	}
	public function cek_namajamkerja()
	{
		$like = $this->input->post('like');
		$data = $this->db->query("select * from jam_kerja where hari like '%$like%'")->num_rows();
		if ($data > 0) {
			echo json_encode(1);
		} else {
			echo json_encode(0);
		}
	}
	public function libur()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Libur',
			'data' => show_data('libur'),
			'title1' => "Tambah Data Validasi",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/libur', $data);
	}
	public function jamkerja()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Jam Kerja',
			'data' => show_data('jam_kerja'),
			'title1' => "Seting Data Jam Kerja",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/jamkerja', $data);
	}
	public function tambah_jamkerja()
	{
		$hari = $this->input->post('hari');
		$jam_masuk = $this->input->post('jam_masuk');
		$jam_pulang = $this->input->post('jam_pulang');
		$toleransi = $this->input->post('toleransi');
		$jam_efektif = $this->input->post('jam_efektif');

		// echo json_encode([

		// ]);

		$data = insert_table('jam_kerja', [
			'hari' => $hari,
			'jam_masuk' => $jam_masuk,
			'jam_pulang' => $jam_pulang,
			'toleransi' => $toleransi,
			'efektif' => $jam_efektif,
			'created_at' => date("Y-m-d H:i:s"),
			'create_who' => $this->session->userdata('username')
		]);
		if ($data != true) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode(0);
		} else {
			echo json_encode(1);
		}
	}
	// end


	public function hakAkses()
	{
		$login = $this->login->session();

		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Karyawan',
			'data' => show_data('karyawan'),
			'dataAdmin' => show_data('role'),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];

		// echo json_encode($data['menuHakAkses']);
		// die;
		$this->template->load("template", 'setting/hakakses', $data);
	}

	public function getMenuHakAkses()
	{
		echo json_encode([
			'parentMenu' => $this->db->select("*")->from('parent_menu')->order_by('is_urut', 'ASC')->get()->result(),
			'mainMenu' => $this->db->select("*")->from('main_menu')->order_by('is_urut', 'ASC')->get()->result(),
			'subMenu' => $this->db->select("*")->from('sub_menu')->order_by('is_urut', 'ASC')->get()->result(),
		]);
	}

	public function getMenuHakAksesById()
	{

		echo json_encode([
			'parentMenu' => $this->db->select("*")->from('access_parent_menu')->where('id_role', $this->input->post('idRole'))->get()->result(),
			'mainMenu' => $this->db->select("*")->from('access_main_menu')->where('id_role', $this->input->post('idRole'))->get()->result(),
			'subMenu' => $this->db->select("*")->from('access_sub_menu')->where('id_role', $this->input->post('idRole'))->get()->result(),
		]);
	}

	public function saveDataMenuHakAkses()
	{
		$dataPost = $this->input->post();

		$this->db->trans_begin();

		$this->db->delete("access_parent_menu", ['id_role' => $dataPost['idRole']]);
		$this->db->delete("access_main_menu", ['id_role' => $dataPost['idRole']]);
		$this->db->delete("access_sub_menu", ['id_role' => $dataPost['idRole']]);

		//insert to access parent menu
		if (!empty($dataPost['arrParentMenu'])) {
			foreach ($dataPost['arrParentMenu'] as $key => $value) {
				$dataParent = [
					'id_role' => $dataPost['idRole'],
					'id_parent_menu' => $value,
					'is_akses' => 1
				];

				insert_table('access_parent_menu', $dataParent);
			}
		}


		//insert to access main menu
		if (!empty($dataPost['arrMainMenu'])) {
			foreach ($dataPost['arrMainMenu'] as $key => $value) {
				$dataMain = [
					'id_role' => $dataPost['idRole'],
					'id_main_menu' => $value,
					'is_akses' => 1
				];

				insert_table('access_main_menu', $dataMain);
			}
		}

		//insert to access sub menu
		if (!empty($dataPost['arrSubMenu'])) {
			foreach ($dataPost['arrSubMenu'] as $key => $value) {
				$dataSub = [
					'id_role' => $dataPost['idRole'],
					'id_sub_menu' => $value,
					'is_akses' => 1
				];

				insert_table('access_sub_menu', $dataSub);
			}
		}

		if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			echo json_encode([
				'status' => 400,
				'message' => 'Data gagal disimpan',
			]);
		} else {
			$this->db->trans_commit();
			echo json_encode([
				'status' => 201,
				'message' => 'Data berhasil disimpan',
			]);
		}
	}

	public function lokasi()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Setting Lokasi',
			'data' => $this->db->query('select lokasi_perusahaan.*, unit.name as unit from lokasi_perusahaan left join unit on lokasi_perusahaan.id_unit = unit.id')->result(),
			'dataUnit' => show_data('unit'),
			'title1' => "Setting Lokasi Perusahaan",
			'title2' => "Setting Lokasi",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];

		$this->template->load("template", 'setting/lokasi', $data);
	}

	public function getSettingLokasiByid()
	{
		$id = $this->input->post('id');

		$data = $this->db->query("select *
								  from lokasi_perusahaan
								  where id_unit = '$id'")->row();

		echo json_encode($data);
	}

	public function save_lokasi()
	{
		$data = $this->input->post();

		if ($data['type'] == 'insert') {
			$dataLokasiInsert = [
				'id_unit' => $data['id'],
				'alamat' => $data['alamat'],
				'longitude' => $data['longitude'],
				'latitude' => $data['latitude'],
				'satuan' => $data['satuan'],
				'jarak' => $data['jarak'],
				'created_at' => date('Y-m-d H:i:s')

			];

			insert_table('lokasi_perusahaan', $dataLokasiInsert);
			echo json_encode([
				'status' => 200,
				'message' => 'Data berhasil disimpan'
			]);
		}

		if ($data['type'] == 'update') {
			$dataLokasiUpdate = [
				'alamat' => $data['alamat'],
				'longitude' => $data['longitude'],
				'latitude' => $data['latitude'],
				'satuan' => $data['satuan'],
				'jarak' => $data['jarak'],
				'created_at' => date('Y-m-d H:i:s')

			];

			update_table('lokasi_perusahaan', $dataLokasiUpdate, ['id' => $data['id']]);
			echo json_encode([
				'status' => 200,
				'message' => 'Data berhasil disimpan'
			]);
		}
	}

	public function getorganisasi()
	{
		// $data = $this->db->query("select *,jabatan.id as idjabatanutama,karyawan.name as karyawan_nama, jabatan.name as organisasi_nama,organisasi_detail.id as id_organisasi_detail , divisi.nama_divisi from jabatan LEFT join organisasi_detail on organisasi_detail.id_jabatan = jabatan.id left join karyawan on karyawan.id = organisasi_detail.id_karyawan left join divisi on divisi.id = organisasi_detail.id_divisi WHERE jabatan.id in(select organisasi_detail.id_jabatan from organisasi_detail)")->result();
		// $data = $this->db->query('select *, jabatan.id as idjabatanutama, divisi.id as id_divisiutama, organisasi_detail.id as id_organisasidetailutama, organisasi_detail.id_karyawan as id_karyawanutama, karyawan.name as karyawan_nama, jabatan.name as organisasi_nama,organisasi_detail.id as id_organisasi_detail , divisi.nama_divisi from jabatan LEFT join organisasi_detail on organisasi_detail.id_jabatan = jabatan.id left join karyawan on karyawan.id = organisasi_detail.id_karyawan left join divisi on divisi.id = organisasi_detail.id_divisi WHERE jabatan.id in(select organisasi_detail.id_jabatan from organisasi_detail);')->result();
		$data = $this->db->query('select *, jabatan.id as idjabatanutama, divisi.id as id_divisiutama, organisasi_detail.id as id_organisasidetailutama, organisasi_detail.id_karyawan as id_karyawanutama, karyawan.name as karyawan_nama, jabatan.name as organisasi_nama, organisasi_detail.id as id_organisasi_detail, divisi.nama_divisi from organisasi_detail LEFT join jabatan on organisasi_detail.id_jabatan = jabatan.id left join karyawan on karyawan.id = organisasi_detail.id_karyawan left join divisi on divisi.id = organisasi_detail.id_divisi')->result();
		echo json_encode($data);
	}
	public function settingvalidasi()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Setting Validasi',
			'jenis_cuti' => $this->db->select("*")->from('profil_perusahaan')->get()->row(),
			'datavalidasi' => show_data('validasi'),
			'datavalidator' => show_data('validator'),
			'data' => show_data('profil_perusahaan'),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];

		$this->template->load("template", 'setting/settingvalidasi', $data);
	}
	public function tambah_aktivitas()
	{
		$nama_aktivitas = $this->input->post('nama_aktivitas');
		$jenis_validasi = $this->input->post('jenis_validasi');
		$detail = $this->input->post('detail');
		$this->db->trans_begin();

		$data = insert_table('validasi', [
			'nama_aktivitas' => $nama_aktivitas,
			'id_jenis' => $jenis_validasi,

		]);
		insert_logAktivitas('Insert data validasi');
		$getid = $this->db->query('select max(id) as id from validasi')->row();
		foreach ($detail as $key => $value) {
			insert_table(
				'nama_step_validasi',
				[
					'id_validasi' => $getid->id,
					'urut' => $value['urut'],
					'nama_step' => $value['nama_step'],
					'created_at' => date("Y-m-d H:i:s"),
				]
			);
		}

		if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			echo json_encode(0);
		} else {
			$this->db->trans_commit();
			echo json_encode(1);
		}
	}
	public function edit_aktivitas()
	{
		$id = $this->input->post('id');
		$nama_aktivitas = $this->input->post('nama_aktivitas');
		$jenis_validasi = $this->input->post('jenis_validasi');
		$detail = $this->input->post('detail');
		$this->db->trans_begin();

		$data = update_table('validasi', [
			'nama_aktivitas' => $nama_aktivitas,
			'id_jenis' => $jenis_validasi,

		], ['id' => $id]);
		insert_logAktivitas('Update data validasi');
		$this->db->delete("nama_step_validasi", ['id_validasi' => $id]);
		foreach ($detail as $key => $value) {
			insert_table(
				'nama_step_validasi',
				[
					'id_validasi' => $id,
					'urut' => $value['urut'],
					'nama_step' => $value['nama_step'],
					'created_at' => date("Y-m-d H:i:s"),
				]
			);
		}

		if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			echo json_encode(0);
		} else {
			$this->db->trans_commit();
			echo json_encode(1);
		}
	}
	public function edit_validator()
	{
		$id = $this->input->post('id');
		$id_aktivitas = $this->input->post('id_aktivitas');
		$id_jenis_validasi = $this->input->post('id_jenis_validasi');
		$detail = $this->input->post('detail');
		$this->db->trans_begin();

		$this->db->delete("validator", ['id_aktivitasvalidasi' => $id_aktivitas]);
		insert_logAktivitas('Update data validasi');
		foreach ($detail as $key => $value) {
			insert_table(
				'validator',
				[
					'id_jabatan' => $value['id_jabatan'] == '' ? 0 : $value['id_jabatan'],
					'id_jenisvalidasi' => $id_jenis_validasi,
					'id_bidang' => $value['id_bidang'] == '' ? 0 : $value['id_bidang'],
					'id_karyawan' => $value['id_karyawan'] == '' ? 0 : $value['id_karyawan'],
					'id_aktivitasvalidasi' => $id_aktivitas,
					'stepvalidasi' => $value['urut'],
					'created_at' => date("Y-m-d H:i:s"),
				]
			);
		}

		if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			echo json_encode(0);
		} else {
			$this->db->trans_commit();
			echo json_encode(1);
		}
	}
	public function getdetailnamastepbyidvalidasi()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("select * from nama_step_validasi where id_validasi ='$id'")->result();
		echo json_encode($data);
	}
	public function getdetailnamastepjabatanbyidvalidasi()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("SELECT * FROM nama_step_validasi LEFT join validasi on validasi.id = nama_step_validasi.id_validasi  where validasi.id = '$id'")->result();
		echo json_encode($data);
	}
	public function getvalidatorbyid()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("SELECT * FROM validator where validator.id_aktivitasvalidasi = '$id' order by validator.stepvalidasi")->result();
		echo json_encode($data);
	}
	public function getdataaktivitasbyidjenis()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("select * from validasi where id_jenis ='$id'")->result();
		echo json_encode($data);
	}
	public function getdatastepbyidaktivitas()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("select * from nama_step_validasi where id_validasi ='$id'")->result();
		echo json_encode($data);
	}
	public function getalljabatan()
	{
		$id = $this->input->post('id');
		$data = show_data('jabatan');
		echo json_encode($data);
	}
	public function getjabatanbyvalidator()
	{
		$id = $this->input->post('id');
		// $data = $this->db->query('select * from jabatan where id_role not in (1,3,6)')->result();
		$data = $this->db->query('select * from jabatan where id not in (19,20,22,25,27,28,29)')->result();
		echo json_encode($data);
	}
	public function getbidangbyvalidator()
	{
		$id = $this->input->post('id');
		$data = $this->db->query('select * from divisi')->result();
		echo json_encode($data);
	}
	public function getkaryawanbyvalidator()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("select id,name from karyawan where id_divisi ='$id'")->result();
		echo json_encode($data);
	}
	public function getkaryawanall()
	{
		$id = $this->input->post('id');
		$data = $this->db->query("select id,name from karyawan")->result();
		echo json_encode($data);
	}
	public function tambahvalidator()
	{
		$nmaktivitasvalidator = $this->input->post('nmaktivitasvalidator');
		$jenisvalidasivalidator = $this->input->post('jenisvalidasivalidator');
		$stepvalidasivalidator = $this->input->post('stepvalidasivalidator');
		$nmjabatanvalidator = $this->input->post('nmjabatanvalidator');

		$data = insert_table('validator', [
			'id_karyawan' => $nmjabatanvalidator,
			'id_jenisvalidasi' => $jenisvalidasivalidator,
			'nmaktivitasvalidator' => $nmaktivitasvalidator,
			'stepvalidasi' => $stepvalidasivalidator,
			'created_at' => date("Y-m-d H:i:s"),
			'create_who' => $this->session->userdata('username')

		]);
		insert_logAktivitas('Insert data validator');
		if ($data != true) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode($data);
		} else {
			echo json_encode($data);
		}
	}
	public function editvalidator()
	{
		$id = $this->input->post('id');
		$nmaktivitasvalidator = $this->input->post('nmaktivitasvalidator');
		$jenisvalidasivalidator = $this->input->post('jenisvalidasivalidator');
		$stepvalidasivalidator = $this->input->post('stepvalidasivalidator');
		$nmjabatanvalidator = $this->input->post('nmjabatanvalidator');

		$data = update_table('validator', [
			'id_karyawan' => $nmjabatanvalidator,
			'id_jenisvalidasi' => $jenisvalidasivalidator,
			'nmaktivitasvalidator' => $nmaktivitasvalidator,
			'stepvalidasi' => $stepvalidasivalidator,
			'created_at' => date("Y-m-d H:i:s"),
			'create_who' => $this->session->userdata('username')

		], ['id' => $id]);
		insert_logAktivitas('Update data Validator');
		if ($data != true) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode($data);
		} else {
			echo json_encode($data);
		}
	}
	public function editorganisasidetail()
	{
		$detail = $this->input->post('detail');
		foreach ($detail as $key => $value) {
			$jabatan = $value['id_jabatan'];
			if ($jabatan == '27' || (int)$jabatan == 27) {
				$id_plt = 27;
				$is_plt = 1;
				$data = update_table('karyawan', [
					// 'id_karyawan' => $value['id_karyawan'],
					// 'id_jabatan' => $value['id_jabatan'],
					// 'id_divisi' => $value['id_divisi'],
					'id_plt_divisi' => $value['id_divisi'],
					'id_plt' => $id_plt,
					'is_plt' => $is_plt,

				], ['id' => $value['id_karyawan']]);
			} else {
				$id_plt = null;
				$is_plt = 0;
				$data = update_table('karyawan', [
					// 'id_karyawan' => $value['id_karyawan'],
					'id_jabatan' => $value['id_jabatan'],
					'id_divisi' => $value['id_divisi'],
					// 'id_plt' => $id_plt,
					// 'is_plt' => $is_plt,


				], ['id' => $value['id_karyawan']]);
			}

			$data = update_table('organisasi_detail', [
				'id_karyawan' => $value['id_karyawan'],
				'id_jabatan' => $value['id_jabatan'],
				'id_divisi' => $value['id_divisi']

			], ['id' => $value['idutama']]);
		}
		if ($data != true) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode(0);
		} else {
			echo json_encode(1);
		}
	}
	public function getdatajamkerja()
	{
		$id = $this->input->post('id');
		// $data = show_data_order_by("hari", "jam_kerja");
		$data = $this->db->query('SELECT *,jam_kerja.id as id_jamkerja FROM `jam_kerja` left join hariefektif on hariefektif.id = jam_kerja.hari')->result();
		echo json_encode($data);
	}
	public function getdataaktivitas()
	{
		// $id = $this->input->post('id');
		$data = $this->db->query('select *, validasi.id as id_val from validasi left join jenis_validasi on jenis_validasi.id = validasi.id_jenis')->result();
		echo json_encode($data);
	}
	public function edit_jamkerja()
	{
		$id = $this->input->post('id');
		$edithari = $this->input->post('edithari');
		$editjam_masuk = $this->input->post('editjam_masuk');
		$editjam_pulang = $this->input->post('editjam_pulang');
		$edittoleransi = $this->input->post('edittoleransi');
		$editjam_efektif = $this->input->post('editjam_efektif');

		$who_create = $this->session->userdata('username');
		$data = update_table('jam_kerja', [
			'hari' => $edithari,
			'jam_masuk' => $editjam_masuk,
			'jam_pulang' => $editjam_pulang,
			'toleransi' => $edittoleransi,
			'efektif' => $editjam_efektif

		], ['id' => $id]);
		insert_logAktivitas('Update data Jamkerja');
		if ($data != true) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode(0);
		} else {
			echo json_encode(1);
		}
	}
	public function hariefektif()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Hari Efektif',
			'data' => show_data('hariefektif'),
			'title1' => "Tambah Data Hari Efektif",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'setting/hariefektif', $data);
	}
	public function cek_hariefektif()
	{
		$like = $this->input->post('like');
		$data = $this->db->query("select * from hariefektif where nama_hari like '%$like%'")->num_rows();
		if ($data > 0) {
			echo json_encode(1);
		} else {
			echo json_encode(0);
		}
	}
	public function tambah_hariefektif()
	{
		$hari = $this->input->post('hariefektif');

		$data = insert_table('hariefektif', [
			'nama_hari' => $hari,
			'created_at' => date("Y-m-d H:i:s"),
		]);
		insert_logAktivitas('Insert data Hari Efektif');
		if ($data != true) {
			$this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode(0);
		} else {
			echo json_encode(1);
		}
	}
	public function edit_hariefektif()
	{
		$id = $this->input->post('id');
		$hari = $this->input->post('hariefektif');


		$data = update_table('hariefektif', [
			'nama_hari' => $hari,
			'created_at' => date("Y-m-d H:i:s"),
		], ['id' => $id]);
		insert_logAktivitas('Update data Hari Efektif');
		if ($data != true) {
			// $this->session->set_flashdata("error", 'Data gagal disimpan! Terjadi kesalahan pada server');
			echo json_encode(0);
		} else {
			echo json_encode(1);
		}
	}
}
