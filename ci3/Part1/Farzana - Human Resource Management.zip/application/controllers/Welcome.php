<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * 
 */
class Welcome extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_MenuAkses', 'akses');
	}
	function kode_members()
	{
		$alphabet = '01234567890';
		$password = array();
		$alpha_length = strlen($alphabet) - 1;
		for ($i = 0; $i < 8; $i++) {
			$n = rand(0, $alpha_length);
			$password[] = $alphabet[$n];
		}
		return implode($password);
	}
	public function index()
	{
		$data = [
			'code' => $this->kode_members(),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'home', $data);
	}
	public function server_wa()
	{
		$page = $_SERVER['PHP_SELF'];
		$sec = "5";
		header("Refresh: $sec; url=$page");
		$data = json_decode(session_wa());
		if ($data->status == "QRCODE") {
			echo "<center><img src='" . $data->qrcode . "' class='img-responsive img-thumbnail'></center>";
		} elseif ($data->status == "CONNECTED") {
			echo "<center>" . $data->status . "</center><br>";
		} else {
			echo "<center><img src='" . base_url('assets/loading.gif') . "'></center>";
		}
	}
	public function slip()
	{
		$this->pdf->setPaper('A4', 'potrait');
		$this->pdf->filename = "laporan-petanikode.pdf";
		$options = $this->pdf->getOptions();
		$options->set(array('isRemoteEnabled' => true));
		$this->pdf->setOptions($options);
		$this->pdf->load_view('view_cetak');
	}

	public function checkInvitedEmail()
	{
		$users = $this->db->select('id, is_invited, waktu_is_edit, email')->from('karyawan')->where('is_invited', 1)->get()->result();

		if (!empty($users)) {
			foreach ($users as $key => $value) {
				$days = (strtotime($value->waktu_is_edit) - strtotime(date('Y-m-d H:i:s'))) / (60 * 60 * 24);

				if ($days < 0) {
					update_table('karyawan', [
						'is_invited' => NULL,
						'waktu_is_edit' => NULL
					], ['id' => $value->id]);

					insert_table('log_aktivitas', [
						'id_users' => 1,
						'deskripsi' => 'Otomatis Menonaktifkan Undang karyawan by email ketika melebihi batas waktu yg ditentukan'
					]);

					$this->_sendEmail($value->email);
				}
			}
		}
	}

	private function _sendEmail($email)
	{

		$config = [
			'mailtype'  => 'html',
			'charset'   => 'utf-8',
			'protocol'  => 'smtp',
			'smtp_host' => 'smtp.gmail.com',
			'smtp_user' => 'akbaraisyah000@gmail.com',  // Email gmail
			'smtp_pass'   => 'jngvwzwxosmldgqv',  // Password gmail
			'smtp_crypto' => 'ssl',
			'smtp_port'   => 465,
			'crlf'    => "\r\n",
			'newline' => "\r\n"
		];

		// Load library email dan konfigurasinya
		$this->load->library('email');
		$this->email->initialize($config);

		// Email dan nama pengirim
		$this->email->from('support@ekitir.com', 'YBN');

		// Email penerima
		$this->email->to($email); // Ganti dengan email tujuan


		// Isi email
		$this->email->subject("Undangan akun karyawan");
		$message = "";
		$message .= '<div class="email" style="border: 1px solid gray;border-radius: 10px;padding: 15px;min-height: 15vh;position: relative;margin: auto;width: 70%;text-align: center;">
                            <h3 style="font-weight: 800;">Undangan akun karyawan</h3>
                            <h6 style="font-weight: 200;margin-top: 10px;">Akun anda telah didinonaktifkan oleh admin untuk bisa melalukan perbaikan data personal anda</h6>

                            <a href="' . base_url('Auth') . '" style="padding: 15px;font-size: 20px;background: #0e7490;border-radius: 10px;font-weight: 700;color: white;font-family: monospace;">Login</a>
                        </div>';

		$this->email->message($message);

		// Tampilkan pesan sukses atau error
		if ($this->email->send()) {
			return true;
		} else {
			echo $this->email->print_debugger();
			die;
		}
	}
}
