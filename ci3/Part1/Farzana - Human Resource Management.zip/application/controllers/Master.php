<?php

/**
 * 
 */
class Master extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_Login', 'login');
		$this->load->model('M_MenuAkses', 'akses');
		cek_session();
	}

	public function grade()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Grade',
			'data' => show_data('grade'),
			'title1' => "Tambah Data Grade",
			'title2' => "Data Grade",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'master/grade', $data);
	}
	public function save_grade()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('grade', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data grade berhasil disimpan');
				redirect("master/grade");
			} else {
				$this->session->set_flashdata("error", 'Data grade gagal disimpan');
				redirect("master/grade");
			}
		} else {
			$save = update_table('grade', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data grade berhasil diperbaharui');
				redirect("master/grade");
			} else {
				$this->session->set_flashdata("error", 'Data grade gagal diperbaharui');
				redirect("master/grade");
			}
		}
	}
	public function tunjangan()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Tunjangan',
			'data' => show_data('tunjangan'),
			'title1' => "Tambah Data Tunjangan",
			'title2' => "Data Tunjangan",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'master/tunjangan', $data);
	}
	public function save_tunjangan()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('tunjangan', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data tunjangan berhasil disimpan');
				redirect("master/tunjangan");
			} else {
				$this->session->set_flashdata("error", 'Data tunjangan gagal disimpan');
				redirect("master/tunjangan");
			}
		} else {
			$save = update_table('tunjangan', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data tunjangan berhasil diperbaharui');
				redirect("master/tunjangan");
			} else {
				$this->session->set_flashdata("error", 'Data tunjangan gagal diperbaharui');
				redirect("master/tunjangan");
			}
		}
	}
	public function bonus()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Bonus',
			'data' => show_data('bonus'),
			'title1' => "Tambah Data Bonus",
			'title2' => "Data Bonus",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'master/bonus', $data);
	}
	public function save_bonus()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('bonus', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data bonus berhasil disimpan');
				redirect("master/bonus");
			} else {
				$this->session->set_flashdata("error", 'Data bonus gagal disimpan');
				redirect("master/bonus");
			}
		} else {
			$save = update_table('bonus', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data bonus berhasil diperbaharui');
				redirect("master/bonus");
			} else {
				$this->session->set_flashdata("error", 'Data bonus gagal diperbaharui');
				redirect("master/bonus");
			}
		}
	}
	public function jabatan()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Jabatan',
			'data' => $this->db->query('select jabatan.*, role.nama as role from jabatan left join role on jabatan.id_role = role.id')->result(),
			'dataRole' => show_data('role'),
			'title1' => "Tambah Data Hak Akses",
			'title2' => "Data Hak Akses",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];

		$this->template->load("template", 'master/jabatan', $data);
	}
	public function save_jabatan()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('jabatan', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data jabatan berhasil disimpan');
				redirect("master/jabatan");
			} else {
				$this->session->set_flashdata("error", 'Data jabatan gagal disimpan');
				redirect("master/jabatan");
			}
		} else {
			$save = update_table('jabatan', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data jabatan berhasil diperbaharui');
				redirect("master/jabatan");
			} else {
				$this->session->set_flashdata("error", 'Data jabatan gagal diperbaharui');
				redirect("master/jabatan");
			}
		}
	}
	public function unit()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Unit Kerja',
			'data' => show_data('unit'),
			'title1' => "Tambah Data Unit Kerja",
			'title2' => "Data Hak Unit Kerja",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'master/unit', $data);
	}
	public function save_unit()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('unit', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data unit berhasil disimpan');
				redirect("master/unit");
			} else {
				$this->session->set_flashdata("error", 'Data unit gagal disimpan');
				redirect("master/unit");
			}
		} else {
			$save = update_table('unit', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data unit berhasil diperbaharui');
				redirect("master/unit");
			} else {
				$this->session->set_flashdata("error", 'Data unit gagal diperbaharui');
				redirect("master/unit");
			}
		}
	}
	public function bidang()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Bidang',
			'data' => show_data('divisi'),
			'title1' => "Tambah Data Bidang",
			'title2' => " Data Bidang",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
			// 'title2' => "Data Hak Unit Kerja"
		];
		$this->template->load("template", 'master/divisi', $data);
	}
	public function save_organisasi()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('divisi', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data divisi berhasil disimpan');
				redirect("master/divisi");
			} else {
				$this->session->set_flashdata("error", 'Data divisi gagal disimpan');
				redirect("master/divisi");
			}
		} else {
			$save = update_table('divisi', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data divisi berhasil diperbaharui');
				redirect("master/divisi");
			} else {
				$this->session->set_flashdata("error", 'Data divisi gagal diperbaharui');
				redirect("master/divisi");
			}
		}
	}
	public function save_divisi()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('organisasi', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data organisasi berhasil disimpan');
				redirect("master/organisasi");
			} else {
				$this->session->set_flashdata("error", 'Data organisasi gagal disimpan');
				redirect("master/organisasi");
			}
		} else {
			$save = update_table('organisasi', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data organisasi berhasil diperbaharui');
				redirect("master/organisasi");
			} else {
				$this->session->set_flashdata("error", 'Data organisasi gagal diperbaharui');
				redirect("master/organisasi");
			}
		}
	}
	public function jeniscuti()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Jenis Cuti',
			'data' => show_data('jenis_cuti'),
			'title1' => "Tambah Data Cuti",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
			// 'title2' => "Data Hak Unit Kerja"
		];
		$this->template->load("template", 'master/jeniscuti', $data);
	}
	public function tambah_jeniscuti()
	{
		$jenis_cuti = $this->input->post('jenis_cuti');

		$who_create = $this->session->userdata('username');
		$data = insert_table('jenis_cuti', [
			'nama_jenis' => $jenis_cuti,
			'create_who' => $who_create,
			'created_at' => date('Y-m-d H:i:s')
		]);
		echo json_encode($data);
	}
	public function edit_jeniscuti()
	{
		$id = $this->input->post('id');
		$jeniscuti = $this->input->post('jeniscuti');

		$who_create = $this->session->userdata('username');
		$data = update_table('jenis_cuti', [
			'nama_jenis' => $jeniscuti,
			'create_who' => $who_create,
		], ['id' => $id]);
		echo json_encode($data);
	}
	public function cek_namacuti()
	{
		$like = $this->input->post('like');
		$data = $this->db->query("select * from jenis_cuti where nama_jenis like '%$like%'")->num_rows();
		if ($data > 0) {
			echo json_encode(1);
		} else {
			echo json_encode(0);
		}
	}
	public function jenisvalidasi()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Jenis Validasi',
			'data' => show_data('jenis_validasi'),
			'title1' => "Tambah Data Validasi",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
			// 'title2' => "Data Hak Unit Kerja"
		];
		$this->template->load("template", 'master/jenisvalidasi', $data);
	}
	public function tambah_jenisvalidasi()
	{
		$jenis_validasi = $this->input->post('jenis_validasi');

		$who_create = $this->session->userdata('username');
		$data = insert_table('jenis_validasi', [
			'nama_jenis_validasi' => $jenis_validasi,
			'create_who' => $who_create,
			'created_at' => date('Y-m-d H:i:s')
		]);
		echo json_encode($data);
	}
	public function edit_jenisvalidasi()
	{
		$id = $this->input->post('id');
		$jenisvalidasi = $this->input->post('jenisvalidasi');

		$who_create = $this->session->userdata('username');
		$data = update_table('jenis_validasi', [
			'nama_jenis_validasi' => $jenisvalidasi,
			'create_who' => $who_create,
		], ['id' => $id]);
		echo json_encode($data);
	}
	public function cek_namavalidasi()
	{
		$like = $this->input->post('like');
		$data = $this->db->query("select * from jenis_validasi where nama_jenis_validasi like '%$like%'")->num_rows();
		if ($data > 0) {
			echo json_encode(1);
		} else {
			echo json_encode(0);
		}
	}



	public function save_statuspegawai()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('statuspegawai', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data berhasil disimpan');
				redirect("master/statuspegawai");
			} else {
				$this->session->set_flashdata("error", 'Data gagal disimpan');
				redirect("master/statuspegawai");
			}
		} else {
			$save = update_table('statuspegawai', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data berhasil diperbaharui');
				redirect("master/statuspegawai");
			} else {
				$this->session->set_flashdata("error", 'Data gagal diperbaharui');
				redirect("master/statuspegawai");
			}
		}
	}
	public function save_kategori_aktivitas()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('kategori_aktivitas', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data berhasil disimpan');
				redirect("master/kategoriaktivitas");
			} else {
				$this->session->set_flashdata("error", 'Data gagal disimpan');
				redirect("master/kategoriaktivitas");
			}
		} else {
			$save = update_table('kategori_aktivitas', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data berhasil diperbaharui');
				redirect("master/kategoriaktivitas");
			} else {
				$this->session->set_flashdata("error", 'Data gagal diperbaharui');
				redirect("master/kategoriaktivitas");
			}
		}
	}
	public function cek_tgllibur()
	{
		$id = $this->input->post('id');
		$like = $this->input->post('like');
		$data = $this->db->query("select * from libur where id != '$id' AND tgl_libur like '%$like%'")->num_rows();
		if ($data > 0) {
			echo json_encode(1);
		} else {
			echo json_encode(0);
		}
	}
	public function tambah_libur()
	{
		$tgllibur = $this->input->post('tgllibur');
		$keterangan = $this->input->post('keterangan');
		$tglliburex = explode("-", $tgllibur)[0];


		$who_create = $this->session->userdata('username');
		$data = insert_table('libur', [
			'tgl_libur' => $tgllibur,
			'keterangan' => $keterangan,
			'tahun' => $tglliburex,
			'create_who' => $who_create,
			'created_at' => date('Y-m-d H:i:s')
		]);
		echo json_encode($data);
	}
	public function edit_libur()
	{
		$id = $this->input->post('id');
		$tgllibur = $this->input->post('tgllibur');
		$keterangan = $this->input->post('keterangan');
		$tglliburex = explode("-", $tgllibur)[0];


		$who_create = $this->session->userdata('username');
		$data = update_table('libur', [
			'tgl_libur' => $tgllibur,
			'keterangan' => $keterangan,
			'tahun' => $tglliburex,
			'create_who' => $who_create,
			// 'created_at' => date('Y-m-d H:i:s')
		], ['id' => $id]);
		echo json_encode($data);
	}
	public function statuspegawai()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Status Pegawai',
			'data' => show_data('statuspegawai'),
			'title1' => "Tambah Data Status Pegawai",
			'title2' => "Data Status Pegawai",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
			// 'title2' => "Data Hak Unit Kerja"
		];
		$this->template->load("template", 'master/statuspegawai', $data);
	}
	public function kategoriaktivitas()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Kategori Aktivitas',
			'data' => show_data('kategori_aktivitas'),
			'title1' => "Tambah Data Kategori Aktivitas",
			'title2' => "Data Kategori",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
			// 'title2' => "Data Hak Unit Kerja"
		];
		$this->template->load("template", 'master/kategoriaktivitas', $data);
	}

	public function role()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Role',
			'data' => show_data('role'),
			'title1' => "Tambah Data Role",
			'title2' => "Data Role",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];

		$this->template->load("template", 'master/role', $data);
	}
	public function save_role()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('role', $data);
			if ($save) {
				$this->session->set_flashdata("success", 'Data role berhasil disimpan');
				redirect("master/role");
			} else {
				$this->session->set_flashdata("error", 'Data role gagal disimpan');
				redirect("master/role");
			}
		} else {
			$save = update_table('role', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data role berhasil diperbaharui');
				redirect("master/role");
			} else {
				$this->session->set_flashdata("error", 'Data role gagal diperbaharui');
				redirect("master/role");
			}
		}
	}

	public function jenis_transaksi_keuangan()
	{
		$login = $this->login->session();
		$data = [
			'users' => where_row('users', ['username' => $login['username']]),
			'title' => 'Master Jenis Transaksi Keuangan',
			'data' => show_data('jenis_transaksi_keuangan'),
			'title1' => "Tambah Data Jenis Transaksi Keuangan",
			'title2' => "Data Jenis Transaksi Keuangan",
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'master/jenis_transaksi_keuangan', $data);
	}
	public function save_jenis_transaksi_keuangan()
	{
		$data = $this->input->post();
		if ($data['id'] == "") {
			$save = insert_table('jenis_transaksi_keuangan', ['name' => $data['name'], 'created_at' => date('Y-m-d H:i:s')]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data Jenis Transaksi Keuangan berhasil disimpan');
				redirect("master/jenis_transaksi_keuangan");
			} else {
				$this->session->set_flashdata("error", 'Data Jenis Transaksi Keuangan gagal disimpan');
				redirect("master/jenis_transaksi_keuangan");
			}
		} else {
			$save = update_table('jenis_transaksi_keuangan', $data, ['id' => $data['id']]);
			if ($save) {
				$this->session->set_flashdata("success", 'Data Jenis Transaksi Keuangan berhasil diperbaharui');
				redirect("master/jenis_transaksi_keuangan");
			} else {
				$this->session->set_flashdata("error", 'Data Jenis Transaksi Keuangan gagal diperbaharui');
				redirect("master/jenis_transaksi_keuangan");
			}
		}
	}
}
