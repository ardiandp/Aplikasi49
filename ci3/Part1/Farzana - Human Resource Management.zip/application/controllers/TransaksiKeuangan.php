<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class TransaksiKeuangan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }
    public function index()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Transaksi keuangan',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'jenisTransaksiKeuangan' => show_data('jenis_transaksi_keuangan')
        ];
        $this->template->load("template", 'transaksi_keuangan', $data);
    }

    public function saveTransaksiKeuangan()
    {
        $dataPost = $this->input->post();

        if ($dataPost['mode'] == "insert") {
            $dataTransaksikeuangan = [
                'id_karyawan' => $dataPost['idUsers'],
                'id_jenis_transaksi_keuangan' => $dataPost['jenisTransaksi'],
                'nominal' => $dataPost['nominalTransaksi'],
                'tanggal' => $dataPost['dateTransaksi'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            $result = insert_table('transaksi_keuangan', $dataTransaksikeuangan);
            if ($result) {
                insert_logAktivitas('Tambah data Transaksi Keuangan');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Transaksi Keuangan berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Transaksi Keuangan gagal disimpan'
                ]);
            }
        }
        if ($dataPost['mode'] == "update") {

            $dataTransaksikeuanganUpdate = [
                'id_jenis_transaksi_keuangan' => $dataPost['jenisTransaksi'],
                'nominal' => $dataPost['nominalTransaksi'],
                'tanggal' => $dataPost['dateTransaksi'],
            ];

            $result = update_table('transaksi_keuangan', $dataTransaksikeuanganUpdate, ['id' => $dataPost['idTransaksiKeuangan']]);
            if ($result) {
                insert_logAktivitas('Edit data Transaksi Keuangan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Transaksi Keuangan berhasil diubah'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Transaksi Keuangan gagal diubah'
                ]);
            }
        }
    }
}
