<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class FormPengajuan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }
    public function pengajuancuti()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Pengajuan Cuti',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select *,p.id as idutama ,jabatan.name as nama_jabatan,karyawan.name as nama_karyawan,DATE_FORMAT(p.tgl_masuk, '%Y-%m-%d') as tgl_masuk2 from pengajuancuti as p left join karyawan on karyawan.id = p.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi left join jenis_cuti on jenis_cuti.id =p.id_jeniscuti;")->result(),
        ];
        $this->template->load("template", 'absensi/pengajuancuti', $data);
    }

    public function pengajuanpayroll()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Pengajuan Payroll',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select *,p.id as idutama ,jabatan.name as nama_jabatan,karyawan.name as nama_karyawan,DATE_FORMAT(p.tgl_masuk, '%Y-%m-%d') as tgl_masuk2 from pengajuancuti as p left join karyawan on karyawan.id = p.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi left join jenis_cuti on jenis_cuti.id =p.id_jeniscuti;")->result(),
        ];
        $this->template->load("template", 'absensi/pengajuanpayroll', $data);
    }
    public function pengajuanaktifitas()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Pengajuan Aktifitas',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select *,p.id as idutama ,jabatan.name as nama_jabatan,karyawan.name as nama_karyawan,DATE_FORMAT(p.tgl_masuk, '%Y-%m-%d') as tgl_masuk2 from pengajuancuti as p left join karyawan on karyawan.id = p.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi left join jenis_cuti on jenis_cuti.id =p.id_jeniscuti;")->result(),
        ];
        $this->template->load("template", 'absensi/pengajuanaktifitas', $data);
    }

    public function filterPengajuanPayroll()
    {
        $dataPost = $this->input->post();


        $query = $this->db->query("SELECT 
                                        pengajuanpayroll.id,
                                        karyawan.name,
                                        jenis_validasi.nama_jenis_validasi,
                                        IFNULL(pengajuanpayroll.keterangan, '-') as keterangan ,
                                        pengajuanpayroll.bulan,
                                        DATE_FORMAT(pengajuanpayroll.created_at, '%Y-%m-%d') as tanggal_pengajuan,
                                        case WHEN pengajuanpayroll.statuspengajuan = 0 then 'Draft'
                                            WHEN pengajuanpayroll.statuspengajuan = 1 then 'In Progres Approval'
                                            ELSE NULL
                                        END as status
                                    from pengajuanpayroll
                                    left join karyawan on pengajuanpayroll.id_karyawan = karyawan.id
                                    left join jenis_validasi on pengajuanpayroll.id_jenisvalidasi = jenis_validasi.id
                                    WHERE pengajuanpayroll.id_karyawan = '" . $dataPost['idKaryawan'] . "' 
                                        AND pengajuanpayroll.bulan =  '" . $dataPost['tanggal'] . "'
                                    ")->result();
        echo json_encode($query);
    }

    public function getDataPengajuanById()
    {
        echo json_encode(where_row('pengajuanpayroll', ['id' => $this->input->post('id')]));
    }

    public function updatepengajuanpayroll()
    {
        $id = $this->input->post('id');
        $idkaryawan = $this->input->post('idkaryawan');
        $bulan = $this->input->post('bulan');

        $keterangan = $this->input->post('keterangan');
        $statuspengajuan = $this->input->post('statuspengajuan');

        $tipevalidasi = $this->input->post('jenis_validasi');
        $queryAtasan1 = $this->db->query("SELECT * FROM organisasi_detail  WHERE id_karyawan = '$idkaryawan'")->row();

        $queryAtasan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                                                FROM organisasi_detail a
                                                LEFT JOIN karyawan b ON a.id_karyawan = b.id
                                                LEFT JOIN jabatan c ON a.id_jabatan = c.id
                                                LEFT JOIN divisi d ON a.id_divisi = d.id
                                                WHERE a.id_uniqjabatan = '$queryAtasan1->pid_uniq'")->row();
        $getvalidatorstep = $this->db->query("SELECT * FROM `validator` where id_jenisvalidasi = '$tipevalidasi' order by stepvalidasi ASC")->result();

        $this->db->trans_begin();
        insert_logAktivitas('Update Pengajuan Payroll');


        $data = update_table('pengajuanpayroll', [
            'id_karyawan' => $idkaryawan,
            'id_jenisvalidasi' => $tipevalidasi,
            'bulan' => $bulan,
            'keterangan' => $keterangan,
            'statuspengajuan' => $statuspengajuan
        ], ['id' => $id]);
        if ($statuspengajuan == "In Progres Approval") {

            foreach ($getvalidatorstep as $key => $value) {
                // var_dump($value);
                $this->db->set('id_approval_validator' . ($key + 1), (int)$value->id_jabatan);
            }
            $this->db->set('id_approval_karyawan', $idkaryawan);
            $this->db->set('step1', null);
            $this->db->set('step2', null);
            $this->db->set('step3', null);
            $this->db->set('step4', null);
            $this->db->set('step5', null);
            $this->db->set('id_tipevalidasi', $tipevalidasi);
            $this->db->set('created_at', date('Y-m-d H:i:s'));
            $this->db->set('tgl_pengajuan', date('Y-m-d H:i:s'));
            $this->db->insert('approval');
        }


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }
}
