<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Members extends CI_Controller
{
	
	function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        header("content-type:application/json");
        cek_post();
        error_reporting(0);
        ini_set('display_errors', 0);
    }
    public function index()
    {
    	$data = where_row("members",['access'=>post("phone")]);
        if ($data && !empty(post("phone"))) {
            $topup = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'topup'])->row();
            $point = $this->db->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'prabayar'])->num_rows();
            $bonus = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'bonus'])->row();
            $bonus_dum = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>0,'jenis'=>'bonus'])->row();
            $prabayar = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'prabayar'])->row();
            $pascabayar = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'pascabayar'])->row();
            $transfer = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'transfer'])->row();
            $upgrade = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'upgrade'])->row();
            $saldo = (($topup ? $topup->harga : 0)+($bonus ? $bonus->harga : 0)) - (($prabayar ? $prabayar->harga : 0 )+($pascabayar ? $pascabayar->harga : 0)+($transfer ? $transfer->harga : 0)+($upgrade ? $upgrade->harga : 0));
            $result = [
                'name'=>$data->name,
                'reff'=>$data->reff,
                'phone'=>$data->phone,
                'token'=>$data->token,
                'saldo'=>$saldo,
                'bonus'=>($bonus_dum->harga == null ? "0" : $bonus_dum->harga),
                'point'=>$point,
                'type'=>$data->type,
                'images'=>$data->images,
                'address'=>$data->address,
                'access'=>$data->access,
                'device'=>$data->device
            ];
        }else{
           $result = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ]; 
        }
    	
    	echo json_encode($result,200);
    }
    public function update_images()
    {
        if (!empty(post("phone"))) {
        $this->db->update("members",['images'=>post("images")],['access'=>post("phone")]);
        $data = [
                'status' => 1,
                'message' => 'Data members berhasil disimpan'
            ];
        }else{
            $data = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ];
        }
        echo json_encode($data);
    }
    public function update_profile()
    {
        if (!empty(post("phone"))) {
            if (empty(post("pin"))) {
                $save = $this->db->update("members",['name'=>post("name"),'address'=>post("address")],['access'=>post("phone")]);
            }else{
                $save = $this->db->update("members",['name'=>post("name"),'address'=>post("address"),'pin'=>MD5(post("pin"))],['access'=>post("phone")]);
            }
            
            if ($save) {
                $data = [
                    'status' => 1,
                    'message' => 'Data members berhasil diperbaharui'
                ];
            }else{
                $data = [
                    'status' => 0,
                    'message' => 'Data members gagal diperbaharui'
                ];
            }
        }else{
            $data = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ];
        }
        echo json_encode($data);
    }
    public function update_token()
    {
        if (!empty(post("phone"))) {
        	$this->db->update("members",['token'=>post("token")],['access'=>post("phone")]);
        	$data = [
                    'status' => 1,
                    'message' => 'Data members berhasil disimpan'
                ];
        }else{
            $data = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ];
        }
        echo json_encode($data);
    }
    public function get_members()
    {
        if (!empty(post("phone"))) {
            $data = where_row("members",['phone'=>post("phone")]);
            if ($data) {
                $result = [
                    'status' => 1,
                    'message' => $data->name."#".$data->phone,
                ];
            }else{
                $result = [
                    'status' => 0,
                    'message' => "No Handphone tidak terdaftar",
                ];
            }
        }else{
            $result = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ];
        }
        echo json_encode($result);
    }
    public function upgrade()
    {
        if (!empty(post("phone"))) {
            $row = $this->db->get_where("members",['access'=>post("phone")])->row();
            $insert = [
                'created_at'=>date("Y-m-d H:i:s"),
                'invoice'=>uniqid(""),
                'members'=>$row->reff,
                'harga'=>150000,
                'jual'=>150000,
                "keterangan"=>"Upgrade Premium  ".$row->name,
                'jenis'=>"upgrade",
                'status'=>1
            ];
            $save = $this->db->insert("transaksi",$insert);
            if ($save) {
                $this->db->update("members",['type'=>1],['access'=>post("phone")]);
                $insert = [
                    'created_at'=>date("Y-m-d H:i:s"),
                    'invoice'=>uniqid(""),
                    'members'=>$row->reff,
                    'harga'=>50000,
                    'jual'=>50000,
                    "keterangan"=>"Bonus upgrade Premium  ".$row->name,
                    'jenis'=>"bonus",
                    'status'=>1
                ];
                $result = [
                    'status'=>1,
                    'message'=>"Proses Upgrade Berhasil"
                ];  
            }else{
                $result = [
                    'status'=>0,
                    'message'=>"Proses Upgrade Gagal"
                ];  
            }
        }else{
           $result = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ]; 
        }
        echo json_encode($result);
    }
    public function downline()
    {
        if (!empty(post("phone"))) {
            $data = where_row("members",['access'=>post("phone")]);
            $result = $this->db->get_where("members",['upline'=>$data->reff])->result();
        }else{
            $result = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ];
        }
        echo json_encode($result);
    }
    public function cek()
    {
        $data = where_row("members",['access'=>post("phone")]);
        $topup = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'topup'])->row();
        $point = $this->db->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'prabayar'])->num_rows();
        $bonus = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'bonus'])->row();
        $bonus_dum = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>0,'jenis'=>'bonus'])->row();
        $prabayar = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'prabayar'])->row();
        $pascabayar = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'pascabayar'])->row();
        $transfer = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'transfer'])->row();
        $upgrade = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'upgrade'])->row();
        $saldo = ($topup->harga+$bonus->harga)- ($prabayar->harga+$pascabayar->harga+$transfer->harga+$upgrade->harga);
        echo $saldo;
    }
    public function transfer()
    {
        if (!empty(post("phone"))) {
            $data = where_row("members",['access'=>post("phone")]);
            $topup = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'topup'])->row();
            $point = $this->db->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'prabayar'])->num_rows();
            $bonus = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>1,'jenis'=>'bonus'])->row();
            $bonus_dum = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status'=>0,'jenis'=>'bonus'])->row();
            $prabayar = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'prabayar'])->row();
            $pascabayar = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'pascabayar'])->row();
            $transfer = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'transfer'])->row();
            $upgrade = $this->db->select_sum("harga")->get_where("transaksi",['members'=>$data->reff,'status <='=>1,'jenis'=>'upgrade'])->row();
            $saldo = ($topup->harga+$bonus->harga) - ($prabayar->harga+$pascabayar->harga+$transfer->harga+$upgrade->harga);
            if ($data->pin == MD5(post("pin"))) {
               if ($saldo > 0 && $saldo > post("amount") && post("amount") > 0) {
                    $client = where_row("members",['phone'=>post("client")]);
                    $inv_trf = "trf".post("invoice");
                    $inv_accp = "acp".post("invoice");
                    $this->db->insert('transaksi',[
                        'members'=>$data->reff,
                        'invoice'=>$inv_trf,
                        'jenis'=>'transfer',
                        'harga'=>post("amount"),
                        'jual'=>post("amount"),
                        'status'=>1,
                        'keterangan'=>"Transfer saldo sebesar Rp. ".number_format(post("amount"))." kepada ".$client->name,
                        'created_at'=>date("Y-m-d H:i:s")
                    ]);
                    $this->db->insert("notificaton",[
                                    'members'=>$data->reff,
                                    'invoice'=>$inv_trf,
                                    'text'=> "Transfer saldo sebesar Rp. ".number_format(post("amount"))." kepada ".$client->name,
                                    'created_at'=>date("Y-m-d H:i:s")
                                ]);
                    send_notif($data->token,'transfer',"Transfer Saldo Berhasil","Transfer saldo sebesar Rp. ".number_format(post("amount"))." kepada ".$client->name." Berhasil diproses",$inv_trf);
                    send_wa($data->phone,"Transfer saldo sebesar Rp. ".number_format(post("amount"))." kepada ".$client->name." Berhasil");

                    $this->db->insert('transaksi',[
                        'members'=>$client->reff,
                        'invoice'=>$inv_accp,
                        'jenis'=>'topup',
                        'harga'=>post("amount"),
                        'jual'=>post("amount"),
                        'status'=>1,
                        'keterangan'=>"Penerimaan saldo sebesar Rp. ".number_format(post("amount"))." dari ".$data->name,
                        'created_at'=>date("Y-m-d H:i:s")
                    ]);
                    $this->db->insert("trx_detail",[
                                    'invoice'=>$inv_trf,
                                    'pelanggan'=>$client->name,
                                    'code'=>"trf_saldo",
                                    'produk'=>"Transfer Saldo",
                                    "sn"=>"TRF".date("YmdHis")."DELTA"
                                ]);
                    $this->db->insert("notificaton",[
                                    'members'=>$client->reff,
                                    'invoice'=>$inv_accp,
                                    'text'=> "Penerimaan saldo sebesar Rp. ".number_format(post("amount"))." dari ".$data->name,
                                    'created_at'=>date("Y-m-d H:i:s")
                                ]);
                    send_notif($client->token,'topup',"Penerimaan Saldo","Penerimaan saldo sebesar Rp. ".number_format(post("amount"))." dari ".$members->name." Berhasil diproses",$inv_accp);
                    send_wa($client->phone,"Penerimaan saldo sebesar Rp. ".number_format(post("amount"))." dari ".$data->name);
                    $result = [
                            'status'=>1,
                            'message'=>"Pengiriman Saldo berasil"
                        ];
                   }else{
                    $result = [
                            'status'=>0,
                            'message'=>$saldo
                        ];
                   }
            }else{
                $result = [
                        'status'=>0,
                        'message'=>"PIN yang anda masukan salah "
                    ];
            }
        }else{
            $result = [
                'status' => 0,
                'message' => 'kredensial anda tidak memenuhi ketentuan'
            ];
        }
        echo json_encode($result);
    }
}