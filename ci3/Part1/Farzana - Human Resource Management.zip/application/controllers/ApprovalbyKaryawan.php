<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class ApprovalbyKaryawan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        // header("content-type:application/json"); 

        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }


    public function getdataapprovalbyjenisForPegawai()
    {
        $arrtemp = [];
        $arrDataApproval = [];
        $arrImplode = [];
        $id = $this->input->post('id');
        $login = $this->login->session();
        $queryBawahan1 = $this->db->query("SELECT *
        FROM organisasi_detail
        WHERE id_karyawan = '" . $login['id'] . "'")->row();
        if ($queryBawahan1 == null) {
            $this->getdataapprovalbyjenis();
        } else {

            $queryBawahan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                                            FROM organisasi_detail a
                                            LEFT JOIN karyawan b ON a.id_karyawan = b.id
                                            LEFT JOIN jabatan c ON a.id_jabatan = c.id
                                            LEFT JOIN divisi d ON a.id_divisi = d.id
                                            WHERE a.pid_uniq = '$queryBawahan1->id_uniqjabatan '
                                            ORDER BY a.id ASC")->result_array();
            foreach ($queryBawahan2 as $key => $value) {
                $queryApproval = $this->db->query("SELECT * from approval left join karyawan on karyawan.id = approval.id_approval_karyawan where id_approval_karyawan= '" . $value['id_karyawan'] . "'")->row();
                array_push($arrDataApproval, $queryApproval);
            }

            foreach (array_filter($arrDataApproval) as $key => $valisi) {
                // print_r($valisi);
                $arrImplode[$key] = "'" . $valisi->id_approval_karyawan . "'";
            }
            if (empty($arrImplode)) {
                $this->getdataapprovalbyjenis();
            } else {

                $query = $this->db->query("SELECT 'bawahan' as details,validasi.id,count(approval.id) as jumlah,validasi.nama_aktivitas FROM approval left join  validasi on approval.id_tipevalidasi = validasi.id_jenis where validasi.id_jenis='$id' AND approval.id_approval_karyawan IN (" . implode(',', $arrImplode) . ")")->row();
                if ($query->nama_aktivitas == null || $query->jumlah == null) {
                    $this->getdataapprovalbyjenis();
                } else {

                    array_push($arrtemp, $query);
                    echo json_encode($arrtemp);
                }
                // echo json_encode($this->db->last_query());
            }
        }
    }
    public function getdataapprovalbyjenis()
    {
        $id = $this->input->post('id');
        $query = $this->db->query("SELECT 'all' as details,validasi.id,count(approval.id) as jumlah,validasi.nama_aktivitas FROM validasi left join approval on approval.id_tipevalidasi = validasi.id_jenis where validasi.id_jenis='$id'")->result();
        echo json_encode($query);
    }
    public function getSettingValidator()
    {
        $idvalidasi = $this->input->post('idvalidasi');
        $idjenisvalidasi = $this->input->post('idjenisvalidasi');
        $query  = $this->db->query("select * from validator left join nama_step_validasi on nama_step_validasi.urut = validator.stepvalidasi where nama_step_validasi.id_validasi = '$idvalidasi'  and validator.id_jenisvalidasi = '$idjenisvalidasi' order by validator.stepvalidasi ASC;;")->result();
        echo json_encode($query);
    }
    public function getAksesValidasi()
    {
        $id = $this->input->post('id');
        $query = $this->db->query("select DISTINCT nama_step_validasi.*
        from validator 
        left join validasi  on validasi.id = validator.id_aktivitasvalidasi
        left join nama_step_validasi on nama_step_validasi.id_validasi = validator.id_aktivitasvalidasi
        where validator.id_jenisvalidasi ='$id' and ")->result();
        echo json_encode($query);
    }
    public function getAksesValidasiByUrut()
    {
        $id = $this->input->post('id');
        $urut = $this->input->post('urut');
        $aktifitas = $this->input->post('aktifitas');
        $query = $this->db->query("select * from validator left join nama_step_validasi on nama_step_validasi.urut = validator.stepvalidasi where nama_step_validasi.id_validasi = '$aktifitas'  and validator.id_jenisvalidasi = '$id' and validator.stepvalidasi='$urut' order by validator.stepvalidasi ASC;")->row();
        echo json_encode($query);
    }
    public function getSettingvalidatorByUrut()
    {
        $login = $this->login->session();
        $urut = $this->input->post('urut');
        $jabatan = $this->input->post('jabatan');
        $bidang = $this->input->post('bidang');
        $karyawan = $this->input->post('karyawan');
        $wherekaryawan = '';
        $wherebidang = '';
        $wherejabatan = '';
        // if ($karyawan != '' && $karyawan != 0) {
        //     $wherekaryawan = "AND id_karyawan= '" . $login['id'] . "'";
        // } else {
        //     $wherekaryawan = '';
        // }
        // if ($jabatan != '' && $jabatan != 0) {
        //     $wherejabatan = "AND id_jabatan= '" . $login['id_jabatan'] . "'";
        // } else {
        //     $wherejabatan = '';
        // }
        // if ($bidang != '' && $bidang != 0) {
        //     $wherebidang = "AND id_bidang= '" . $login['id_divisi'] . "'";
        // } else {
        //     $wherebidang = '';
        // }



        if ($karyawan != '' && $karyawan != 0) {
            if ($karyawan != $login['id']) {
                echo json_encode(null);
                die;
            } else {

                $wherekaryawan = "AND id_karyawan= '" . $login['id'] . "'";
            }
        } else {
            $wherekaryawan = '';
            if ($jabatan != $login['id_jabatan'] || $bidang != $login['id_divisi']) {
                echo json_encode(null);
                die;
            } else {

                if ($jabatan != '' && $jabatan != 0) {
                    $wherejabatan = "AND id_jabatan= '" . $login['id_jabatan'] . "'";
                } else {
                    $wherejabatan = '';
                }
                if ($bidang != '' && $bidang != 0) {
                    $wherebidang = "AND id_bidang= '" . $login['id_divisi'] . "'";
                } else {
                    $wherebidang = '';
                }
            }
        }

        if ($query = !null) {
        }
        $query = $this->db->query("select * from validator where stepvalidasi='$urut' $wherekaryawan $wherebidang $wherejabatan")->row();
        echo json_encode($query);
        // echo json_encode($this->db->last_query());
    }
    public function getSettingvalidatorByUrutIsPayroll()
    {
        $login = $this->login->session();
        $urut = $this->input->post('urut');
        $jabatan = $this->input->post('jabatan');
        $bidang = $this->input->post('bidang');
        $karyawan = $this->input->post('karyawan');
        $aktifitas = $this->input->post('aktifitas');
        $wherekaryawan = '';
        $wherebidang = '';
        $wherejabatan = '';
        // if ($karyawan != '' && $karyawan != 0) {
        //     $wherekaryawan = "AND id_karyawan= '" . $login['id'] . "'";
        // } else {
        //     $wherekaryawan = '';
        //     if ($jabatan != '' && $jabatan != 0) {
        //         $wherejabatan = "AND id_jabatan= '" . $login['id_jabatan'] . "'";
        //     } else {
        //         $wherejabatan = '';
        //     }
        //     if ($bidang != '' && $bidang != 0) {
        //         $wherebidang = "AND id_bidang= '" . $login['id_divisi'] . "'";
        //     } else {
        //         $wherebidang = '';
        //     }
        // }
        if ($karyawan != '' && $karyawan != 0) {
            if ($karyawan != $login['id']) {
                echo json_encode(null);
                die;
            } else {

                $wherekaryawan = "AND id_karyawan= '" . $login['id'] . "'";
            }
        } else {
            $wherekaryawan = '';
            if ($jabatan != $login['id_jabatan'] || $bidang != $login['id_divisi']) {
                echo json_encode(null);
                die;
            } else {

                if ($jabatan != '' && $jabatan != 0) {
                    $wherejabatan = "AND id_jabatan= '" . $login['id_jabatan'] . "'";
                } else {
                    $wherejabatan = '';
                }
                if ($bidang != '' && $bidang != 0) {
                    $wherebidang = "AND id_bidang= '" . $login['id_divisi'] . "'";
                } else {
                    $wherebidang = '';
                }
            }
        }

        // $query = $this->db->query("select * from validator where stepvalidasi='$urut' $wherekaryawan $wherebidang $wherejabatan")->row();
        if ($query = !null) {
        }
        $query = $this->db->query("select * from validator where stepvalidasi='$urut' AND id_aktivitasvalidasi='$aktifitas' $wherekaryawan $wherebidang $wherejabatan")->row();
        echo json_encode($query);
    }
    public function getDataIfValidator()
    {
        $login = $this->login->session();
        $query = $this->db->query("select jabatan.name as nama_jabatan, divisi.nama_divisi from karyawan
        LEFT JOIN jabatan on jabatan.id = karyawan.id_jabatan
        LEFT JOIN divisi on divisi.id = karyawan.id_divisi
        left join role on role.id = jabatan.id_role
        where karyawan.id = '" . $login['id'] . "'")->row();
        echo json_encode($query);
    }
    public function getDataIfValidator2()
    {
        $login = $this->login->session();
        $query = $this->db->query("select * from validator where id_karyawan= '" . $login['id'] . "' OR id_jabatan= '" . $login['id_jabatan'] . "' OR id_bidang= '" . $login['id_divisi'] . "'")->row();
        echo json_encode($query);
    }
    public function getdataapproval()
    {
        $login = $this->login->session();

        $id = $this->input->post('id');
        $query = $this->db->query("SELECT * from approval")->result();
        foreach ($query as $key => $value) {
            if ($query['id_approval_validator' . $key] == $login['id_jabatan']) {
                var_dump("SU");
            }
        }
        echo json_encode($query);
    }
    public function getdatadetailapproval()
    {
        $login = $this->login->session();
        $id = $this->input->post('id');
        $query = $this->db->query("SELECT 
        approval.id as id_approval,
        karyawan.id as id_karyawan,
        jb1.id as id_jabatan1,
        jb2.id as id_jabatan2,
        jb3.id as id_jabatan3,
        jb4.id as id_jabatan4,
        jb5.id as id_jabatan5,
        karyawan.name as nama_karyawan,
        DATE_FORMAT(approval.tgl_pengajuan, '%d-%m:%Y')as tgl_pengajuan ,
        approval.id_approval_validator1 as id_jabatanvalidator1,
        approval.id_approval_validator2 as id_jabatanvalidator2,
        approval.id_approval_validator3 as id_jabatanvalidator3,
        approval.id_approval_validator4 as id_jabatanvalidator4,
        approval.id_approval_validator5 as id_jabatanvalidator5,
        approval.step1,
        approval.step2,
        approval.step3,
        approval.step4,
        approval.step5
         FROM `approval`
        left join karyawan on karyawan.id = approval.id_approval_karyawan
        left join jabatan on jabatan.id = karyawan.id_jabatan
		LEFT JOIN role on role.id = jabatan.id_role
        left join jabatan as jb1 on  jb1.id =  approval.id_approval_validator1
        left join jabatan as jb2 on jb2.id = approval.id_approval_validator2
        left join jabatan as jb3 on jb3.id = approval.id_approval_validator3
        left join jabatan as jb4 on jb4.id = approval.id_approval_validator4 
        left join jabatan as jb5 on jb5.id = approval.id_approval_validator5
        where approval.id_tipevalidasi ='$id'
        AND approval.id_approval_validator1 = '" . $login['id_jabatan'] . "' 
        OR approval.id_approval_validator2 = '" . $login['id_jabatan'] . "' 
        OR approval.id_approval_validator3 = '" . $login['id_jabatan'] . "' 
        OR approval.id_approval_validator4 = '" . $login['id_jabatan'] . "' 
        OR approval.id_approval_validator5 = '" . $login['id_jabatan'] . "';")->result();
        // echo json_encode($query);
        echo json_encode($this->db->last_query());
    }

    public function dataApprovalbawahan()
    {
        $arrDataApproval = [];
        $arrDataApprovalFix = [];
        $login = $this->login->session();
        $queryBawahan1 = $this->db->query("SELECT *
        FROM organisasi_detail
        WHERE id_karyawan = '" . $login['id'] . "'")->row();
        // var_dump($queryBawahan1);
        if (!empty($queryBawahan1)) {
            $queryBawahan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
            FROM organisasi_detail a
            LEFT JOIN karyawan b ON a.id_karyawan = b.id
            LEFT JOIN jabatan c ON a.id_jabatan = c.id
            LEFT JOIN divisi d ON a.id_divisi = d.id
            WHERE a.pid_uniq = '$queryBawahan1->id_uniqjabatan '
            ORDER BY a.id ASC")->result_array();
            foreach ($queryBawahan2 as $key => $value) {
                $queryApproval = $this->db->query("SELECT * from approval left join karyawan on karyawan.id = approval.id_approval_karyawan where id_approval_karyawan= '" . $value['id_karyawan'] . "'")->result();
                array_push($arrDataApproval, $queryApproval);
            }
            // echo json_encode(array_filter($arrDataApproval));
            foreach (array_filter($arrDataApproval) as $key => $value) {

                $query = $this->db->query("SELECT 
                    approval.id as id_approval,
                    karyawan.id as id_karyawan,
                    jb1.id as id_jabatan1,
                    jb2.id as id_jabatan2,
                    jb3.id as id_jabatan3,
                    jb4.id as id_jabatan4,
                    jb5.id as id_jabatan5,
                    karyawan.name as nama_karyawan,
                    DATE_FORMAT(approval.tgl_pengajuan, '%d-%m:%Y')as tgl_pengajuan ,
                    approval.id_approval_validator1 as id_jabatanvalidator1,
                    approval.id_approval_validator2 as id_jabatanvalidator2,
                    approval.id_approval_validator3 as id_jabatanvalidator3,
                    approval.id_approval_validator4 as id_jabatanvalidator4,
                    approval.id_approval_validator5 as id_jabatanvalidator5,
                    approval.step1,
                    approval.step2,
                    approval.step3,
                    approval.step4,
                    approval.step5
                    FROM `approval`
                    left join karyawan on karyawan.id = approval.id_approval_karyawan
                    left join jabatan on jabatan.id = karyawan.id_jabatan
                    LEFT JOIN role on role.id = jabatan.id_role
                    left join jabatan as jb1 on  jb1.id =  approval.id_approval_validator1
                    left join jabatan as jb2 on jb2.id = approval.id_approval_validator2
                    left join jabatan as jb3 on jb3.id = approval.id_approval_validator3
                    left join jabatan as jb4 on jb4.id = approval.id_approval_validator4 
                    left join jabatan as jb5 on jb5.id = approval.id_approval_validator5
                    where approval.id_tipevalidasi ='10'
                    AND approval.id_approval_karyawan ='" . $value[0]->id . "'")->row();
                array_push($arrDataApprovalFix, $query);
            }
            if (empty($arrDataApprovalFix)) {
                return null;
            } else {

                echo json_encode(array_filter($arrDataApprovalFix));
            }
        } else {
            return null;
        }
    }

    public function SaveApproval()
    {
        $detailarr = $this->input->post('arr');
        $this->db->trans_begin();
        foreach ($detailarr as $key => $value) {

            $id = $value['id'];
            $status = $value['status'];
            $id_karyawan = $value['id_karyawan'];
            $cekstep = $this->db->query("select * from approval where id='$id'")->row();

            $str = '';

            if ($cekstep->step1 == "") {
                $str = 'step1';
            } else 
            if ($cekstep->step2 == "") {
                $str = 'step2';
            } else 
            if ($cekstep->step3 == "") {
                $str = 'step3';
            } else 
            if ($cekstep->step4 == "") {
                $str = 'step4';
            } else
            if ($cekstep->step5 == "") {
                $str = 'step5';
            }

            $data = update_table(
                'approval',
                [

                    $str => $status,

                ],
                ['id' => $id, 'id_approval_karyawan' => $id_karyawan]
            );
        }
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }
}



// berarti cek langsung bawahane sng aproval, lek ono tampilno
