<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Approval extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        // header("content-type:application/json"); 

        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }
    public function getdataapprovalbyjenis()
    {
        $id = $this->input->post('id');
        $query = $this->db->query("SELECT count(approval.id) as jumlah,validasi.nama_aktivitas FROM validasi left join approval on approval.id_tipevalidasi = validasi.id_jenis where validasi.id_jenis='$id'")->result();
        echo json_encode($query);
    }

    // public function getdataapprovalbyjenis()
    // {
    //     $id = $this->input->post('id');
    //     $query = $this->db->query("SELECT count(approval.id) as jumlah,validasi.nama_aktivitas FROM validasi left join approval on approval.id_tipevalidasi = validasi.id_jenis where validasi.id_jenis='$id'")->result();
    //     echo json_encode($query);
    // }
    public function getdataapproval()
    {
        $id = $this->input->post('id');
        $query = $this->db->query("SELECT * from approval")->result();
        echo json_encode($query);
    }
    public function getdatadetailapproval()
    {
        $id = $this->input->post('id');
        $query = $this->db->query("SELECT 
        approval.id as id_approval,
        karyawan.id as id_karyawan,
        jb1.id as id_jabatan1,
        jb2.id as id_jabatan2,
        jb3.id as id_jabatan3,
        jb4.id as id_jabatan4,
        jb5.id as id_jabatan5,
        karyawan.name as nama_karyawan,
        DATE_FORMAT(approval.tgl_pengajuan, '%d-%m:%Y')as tgl_pengajuan ,
        approval.id_approval_validator1 as id_jabatanvalidator1,
        approval.id_approval_validator2 as id_jabatanvalidator2,
        approval.id_approval_validator3 as id_jabatanvalidator3,
        approval.id_approval_validator4 as id_jabatanvalidator4,
        approval.id_approval_validator5 as id_jabatanvalidator5,
        approval.step1,
        approval.step2,
        approval.step3,
        approval.step4,
        approval.step5
         FROM `approval`
        left join karyawan on karyawan.id = approval.id_approval_karyawan
        left join jabatan as jb1 on  jb1.id =  approval.id_approval_validator1
        left join jabatan as jb2 on jb2.id = approval.id_approval_validator2
        left join jabatan as jb3 on jb3.id = approval.id_approval_validator3
        left join jabatan as jb4 on jb4.id = approval.id_approval_validator4 
        left join jabatan as jb5 on jb5.id = approval.id_approval_validator5
        where approval.id_tipevalidasi ='$id'")->result();
        echo json_encode($query);
    }
    public function SaveApproval()
    {
        $detailarr = $this->input->post('arr');
        $this->db->trans_begin();
        foreach ($detailarr as $key => $value) {

            $id = $value['id'];
            $status = $value['status'];
            $id_karyawan = $value['id_karyawan'];
            $cekstep = $this->db->query("select * from approval where id='$id'")->row();

            $str = '';

            if ($cekstep->step1 == "") {
                $str = 'step1';
            } else 
            if ($cekstep->step2 == "") {
                $str = 'step2';
            } else 
            if ($cekstep->step3 == "") {
                $str = 'step3';
            } else 
            if ($cekstep->step4 == "") {
                $str = 'step4';
            } else
            if ($cekstep->step5 == "") {
                $str = 'step5';
            }

            $data = update_table(
                'approval',
                [

                    $str => $status,

                ],
                ['id' => $id, 'id_approval_karyawan' => $id_karyawan]
            );
        }
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }
}
