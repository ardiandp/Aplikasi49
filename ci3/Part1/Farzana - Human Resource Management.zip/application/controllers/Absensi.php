<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Absensi extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        // header("content-type:application/json"); 

        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }
    public function presensi()
    {
        $login = $this->login->session();
        $namahari = longdate_indo(date('Y-m-d'));
        $pecahnamahari = explode(",", $namahari)[0];
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Penggajian',
            'hari' => $pecahnamahari,
            'haritanggal' => $namahari,
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select *,
                                            absensi.id as idutama, 
                                            DATE_FORMAT(absensi.jam_masuk, '%Y:%d:%m') as tgl_absen,
                                            DATE_FORMAT(absensi.jam_masuk, '%H:%i:%s') as absenjam_masuk, 
                                            DATE_FORMAT(absensi.jam_pulang, '%H:%i:%s') as absenjam_pulang,
                                            jam_kerja.jam_masuk jadwal_masuk,
                                            jam_kerja.jam_pulang jadwal_pulang,
                                            hariefektif.nama_hari
                                        from absensi 
                                        left join karyawan on karyawan.id = absensi.id_karyawan 
                                        left join jam_kerja on jam_kerja.id = absensi.id_jamkerja
                                        left join hariefektif on jam_kerja.hari = hariefektif.id
                                        where absensi.tgl = '" . date('Y-m-d') . "'
                                        order by absensi.tgl ASC")->result()
        ];
        // echo json_encode($data);
        // die;
        $this->template->load("template", 'absensi/presensi', $data);
    }


    public function penugasan()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Penggajian',
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'absensi/penugasan', $data);
    }
    public function laporanketidakhadiran()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Penggajian',
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'absensi/laporanketidakhadiran', $data);
    }
    public function getdatapengajuanaktifitas()
    {
        if ($this->session->userdata('user') == 'admin') {
            $whereData = "";
        } else {
            $whereData = "WHERE p.id_karyawan = '" . $this->session->userdata('id') . "'";
        }

        $data = $this->db->query("select *,p.id as idutama ,jabatan.name as nama_jabatan,karyawan.name as nama_karyawan,DATE_FORMAT(p.tgl_masuk, '%d-%m-%Y') as tgl_masuk2,DATE_FORMAT(p.tgl_akhir, '%d-%m-%Y') as tgl_akhir1,DATE_FORMAT(p.tgl_mulai, '%d-%m-%Y') as tgl_mulai1 from pengajuanaktifitas p left join karyawan on karyawan.id = p.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi left join jenis_cuti on jenis_cuti.id =p.id_jeniscuti $whereData")->result();
        echo json_encode($data);
    }


    // //////////////////////////////GETT
    public function getdatajam()
    {
        $hari = strtolower($this->input->post('hari'));
        $query = $this->db->query("select *, j.id as id_jamkerja from jam_kerja j left join hariefektif h on j.hari = h.id where LOWER(h.nama_hari) = '$hari'")->row();
        echo json_encode($query);
    }
    public function getdataabsensi()
    {
        $tgl = explode(" - ", $this->input->post('filterTanggal'));

        $tgl1 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[0])));
        $tgl2 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[1])));

        $query = $this->db->query("SELECT *,
                                        absensi.id as idutama, 
                                        DATE_FORMAT(absensi.jam_masuk, '%Y-%d-%m') as tgl_absen,
                                        DATE_FORMAT(absensi.jam_masuk, '%H:%i:%s') as absenjam_masuk, 
                                        DATE_FORMAT(absensi.jam_pulang, '%H:%i:%s') as absenjam_pulang,
                                        jam_kerja.jam_masuk jadwal_masuk,
                                        jam_kerja.jam_pulang jadwal_pulang,
                                        hariefektif.nama_hari
                                    from absensi 
                                    left join karyawan on karyawan.id = absensi.id_karyawan 
                                    left join jam_kerja on jam_kerja.id = absensi.id_jamkerja
                                    left join hariefektif on jam_kerja.hari = hariefektif.id
                                    where absensi.tgl BETWEEN '$tgl1' AND '$tgl2'
                                    order by absensi.tgl ASC")->result();
        echo json_encode($query);
    }
    public function getdatakaryawan()
    {
        $idkaryawan = $this->input->post('idkaryawan');
        $data = $this->db->query("select *, divisi.nama_divisi from karyawan left join jabatan on jabatan.id = karyawan.id_jabatan 
                                    left join divisi on divisi.id = karyawan.id_divisi
                                    where karyawan.id = '$idkaryawan'")->row();
        echo json_encode($data);
    }



    //////////////////////////end get


    // ////////////////////////////////////CETAK

    public function cetakpengajuancuti()
    {
        $id = $_GET['id'];
        $data['id'] = $_GET['id'];
        $data['response'] = $this->db->query("select *,jabatan.name as nama_jabatan, karyawan.name as nama_karyawan from pengajuancuti left join karyawan on karyawan.id = pengajuancuti.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi where pengajuancuti.id = '$id'")->row();
        // echo json_encode($data['response']);
        // die;
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->filename = "pengajuancuti.pdf";
        $options = $this->pdf->getOptions();
        $options->set(array('isRemoteEnabled' => true));
        $this->pdf->setOptions($options);
        $login = $this->login->session();
        $users = where_row('users', ['username' => $login['username']]);

        // $this->template->load("template", 'absensi/presensi', $data);
        $this->pdf->load_view('absensi/cetakpengajuancuti', $data);
    }
    /////////////////////end cetak
    public function addpengajuancuti()
    {

        $idkaryawan = $this->input->post('idkaryawan');
        $jenis_cuti = $this->input->post('jenis_cuti');
        $lama = $this->input->post('lama');
        $tanggal_mulai = $this->input->post('tanggal_mulai');
        $tanggal_akhir = $this->input->post('tanggal_akhir');
        $tanggal_masuk = $this->input->post('tanggal_masuk');
        $keterangan = $this->input->post('keterangan');
        $statuspengajuan = $this->input->post('statuspengajuan');
        $jumlah_hari_kerja = $this->input->post('jumlah_hari_kerja');
        $jumlah_hari_libur = $this->input->post('jumlah_hari_libur');
        $tipevalidasi = $this->input->post('jenis_validasi');
        // $queryAtasan1 = $this->db->query("SELECT * FROM organisasi_detail  WHERE id_karyawan = '$idkaryawan'")->row();

        // $queryAtasan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
        //                                         FROM organisasi_detail a
        //                                         LEFT JOIN karyawan b ON a.id_karyawan = b.id
        //                                         LEFT JOIN jabatan c ON a.id_jabatan = c.id
        //                                         LEFT JOIN divisi d ON a.id_divisi = d.id
        //                                         WHERE a.id_uniqjabatan = '$queryAtasan1->pid_uniq'")->row();
        $getvalidatorstep = $this->db->query("SELECT * FROM `validator` where id_jenisvalidasi = '$tipevalidasi' order by stepvalidasi ASC")->result();

        $this->db->trans_begin();
        insert_logAktivitas('Insert Pengajuan Cuti');


        $data = insert_table('pengajuancuti', [
            'id_karyawan' => $idkaryawan,
            'id_jenisvalidasi' => 10,
            'id_jeniscuti' => $jenis_cuti,
            'lama' => $lama,
            'tgl_mulai' => $tanggal_mulai,
            'tgl_akhir' => $tanggal_akhir,
            'tgl_masuk' => $tanggal_masuk,
            'keterangan' => $keterangan,
            'jumlah_hari_kerja' => $jumlah_hari_kerja,
            'jumlah_hari_libur' => $jumlah_hari_libur,
            'statuspengajuan' => $statuspengajuan,
            'acc_by' => NULL,
            'acc_on' => NULL
        ]);
        if ($statuspengajuan == "In Progres Approval") {

            foreach ($getvalidatorstep as $key => $value) {
                // var_dump($value);
                $this->db->set('id_approval_validator' . ($key + 1), (int)$value->id_jabatan);
            }
            $this->db->set('id_approval_karyawan', $idkaryawan);
            $this->db->set('step1', null);
            $this->db->set('step2', null);
            $this->db->set('step3', null);
            $this->db->set('step4', null);
            $this->db->set('step5', null);
            $this->db->set('id_tipevalidasi', $tipevalidasi);
            $this->db->set('created_at', date('Y-m-d H:i:s'));
            $this->db->set('tgl_pengajuan', date('Y-m-d H:i:s'));
            $eek = $this->db->insert('approval');
        }


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }
    public function addpengajuanaktifitas()
    {

        $idkaryawan = $this->input->post('idkaryawan');
        $namaaktifitas = $this->input->post('namaaktifitas');
        $lama = $this->input->post('lama');
        $tanggal_mulai = $this->input->post('tanggal_mulai');
        $tanggal_akhir = $this->input->post('tanggal_akhir');
        $tanggal_masuk = $this->input->post('tanggal_masuk');
        $keterangan = $this->input->post('keterangan');
        $statuspengajuan = $this->input->post('statuspengajuan');
        $jumlah_hari_kerja = $this->input->post('jumlah_hari_kerja');
        $jumlah_hari_libur = $this->input->post('jumlah_hari_libur');
        $tipevalidasi = $this->input->post('jenis_validasi');
        // $queryAtasan1 = $this->db->query("SELECT * FROM organisasi_detail  WHERE id_karyawan = '$idkaryawan'")->row();

        // $queryAtasan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
        //                                         FROM organisasi_detail a
        //                                         LEFT JOIN karyawan b ON a.id_karyawan = b.id
        //                                         LEFT JOIN jabatan c ON a.id_jabatan = c.id
        //                                         LEFT JOIN divisi d ON a.id_divisi = d.id
        //                                         WHERE a.id_uniqjabatan = '$queryAtasan1->pid_uniq'")->row();
        $getvalidatorstep = $this->db->query("SELECT * FROM `validator` where id_jenisvalidasi = '$tipevalidasi' order by stepvalidasi ASC")->result();

        $this->db->trans_begin();
        insert_logAktivitas('Insert Pengajuan Cuti');


        $data = insert_table('pengajuanaktifitas', [
            'id_karyawan' => $idkaryawan,
            'id_jenisvalidasi' => $tipevalidasi,
            'namaaktifitas' => $namaaktifitas,
            'lama' => $lama,
            'tgl_mulai' => $tanggal_mulai,
            'tgl_akhir' => $tanggal_akhir,
            'tgl_masuk' => $tanggal_masuk,
            'keterangan' => $keterangan,
            'jumlah_hari_kerja' => $jumlah_hari_kerja,
            'jumlah_hari_libur' => $jumlah_hari_libur,
            'statuspengajuan' => $statuspengajuan,
            'acc_by' => NULL,
            'acc_on' => NULL
        ]);
        if ($statuspengajuan == "In Progres Approval") {

            foreach ($getvalidatorstep as $key => $value) {
                // var_dump($value);
                $this->db->set('id_approval_validator' . ($key + 1), (int)$value->id_jabatan);
            }
            $this->db->set('id_approval_karyawan', $idkaryawan);
            $this->db->set('step1', null);
            $this->db->set('step2', null);
            $this->db->set('step3', null);
            $this->db->set('step4', null);
            $this->db->set('step5', null);
            $this->db->set('id_tipevalidasi', $tipevalidasi);
            $this->db->set('created_at', date('Y-m-d H:i:s'));
            $this->db->set('tgl_pengajuan', date('Y-m-d H:i:s'));
            $eek = $this->db->insert('approval');
        }


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }
    public function addpengajuanpayroll()
    {
        $idkaryawan = $this->input->post('idkaryawan');
        $bulan = $this->input->post('bulan');

        $keterangan = $this->input->post('keterangan');
        $statuspengajuan = $this->input->post('statuspengajuan');

        $tipevalidasi = $this->input->post('jenis_validasi');
        $queryAtasan1 = $this->db->query("SELECT * FROM organisasi_detail  WHERE id_karyawan = '$idkaryawan'")->row();

        $queryAtasan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                                                FROM organisasi_detail a
                                                LEFT JOIN karyawan b ON a.id_karyawan = b.id
                                                LEFT JOIN jabatan c ON a.id_jabatan = c.id
                                                LEFT JOIN divisi d ON a.id_divisi = d.id
                                                WHERE a.id_uniqjabatan = '$queryAtasan1->pid_uniq'")->row();
        $getvalidatorstep = $this->db->query("SELECT * FROM `validator` where id_jenisvalidasi = '$tipevalidasi' order by stepvalidasi ASC")->result();

        $this->db->trans_begin();
        insert_logAktivitas('Insert Pengajuan Payroll');


        $data = insert_table('pengajuanpayroll', [
            'id_karyawan' => $idkaryawan,
            'id_jenisvalidasi' => $tipevalidasi,
            'bulan' => $bulan,
            'keterangan' => $keterangan,
            'statuspengajuan' => $statuspengajuan,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        if ($statuspengajuan == "In Progres Approval") {

            foreach ($getvalidatorstep as $key => $value) {
                // var_dump($value);
                $this->db->set('id_approval_validator' . ($key + 1), (int)$value->id_jabatan);
            }
            $this->db->set('id_approval_karyawan', $idkaryawan);
            $this->db->set('step1', null);
            $this->db->set('step2', null);
            $this->db->set('step3', null);
            $this->db->set('step4', null);
            $this->db->set('step5', null);
            $this->db->set('id_tipevalidasi', $tipevalidasi);
            $this->db->set('created_at', date('Y-m-d H:i:s'));
            $this->db->set('tgl_pengajuan', date('Y-m-d H:i:s'));
            $eek = $this->db->insert('approval');
        }


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }
    public function editpengajuancuti()
    {
        $id = $this->input->post('id');

        $idkaryawan = $this->input->post('idkaryawan');
        $jenis_cuti = $this->input->post('jenis_cuti');
        $lama = $this->input->post('lama');
        $tanggal_mulai = $this->input->post('tanggal_mulai');
        $tanggal_akhir = $this->input->post('tanggal_akhir');
        $tanggal_masuk = $this->input->post('tanggal_masuk');
        $keterangan = $this->input->post('keterangan');
        $statuspengajuan = $this->input->post('statuspengajuan');
        $jumlah_hari_kerja = $this->input->post('jumlah_hari_kerja');
        $jumlah_hari_libur = $this->input->post('jumlah_hari_libur');
        $this->db->trans_begin();
        insert_logAktivitas('Insert Pengajuan Cuti');

        $data = update_table('pengajuancuti', [
            // 'id_karyawan' => $idkaryawan,
            // 'id_jenisvalidasi' => NULL,
            'id_jeniscuti' => $jenis_cuti,
            'lama' => $lama,
            'tgl_mulai' => $tanggal_mulai,
            'tgl_akhir' => $tanggal_akhir,
            'tgl_masuk' => $tanggal_masuk,
            'keterangan' => $keterangan,
            'jumlah_hari_kerja' => $jumlah_hari_kerja,
            'jumlah_hari_libur' => $jumlah_hari_libur,
            'statuspengajuan' => $statuspengajuan,
            'acc_by' => NULL,
            'acc_on' => NULL
        ], ['id' => $id]);


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
        // echo json_encode(1);
    }
    public function addabsensi()
    {
        $idkaryawan = $this->input->post('idkaryawan');
        $hari = $this->input->post('hari');
        $id_jam_kerja = $this->input->post('id_jam_kerja');
        $jam_absen = date('Y-m-d H:i:s');
        $tgl = date('Y-m-d');
        $tanggal_mulai = $this->input->post('tanggal_mulai');
        $tanggal_akhir = $this->input->post('tanggal_akhir');
        $keterangan = $this->input->post('keterangan');
        $status = $this->input->post('status');
        $statuspengajuan = $this->input->post('statuspengajuan');
        $latPositionUser = $this->input->post('latPositionUser');
        $longPositionUser = $this->input->post('longPositionUser');
        $type = $this->input->post('type');
        $data = $this->db->query("select * from absensi where id_karyawan ='$idkaryawan' and DATE_FORMAT(tgl, '%Y-%m-%d') ='$tgl'")->row();
        $users = where_row('karyawan', ['id' => $idkaryawan]);

        if (!empty($data)) {
            $error = false;

            if ($type == '1') {
                if ($data->jam_masuk == "") {
                    $error = false;
                    update_table('absensi', [
                        'jam_masuk' => $jam_absen,
                        'status_masuk' => $status,
                    ], ['id' => $data->id]);
                } else {
                    $error = true;
                    echo json_encode([
                        'status' => 400,
                        'message' => $users->name . " Telah melakukan absen masuk",
                    ]);
                }
            }

            if ($type == '2') {
                if ($data->jam_pulang == "") {
                    $error = false;
                    update_table('absensi', [
                        'jam_pulang' => $jam_absen,
                        'status_pulang' => $status,
                    ], ['id' => $data->id]);
                } else {
                    $error = true;
                    echo json_encode([
                        'status' => 400,
                        'message' => $users->name . " Telah melakukan absen pulang",
                    ]);
                }
            }

            if (!$error) {
                insert_table('absensi_detail', [
                    'id_absensi' => $data->id,
                    'latitude' => $latPositionUser,
                    'longitude' => $longPositionUser,
                    'type' => $type,
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                echo json_encode([
                    'status' => 200,
                    'message' => "Berhasil melakukan absen",
                ]);

                insert_logAktivitas('Update Absensi');
            }
        } else {


            if ($type == '1') {
                $absen = 'jam_masuk';
                $statusAbsen = 'status_masuk';
            }

            if ($type == '2') {
                $absen = 'jam_pulang';
                $statusAbsen = 'status_pulang';
            }

            $result =  insert_table('absensi', [
                'id_karyawan' => $idkaryawan,
                'id_jamkerja' => $id_jam_kerja,
                'tgl' => date('Y-m-d'),
                $absen => $jam_absen,
                $statusAbsen => $status,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            if ($result) {

                insert_table('absensi_detail', [
                    'id_absensi' => $this->db->insert_id(),
                    'latitude' => $latPositionUser,
                    'longitude' => $longPositionUser,
                    'type' => $type,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                insert_logAktivitas('Insert Absensi');
                echo json_encode([
                    'status' => 200,
                    'message' => "Berhasil melakukan absen",
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => "gagal melakukan absen, silahkan coba kembali",
                ]);
            }
        }
    }

    public function getLokasiKantor()
    {
        $datas = $this->db->select("b.name,c.latitude,c.longitude, c.satuan, c.jarak")
            ->from('penerimaan a')
            ->join('unit b', 'a.unit = b.id', 'left')
            ->join('lokasi_perusahaan c', 'b.id = c.id_unit', 'left')
            ->where('a.karyawan', $this->input->post('idkaryawan'))->get()->row();
        echo json_encode($datas);
    }

    public function laporankehadiran()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Laporan Kehadiran',
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'absensi/laporankehadiran', $data);
    }

    public function filterPresensi()
    {
        $dataPost = $this->input->post();

        $tgl = explode(" - ", $dataPost['tanggal']);

        $tgl1 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[0])));
        $tgl2 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[1])));

        $query = $this->db->query("SELECT   karyawan.name as karyawan_nama,
                                            hariefektif.nama_hari, 
                                            absensi.tgl, 
                                            jam_kerja.jam_masuk as jadwal_masuk,
                                            jam_kerja.jam_pulang as jadwal_pulang,
                                            DATE_FORMAT(absensi.jam_masuk, '%H:%i:%s') as jam_masuk,
                                            DATE_FORMAT(absensi.jam_pulang, '%H:%i:%s') as jam_pulang,
                                            absensi.status_masuk,
                                            absensi.status_pulang
                                    FROM absensi 
                                    LEFT JOIN karyawan ON absensi.id_karyawan = karyawan.id
                                    LEFT JOIN jam_kerja ON absensi.id_jamkerja = jam_kerja.id
                                    LEFT JOIN hariefektif ON jam_kerja.hari = hariefektif.id
                                    WHERE absensi.id_karyawan = '" . $dataPost['idKaryawan'] . "'
                                        AND absensi.tgl BETWEEN '$tgl1' AND '$tgl2'
                                        order by absensi.tgl ASC")->result();
        echo json_encode($query);
    }
}
