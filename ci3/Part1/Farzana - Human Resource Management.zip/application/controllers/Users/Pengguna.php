<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Pengguna extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }

    public function index()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Data Users',
            'tunjangan' => show_data('bonus'),
            'data' => $this->db->query("select users.*, jabatan.name as jabatan from users left join jabatan on users.id_jabatan = jabatan.id")->result(),
            'dataJabatan' => show_data('jabatan'),
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'Users/pengguna', $data);
    }
    public function save_pengguna()
    {
        $data = $this->input->post();
        $cek = where_count("users", ['username' => $data['username']]);
        $data['password'] = create_pass($data['password']);
        if ($cek == 0) {
            $save = insert_table('users', $data);
            insert_logAktivitas('Menambahkan data pengguna');
        } else {
            $save = update_table('users', $data, ['username' => $data['username']]);
            insert_logAktivitas('Update data pengguna');
        }
        if ($save) {
            $this->session->set_flashdata("success", 'Data pengaturan pengguna berhasil disimpan');
            redirect("Users/Pengguna");
        } else {
            $this->session->set_flashdata("error", 'Data pengaturan pengguna karyawan gagal disimpan');
            redirect("Users/Pengguna");
        }
    }
}
