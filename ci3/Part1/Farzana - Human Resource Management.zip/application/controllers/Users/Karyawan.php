<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
require 'vendor/autoload.php';

// Include librari PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;

class Karyawan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        $this->load->model('M_Karyawan');
        cek_session();
    }

    public function index()
    {
        $login = $this->login->session();

        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Data Karyawan',
            'data' => show_data('karyawan'),
            'dataAdmin' => show_data('users'),
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];

        $this->template->load("template", 'Users/karyawan', $data);
    }

    public function getDataKotaByProvinsiId()
    {
        echo json_encode($this->db->select('city_id as id, city_name as nama')
            ->from('cities')
            ->order_by('city_name', 'ASC')
            ->where('prov_id', $this->input->post('idProvinsi'))->get()->result());
    }

    public function getDataKecamatanByKotaId()
    {
        echo json_encode($this->db->select('dis_id as id, dis_name as nama')
            ->from('districts')
            ->order_by('dis_name', 'ASC')
            ->where('city_id', $this->input->post('idKota'))->get()->result());
    }

    public function getDataDesaByKecamatanId()
    {
        echo json_encode($this->db->select('subdis_id as id, subdis_name as nama')
            ->from('subdistricts')
            ->order_by('subdis_name', 'ASC')
            ->where('dis_id', $this->input->post('idKecamatan'))->get()->result());
    }

    public function form_karyawan()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Form Karyawan',
            'data' => show_data('karyawan'),
            'dataJabatan' => show_data('jabatan'),
            'dataStatusPegawai' => show_data('statuspegawai'),
            'dataUnit' => show_data('unit'),
            'dataProvinsi' => $this->db->select("prov_id as id, prov_name as nama")->from('provinces')->order_by('prov_name', 'ASC')->get()->result(),
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];

        if (isset($_GET['id']) || isset($_GET['mode'])) {
            $data['dataAtasan'] = $this->M_Karyawan->getAtasanKaryawan($_GET['id']);
            $data['dataBawahan'] = $this->M_Karyawan->getBawahanKaryawan($_GET['id']);
            $data['dataSKPengangkatan'] = $this->db->select("*")->from('tbl_skpengangkatan')->where('id_karyawan', $_GET['id'])->where('is_aktif', 'Active')->order_by('id', 'ASC')->get()->result();
        }

        // $this->template->load("template", 'Users/tambah_karyawan', $data);
        $this->template->load("template", 'Users/DataKepegawaian/form', $data);
    }

    public function view()
    {
        $login = $this->login->session();

        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Data',
            'dataUser' => $this->db->query("SELECT karyawan.*,
                                                    provinces.prov_name as provinsi_kk,
                                                    cities.city_name as kota_kk,
                                                    districts.dis_name as kecamatan_kk,
                                                    subdistricts.subdis_name as desa_kk,
                                                    provinces2.prov_name as provinsi_dom,
                                                    cities2.city_name as kota_dom,
                                                    districts2.dis_name as kecamatan_dom,
                                                    subdistricts2.subdis_name as desa_dom
                                            from karyawan
                                            left join provinces on karyawan.provinsi = provinces.prov_id
                                            left join provinces provinces2 on karyawan.provinsi_domisili = provinces2.prov_id
                                            left join cities on karyawan.kota = cities.city_id
                                            left join cities cities2 on karyawan.kota_domisili = cities2.city_id
                                            left join districts on karyawan.kecamatan = districts.dis_id
                                            left join districts districts2 on karyawan.kecamatan_domisili = districts2.dis_id
                                            left join subdistricts on karyawan.desa = subdistricts.subdis_id
                                            left join subdistricts subdistricts2 on karyawan.desa_domisili = subdistricts2.subdis_id
                                            where karyawan.id = '" . $_GET['id'] . "'")->row(),
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];

        $this->template->load("template", 'Users/view_karyawan', $data);
    }


    public function tambah_karyawan_by_email()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('users', ['username' => $login['username']]),
            'title' => 'Input Data Karyawan by Email',
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'Users/tambah_karyawan_by_email', $data);
    }

    public function saveKaryawanByEmail()
    {
        $dataPost = $this->input->post();

        $waktu = $dataPost['waktu'] == "" || $dataPost['waktu'] == null ? "+ 7 days" : "+ " . $dataPost['waktu'] . " days";


        $emailEmpty  = [];
        $this->db->trans_begin();

        if ($dataPost['type'] == "") {
            foreach ($dataPost['dataChecked'] as $key => $value) {

                $dataKaryawan = where_row('karyawan', ['id' => $value]);

                if ($dataKaryawan->email == "") {
                    array_push($emailEmpty, $dataKaryawan->name);
                }


                update_table('karyawan', [
                    'is_invited' => 1,
                    'waktu_is_edit' => date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s') . $waktu))
                ], ['id' => $value]);

                $this->_sendEmail($dataKaryawan->email, $dataPost['type']);
            }

            insert_logAktivitas('Undang karyawan by email');
        }

        if ($dataPost['type'] == "invited") {
            $dataKaryawan = where_row('karyawan', ['id' => $dataPost['dataChecked']]);

            if ($dataKaryawan->email == "") {
                array_push($emailEmpty, $dataKaryawan->name);
            }

            update_table('karyawan', [
                'is_invited' => 1,
                'waktu_is_edit' => date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s') . $waktu))
            ], ['id' => $dataPost['dataChecked']]);

            insert_logAktivitas('Undang karyawan by email');

            $this->_sendEmail($dataKaryawan->email, $dataPost['type']);
        }

        if ($dataPost['type'] == "uninvited") {
            $dataKaryawan = where_row('karyawan', ['id' => $dataPost['dataChecked']]);

            if ($dataKaryawan->email == "") {
                array_push($emailEmpty, $dataKaryawan->name);
            }

            update_table('karyawan', [
                'is_invited' => NULL,
                'waktu_is_edit' => NULL
            ], ['id' => $dataPost['dataChecked']]);

            insert_logAktivitas('Menonaktifkan Undang karyawan by email');

            $this->_sendEmail($dataKaryawan->email, $dataPost['type']);
        }

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode([
                'type' => 203,
                'message' => 'Send email gagal',
                'data' => [],
            ]);
        } else if (!empty($emailEmpty)) {
            $this->db->trans_rollback();
            echo json_encode([
                'type' => 202,
                'message' => 'Data gagal disimpan, email karyawan kosong',
                'data' => $emailEmpty,
            ]);
        } else {
            $this->db->trans_commit();
            echo json_encode([
                'type' => 200,
                'message' => 'Berhasil send email ke karyawan yang telah terpilih',
                'data' => [],
            ]);
        }
    }

    private function _sendEmail($email, $type)
    {

        $config = [
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'protocol'  => 'smtp',
            'smtp_host' => 'smtp.gmail.com',
            'smtp_user' => 'akbaraisyah000@gmail.com',  // Email gmail
            'smtp_pass'   => 'jngvwzwxosmldgqv',  // Password gmail
            'smtp_crypto' => 'ssl',
            'smtp_port'   => 465,
            'crlf'    => "\r\n",
            'newline' => "\r\n"
        ];

        // Load library email dan konfigurasinya
        $this->load->library('email');
        $this->email->initialize($config);

        // Email dan nama pengirim
        $this->email->from('support@ekitir.com', 'YBN');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan


        // Isi email
        $this->email->subject("Undangan akun karyawan");
        $message = "";
        $href = $type == "" ? base_url('Auth') . "/verify?email=" . $email : base_url('Auth');
        if ($type == "" || $type == 'invited') {
            $message .= '<div class="email" style="border: 1px solid gray;border-radius: 10px;padding: 15px;min-height: 15vh;position: relative;margin: auto;width: 70%;text-align: center;">
                            <h3 style="font-weight: 800;">Undangan akun karyawan</h3>
                            <h6 style="font-weight: 200;margin-top: 10px;">Akun anda telah diundang oleh admin untuk bisa melalukan perbaikan data personal anda, silahkan ubah data personal anda sebelum admin mengancel undangan ini</h6>
                            <h6 style="font-weight: 200;margin-top: 10px;margin-bottom: 40px;text-align: left">
                                Jika anda belum pernah melakukan perubahaan password, gunakan password berikut <strong>12345678</strong>, dan jika anda sudah pernah berubah password, silahkan login menggunakan password yang terbaru
                            </h6>

                            <a href="' . $href . '" style="padding: 15px;font-size: 20px;background: #0e7490;border-radius: 10px;font-weight: 700;color: white;font-family: monospace;">Login</a>
                        </div>';
        }

        if ($type == 'uninvited') {
            $message .= '<div class="email" style="border: 1px solid gray;border-radius: 10px;padding: 15px;min-height: 15vh;position: relative;margin: auto;width: 70%;text-align: center;">
                            <h3 style="font-weight: 800;">Undangan akun karyawan</h3>
                            <h6 style="font-weight: 200;margin-top: 10px;">Akun anda telah didinonaktifkan oleh admin untuk bisa melalukan perbaikan data personal anda</h6>

                            <a href="' . base_url('Auth') . '" style="padding: 15px;font-size: 20px;background: #0e7490;border-radius: 10px;font-weight: 700;color: white;font-family: monospace;">Login</a>
                        </div>';
        }

        $this->email->message($message);

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {
            return true;
        } else {
            echo $this->email->print_debugger();
            die;
        }
    }

    public function save_karyawan()
    {
        $data = $this->input->post();


        if ($data['idUsers'] == "") {
            $dataKaryawan = [
                'id_jabatan' => $data['jabatanPersonal'],
                'name' => $data['namaPersonal'],
                'phone' => $data['teleponPersonal'],
                'email' => $data['emailPersonal'],
                'jenis_kelamin' => $data['genderPersonal'],
                'tmp_lahir' => $data['tempatLahirPersonal'],
                'tgl_lahir' => $data['tanggalLahirPersonal'],
                'suku' => $data['sukuPersonal'],
                'agama' => $data['agamaPersonal'],
                'golongan_darah' => $data['golDarahPersonal'],
                'status_pernikahan' => $data['statusPernikahanPersonal'],
                'no_ktp' => $data['noKTPPersonal'],
                'no_npwp' => $data['noNPWPPersonal'],
                'nip' => $data['nipPersonal'],
                'provinsi' => $data['provinsiKTP'],
                'kota' => $data['kotaKTP'],
                'kecamatan' => $data['kecamatanKTP'],
                'desa' => $data['desaKTP'],
                'alamat' => $data['alamatKTP'],
                'status' => 0,
                'password' => create_pass('12345678')
            ];

            if ($data['valueChkDomisili'] == '1') {
                $dataKaryawan['provinsi_domisili'] = $data['provinsiDomisili'];
                $dataKaryawan['kota_domisili'] = $data['kotaDomisili'];
                $dataKaryawan['kecamatan_domisili'] = $data['kecamatanDomisili'];
                $dataKaryawan['desa_domisili'] = $data['desaDomisili'];
                $dataKaryawan['alamat_domisili'] = $data['alamatDomisili'];
                $dataKaryawan['is_domisili_same_kk'] = NULL;
            } else {
                $dataKaryawan['is_domisili_same_kk'] = 1;
            }

            $save = insert_table('karyawan', $dataKaryawan);
            if ($save) {

                $lastId = $this->db->insert_id();

                insert_logAktivitas('Tambah data karyawan ( Data umum )');
                $this->session->set_flashdata("success", 'Data karyawan berhasil disimpan');
                redirect("Users/Karyawan/form_karyawan?id=" . $lastId);
            } else {
                $this->session->set_flashdata("error", 'Data karyawan gagal disimpan');
                redirect("Users/Karyawan");
            }
        } else {

            $dataKaryawanUpdate = [
                'id_jabatan' => $data['jabatanPersonal'],
                'name' => $data['namaPersonal'],
                'phone' => $data['teleponPersonal'],
                'email' => $data['emailPersonal'],
                'jenis_kelamin' => $data['genderPersonal'],
                'tmp_lahir' => $data['tempatLahirPersonal'],
                'tgl_lahir' => $data['tanggalLahirPersonal'],
                'suku' => $data['sukuPersonal'],
                'agama' => $data['agamaPersonal'],
                'golongan_darah' => $data['golDarahPersonal'],
                'status_pernikahan' => $data['statusPernikahanPersonal'],
                'no_ktp' => $data['noKTPPersonal'],
                'no_npwp' => $data['noNPWPPersonal'],
                'nip' => $data['nipPersonal'],
                'provinsi' => $data['provinsiKTP'],
                'kota' => $data['kotaKTP'],
                'kecamatan' => $data['kecamatanKTP'],
                'desa' => $data['desaKTP'],
                'alamat' => trim($data['alamatKTP']),
            ];

            if ($data['valueChkDomisili'] == '1') {
                $dataKaryawanUpdate['provinsi_domisili'] = $data['provinsiDomisili'];
                $dataKaryawanUpdate['kota_domisili'] = $data['kotaDomisili'];
                $dataKaryawanUpdate['kecamatan_domisili'] = $data['kecamatanDomisili'];
                $dataKaryawanUpdate['desa_domisili'] = $data['desaDomisili'];
                $dataKaryawanUpdate['alamat_domisili'] = trim($data['alamatDomisili']);
                $dataKaryawanUpdate['is_domisili_same_kk'] = NULL;
            } else {
                $dataKaryawanUpdate['provinsi_domisili'] = NULL;
                $dataKaryawanUpdate['kota_domisili'] = NULL;
                $dataKaryawanUpdate['kecamatan_domisili'] = NULL;
                $dataKaryawanUpdate['desa_domisili'] = NULL;
                $dataKaryawanUpdate['alamat_domisili'] = NULL;
                $dataKaryawanUpdate['is_domisili_same_kk'] = 1;
            }

            $save = update_table('karyawan', $dataKaryawanUpdate, ['id' => $data['idUsers']]);
            if ($save) {

                insert_logAktivitas('Update data karyawan ( Data umum )');

                $this->session->set_flashdata("success", 'Data karyawan berhasil diperbaharui');
                redirect("Users/karyawan/form_karyawan?id=" . $data['idUsers']);
            } else {
                $this->session->set_flashdata("error", 'Data karyawan gagal diperbaharui');
                redirect("Users/Karyawan");
            }
        }
    }

    public function getDataKeluargaInti()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('*')->from('tbl_keluarga')->where('id_karyawan', $this->input->post('idUsers'))->where('type', 1)->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataKeluargaAnda()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('a.*, b.prov_name as provinsiNama, c.city_name as kotaNama, d.dis_name as kecamatanNama, e.subdis_name as desaNama')
                ->from('tbl_keluarga a')
                ->join('provinces b', 'a.provinsi = b.prov_id', 'left')
                ->join('cities c', 'a.kota = c.city_id', 'left')
                ->join('districts d', 'a.kecamatan = d.dis_id', 'left')
                ->join('subdistricts e', 'a.desa = e.subdis_id', 'left')
                ->where('a.id_karyawan', $this->input->post('idUsers'))
                ->where('a.type', 2)->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataKeluargaEmergency()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('a.*, b.prov_name as provinsiNama, c.city_name as kotaNama, d.dis_name as kecamatanNama, e.subdis_name as desaNama')
                ->from('tbl_keluarga a')
                ->join('provinces b', 'a.provinsi = b.prov_id', 'left')
                ->join('cities c', 'a.kota = c.city_id', 'left')
                ->join('districts d', 'a.kecamatan = d.dis_id', 'left')
                ->join('subdistricts e', 'a.desa = e.subdis_id', 'left')
                ->where('a.id_karyawan', $this->input->post('idUsers'))
                ->where('a.is_emergency_contact', 1)->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataKeluargaById()
    {
        echo json_encode(where_row('tbl_keluarga', ['id' => $this->input->post('idKeluarga')]));
    }

    public function saveKeluargaKaryawan()
    {
        $dataPost = $this->input->post();

        if ($dataPost['mode'] == 'insert') {
            $dataKeluarga = [
                'id_karyawan' => $dataPost['idUsers'],
                'nik' => $dataPost['nik'],
                'nama' => $dataPost['nama'],
                'tempat_lahir' => $dataPost['tempat_lahir'],
                'tanggal_lahir' => $dataPost['tanggal_lahir'],
                'jenis_kelamin' => $dataPost['jenis_kelamin'],
                'hubungan' => $dataPost['hubungan'],
                'status' => $dataPost['status'],
                'pekerjaan' => $dataPost['pekerjaan'],
                'type' => $dataPost['type'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            if ($dataPost['type'] == '2') {
                $dataKeluarga['phone'] = $dataPost['noPhone'];
                $dataKeluarga['provinsi'] = $dataPost['provinsi'];
                $dataKeluarga['kota'] = $dataPost['kota'];
                $dataKeluarga['kecamatan'] = $dataPost['kecamatan'];
                $dataKeluarga['desa'] = $dataPost['desa'];
                $dataKeluarga['alamat'] = $dataPost['alamat'];

                if ($dataPost['isEmegercy'] == '1') {
                    $dataKeluarga['is_emergency_contact'] = 1;
                }
            }

            $result = insert_table('tbl_keluarga', $dataKeluarga);

            if ($result) {
                insert_logAktivitas('Tambah data karyawan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'type' => $dataPost['type'],
                    'message' => 'Data Keluarga berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Keluarga gagal disimpan'
                ]);
            }
        }

        if ($dataPost['mode'] == 'update') {
            $dataKeluarga = [
                'nik' => $dataPost['nik'],
                'nama' => $dataPost['nama'],
                'tempat_lahir' => $dataPost['tempat_lahir'],
                'tanggal_lahir' => $dataPost['tanggal_lahir'],
                'jenis_kelamin' => $dataPost['jenis_kelamin'],
                'hubungan' => $dataPost['hubungan'],
                'status' => $dataPost['status'],
                'pekerjaan' => $dataPost['pekerjaan']
            ];

            if ($dataPost['type'] == '2') {
                $dataKeluarga['phone'] = $dataPost['noPhone'];
                $dataKeluarga['provinsi'] = $dataPost['provinsi'];
                $dataKeluarga['kota'] = $dataPost['kota'];
                $dataKeluarga['kecamatan'] = $dataPost['kecamatan'];
                $dataKeluarga['desa'] = $dataPost['desa'];
                $dataKeluarga['alamat'] = $dataPost['alamat'];

                if ($dataPost['isEmegercy'] == '1') {
                    $dataKeluarga['is_emergency_contact'] = 1;
                } else {
                    $dataKeluarga['is_emergency_contact'] = NULL;
                }
            }

            $result = update_table('tbl_keluarga', $dataKeluarga, ['id' => $dataPost['idKeluarga']]);

            if ($result) {
                insert_logAktivitas('Edit data karyawan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'type' => $dataPost['type'],
                    'message' => 'Data Keluarga berhasil diedit'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Keluarga gagal diedit'
                ]);
            }
        }
    }

    public function updateDataKeluargaToEmergemcy()
    {
        $dataPost = $this->input->post();
        $this->db->set('is_emergency_contact', 1);
        $this->db->where_in('id', $dataPost['dataIdKeluarga']);
        $result =  $this->db->update('tbl_keluarga');

        if ($result) {
            insert_logAktivitas('Mengubah data keluarga ke emergency contact');
            echo json_encode([
                'status' => 200,
                'type' => $dataPost['type'],
                'message' => 'Data Keluarga berhasil diubah ke emergency contact'
            ]);
        } else {
            echo json_encode([
                'status' => 400,
                'message' => 'Data Keluarga gagal diubah ke emergency contact'
            ]);
        }
    }

    /******************************************** Controller Pekerjaan ***********************************************/

    public function getLokasiUnitById()
    {
        $data = $this->db->select("*")->from('lokasi_perusahaan')->where('id_unit', $this->input->post('value'))->get()->row();
        echo json_encode($data);
    }

    public function save_pekerjaan()
    {
        $dataPost = $this->input->post();

        $ifExistPekerjaan = where_count("tbl_pekerjaan", ['id_karyawan' => $dataPost['idUsers']]);
        $ifExistPenerimaan = where_count("penerimaan", ['karyawan' => $dataPost['idUsers']]);

        $this->db->trans_begin();

        if ($dataPost['cabang_unit'] != "" || $dataPost['tanggal_gabung'] != "") {
            if ($ifExistPenerimaan == 0) {
                $dataPenerimaanInsert = [
                    'karyawan' => $dataPost['idUsers'],
                    'unit' => $dataPost['cabang_unit'] == "" ? NULL : $dataPost['cabang_unit'],
                    'date' => $dataPost['tanggal_gabung'] == "" ? NULL : $dataPost['tanggal_gabung'],
                    'created_at' => date('Y-m-d H:i:s'),
                ];

                insert_table('penerimaan', $dataPenerimaanInsert);
            } else {
                $dataPenerimaanUpdate = [
                    'unit' => $dataPost['cabang_unit'] == "" ? NULL : $dataPost['cabang_unit'],
                    'date' => $dataPost['tanggal_gabung'] == "" ? NULL : $dataPost['tanggal_gabung']
                ];

                update_table('penerimaan', $dataPenerimaanUpdate, ['karyawan' => $dataPost['idUsers']]);
            }
        }

        if ($ifExistPekerjaan == 0) {

            $dataPekerjaan = [
                'id_karyawan' => $dataPost['idUsers'],
                'id_statuspegawai' => $dataPost['status_pegawai'],
                'id_skpengangkatan' => $dataPost['sk_pengangkatan'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            insert_table('tbl_pekerjaan', $dataPekerjaan);
            insert_logAktivitas('Tambah data pekerjaan Karyawan');
        } else {
            $dataPekerjaanUpdate = [
                'organisasi' => $dataPost['organisasi'],
                'id_statuspegawai' => $dataPost['status_pegawai'],
                'id_skpengangkatan' =>  $dataPost['sk_pengangkatan']
            ];

            update_table('tbl_pekerjaan', $dataPekerjaanUpdate, ['id_karyawan' => $dataPost['idUsers']]);
            insert_logAktivitas('Edit data pekerjaan Karyawan');
        }


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();

            $this->session->set_flashdata("error", 'Data gagal disimpan!');
            redirect("Users/Karyawan/form_karyawan/?id=" . $dataPost['idUsers']);
        } else {
            $this->db->trans_commit();
            $this->session->set_flashdata("success", 'Data berhasil disimpan!');
            redirect("Users/Karyawan/form_karyawan/?id=" . $dataPost['idUsers']);
        }
    }

    public function getDataPendidikanFormal()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('tbl_sekolah.*, pendidikan.name as jenjang')
                ->from('tbl_sekolah')
                ->join('pendidikan', 'tbl_sekolah.id_pendidikan = pendidikan.id', 'left')
                ->where('tbl_sekolah.id_karyawan', $this->input->post('idUsers'))
                ->where('type', 1)->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataPendidikanInformal()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('*')
                ->from('tbl_sekolah')
                ->where('id_karyawan', $this->input->post('idUsers'))
                ->where('type', 2)->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function saveSekolahKaryawan()
    {
        $dataPost = $this->input->post();


        if ($dataPost['mode'] == "insert") {
            if ($dataPost['type'] == "1") {
                $dataSekolah = [
                    'id_karyawan' => $dataPost['idUsers'],
                    'id_pendidikan' => $dataPost['jenjangFormal'],
                    'nama_sekolah' => $dataPost['namaSekolahFormal'],
                    'jurusan' => $dataPost['jurusanFormal'],
                    'tahun_masuk' => $dataPost['tahunMasukFormal'],
                    'tahun_keluar' => $dataPost['tahunKeluarFormal'],
                    'type' => $dataPost['type'],
                    'created_at' => date('Y-m-d H:i:s')
                ];
            } else {
                $dataSekolah = [
                    'id_karyawan' => $dataPost['idUsers'],
                    'penyelenggara' => $dataPost['penyelenggaraInformal'],
                    'nama_kursus' => $dataPost['namaKursusInformal'],
                    'tempat' => $dataPost['tempatInformal'],
                    'tahun' => $dataPost['tahunInformal'],
                    'keterangan' => $dataPost['keteranganInformal'],
                    'type' => $dataPost['type'],
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }


            $result = insert_table('tbl_sekolah', $dataSekolah);
            if ($result) {
                insert_logAktivitas('Tambah data Pendidikan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'type' => $dataPost['type'],
                    'message' => 'Data Pendidikan berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Pendidikan gagal disimpan'
                ]);
            }
        }
        if ($dataPost['mode'] == "update") {

            if ($dataPost['type'] == "1") {
                $dataSekolahUpdate = [
                    'id_karyawan' => $dataPost['idUsers'],
                    'id_pendidikan' => $dataPost['jenjangFormal'],
                    'nama_sekolah' => $dataPost['namaSekolahFormal'],
                    'jurusan' => $dataPost['jurusanFormal'],
                    'tahun_masuk' => $dataPost['tahunMasukFormal'],
                    'tahun_keluar' => $dataPost['tahunKeluarFormal'],
                    'type' => $dataPost['type']
                ];
            } else {
                $dataSekolahUpdate = [
                    'id_karyawan' => $dataPost['idUsers'],
                    'penyelenggara' => $dataPost['penyelenggaraInformal'],
                    'nama_kursus' => $dataPost['namaKursusInformal'],
                    'tempat' => $dataPost['tempatInformal'],
                    'tahun' => $dataPost['tahunInformal'],
                    'keterangan' => $dataPost['keteranganInformal'],
                    'type' => $dataPost['type']
                ];
            }

            $result = update_table('tbl_sekolah', $dataSekolahUpdate, ['id' => $dataPost['idSekolah']]);
            if ($result) {
                insert_logAktivitas('Edit data Pendidikan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'type' => $dataPost['type'],
                    'message' => 'Data Pendidikan berhasil diubah'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Pendidikan gagal diubah'
                ]);
            }
        }
    }

    public function getDataPendidikanById()
    {
        echo json_encode(where_row('tbl_sekolah', ['id' => $this->input->post('idSekolah')]));
    }


    /******************************************** Controller Pekerjaan ***********************************************/

    /******************************************** Controller Pengalaman Kerja ***********************************************/

    public function getDataPengalamanKerja()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('*')
                ->from('tbl_pengalaman_kerja')
                ->where('id_karyawan', $this->input->post('idUsers'))->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataPengalamanKerjaById()
    {
        echo json_encode(where_row('tbl_pengalaman_kerja', ['id' => $this->input->post('idPengalamanKerja')]));
    }

    public function savePengalamanKerjaKaryawan()
    {
        $dataPost = $this->input->post();

        if ($dataPost['mode'] == "insert") {
            $dataPengalamanKerja = [
                'id_karyawan' => $dataPost['idUsers'],
                'nama_pekerjaan' => $dataPost['namaPekerjaanPengalamanKerja'],
                'jabatan' => $dataPost['jabatanPengalamanKerja'],
                'tahun_masuk' => $dataPost['tahunMasukPengalamanKerja'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            if ($dataPost['thnPngalamanNow'] == 'true') {
                $dataPengalamanKerja['is_now_work'] = 1;
            } else {
                $dataPengalamanKerja['tahun_keluar'] = $dataPost['tahunKeluarPengalamanKerja'];
            }

            $result = insert_table('tbl_pengalaman_kerja', $dataPengalamanKerja);
            if ($result) {
                insert_logAktivitas('Tambah data Pengalaman Kerja ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Pengalaman Kerja berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Pengalaman Kerja gagal disimpan'
                ]);
            }
        }
        if ($dataPost['mode'] == "update") {

            $dataPengalamanKerjaUpdate = [
                'nama_pekerjaan' => $dataPost['namaPekerjaanPengalamanKerja'],
                'jabatan' => $dataPost['jabatanPengalamanKerja'],
                'tahun_masuk' => $dataPost['tahunMasukPengalamanKerja']
            ];

            if ($dataPost['thnPngalamanNow'] == 'true') {
                $dataPengalamanKerjaUpdate['is_now_work'] = 1;
                $dataPengalamanKerjaUpdate['tahun_keluar'] = NULL;
            } else {
                $dataPengalamanKerjaUpdate['is_now_work'] = NULL;
                $dataPengalamanKerjaUpdate['tahun_keluar'] = $dataPost['tahunKeluarPengalamanKerja'];
            }

            $result = update_table('tbl_pengalaman_kerja', $dataPengalamanKerjaUpdate, ['id' => $dataPost['idPengalamanKerja']]);
            if ($result) {
                insert_logAktivitas('Edit data Pengalaman Kerja ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Pengalaman Kerja berhasil diubah'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Pengalaman Kerja gagal diubah'
                ]);
            }
        }
    }

    /******************************************** Controller Pengalaman Kerja ***********************************************/


    /******************************************** Controller SK Pengangkatan ***********************************************/

    public function getLastNomorSK()
    {
        $result = $this->M_Karyawan->getLastNomorSK();
        if ($result == '') {
            echo json_encode("0001.K/SDM/PRS/" . date('Y'));
        } else {
            $idx = explode('/', $result->nomor_sk);
            $kode = (int)substr(explode(".", $idx[0])[0], -1, 4) + 1;
            $newKode = str_repeat('0', 4 - strlen((string)$kode)) . $kode . ".K/SDM/PRS" . "/" . date('Y');
            echo json_encode($newKode);
        }
    }

    public function getDataSKPengangkatan()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('*')
                ->from('tbl_skpengangkatan')
                ->where('id_karyawan', $this->input->post('idUsers'))->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataSKPengangkatanById()
    {
        echo json_encode(where_row('tbl_skpengangkatan', ['id' => $this->input->post('idSKPengangkatan')]));
    }

    public function saveSKPengangkatanKaryawan()
    {
        $dataPost = $this->input->post();

        if ($dataPost['mode'] == "insert") {
            $dataSKPengangkatan = [
                'id_karyawan' => $dataPost['idUsers'],
                'tanggal_sk' => $dataPost['tanggalSKPengangkatan'],
                'nomor_sk' => $dataPost['nomorSKPengangkatan'],
                'keterangan' => $dataPost['keteranganSKPengangkatan'],
                'is_aktif' => $dataPost['isActive'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            $result = insert_table('tbl_skpengangkatan', $dataSKPengangkatan);
            if ($result) {
                insert_logAktivitas('Tambah data SK Pengangkatan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data SK Pengangkatan berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data SK Pengangkatan gagal disimpan'
                ]);
            }
        }
        if ($dataPost['mode'] == "update") {

            $dataSKPengangkatanUpdate = [
                'tanggal_sk' => $dataPost['tanggalSKPengangkatan'],
                'keterangan' => $dataPost['keteranganSKPengangkatan'],
                'is_aktif' => $dataPost['isActive'],
            ];

            $result = update_table('tbl_skpengangkatan', $dataSKPengangkatanUpdate, ['id' => $dataPost['idSKPengangkatan']]);
            if ($result) {
                insert_logAktivitas('Edit data SK Pengangkatan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data SK Pengangkatan berhasil diubah'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data SK Pengangkatan gagal diubah'
                ]);
            }
        }
    }

    /******************************************** Controller SK Pengangkatan ***********************************************/

    /******************************************** Controller Pelatihan ***********************************************/

    public function getDataPelatihan()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('*')
                ->from('tbl_pelatihan')
                ->where('id_karyawan', $this->input->post('idUsers'))->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataPelatihanById()
    {
        echo json_encode(where_row('tbl_pelatihan', ['id' => $this->input->post('idPelatihan')]));
    }

    public function savePelatihanKaryawan()
    {
        $dataPost = $this->input->post();

        if ($dataPost['mode'] == "insert") {
            $dataPelatihan = [
                'id_karyawan' => $dataPost['idUsers'],
                'nama_pelatihan' => $dataPost['namaPelatihanPelatihan'],
                'status' => $dataPost['statusPelatihan'],
                'tahun' => $dataPost['tahunPelatihan'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            $result = insert_table('tbl_pelatihan', $dataPelatihan);
            if ($result) {
                insert_logAktivitas('Tambah data Pelatihan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Pelatihan berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Pelatihan gagal disimpan'
                ]);
            }
        }
        if ($dataPost['mode'] == "update") {

            $dataPelatihanUpdate = [
                'nama_pelatihan' => $dataPost['namaPelatihanPelatihan'],
                'status' => $dataPost['statusPelatihan'],
                'tahun' => $dataPost['tahunPelatihan'],
            ];

            $result = update_table('tbl_pelatihan', $dataPelatihanUpdate, ['id' => $dataPost['idPelatihan']]);
            if ($result) {
                insert_logAktivitas('Edit data Pelatihan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Pelatihan berhasil diubah'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Pelatihan gagal diubah'
                ]);
            }
        }
    }

    /******************************************** Controller Pelatihan ***********************************************/


    /******************************************** Controller Info Tambahan ***********************************************/

    public function getDataInfoTambahan()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('*')
                ->from('tbl_infotambahan')
                ->where('id_karyawan', $this->input->post('idUsers'))->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataInfoTambahanById()
    {
        echo json_encode(where_row('tbl_infotambahan', ['id' => $this->input->post('idInfoTambahan')]));
    }

    public function saveInfoTambahanKaryawan()
    {
        $dataPost = $this->input->post();

        if ($dataPost['mode'] == "insert") {
            $dataInfoTambahan = [
                'id_karyawan' => $dataPost['idUsers'],
                'deskripsi' => $dataPost['deskripsiInfoTambahan'],
                'value' => $dataPost['valueInfoTambahan'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            $result = insert_table('tbl_infotambahan', $dataInfoTambahan);
            if ($result) {
                insert_logAktivitas('Tambah data Info Tambahan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Info Tambahan berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Info Tambahan gagal disimpan'
                ]);
            }
        }
        if ($dataPost['mode'] == "update") {

            $dataInfoTambahanUpdate = [
                'deskripsi' => $dataPost['deskripsiInfoTambahan'],
                'value' => $dataPost['valueInfoTambahan'],
            ];

            $result = update_table('tbl_infotambahan', $dataInfoTambahanUpdate, ['id' => $dataPost['idInfoTambahan']]);
            if ($result) {
                insert_logAktivitas('Edit data Info Tambahan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Info Tambahan berhasil diubah'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Info Tambahan gagal diubah'
                ]);
            }
        }
    }

    /******************************************** Controller Info Tambahan ***********************************************/


    /******************************************** Controller Upload Dokumen Personal **********************************************/

    public function saveDokumenPersonal()
    {

        $dataPost = $this->input->post();

        $this->db->trans_begin();

        if ($_FILES['fileKTP']['size'] == 0 && $_FILES['fileNPWP']['size'] == 0 && $_FILES['fileKK']['size'] == 0) {
            $this->session->set_flashdata("error", 'Minimal 1 file yang akan diupload');
            redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
        }

        $checkIfExist = where_count('tbl_dokumen_personal', ['id_karyawan' => $dataPost['idUsers']]);
        $errorSize = [];
        $errorEkstensi = [];
        $errorUpload = [];
        $tempNameToInsert = [];

        $uploadDirectory = "assets/upload/kepegawaian/dokumen/";
        $fileExtensionsAllowed = ['jpeg', 'jpg', 'png', 'gif', 'JPG', 'JPEG', 'GIF']; // Allowed file extensions

        if ($checkIfExist == 0) {

            if ($_FILES['fileKTP']['name'] != "") {
                $fileNameKTP = $_FILES['fileKTP']['name'];
                $fileSizeKTP = $_FILES['fileKTP']['size'];

                $fileTmpNameKTP  = $_FILES['fileKTP']['tmp_name'];
                $files = explode(".", $fileNameKTP);
                $namaFileKTP = 'KTP-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));

                if ($fileSizeKTP > 1024000) {
                    array_push($errorSize, ['message' => 'Data gagal disimpan, ukuran file maks 1mb']);
                } else {
                    if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
                        array_push($errorEkstensi, ['message' => 'Data gagal disimpan, Ekstensi file tidak sesuai']);
                    } else {
                        $uploadPathKTP = $uploadDirectory . $namaFileKTP;
                        $didUploadKTP = move_uploaded_file($fileTmpNameKTP, $uploadPathKTP);
                        if (!$didUploadKTP) {
                            array_push($errorUpload, ['message' => 'Data gagal disimpan, Terjadi kesalahan pada server']);
                        } else {
                            array_push($tempNameToInsert, $namaFileKTP);
                        }
                    }
                }
            }

            if ($_FILES['fileNPWP']['name'] != "") {
                $fileNameNPWP = $_FILES['fileNPWP']['name'];
                $fileSizeNPWP = $_FILES['fileNPWP']['size'];

                $fileTmpNameNPWP  = $_FILES['fileNPWP']['tmp_name'];
                $files = explode(".", $fileNameNPWP);
                $namaFileNPWP = 'NPWP-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));

                if ($fileSizeNPWP > 1024000) {
                    array_push($errorSize, ['message' => 'Data gagal disimpan, ukuran file maks 1mb']);
                } else {
                    if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
                        array_push($errorEkstensi, ['message' => 'Data gagal disimpan, Ekstensi file tidak sesuai']);
                    } else {
                        $uploadPathNPWP = $uploadDirectory . $namaFileNPWP;
                        $didUploadNPWP = move_uploaded_file($fileTmpNameNPWP, $uploadPathNPWP);
                        if (!$didUploadNPWP) {
                            array_push($errorUpload, ['message' => 'Data gagal disimpan, Terjadi kesalahan pada server']);
                        } else {
                            array_push($tempNameToInsert, $namaFileNPWP);
                        }
                    }
                }
            }

            if ($_FILES['fileKK']['name'] != "") {
                $fileNameKK = $_FILES['fileKK']['name'];
                $fileSizeKK = $_FILES['fileKK']['size'];

                $fileTmpNameKK  = $_FILES['fileKK']['tmp_name'];
                $files = explode(".", $fileNameKK);
                $namaFileKK = 'KK-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));

                if ($fileSizeKK > 1024000) {
                    array_push($errorSize, ['message' => 'Data gagal disimpan, ukuran file maks 1mb']);
                } else {
                    if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
                        array_push($errorEkstensi, ['message' => 'Data gagal disimpan, Ekstensi file tidak sesuai']);
                    } else {
                        $uploadPathKK = $uploadDirectory . $namaFileKK;
                        $didUploadKK = move_uploaded_file($fileTmpNameKK, $uploadPathKK);
                        if (!$didUploadKK) {
                            array_push($errorUpload, ['message' => 'Data gagal disimpan, Terjadi kesalahan pada server']);
                        } else {
                            array_push($tempNameToInsert, $namaFileKK);
                        }
                    }
                }
            }

            $fixDataToInsert = [];
            foreach ($tempNameToInsert as $key => $value) {
                $flfl = explode("-", $value);
                if ($flfl[0] == 'KTP') {
                    $fixDataToInsert['file_ktp'] = $flfl[0] . "-" . $flfl[1];
                }

                if ($flfl[0] == 'NPWP') {
                    $fixDataToInsert['file_npwp'] = $flfl[0] . "-" . $flfl[1];
                }

                if ($flfl[0] == 'KK') {
                    $fixDataToInsert['file_kk'] = $flfl[0] . "-" . $flfl[1];
                }
            }
            $fixDataToInsert['id_karyawan'] = $dataPost['idUsers'];
            $fixDataToInsert['created_at'] = date('Y-m-d H:i:s');
            insert_table('tbl_dokumen_personal', $fixDataToInsert);

            if ($this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
                $this->session->set_flashdata("error", 'Upload file gagal');
            } else if (!empty($errorSize)) {
                foreach ($errorSize as $key => $value) {
                    $this->session->set_flashdata("error", $value['message']);
                }
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            } else if (!empty($errorEkstensi)) {
                foreach ($errorEkstensi as $key => $value) {
                    $this->session->set_flashdata("error", $value['message']);
                }
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            } else if (!empty($errorUpload)) {
                foreach ($errorUpload as $key => $value) {
                    $this->session->set_flashdata("error", $value['message']);
                }
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            } else {
                $this->db->trans_commit();
                $this->session->set_flashdata("success", 'Upload file dokumen berhasil');
                insert_logAktivitas('Insert Upload file dokumen Data Umum ');
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            }
        } else {
            //update data dan unlink

            $dataDokumenPersonal = where_row('tbl_dokumen_personal', ['id_karyawan' => $dataPost['idUsers']]);

            if ($_FILES['fileKTP']['name'] != "") {
                $fileNameKTP = $_FILES['fileKTP']['name'];
                $fileSizeKTP = $_FILES['fileKTP']['size'];

                $fileTmpNameKTP  = $_FILES['fileKTP']['tmp_name'];
                $files = explode(".", $fileNameKTP);
                $namaFileKTP = 'KTP-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));

                if ($fileSizeKTP > 1024000) {
                    array_push($errorSize, ['message' => 'Data gagal diubah, ukuran file maks 1mb']);
                } else {
                    if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
                        array_push($errorEkstensi, ['message' => 'Data gagal diubah, Ekstensi file tidak sesuai']);
                    } else {
                        $uploadPathKTP = $uploadDirectory . $namaFileKTP;
                        $didUploadKTP = move_uploaded_file($fileTmpNameKTP, $uploadPathKTP);
                        if (!$didUploadKTP) {
                            array_push($errorUpload, ['message' => 'Data gagal diubah, Terjadi kesalahan pada server']);
                        } else {
                            if ($dataDokumenPersonal->file_ktp != null) {
                                unlink($uploadDirectory . $dataDokumenPersonal->file_ktp);
                            }
                            array_push($tempNameToInsert, $namaFileKTP);
                        }
                    }
                }
            }

            if ($_FILES['fileNPWP']['name'] != "") {
                $fileNameNPWP = $_FILES['fileNPWP']['name'];
                $fileSizeNPWP = $_FILES['fileNPWP']['size'];

                $fileTmpNameNPWP  = $_FILES['fileNPWP']['tmp_name'];
                $files = explode(".", $fileNameNPWP);
                $namaFileNPWP = 'NPWP-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));

                if ($fileSizeNPWP > 1024000) {
                    array_push($errorSize, ['message' => 'Data gagal diubah, ukuran file maks 1mb']);
                } else {
                    if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
                        array_push($errorEkstensi, ['message' => 'Data gagal diubah, Ekstensi file tidak sesuai']);
                    } else {
                        $uploadPathNPWP = $uploadDirectory . $namaFileNPWP;
                        $didUploadNPWP = move_uploaded_file($fileTmpNameNPWP, $uploadPathNPWP);
                        if (!$didUploadNPWP) {
                            array_push($errorUpload, ['message' => 'Data gagal diubah, Terjadi kesalahan pada server']);
                        } else {
                            if ($dataDokumenPersonal->file_npwp != null) {
                                unlink($uploadDirectory . $dataDokumenPersonal->file_npwp);
                            }
                            array_push($tempNameToInsert, $namaFileNPWP);
                        }
                    }
                }
            }

            if ($_FILES['fileKK']['name'] != "") {
                $fileNameKK = $_FILES['fileKK']['name'];
                $fileSizeKK = $_FILES['fileKK']['size'];

                $fileTmpNameKK  = $_FILES['fileKK']['tmp_name'];
                $files = explode(".", $fileNameKK);
                $namaFileKK = 'KK-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));

                if ($fileSizeKK > 1024000) {
                    array_push($errorSize, ['message' => 'Data gagal diubah, ukuran file maks 1mb']);
                } else {
                    if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
                        array_push($errorEkstensi, ['message' => 'Data gagal diubah, Ekstensi file tidak sesuai']);
                    } else {
                        $uploadPathKK = $uploadDirectory . $namaFileKK;
                        $didUploadKK = move_uploaded_file($fileTmpNameKK, $uploadPathKK);
                        if (!$didUploadKK) {
                            array_push($errorUpload, ['message' => 'Data gagal diubah, Terjadi kesalahan pada server']);
                        } else {
                            if ($dataDokumenPersonal->file_kk != null) {
                                unlink($uploadDirectory . $dataDokumenPersonal->file_kk);
                            }
                            array_push($tempNameToInsert, $namaFileKK);
                        }
                    }
                }
            }

            $fixDataToUpdate = [];
            foreach ($tempNameToInsert as $key => $value) {
                $flfl = explode("-", $value);
                if ($flfl[0] == 'KTP') {
                    $fixDataToUpdate['file_ktp'] = $flfl[0] . "-" . $flfl[1];
                }

                if ($flfl[0] == 'NPWP') {
                    $fixDataToUpdate['file_npwp'] = $flfl[0] . "-" . $flfl[1];
                }

                if ($flfl[0] == 'KK') {
                    $fixDataToUpdate['file_kk'] = $flfl[0] . "-" . $flfl[1];
                }
            }
            update_table('tbl_dokumen_personal', $fixDataToUpdate, ['id_karyawan' => $dataPost['idUsers']]);

            if ($this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
                $this->session->set_flashdata("error", 'Upload file gagal');
            } else if (!empty($errorSize)) {
                foreach ($errorSize as $key => $value) {
                    $this->session->set_flashdata("error", $value['message']);
                }
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            } else if (!empty($errorEkstensi)) {
                foreach ($errorEkstensi as $key => $value) {
                    $this->session->set_flashdata("error", $value['message']);
                }
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            } else if (!empty($errorUpload)) {
                foreach ($errorUpload as $key => $value) {
                    $this->session->set_flashdata("error", $value['message']);
                }
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            } else {
                $this->db->trans_commit();
                $this->session->set_flashdata("success", 'Upload file dokumen diubah');
                insert_logAktivitas('Update Upload file dokumen Data Umum ');
                redirect("Users/Karyawan/form_karyawan?id=" . $dataPost['idUsers']);
            }
        }
    }

    /******************************************** Controller Upload Dokumen Personal **********************************************/


    /******************************************** Controller Upload Dokumen Pekerjaan **********************************************/

    public function saveUploadDokumenPekerjaan()
    {
        $dataPost = $this->input->post();


        $uploadDirectory = "assets/upload/kepegawaian/dokumen/";
        $fileExtensionsAllowed = ['jpeg', 'jpg', 'png', 'gif', 'JPG', 'JPEG', 'GIF', 'pdf', 'PDF', 'doc', 'DOC', 'docx', 'DOCX', 'xlsx', 'csv', 'xls']; // Allowed file extensions
        $fileName = $_FILES['file']['name'];
        $fileSize = $_FILES['file']['size'];
        $fileTmpName  = $_FILES['file']['tmp_name'];
        $files = explode(".", $fileName);
        if ($dataPost['type'] == '1') {
            $namaFileDokumen = 'SKPengangkatan-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));
            $jenisMessage = "SK Pengangkatan";
        }

        if ($dataPost['type'] == '2') {
            $namaFileDokumen = 'Ijazah-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));
            $jenisMessage = "Ijazah";
        }

        if ($dataPost['type'] == '3') {
            $namaFileDokumen = 'Sertifikat-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));
            $jenisMessage = "Sertifikat";
        }

        if ($dataPost['type'] == '4') {
            $namaFileDokumen = 'SuratReferensi-' . time() . random_string('alnum', 8) . '.' . strtolower(end($files));
            $jenisMessage = "Surat Referensi";
        }

        if (empty($fileName)) {
            echo json_encode(array('status' => false, 'message' => 'Data gagal disimpan! File Attactment tidak boleh kosong'));
        } else {
            if ($fileSize > 1024000) {
                echo json_encode(array('status' => false, 'message' => 'Data gagal disimpan! Ukuran file maks 1mb'));
            } else {
                if (!in_array(strtolower(end($files)), $fileExtensionsAllowed)) {
                    echo json_encode(array('status' => false, 'message' => 'Data gagal disimpan! File Attactment tidak sesuai ketentuan'));
                } else {
                    $uploadPath = $uploadDirectory . $namaFileDokumen;
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                    if (!$didUpload) {
                        echo json_encode(array('status' => false, 'message' => 'Data gagal disimpan! Terjadi kesalahan pada server'));
                    } else {
                        $dataDokumenUpload = [
                            'id_karyawan' => $dataPost['idUsers'],
                            'nama' => $dataPost['namaDokumen'],
                            'file' => $namaFileDokumen,
                            'type' => $dataPost['type'],
                            'created_at' => date('Y-m-d H:i:s')
                        ];

                        $insert = insert_table('tbl_dokumen_pekerjaan', $dataDokumenUpload);
                        if ($insert) {
                            insert_logAktivitas('Insert Data Dokumen Pekerjaan');
                            echo json_encode([
                                'status' => 201,
                                'message' => 'Upload dokumen ' . $jenisMessage . " berhasil"
                            ]);
                        } else {
                            echo json_encode([
                                'status' => 400,
                                'message' => 'Upload dokumen ' . $jenisMessage . " gagal"
                            ]);
                        }
                    }
                }
            }
        }
    }

    public function deleteDokumenPekerjaan()
    {
        $dataDokumen = where_row('tbl_dokumen_pekerjaan', ['id' => $this->input->get('id')]);

        unlink("assets/upload/kepegawaian/dokumen/" . $dataDokumen->file);

        $deleteData = $this->db->delete("tbl_dokumen_pekerjaan", ['id' => $this->input->get('id')]);

        if ($deleteData) {
            insert_logAktivitas("Melakukan delete data dokumen");

            $this->session->set_flashdata("success", 'Data Dokumen Pekerjaan berhasil dihapus');
            redirect("Users/Karyawan/form_karyawan?id=" . $_GET['idUser']);
        } else {
            $this->session->set_flashdata("error", 'Data Dokumen Pekerjaan gagal dihapus');
            redirect("Users/Karyawan/form_karyawan?id=" . $_GET['idUser']);
        }
    }

    /******************************************** Controller Upload Dokumen Pekerjaan **********************************************/


    /******************************************** Controller Time Management **********************************************/

    public function filterPresensi()
    {
        $dataPost = $this->input->post();

        $tgl = explode(" - ", $dataPost['filterTanggal']);

        $tgl1 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[0])));
        $tgl2 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[1])));

        $query = $this->db->query("SELECT hariefektif.nama_hari, 
                                        absensi.tgl, 
                                        jam_kerja.jam_masuk as jadwal_masuk,
                                        jam_kerja.jam_pulang as jadwal_pulang,
                                        DATE_FORMAT(absensi.jam_masuk, '%H:%i:%s') as jam_masuk,
                                        DATE_FORMAT(absensi.jam_pulang, '%H:%i:%s') as jam_pulang,
                                        absensi.status_masuk,
                                        absensi.status_pulang
                                    FROM absensi 
                                    LEFT JOIN jam_kerja ON absensi.id_jamkerja = jam_kerja.id
                                    LEFT JOIN hariefektif ON jam_kerja.hari = hariefektif.id
                                    WHERE absensi.id_karyawan = '" . $dataPost['idKaryawan'] . "'
                                        AND absensi.tgl BETWEEN '$tgl1' AND '$tgl2'
                                        order by absensi.tgl ASC")->result();
        echo json_encode($query);
    }

    public function filterCuti()
    {
        $dataPost = $this->input->post();

        $tgl = explode(" - ", $dataPost['filterTanggal']);

        $tgl1 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[0])));
        $tgl2 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[1])));

        $query = $this->db->query("SELECT *
                                    FROM pengajuancuti
                                    WHERE id_karyawan = '" . $dataPost['idKaryawan'] . "'
                                        AND tgl_mulai BETWEEN '$tgl1' AND '$tgl2'
                                        order by id ASC")->result();
        echo json_encode($query);
    }

    /******************************************** Controller Time Management **********************************************/

    /******************************************** Controller Keuangan **********************************************/


    public function getDataTransaksiKeuangan()
    {
        if ($this->input->post('idUsers') != null || $this->input->post('idUsers') != "") {
            echo json_encode($this->db->select('a.*, b.name')
                ->from('transaksi_keuangan a')
                ->join('jenis_transaksi_keuangan b', 'a.id_jenis_transaksi_keuangan = b.id', 'left')
                ->where('a.id_karyawan', $this->input->post('idUsers'))->order_by('id', 'DESC')->get()->result());
        } else {
            echo json_encode([]);
        }
    }

    public function getDataTransaksiKeuanganById()
    {
        echo json_encode(where_row('transaksi_keuangan', ['id' => $this->input->post('idTransaksi')]));
    }

    public function saveTransaksiKeuanganKaryawan()
    {
        $dataPost = $this->input->post();

        if ($dataPost['mode'] == "insert") {
            $dataTransaksikeuangan = [
                'id_karyawan' => $dataPost['idUsers'],
                'id_jenis_transaksi_keuangan' => $dataPost['jenisTransaksi'],
                'nominal' => $dataPost['nominalTransaksi'],
                'tanggal' => $dataPost['dateTransaksi'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            $result = insert_table('transaksi_keuangan', $dataTransaksikeuangan);
            if ($result) {
                insert_logAktivitas('Tambah data Transaksi Keuangan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Transaksi Keuangan berhasil disimpan'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Transaksi Keuangan gagal disimpan'
                ]);
            }
        }
        if ($dataPost['mode'] == "update") {

            $dataTransaksikeuanganUpdate = [
                'id_jenis_transaksi_keuangan' => $dataPost['jenisTransaksi'],
                'nominal' => $dataPost['nominalTransaksi'],
                'tanggal' => $dataPost['dateTransaksi'],
            ];

            $result = update_table('transaksi_keuangan', $dataTransaksikeuanganUpdate, ['id' => $dataPost['idTransaksiKeuangan']]);
            if ($result) {
                insert_logAktivitas('Edit data Transaksi Keuangan ( Data umum )');
                echo json_encode([
                    'status' => 200,
                    'message' => 'Data Transaksi Keuangan berhasil diubah'
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => 'Data Transaksi Keuangan gagal diubah'
                ]);
            }
        }
    }

    /******************************************** Controller Keuangan **********************************************/

    /**************************************** Global Controller  ****************************************/

    public function deleteData()
    {
        $dataPost = $this->input->post();
        $modul = $dataPost['modul'] == 'keluarga' ? 'Keluarga' : ($dataPost['modul'] == 'pendidikan' ? 'Pendidikan' : ($dataPost['modul'] == 'pengalamanKerja' ? 'Pengalaman Kerja' : ($dataPost['modul'] == 'SKPengangkatan' ? 'SK Pengangkatan' : ($dataPost['modul'] == 'Pelatihan' ? 'Pelatihan' : ($dataPost['modul'] == 'infoTambahan' ? 'Info Tambahan' : 'Transaksi Keuangan')))));

        if ($dataPost['modul'] == 'keluarga') {
            if ($dataPost['type'] == '3') {
                $result = update_table('tbl_keluarga', ['is_emergency_contact' => NULL], ['id' => $dataPost['id']]);
            } else {
                $result = $this->db->delete("tbl_keluarga", ['id' => $dataPost['id']]);
            }
        }

        if ($dataPost['modul'] == 'pendidikan') {
            $result = $this->db->delete("tbl_sekolah", ['id' => $dataPost['id']]);
        }

        if ($dataPost['modul'] == 'pengalamanKerja') {
            $result = $this->db->delete("tbl_pengalaman_kerja", ['id' => $dataPost['id']]);
        }

        if ($dataPost['modul'] == 'SKPengangkatan') {
            $result = $this->db->delete("tbl_skpengangkatan", ['id' => $dataPost['id']]);
        }

        if ($dataPost['modul'] == 'Pelatihan') {
            $result = $this->db->delete("tbl_pelatihan", ['id' => $dataPost['id']]);
        }

        if ($dataPost['modul'] == 'infoTambahan') {
            $result = $this->db->delete("tbl_infotambahan", ['id' => $dataPost['id']]);
        }

        if ($dataPost['modul'] == 'TransaksiKeuangan') {
            $result = $this->db->delete("transaksi_keuangan", ['id' => $dataPost['id']]);
        }


        if ($result) {
            insert_logAktivitas("Hapus data '$modul' ( Data umum )");
            echo json_encode([
                'status' => 200,
                'type' => $dataPost['type'],
                'message' => "Data '$modul' berhasil dihapus"
            ]);
        } else {
            echo json_encode([
                'status' => 400,
                'message' => "Data '$modul' gagal dihapus"
            ]);
        }
    }

    /**************************************** Global Controller  ****************************************/


    public function getGajiKaryawanByDate()
    {
        $dataPost = $this->input->post();

        $dataGaji = $this->db->query("SELECT 
                                    gaji.id,
                                    unit.name as bagian,
                                    gaji.p1_1,
                                    gaji.p1_2,
                                    gaji.p1,
                                    gaji.p2,
                                    gaji.p3,
                                    gaji.total,
                                    gaji.date
                                FROM gaji
                                left join penerimaan on gaji.karyawan = penerimaan.karyawan
                                left join unit on penerimaan.unit = unit.id
                                left join karyawan on penerimaan.karyawan = karyawan.id
                                where gaji.karyawan = '" . $dataPost['idUsers'] . "' AND DATE_FORMAT(gaji.date, '%Y-%m') = '" . $dataPost['date'] . "'")->result();

        $tunjangan = where_row('int_tunjangan', ['karyawan' => $dataPost['idUsers']]);
        if ($tunjangan) {
            $show_tunjangan = json_decode($tunjangan->tunjangan);
        }
        $bonus = where_row('int_bonus', ['karyawan' => $dataPost['idUsers']]);
        if ($bonus) {
            $show_bonus = json_decode($bonus->bonus);
        }
        echo json_encode([
            'dataGaji' => $dataGaji,
            'dataTunjangan' => $tunjangan ? $show_tunjangan : [],
            'dataBonus' => $bonus ? $show_bonus : [],
        ]);
    }

    public function requestPreviewImport()
    {
        $nama_file_baru = 'data' . date('Ymd') . '.xlsx';
        // Cek apakah terdapat file data.xlsx pada folder tmp
        if (is_file('assets/upload/import_template/' . $nama_file_baru)) // Jika file tersebut ada
            unlink('assets/upload/import_template/' . $nama_file_baru); // Hapus file tersebut
        $ext = pathinfo($_FILES['files']['name'], PATHINFO_EXTENSION); // Ambil ekstensi filenya apa
        $tmp_file = $_FILES['files']['tmp_name'];

        if ($ext == "xlsx") {
            move_uploaded_file($tmp_file, 'assets/upload/import_template/' . $nama_file_baru);
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            $spreadsheet = $reader->load('assets/upload/import_template/' . $nama_file_baru); // Load file yang tadi diupload ke folder tmp
            $worksheet  = $spreadsheet->getActiveSheet();

            $highestRow = $worksheet->getHighestRow();

            $response = [];

            for ($row = 5; $row <= $highestRow; ++$row) {

                $response[] = [
                    'jabatan' => $worksheet->getCellByColumnAndRow(2, $row)->getValue(),
                    'nama' => $worksheet->getCellByColumnAndRow(3, $row)->getValue(),
                    'telepon' => $worksheet->getCellByColumnAndRow(4, $row)->getValue(),
                    'email' => $worksheet->getCellByColumnAndRow(5, $row)->getValue(),
                    'jenis_kelamin' => $worksheet->getCellByColumnAndRow(6, $row)->getValue(),
                    'tempat_lahir' => $worksheet->getCellByColumnAndRow(7, $row)->getValue(),
                    'tanggal_lahir' => $worksheet->getCellByColumnAndRow(8, $row)->getValue(),
                    'suku' => $worksheet->getCellByColumnAndRow(9, $row)->getValue(),
                    'agama' => $worksheet->getCellByColumnAndRow(10, $row)->getValue(),
                    'golongan_darah' => $worksheet->getCellByColumnAndRow(11, $row)->getValue(),
                    'status_pernikahan' => $worksheet->getCellByColumnAndRow(12, $row)->getValue(),
                    'no_ktp' => $worksheet->getCellByColumnAndRow(13, $row)->getValue(),
                    'no_npwp' => $worksheet->getCellByColumnAndRow(14, $row)->getValue(),
                    'no_nip' => $worksheet->getCellByColumnAndRow(15, $row)->getValue(),
                ];
            }

            echo json_encode($response);
        }
    }

    public function requestImportData()
    {
        // $nama_file_baru = 'data' . date('Ymd') . '.xlsx';
        // // Cek apakah terdapat file data.xlsx pada folder tmp
        // if (is_file('assets/upload/import_template/' . $nama_file_baru)) // Jika file tersebut ada
        //     unlink('assets/upload/import_template/' . $nama_file_baru); // Hapus file tersebut
        $ext = pathinfo($_FILES['files']['name'], PATHINFO_EXTENSION); // Ambil ekstensi filenya apa
        $tmp_file = $_FILES['files']['tmp_name'];

        if ($ext == "xlsx") {
            // move_uploaded_file($tmp_file, 'assets/upload/import_template/' . $nama_file_baru);
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            $spreadsheet = $reader->load($tmp_file);
            $worksheet  = $spreadsheet->getActiveSheet();

            $highestRow = $worksheet->getHighestRow();

            $response = [];

            for ($row = 5; $row <= $highestRow; ++$row) {
                $jabatan = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
                $jenis_kelamin = $worksheet->getCellByColumnAndRow(6, $row)->getValue();
                $tanggal_lahir = $worksheet->getCellByColumnAndRow(8, $row)->getFormattedValue();
                $status_pernikahan = $worksheet->getCellByColumnAndRow(12, $row)->getValue();

                $getIdJabatan = where_row('jabatan', ['name' => $jabatan]);

                $response[] = [
                    'id_jabatan' => $getIdJabatan->id,
                    'name' => $worksheet->getCellByColumnAndRow(3, $row)->getValue(),
                    'phone' => $worksheet->getCellByColumnAndRow(4, $row)->getValue(),
                    'email' => $worksheet->getCellByColumnAndRow(5, $row)->getValue(),
                    'jenis_kelamin' => $jenis_kelamin == 'Laki - Laki ' ? 0 : 1,
                    'tmp_lahir' => $worksheet->getCellByColumnAndRow(7, $row)->getValue(),
                    'tgl_lahir' => date('Y-m-d', strtotime($tanggal_lahir)),
                    'suku' => $worksheet->getCellByColumnAndRow(9, $row)->getValue(),
                    'agama' => $worksheet->getCellByColumnAndRow(10, $row)->getValue(),
                    'golongan_darah' => $worksheet->getCellByColumnAndRow(11, $row)->getValue(),
                    'status_pernikahan' => $status_pernikahan == 'Belum Nikah' ? 0 : 1,
                    'no_ktp' => $worksheet->getCellByColumnAndRow(13, $row)->getValue(),
                    'no_npwp' => $worksheet->getCellByColumnAndRow(14, $row)->getValue(),
                    'nip' => $worksheet->getCellByColumnAndRow(15, $row)->getValue(),
                    'password' => create_pass('12345678')
                ];
            }

            $result = $this->db->insert_batch('karyawan', $response);
            if ($result) {
                insert_logAktivitas("Import data karyawan");
                echo json_encode([
                    'status' => 201,
                    'message' => "Import Data karyawan berhasil"
                ]);
            } else {
                echo json_encode([
                    'status' => 400,
                    'message' => "Import Data karyawan gagal"
                ]);
            }

            // echo json_encode($response);
        }
    }
}
