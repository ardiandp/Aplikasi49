<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Timesheet extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
        $login = $this->login->session();
    }

    public function monitoringaktivitas()
    {
        $login = $this->login->session();
        $users = where_row('karyawan', ['id' => $login['id']]);
        $id = $login['id'];
        $data = [
            'users' => $users,
            'title' => 'Data Pembuatan Aktivitas',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select tk.*,DATE_FORMAT(tk.tanggal_aktivitas, '%d-%m-%Y') as tglaktivitas, k.name as name_karyawan, ka.name as name_kategori, tk.id as idutama from todokaryawan as tk left join karyawan as k on k.id = tk.id_karyawan left join kategori_aktivitas as ka on ka.id = tk.id_kategoriaktivitas where DATE_FORMAT(tanggal_aktivitas,'%Y-%m-%d')='" . date('Y-m-d') . "'")->result()
        ];
        // echo json_encode($data);
        // echo json_encode($this->db->last_query());
        // die;
        $this->template->load("template", 'timesheet/monitoringaktivitas', $data);
    }
    public function getDataMonitoringAktivitas()
    {
        $id = $this->input->post('idkaryawan');
        $tgl = $this->input->post('tanggal');
        $data = $this->db->query("select tk.*,DATE_FORMAT(tk.tanggal_aktivitas, '%Y-%m-%d') as tglaktivitas, k.name as name_karyawan, ka.name as name_kategori, tk.id as idutama, ka.id as id_kategori from todokaryawan as tk left join karyawan as k on k.id = tk.id_karyawan left join kategori_aktivitas as ka on ka.id = tk.id_kategoriaktivitas where tk.id_karyawan = '$id' AND DATE_FORMAT(tanggal_aktivitas,'%Y-%m')='$tgl'")->result();
        echo json_encode($data);
    }
}
