<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Doku extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		header("Content-Type:application/json");
		cek_post();
	}
	public function index()
	{
		$this->template->load("template", 'home');
	}
	public function transfer()
	{
		$requestBody = array(
			'order' =>
			array(
				'amount' => post("amount"),
				'invoice_number' => post("invoice"),
				// 'currency' => 'IDR',
				'callback_url' => 'http://localhost/jokul_checkout/' . post("invoice"),
				'line_items' =>
				array(
					0 =>
					array(
						'name' => post("product"),
						'price' => post("amount"),
						'quantity' => 1
					),

				),
			),
			'payment' =>
			array(
				'payment_due_date' => 60,
			),
			'customer' =>
			array(
				'id' => '112222233',
				'name' => 'Doku Test',
				'email' => 'test@doku.com',
				'phone' => '6287805586273',
				'address' => 'Jalan Sunset road Kuta Bali',
				'country' => 'ID',
			),
		);;
		$requestId = rand(1, 100000); // You can use UUID or anything
		$dateTime = gmdate("Y-m-d H:i:s");
		$isoDateTime = date(DATE_ISO8601, strtotime($dateTime));
		$dateTimeFinal = substr($isoDateTime, 0, 19) . "Z";
		$clientId = "BRN-0263-1662984282377";
		$secretKey = "SK-ohwnYfj4NBBcF7qA8sKS";
		$getUrl = 'https://api.doku.com';
		$targetPath = '/checkout/v1/payment';
		$url = $getUrl . $targetPath;
		$digestValue = base64_encode(hash('sha256', json_encode($requestBody), true));
		$componentSignature = "Client-Id:" . $clientId . "\n" .
			"Request-Id:" . $requestId . "\n" .
			"Request-Timestamp:" . $dateTimeFinal . "\n" .
			"Request-Target:" . $targetPath . "\n" .
			"Digest:" . $digestValue;
		$signature = base64_encode(hash_hmac('sha256', $componentSignature, $secretKey, true));
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestBody));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Client-Id:' . $clientId,
			'Request-Id:' . $requestId,
			'Request-Timestamp:' . $dateTimeFinal,
			'Signature:' . "HMACSHA256=" . $signature,
		));
		$responseJson = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		echo $responseJson;
	}
	public function bri()
	{
		$requestBody = [
			'order' => [
				'invoice_number' => post("invoice"),
				'amount' => post("amount"),
			],
			"virtual_account_info" => [
				"billing_type" => "FIX_BILL",
				"expired_time" => 60,
				"reusable_status" => false,
				"info1" => "Merchant Demo Store",
			],
			"customer" => [
				"name" => "Anton Budiman",
				"email" => "anton@example.com"
			],
		];
		$requestId = rand(1, 100000); // You can use UUID or anything
		$dateTime = gmdate("Y-m-d H:i:s");
		$isoDateTime = date(DATE_ISO8601, strtotime($dateTime));
		$dateTimeFinal = substr($isoDateTime, 0, 19) . "Z";
		$clientId = "BRN-0263-1662984282377";
		$secretKey = "SK-ohwnYfj4NBBcF7qA8sKS";
		$getUrl = 'https://api.doku.com';
		$targetPath = '/bri-virtual-account/v2/payment-code';
		$url = $getUrl . $targetPath;
		$digestValue = base64_encode(hash('sha256', json_encode($requestBody), true));
		$componentSignature = "Client-Id:" . $clientId . "\n" .
			"Request-Id:" . $requestId . "\n" .
			"Request-Timestamp:" . $dateTimeFinal . "\n" .
			"Request-Target:" . $targetPath . "\n" .
			"Digest:" . $digestValue;
		$signature = base64_encode(hash_hmac('sha256', $componentSignature, $secretKey, true));
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestBody));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Client-Id:' . $clientId,
			'Request-Id:' . $requestId,
			'Request-Timestamp:' . $dateTimeFinal,
			'Signature:' . "HMACSHA256=" . $signature,
		));
		$responseJson = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		echo $responseJson;
	}
	public function mandiri()
	{
		$requestBody = [
			'order' => [
				'invoice_number' => post("invoice"),
				'amount' => post("amount"),
			],
			"virtual_account_info" => [
				"billing_type" => "FIX_BILL",
				"expired_time" => 60,
				"reusable_status" => false,
				"info1" => "Merchant Demo Store",
			],
			"customer" => [
				"name" => "Anton Budiman",
				"email" => "anton@example.com"
			],
		];
		$requestId = rand(1, 100000); // You can use UUID or anything
		$dateTime = gmdate("Y-m-d H:i:s");
		$isoDateTime = date(DATE_ISO8601, strtotime($dateTime));
		$dateTimeFinal = substr($isoDateTime, 0, 19) . "Z";
		$clientId = "BRN-0263-1662984282377";
		$secretKey = "SK-ohwnYfj4NBBcF7qA8sKS";
		$getUrl = 'https://api.doku.com';
		$targetPath = '/mandiri-virtual-account/v2/payment-code';
		$url = $getUrl . $targetPath;
		$digestValue = base64_encode(hash('sha256', json_encode($requestBody), true));
		$componentSignature = "Client-Id:" . $clientId . "\n" .
			"Request-Id:" . $requestId . "\n" .
			"Request-Timestamp:" . $dateTimeFinal . "\n" .
			"Request-Target:" . $targetPath . "\n" .
			"Digest:" . $digestValue;
		$signature = base64_encode(hash_hmac('sha256', $componentSignature, $secretKey, true));
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestBody));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Client-Id:' . $clientId,
			'Request-Id:' . $requestId,
			'Request-Timestamp:' . $dateTimeFinal,
			'Signature:' . "HMACSHA256=" . $signature,
		));
		$responseJson = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		echo $responseJson;
	}
	public function bni()
	{
		$requestBody = [
			"order" => [
				"invoice_number" => post("invoice"),
				"amount" => post("amount"),
			],
			"virtual_account_info" => [
				"expired_time" => 60,
				"biling_type" => "FIXED",
				"info" => post("product"),
				"merchant_unique_reference" => date("Ymd"),
			],
			"customer" => [
				"name" => "Anton Budiman",
				"email" => "anton@doku.com"
			],
		];
		$requestId = rand(1, 100000); // You can use UUID or anything
		$dateTime = gmdate("Y-m-d H:i:s");
		$isoDateTime = date(DATE_ISO8601, strtotime($dateTime));
		$dateTimeFinal = substr($isoDateTime, 0, 19) . "Z";
		$clientId = "BRN-0263-1662984282377";
		$secretKey = "SK-ohwnYfj4NBBcF7qA8sKS";
		$getUrl = 'https://api.doku.com';
		$targetPath = '/bni-virtual-account/v2/payment-code';
		$url = $getUrl . $targetPath;
		$digestValue = base64_encode(hash('sha256', json_encode($requestBody), true));
		$componentSignature = "Client-Id:" . $clientId . "\n" .
			"Request-Id:" . $requestId . "\n" .
			"Request-Timestamp:" . $dateTimeFinal . "\n" .
			"Request-Target:" . $targetPath . "\n" .
			"Digest:" . $digestValue;
		$signature = base64_encode(hash_hmac('sha256', $componentSignature, $secretKey, true));
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestBody));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Client-Id:' . $clientId,
			'Request-Id:' . $requestId,
			'Request-Timestamp:' . $dateTimeFinal,
			'Signature:' . "HMACSHA256=" . $signature,
		));
		$responseJson = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		echo $responseJson;
	}
	public function bca()
	{
		$requestBody = [
			"order" => [
				"amount" => post("amount"),
				"invoice_number" => post("invoice"),
				"item_name" => post("product"),
				"customer_address" => "Jakarta Selatan"
			],
			"customer" => [
				"email" => "heriyatmo@doku.com",
				"name" => "yatmo"
			]
		];
		$requestId = rand(1, 100000); // You can use UUID or anything
		$dateTime = gmdate("Y-m-d H:i:s");
		$isoDateTime = date(DATE_ISO8601, strtotime($dateTime));
		$dateTimeFinal = substr($isoDateTime, 0, 19) . "Z";
		$clientId = "BRN-0263-1662984282377";
		$secretKey = "SK-ohwnYfj4NBBcF7qA8sKS";
		$getUrl = 'https://api.doku.com';
		$targetPath = '/bca-direct-transfer/v1/order';
		$url = $getUrl . $targetPath;
		$digestValue = base64_encode(hash('sha256', json_encode($requestBody), true));
		$componentSignature = "Client-Id:" . $clientId . "\n" .
			"Request-Id:" . $requestId . "\n" .
			"Request-Timestamp:" . $dateTimeFinal . "\n" .
			"Request-Target:" . $targetPath . "\n" .
			"Digest:" . $digestValue;
		$signature = base64_encode(hash_hmac('sha256', $componentSignature, $secretKey, true));
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestBody));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Client-Id:' . $clientId,
			'Request-Id:' . $requestId,
			'Request-Timestamp:' . $dateTimeFinal,
			'Signature:' . "HMACSHA256=" . $signature,
		));
		$responseJson = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		echo $responseJson;
	}
}
