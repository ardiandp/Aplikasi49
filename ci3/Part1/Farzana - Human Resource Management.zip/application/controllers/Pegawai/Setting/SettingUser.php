<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class SettingUser extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
    }
    public function index()
    {
        $login = $this->login->session();
        $users = where_row('karyawan', ['id' => $login['id']]);

        $data = [
            'users' => $users,
            'title' => 'Setting User',
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'pegawai/pages/setting/settingUser/index', $data);
    }

    public function updateData()
    {
        $dataPost = $this->input->post();

        if ($dataPost['password'] != "") {
            $passwordHash = create_pass($dataPost['password']);
            $dataPost['password'] = $passwordHash;

            $save = update_table('karyawan', $dataPost, ['id' => $dataPost['id']]);
            if ($save) {

                insert_logAktivitas('Update data personal');

                $this->session->set_flashdata("success", 'Data karyawan berhasil diperbaharui');
                redirect("Pegawai/Setting/SettingUser");
            } else {
                $this->session->set_flashdata("error", 'Data karyawan gagal diperbaharui');
                redirect("Pegawai/Setting/SettingUser");
            }
        } else {
            $save = update_table('karyawan', ['email' => $dataPost['email'], 'phone' => $dataPost['phone']], ['id' => $dataPost['id']]);
            if ($save) {
                insert_logAktivitas('Update data personal');
                $this->session->set_flashdata("success", 'Data karyawan berhasil diperbaharui');
                redirect("Pegawai/Setting/SettingUser");
            } else {
                $this->session->set_flashdata("error", 'Data karyawan gagal diperbaharui');
                redirect("Pegawai/Setting/SettingUser");
            }
        }
    }
}
