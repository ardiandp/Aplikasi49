<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class DataPersonal extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_Login', 'login');
		$this->load->model('M_MenuAkses', 'akses');
		$this->load->model('M_Karyawan');
		cek_session();
	}
	public function index()
	{
		$login = $this->login->session();
		$users = where_row('karyawan', ['id' => $login['id']]);

		$data = [
			'users' => $users,
			'title' => 'Data Personal',
			'dataJabatan' => show_data('jabatan'),
			'dataStatusPegawai' => show_data('statuspegawai'),
			'dataUnit' => show_data('unit'),
			'dataProvinsi' => $this->db->select("prov_id as id, prov_name as nama")->from('provinces')->order_by('prov_name', 'ASC')->get()->result(),
			'dataAtasan' => $this->M_Karyawan->getAtasanKaryawan($login['id']),
			'dataBawahan' => $this->M_Karyawan->getBawahanKaryawan($login['id']),
			'dataSKPengangkatan' => $this->db->select("*")->from('tbl_skpengangkatan')->where('is_aktif', 'Active')->order_by('id', 'ASC')->get()->result(),
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'pegawai/pages/DataPersonal/form', $data);
	}

	public function save_karyawan()
	{
		$data = $this->input->post();
		$dataKaryawanUpdate = [
			'id_jabatan' => $data['jabatanPersonal'],
			'name' => $data['namaPersonal'],
			'phone' => $data['teleponPersonal'],
			'email' => $data['emailPersonal'],
			'jenis_kelamin' => $data['genderPersonal'],
			'tmp_lahir' => $data['tempatLahirPersonal'],
			'tgl_lahir' => $data['tanggalLahirPersonal'],
			'suku' => $data['sukuPersonal'],
			'agama' => $data['agamaPersonal'],
			'golongan_darah' => $data['golDarahPersonal'],
			'status_pernikahan' => $data['statusPernikahanPersonal'],
			'no_ktp' => $data['noKTPPersonal'],
			'no_npwp' => $data['noNPWPPersonal'],
			'nip' => $data['nipPersonal'],
			'provinsi' => $data['provinsiKTP'],
			'kota' => $data['kotaKTP'],
			'kecamatan' => $data['kecamatanKTP'],
			'desa' => $data['desaKTP'],
			'alamat' => trim($data['alamatKTP']),
		];

		if ($data['valueChkDomisili'] == '1') {
			$dataKaryawanUpdate['provinsi_domisili'] = $data['provinsiDomisili'];
			$dataKaryawanUpdate['kota_domisili'] = $data['kotaDomisili'];
			$dataKaryawanUpdate['kecamatan_domisili'] = $data['kecamatanDomisili'];
			$dataKaryawanUpdate['desa_domisili'] = $data['desaDomisili'];
			$dataKaryawanUpdate['alamat_domisili'] = trim($data['alamatDomisili']);
			$dataKaryawanUpdate['is_domisili_same_kk'] = NULL;
		} else {
			$dataKaryawanUpdate['provinsi_domisili'] = NULL;
			$dataKaryawanUpdate['kota_domisili'] = NULL;
			$dataKaryawanUpdate['kecamatan_domisili'] = NULL;
			$dataKaryawanUpdate['desa_domisili'] = NULL;
			$dataKaryawanUpdate['alamat_domisili'] = NULL;
			$dataKaryawanUpdate['is_domisili_same_kk'] = 1;
		}

		$save = update_table('karyawan', $dataKaryawanUpdate, ['id' => $data['idUsers']]);
		if ($save) {

			insert_logAktivitas('Update data karyawan ( Data umum )');

			$this->session->set_flashdata("success", 'Data karyawan berhasil diperbaharui');
			redirect("Pegawai/DataPersonal");
		} else {
			$this->session->set_flashdata("error", 'Data karyawan gagal diperbaharui');
			redirect("Pegawai/DataPersonal");
		}
	}

	public function save_pekerjaan()
	{
		$dataPost = $this->input->post();

		$ifExistPekerjaan = where_count("tbl_pekerjaan", ['id_karyawan' => $dataPost['idUsers']]);
		$ifExistPenerimaan = where_count("penerimaan", ['karyawan' => $dataPost['idUsers']]);

		$this->db->trans_begin();

		if ($dataPost['cabang_unit'] != "" || $dataPost['tanggal_gabung'] != "") {
			if ($ifExistPenerimaan == 0) {
				$dataPenerimaanInsert = [
					'karyawan' => $dataPost['idUsers'],
					'unit' => $dataPost['cabang_unit'] == "" ? NULL : $dataPost['cabang_unit'],
					'date' => $dataPost['tanggal_gabung'] == "" ? NULL : $dataPost['tanggal_gabung'],
					'created_at' => date('Y-m-d H:i:s'),
				];

				insert_table('penerimaan', $dataPenerimaanInsert);
			} else {
				$dataPenerimaanUpdate = [
					'unit' => $dataPost['cabang_unit'] == "" ? NULL : $dataPost['cabang_unit'],
					'date' => $dataPost['tanggal_gabung'] == "" ? NULL : $dataPost['tanggal_gabung']
				];

				update_table('penerimaan', $dataPenerimaanUpdate, ['karyawan' => $dataPost['idUsers']]);
			}
		}

		if ($ifExistPekerjaan == 0) {

			$dataPekerjaan = [
				'id_karyawan' => $dataPost['idUsers'],
				'organisasi' => $dataPost['organisasi'],
				'id_statuspegawai' => $dataPost['status_pegawai'],
				'id_skpengangkatan' => $dataPost['sk_pengangkatan'],
				'created_at' => date('Y-m-d H:i:s')
			];

			insert_table('tbl_pekerjaan', $dataPekerjaan);
			insert_logAktivitas('Tambah data pekerjaan Karyawan');
		} else {
			$dataPekerjaanUpdate = [
				'organisasi' => $dataPost['organisasi'],
				'id_statuspegawai' => $dataPost['status_pegawai'],
				'id_skpengangkatan' =>  $dataPost['sk_pengangkatan']
			];

			update_table('tbl_pekerjaan', $dataPekerjaanUpdate, ['id_karyawan' => $dataPost['idUsers']]);
			insert_logAktivitas('Edit data pekerjaan Karyawan');
		}


		if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();

			$this->session->set_flashdata("error", 'Data gagal disimpan!');
			redirect("Pegawai/DataPersonal");
		} else {
			$this->db->trans_commit();
			$this->session->set_flashdata("success", 'Data berhasil disimpan!');
			redirect("Pegawai/DataPersonal");
		}
	}

	public function save_infoTambahan()
	{
		$data = $this->input->post();

		$checkIfExist = where_count('tbl_infotambahan', ['id_karyawan' => $data['idUsers']]);

		if ($checkIfExist == 0) {
			$dataInfoTambahan = [
				'id_karyawan' => $data['idUsers'],
				'ukuran_seragam' => $data['ukuran_seragam'] == "" ? NULL : $data['ukuran_seragam'],
				'tinggi_badan' => $data['tinggi_badan'] == "" ? NULL : $data['tinggi_badan'],
				'berat_badan' => $data['berat_badan'] == "" ? NULL : $data['berat_badan'],
				'created_at' => date('Y-m-d H:i:s')
			];

			$save = insert_table('tbl_infotambahan', $dataInfoTambahan);
			if ($save) {

				insert_logAktivitas('Tambah data Info tambahan ( Data umum )');
				$this->session->set_flashdata("success", 'Data info tambahan berhasil disimpan');
				redirect("Pegawai/DataPersonal");
			} else {
				$this->session->set_flashdata("error", 'Data info tambahan gagal disimpan');
				redirect("Pegawai/DataPersonal");
			}
		} else {
			$dataInfoTambahanUpdate = [
				'id_karyawan' => $data['idUsers'],
				'ukuran_seragam' => $data['ukuran_seragam'] == "" ? NULL : $data['ukuran_seragam'],
				'tinggi_badan' => $data['tinggi_badan'] == "" ? NULL : $data['tinggi_badan'],
				'berat_badan' => $data['berat_badan'] == "" ? NULL : $data['berat_badan']
			];

			$save = update_table('tbl_infotambahan', $dataInfoTambahanUpdate, ['id_karyawan' => $data['idUsers']]);
			if ($save) {
				insert_logAktivitas('Update data Info tambahan ( Data umum )');

				$this->session->set_flashdata("success", 'Data info tambahan berhasil diperbaharui');
				redirect("Pegawai/DataPersonal");
			} else {
				$this->session->set_flashdata("error", 'Data info tambahan gagal diperbaharui');
				redirect("Pegawai/DataPersonal");
			}
		}
	}
}
