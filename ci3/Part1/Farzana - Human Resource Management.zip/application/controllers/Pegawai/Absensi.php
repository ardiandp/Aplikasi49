<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Absensi extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
        $login = $this->login->session();
    }

    public function presensi()
    {
        $login = $this->login->session();
        $users = where_row('karyawan', ['id' => $login['id']]);

        $data = [
            'users' => $users,
            'title' => 'Daftar Presensi Masuk dan Pulang',
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'pegawai/pages/absensi/daftarpresensi', $data);
    }

    public function aktivitasabsensi()
    {
        $login = $this->login->session();
        $users = where_row('karyawan', ['id' => $login['id']]);
        $namahari = longdate_indo(date('Y-m-d'));
        $pecahnamahari = explode(",", $namahari)[0];

        $data = [
            'users' => $users,
            'title' => 'Aktivitas Absensi',
            'hari' => $pecahnamahari,
            'haritanggal' => $namahari,
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'pegawai/pages/absensi/aktivitas', $data);
    }

    public function filterPresensi()
    {
        $dataPost = $this->input->post();

        $tgl = explode(" - ", $dataPost['filterTanggal']);

        $tgl1 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[0])));
        $tgl2 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[1])));

        $query = $this->db->query("SELECT hariefektif.nama_hari, 
                                        absensi.tgl, 
                                        jam_kerja.jam_masuk as jadwal_masuk,
                                        jam_kerja.jam_pulang as jadwal_pulang,
                                        DATE_FORMAT(absensi.jam_masuk, '%H:%i:%s') as jam_masuk,
                                        DATE_FORMAT(absensi.jam_pulang, '%H:%i:%s') as jam_pulang,
                                        absensi.status_masuk,
                                        absensi.status_pulang
                                    FROM absensi 
                                    LEFT JOIN jam_kerja ON absensi.id_jamkerja = jam_kerja.id
                                    LEFT JOIN hariefektif ON jam_kerja.hari = hariefektif.id
                                    WHERE absensi.id_karyawan = '" . $this->session->userdata('id') . "'
                                        AND absensi.tgl BETWEEN '$tgl1' AND '$tgl2'
                                        order by absensi.tgl ASC")->result();
        echo json_encode($query);
    }
    public function pengajuancuti()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('karyawan', ['id' => $login['id']]),
            'title' => 'Penggajian',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select *,p.id as idutama ,jabatan.name as nama_jabatan,karyawan.name as nama_karyawan,DATE_FORMAT(p.tgl_masuk, '%Y-%m-%d') as tgl_masuk2 from pengajuancuti as p left join karyawan on karyawan.id = p.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi left join jenis_cuti on jenis_cuti.id =p.id_jeniscuti;")->result(),
        ];


        $this->template->load("template", 'pegawai/pages/absensi/pengajuancuti', $data);
    }
    public function getdatapengajuancuti()
    {
        $login = $this->login->session();
        $id = $login['id'];

        $data = $this->db->query("select *,p.id as idutama ,jabatan.name as nama_jabatan,karyawan.name as nama_karyawan,DATE_FORMAT(p.tgl_masuk, '%d-%m-%Y') as tgl_masuk2,DATE_FORMAT(p.tgl_akhir, '%d-%m-%Y') as tgl_akhir1,DATE_FORMAT(p.tgl_mulai, '%d-%m-%Y') as tgl_mulai1 from pengajuancuti p left join karyawan on karyawan.id = p.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi left join jenis_cuti on jenis_cuti.id =p.id_jeniscuti where p.id_karyawan = '$id'")->result();
        echo json_encode($data);
    }


    // //////////////////////////////GETT
    public function getdatajam()
    {
        $hari = strtolower($this->input->post('hari'));
        $query = $this->db->query("select * from jam_kerja j left join hariefektif h on j.hari = h.id where LOWER(h.nama_hari) = '$hari'")->row();
        echo json_encode($query);
    }
    public function getdataabsensi()
    {

        $query = $this->db->query("select *,absensi.id as idutama,DATE_FORMAT(absensi.jam_masuk, '%Y-%d-%m') as tgl_absen,absensi.jam_masuk as absenjam_masuk, absensi.jam_pulang as absenjam_pulang  from absensi left join karyawan on karyawan.id = absensi.id_karyawan left join jam_kerja on jam_kerja.id = absensi.id_jamkerja")->result();
        echo json_encode($query);
    }
    public function getdatakaryawan()
    {
        $idkaryawan = $this->input->post('idkaryawan');
        $data = $this->db->query("select *, divisi.nama_divisi from karyawan left join jabatan on jabatan.id = karyawan.id_jabatan 
                                    left join divisi on divisi.id = karyawan.id_divisi
                                    where karyawan.id = '$idkaryawan'")->row();
        echo json_encode($data);
    }



    //////////////////////////end get


    // ////////////////////////////////////CETAK

    public function cetakpengajuancuti()
    {
        $id = $_GET['id'];
        $data['id'] = $_GET['id'];
        $data['response'] = $this->db->query("select *,jabatan.name as nama_jabatan, karyawan.name as nama_karyawan from pengajuancuti left join karyawan on karyawan.id = pengajuancuti.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi where pengajuancuti.id = '$id'")->row();
        // echo json_encode($data['response']);
        // die;
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->filename = "pengajuancuti.pdf";
        $options = $this->pdf->getOptions();
        $options->set(array('isRemoteEnabled' => true));
        $this->pdf->setOptions($options);
        $login = $this->login->session();
        $users = where_row('users', ['username' => $login['username']]);

        // $this->template->load("template", 'absensi/presensi', $data);
        $this->pdf->load_view('absensi/cetakpengajuancuti', $data);
    }
    /////////////////////end cetak
    public function addpengajuancuti()
    {

        $idkaryawan = $this->input->post('idkaryawan');
        $jenis_cuti = $this->input->post('jenis_cuti');
        $lama = $this->input->post('lama');
        $tanggal_mulai = $this->input->post('tanggal_mulai');
        $tanggal_akhir = $this->input->post('tanggal_akhir');
        $tanggal_masuk = $this->input->post('tanggal_masuk');
        $keterangan = $this->input->post('keterangan');
        $statuspengajuan = $this->input->post('statuspengajuan');
        $jumlah_hari_kerja = $this->input->post('jumlah_hari_kerja');
        $jumlah_hari_libur = $this->input->post('jumlah_hari_libur');
        $tipevalidasi = $this->input->post('jenis_validasi');
        $this->db->trans_begin();
        insert_logAktivitas('Insert Pengajuan Cuti');


        $data = insert_table('pengajuancuti', [
            'id_karyawan' => $idkaryawan,
            'id_jenisvalidasi' => 10,
            'id_jeniscuti' => $jenis_cuti,
            'lama' => $lama,
            'tgl_mulai' => $tanggal_mulai,
            'tgl_akhir' => $tanggal_akhir,
            'tgl_masuk' => $tanggal_masuk,
            'keterangan' => $keterangan,
            'jumlah_hari_kerja' => $jumlah_hari_kerja,
            'jumlah_hari_libur' => $jumlah_hari_libur,
            'statuspengajuan' => $statuspengajuan,
            'acc_by' => NULL,
            'acc_on' => NULL
        ]);
        // insert_table('approval', [
        //     'id_approval_validator1' => $id_approval_validator1,
        //     'id_approval_validator2' => $id_approval_validator2,
        //     'id_approval_validator3' => $id_approval_validator3,
        //     'id_approval_validator4' => $id_approval_validator4,
        //     'id_approval_validator5' => $id_approval_validator5,
        //     'id_approval_karyawan' => $idkaryawan,
        //     'step1' => null,
        //     'step2' => null,
        //     'step3' => null,
        //     'step4' => null,
        //     'step5' => null,
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'tgl_mulai' => $tanggal_mulai,
        //     'tgl_akhir' => $tanggal_akhir,
        //     'tgl_masuk' => $tanggal_masuk,
        //     'keterangan' => $keterangan,


        // ]);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
        // echo json_encode(1);
    }
    public function editpengajuancuti()
    {
        $id = $this->input->post('id');

        $idkaryawan = $this->input->post('idkaryawan');
        $jenis_cuti = $this->input->post('jenis_cuti');
        $lama = $this->input->post('lama');
        $tanggal_mulai = $this->input->post('tanggal_mulai');
        $tanggal_akhir = $this->input->post('tanggal_akhir');
        $tanggal_masuk = $this->input->post('tanggal_masuk');
        $keterangan = $this->input->post('keterangan');
        $statuspengajuan = $this->input->post('statuspengajuan');
        $jumlah_hari_kerja = $this->input->post('jumlah_hari_kerja');
        $jumlah_hari_libur = $this->input->post('jumlah_hari_libur');
        $this->db->trans_begin();
        insert_logAktivitas('Insert Pengajuan Cuti');

        $data = update_table('pengajuancuti', [
            // 'id_karyawan' => $idkaryawan,
            // 'id_jenisvalidasi' => NULL,
            'id_jeniscuti' => $jenis_cuti,
            'lama' => $lama,
            'tgl_mulai' => $tanggal_mulai,
            'tgl_akhir' => $tanggal_akhir,
            'tgl_masuk' => $tanggal_masuk,
            'keterangan' => $keterangan,
            'jumlah_hari_kerja' => $jumlah_hari_kerja,
            'jumlah_hari_libur' => $jumlah_hari_libur,
            'statuspengajuan' => $statuspengajuan,
            'acc_by' => NULL,
            'acc_on' => NULL
        ], ['id' => $id]);


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
        // echo json_encode(1);
    }
}
