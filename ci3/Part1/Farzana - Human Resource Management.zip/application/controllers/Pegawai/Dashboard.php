<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Dashboard extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('M_Login', 'login');
		$this->load->model('M_MenuAkses', 'akses');
		cek_session();
	}
	public function index()
	{
		$login = $this->login->session();
		$users = where_row('karyawan', ['id' => $login['id']]);
		$namahari = longdate_indo(date('Y-m-d'));
		$pecahnamahari = explode(",", $namahari)[0];

		$data = [
			'users' => $users,
			'title' => 'Dashboard',
			'hari' => $pecahnamahari,
			'haritanggal' => $namahari,
			'menuHakAkses' => $this->akses->getMenuHakAkses()
		];
		$this->template->load("template", 'pegawai/pages/dashboard', $data);
	}
}
