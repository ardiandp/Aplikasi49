<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * 
 */
class Timesheet extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('M_Login', 'login');
        $this->load->model('M_MenuAkses', 'akses');
        cek_session();
        $login = $this->login->session();
    }

    public function pembuatanaktivitas()
    {
        $login = $this->login->session();
        $users = where_row('karyawan', ['id' => $login['id']]);
        $id = $login['id'];
        $data = [
            'users' => $users,
            'title' => 'Data Pembuatan Aktivitas',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select tk.*, k.name as name_karyawan, ka.name as name_kategori, tk.id as idutama from todokaryawan as tk left join karyawan as k on k.id = tk.id_karyawan left join kategori_aktivitas as ka on ka.id = tk.id_kategoriaktivitas where tk.id_karyawan = '$id'")->result()
        ];
        $this->template->load("template", 'pegawai/pages/timesheet/pembuatanaktivitas', $data);
    }

    public function aktivitasabsensi()
    {
        $login = $this->login->session();
        $users = where_row('karyawan', ['id' => $login['id']]);
        $namahari = longdate_indo(date('Y-m-d'));
        $pecahnamahari = explode(",", $namahari)[0];

        $data = [
            'users' => $users,
            'title' => 'Aktivitas Absensi',
            'hari' => $pecahnamahari,
            'haritanggal' => $namahari,
            'menuHakAkses' => $this->akses->getMenuHakAkses()
        ];
        $this->template->load("template", 'pegawai/pages/absensi/aktivitas', $data);
    }

    public function filterPresensi()
    {
        $dataPost = $this->input->post();

        $tgl = explode(" - ", $dataPost['filterTanggal']);

        $tgl1 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[0])));
        $tgl2 = date('Y-m-d', strtotime(str_replace("/", "-", $tgl[1])));

        $query = $this->db->query("SELECT hariefektif.nama_hari, 
                                        absensi.tgl, 
                                        jam_kerja.jam_masuk as jadwal_masuk,
                                        jam_kerja.jam_pulang as jadwal_pulang,
                                        DATE_FORMAT(absensi.jam_masuk, '%H:%i:%s') as jam_masuk,
                                        DATE_FORMAT(absensi.jam_pulang, '%H:%i:%s') as jam_pulang,
                                        absensi.status_masuk,
                                        absensi.status_pulang
                                    FROM absensi 
                                    LEFT JOIN jam_kerja ON absensi.id_jamkerja = jam_kerja.id
                                    LEFT JOIN hariefektif ON jam_kerja.hari = hariefektif.id
                                    WHERE absensi.id_karyawan = '" . $this->session->userdata('id') . "'
                                        AND absensi.tgl BETWEEN '$tgl1' AND '$tgl2'
                                        order by absensi.tgl ASC")->result();
        echo json_encode($query);
    }
    public function pengajuancuti()
    {
        $login = $this->login->session();
        $data = [
            'users' => where_row('karyawan', ['id' => $login['id']]),
            'title' => 'Penggajian',
            'menuHakAkses' => $this->akses->getMenuHakAkses(),
            'data' => $this->db->query("select *,p.id as idutama ,jabatan.name as nama_jabatan,karyawan.name as nama_karyawan,DATE_FORMAT(p.tgl_masuk, '%Y-%m-%d') as tgl_masuk2 from pengajuancuti as p left join karyawan on karyawan.id = p.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi left join jenis_cuti on jenis_cuti.id =p.id_jeniscuti;")->result(),
        ];


        $this->template->load("template", 'pegawai/pages/absensi/pengajuancuti', $data);
    }
    public function getPembuatanAktivitas()
    {
        $login = $this->login->session();
        $id = $login['id'];

        $data = $this->db->query("select tk.*, k.name as name_karyawan, ka.name as name_kategori, tk.id as idutama, ka.id as id_kategori from todokaryawan as tk left join karyawan as k on k.id = tk.id_karyawan left join kategori_aktivitas as ka on ka.id = tk.id_kategoriaktivitas where tk.id_karyawan = '$id'")->result();
        echo json_encode($data);
        // echo json_encode($this->db->last_query());
    }


    // //////////////////////////////GETT
    public function getdatajam()
    {
        $hari = strtolower($this->input->post('hari'));
        $query = $this->db->query("select * from jam_kerja j left join hariefektif h on j.hari = h.id where LOWER(h.nama_hari) = '$hari'")->row();
        echo json_encode($query);
    }
    public function getdataabsensi()
    {

        $query = $this->db->query("select *,absensi.id as idutama,DATE_FORMAT(absensi.jam_masuk, '%Y-%d-%m') as tgl_absen,absensi.jam_masuk as absenjam_masuk, absensi.jam_pulang as absenjam_pulang  from absensi left join karyawan on karyawan.id = absensi.id_karyawan left join jam_kerja on jam_kerja.id = absensi.id_jamkerja")->result();
        echo json_encode($query);
    }
    public function getdatakaryawan()
    {
        $idkaryawan = $this->input->post('idkaryawan');
        $data = $this->db->query("select *, divisi.nama_divisi from karyawan left join jabatan on jabatan.id = karyawan.id_jabatan 
                                    left join divisi on divisi.id = karyawan.id_divisi
                                    where karyawan.id = '$idkaryawan'")->row();
        echo json_encode($data);
    }



    //////////////////////////end get


    // ////////////////////////////////////CETAK

    public function cetakpengajuancuti()
    {
        $id = $_GET['id'];
        $data['id'] = $_GET['id'];
        $data['response'] = $this->db->query("select *,jabatan.name as nama_jabatan, karyawan.name as nama_karyawan from pengajuancuti left join karyawan on karyawan.id = pengajuancuti.id_karyawan left join jabatan on jabatan.id = karyawan.id_jabatan left join divisi on divisi.id = karyawan.id_divisi where pengajuancuti.id = '$id'")->row();
        // echo json_encode($data['response']);
        // die;
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->filename = "pengajuancuti.pdf";
        $options = $this->pdf->getOptions();
        $options->set(array('isRemoteEnabled' => true));
        $this->pdf->setOptions($options);
        $login = $this->login->session();
        $users = where_row('users', ['username' => $login['username']]);

        // $this->template->load("template", 'absensi/presensi', $data);
        $this->pdf->load_view('absensi/cetakpengajuancuti', $data);
    }
    /////////////////////end cetak
    public function addpembuatanaktivitas()
    {

        $idkaryawan = $this->input->post('idkaryawan');
        $kategori = $this->input->post('kategori');
        $judulaktivitas = $this->input->post('judulaktivitas');
        $durasi = $this->input->post('durasi');
        $lokasi = $this->input->post('lokasi');

        $this->db->trans_begin();
        insert_logAktivitas('Insert Pembuatan Aktivitas');


        $data = insert_table('todokaryawan', [
            'id_karyawan' => $idkaryawan,
            'id_kategoriaktivitas' => $kategori,
            'judul_aktivitas' => $judulaktivitas,
            'durasi' => $durasi,
            'lokasi' => $lokasi,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }
    public function editpembuatanaktivitas()
    {
        $id = $this->input->post('id');

        $idkaryawan = $this->input->post('idkaryawan');
        $kategori = $this->input->post('kategori');
        $judulaktivitas = $this->input->post('judulaktivitas');
        $durasi = $this->input->post('durasi');
        $lokasi = $this->input->post('lokasi');
        $tglaktivitas = $this->input->post('tglaktivitas');
        $this->db->trans_begin();
        insert_logAktivitas('Update Pembuatan Aktivitas');

        $data = update_table('todokaryawan', [
            'id_karyawan' => $idkaryawan,
            'id_kategoriaktivitas' => $kategori,
            'judul_aktivitas' => $judulaktivitas,
            'tanggal_aktivitas' => $tglaktivitas,
            'durasi' => $durasi,
            'lokasi' => $lokasi,
        ], ['id' => $id]);


        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            echo json_encode(0);
        } else {
            $this->db->trans_commit();
            echo json_encode(1);
        }
    }

    public function getAktivitasToday()
    {
        $idkaryawan = $this->input->post('idkaryawan');
        $tglaktivitas = $this->input->post('tglaktivitas');
        $query = $this->db->query("select sum(durasi) as durasi from todokaryawan where id_karyawan = '$idkaryawan' and DATE_FORMAT(tanggal_aktivitas,'%Y-%m-%d')  = '$tglaktivitas'")->row();
        echo json_encode($query);
        // echo json_encode($this->db->last_query());
    }
}
