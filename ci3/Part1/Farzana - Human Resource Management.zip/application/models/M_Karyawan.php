<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * 
 */
class M_Karyawan extends CI_Model
{
    public function getAtasanKaryawan($id)
    {
        $queryAtasan1 = $this->db->query("SELECT *
        FROM organisasi_detail
        WHERE id_karyawan = '$id'")->row();
        $arrDataAtasan = [];

        if (!empty($queryAtasan1)) {
            if ($queryAtasan1->pid_uniq != 0) {
                $queryAtasan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                                                FROM organisasi_detail a
                                                LEFT JOIN karyawan b ON a.id_karyawan = b.id
                                                LEFT JOIN jabatan c ON a.id_jabatan = c.id
                                                LEFT JOIN divisi d ON a.id_divisi = d.id
                                                WHERE a.id_uniqjabatan = '$queryAtasan1->pid_uniq'")->row();

                array_push($arrDataAtasan, $queryAtasan2);

                // if ($queryAtasan2->pid != 0) {
                //     $queryAtasan3 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                //                                         FROM organisasi_detail a
                //                                         LEFT JOIN karyawan b ON a.id_karyawan = b.id
                //                                         LEFT JOIN jabatan c ON a.id_jabatan = c.id
                //                                         LEFT JOIN divisi d ON a.id_divisi = d.id
                //                                         WHERE a.id_jabatan = '$queryAtasan2->pid'")->row();

                //     array_push($arrDataAtasan, $queryAtasan3);

                //     if ($queryAtasan3->pid != 0) {
                //         $queryAtasan4 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                //                                             FROM organisasi_detail a
                //                                             LEFT JOIN karyawan b ON a.id_karyawan = b.id
                //                                             LEFT JOIN jabatan c ON a.id_jabatan = c.id
                //                                             LEFT JOIN divisi d ON a.id_divisi = d.id
                //                                             WHERE a.id_jabatan = '$queryAtasan3->pid'")->row();
                //         array_push($arrDataAtasan, $queryAtasan4);
                //         if ($queryAtasan4->pid != 0) {
                //             $queryAtasan5 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                //                                             FROM organisasi_detail a
                //                                             LEFT JOIN karyawan b ON a.id_karyawan = b.id
                //                                             LEFT JOIN jabatan c ON a.id_jabatan = c.id
                //                                             LEFT JOIN divisi d ON a.id_divisi = d.id
                //                                             WHERE a.id_jabatan = '$queryAtasan4->pid'")->row();
                //             array_push($arrDataAtasan, $queryAtasan5);
                //             if ($queryAtasan5->pid != 0) {
                //                 $queryAtasan6 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                //                                                     FROM organisasi_detail a
                //                                                     LEFT JOIN karyawan b ON a.id_karyawan = b.id
                //                                                     LEFT JOIN jabatan c ON a.id_jabatan = c.id
                //                                                     LEFT JOIN divisi d ON a.id_divisi = d.id
                //                                                     WHERE a.id_jabatan = '$queryAtasan5->pid'")->row();
                //                 array_push($arrDataAtasan, $queryAtasan6);
                //                 if ($queryAtasan6->pid != 0) {
                //                     $queryAtasan7 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
                //                                                     FROM organisasi_detail a
                //                                                     LEFT JOIN karyawan b ON a.id_karyawan = b.id
                //                                                     LEFT JOIN jabatan c ON a.id_jabatan = c.id
                //                                                     LEFT JOIN divisi d ON a.id_divisi = d.id
                //                                                     WHERE a.id_jabatan = '$queryAtasan6->pid'")->row();
                //                     array_push($arrDataAtasan, $queryAtasan7);
                //                 }
                //             }
                //         }
                //     }
                // }
            } else {
                $arrDataAtasan = [];
            }
        } else {
            $arrDataAtasan = [];
        }



        array_multisort(array_column($arrDataAtasan, 'id'), SORT_ASC, $arrDataAtasan);

        return $arrDataAtasan;
    }

    public function getBawahanKaryawan($id)
    {
        $queryBawahan1 = $this->db->query("SELECT *
                                            FROM organisasi_detail
                                            WHERE id_karyawan = '$id'")->row();
        if (!empty($queryBawahan1)) {
            $queryBawahan2 = $this->db->query("SELECT a.*, b.name as karyawan, c.name as jabatan, d.nama_divisi as divisi
            FROM organisasi_detail a
            LEFT JOIN karyawan b ON a.id_karyawan = b.id
            LEFT JOIN jabatan c ON a.id_jabatan = c.id
            LEFT JOIN divisi d ON a.id_divisi = d.id
            WHERE a.pid_uniq = '$queryBawahan1->id_uniqjabatan'
            ORDER BY a.id ASC")->result();
            return $queryBawahan2;
        } else {
            return [];
        }
    }

    public function getLastNomorSK()
    {
        $this->db->select('nomor_sk');
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        return $this->db->get('tbl_skpengangkatan')->row();
    }
}
