<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * 
 */
class M_Login extends CI_Model
{

    function cek_login($username, $password, $type)
    {

        if ($type == 'admin') {
            $user = $this->db->select('*')->from('users')->where('username', $username)->get()->row();
        }

        if ($type == 'pegawai') {
            $user = $this->db->select('*')->from('karyawan')->where('email', $username)->get()->row();
        }


        if (!empty($user)) {
            if (password_verify($password, $user->password)) {
                if ($type == 'admin') {
                    $session_data = array(
                        'login' => TRUE,
                        'username'  => $user->username,
                        'user' => 'admin',
                        'id'  => $user->id,
                        'id_jabatan' => $user->id_jabatan

                    );
                    $this->session->set_userdata($session_data);

                    insert_logAktivitas('Login ke aplikasi');

                    $response = [
                        'type' => 200,
                        'message' => 'Login berhasil',
                        'url' => ""
                    ];
                }

                if ($type == 'pegawai') {
                    if ($user->status != 0) {
                        //user aktif
                        $session_data = array(
                            'login' => TRUE,
                            'username'  => $user->name,
                            'user' => 'pegawai',
                            'id'  => $user->id,
                            'id_jabatan' => $user->id_jabatan,
                            'id_divisi' => $user->id_divisi
                        );
                        $this->session->set_userdata($session_data);

                        insert_logAktivitas('Login ke aplikasi');

                        $response = [
                            'type' => 200,
                            'message' => 'Login berhasil',
                            'url' => "Pegawai/dashboard"
                        ];
                    } else {
                        //user not aktif
                        $response = [
                            'type' => 203,
                            'message' => "Login gagal, User $username belum aktif",
                            'url' => ""
                        ];
                    }
                }
            } else {

                $types = $type == 'admin' ? 'Username' : 'Email';

                $response = [
                    'type' => 203,
                    'message' => "Login gagal, $types /  password salah",
                    'url' => ""
                ];
            }
        } else {
            $response = [
                'type' => 204,
                'message' => 'user tidak ditemukan',
                'url' => ""
            ];
        }

        return $response;
    }
    public function session()
    {
        return $this->session->userdata();
    }
}
