<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * 
 */
class M_MenuAkses extends CI_Model
{
    public function getMenuHakAkses()
    {
        $whereColoumn = $this->session->userdata('user') == 'admin' ? "id_user" : "id_karyawan";

        $parentMenu = $this->db->select("parent_menu.*")
            ->from('parent_menu')
            ->join("access_parent_menu", "parent_menu.id = access_parent_menu.id_parent_menu", "left")
            ->join("jabatan", "access_parent_menu.id_role = jabatan.id_role", "left")
            ->where('parent_menu.is_aktif', 1)
            ->where('jabatan.id', $this->session->userdata('id_jabatan'))
            ->order_by('parent_menu.is_urut', 'ASC')->get()->result();

        $mainMenu = $this->db->select("main_menu.*")
            ->from('main_menu')
            ->join("access_main_menu", "main_menu.id = access_main_menu.id_main_menu", "left")
            ->join("jabatan", "access_main_menu.id_role = jabatan.id_role", "left")
            ->where('main_menu.is_aktif', 1)
            ->where('jabatan.id', $this->session->userdata('id_jabatan'))
            ->order_by('main_menu.is_urut', 'ASC')->get()->result();

        $subMenu = $this->db->select("sub_menu.*")
            ->from('sub_menu')
            ->join("access_sub_menu", "sub_menu.id = access_sub_menu.id_sub_menu", "left")
            ->join("jabatan", "access_sub_menu.id_role = jabatan.id_role", "left")
            ->where('sub_menu.is_aktif', 1)
            ->where('jabatan.id', $this->session->userdata('id_jabatan'))
            ->order_by('sub_menu.is_urut', 'ASC')->get()->result();

        $response = [
            'parentMenu' => $parentMenu,
            'mainMenu' => $mainMenu,
            'subMenu' => $subMenu,
        ];

        return $response;

        // return $this->db->select("*")
        //     ->from("parent_menu")
        //     ->join("main_menu", "parent_menu.id = main_menu.id_parent_menu", "left")
        //     ->join("sub_menu", "main_menu.id = sub_menu.id_main_menu", "left")
        //     ->join("access_parent_menu", "parent_menu.id = access_parent_menu.id_parent_menu", "left")
        //     ->join("access_main_menu", "main_menu.id = access_main_menu.id_main_menu", "left")
        //     ->join("access_sub_menu", "sub_menu.id = access_sub_menu.id_sub_menu", "left")
        //     ->where('access_parent_menu.' . $whereColoumn, $this->session->userdata('id'))
        //     ->where('access_main_menu.' . $whereColoumn, $this->session->userdata('id'))
        //     ->where('access_sub_menu.' . $whereColoumn, $this->session->userdata('id'))
        //     ->order_by('parent_menu.is_urut', 'ASC')
        //     ->order_by('main_menu.is_urut', 'ASC')
        //     ->order_by('sub_menu.is_urut', 'ASC')
        //     ->get()->result();
    }
}
