<style>
    body{
        font-family : 'arial';
        font-size : 10px !important;
    }
    @media print{
        #main{
            width : 100%;
        }
    }
</style>

<table id="main" border='1' width="50%" cellspacing='0' cellpadding="10">
    <tr>
        <td colspan="3">
            <u> KLINIK PRATAMA AGIAN MEDICAL CENTER</u>
            <br>
                Keputih Tegal Timur No 116, Surabaya 
            <br>
            Telp. 031 (5952220)
        </td>
    </tr>
    <tr>
        <td width="50%" colspan="2">
            Nama Dr : ....................
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
        </td>
        <td width="50%">
        </td>
    </tr>
    <tr>
        <td width="35%">
            Tanggal : 
        </td>
        <td width="15%">
            BB :
        </td>
        <td>
            Alergi Obat : &nbsp;&nbsp;
            <img src="<?= base_url()."assets/box.png" ?>" width="15px" alt="">  Ya 
            &nbsp;
            <img src="<?= base_url()."assets/box.png" ?>" width="15px"> Tidak 
        </td>
    </tr>
    <tr>
        <td colspan="3">
            <br>
            <i>R/</i>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
        </td>
    </tr>
</table>