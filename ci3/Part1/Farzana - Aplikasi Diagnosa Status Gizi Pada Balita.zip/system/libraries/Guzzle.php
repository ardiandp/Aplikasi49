<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CI_Guzzle {
    public function __construct() {
        // require_once('vendor/autoload.php');
        require 'vendor/autoload.php';
    }
}
?>