<!DOCTYPE html>
<html lang="en">

<head>

   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="">
   <meta name="author" content="">

   <title><?= $title; ?></title>


   <!-- Bootstrap core CSS -->
   <link href="<?= base_url("assets/shop-pages/vendor/bootstrap/css/bootstrap.min.css"); ?>" rel="stylesheet">
   <link href="<?= base_url('assets/sb-admin2/') ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <!-- Custom styles for this template -->
   <link href="<?= base_url("assets/shop-pages/css/shop-homepage.css"); ?>" rel="stylesheet">
   <link rel="stylesheet" href="<?= base_url('assets/my-css/style.css'); ?>" rel="stylesheet" type="text/css">
   <script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-INElg1SZkUe7y_zW"></script>
   <script src="https://js.pusher.com/6.0/pusher.min.js"></script>
   <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

</head>

<body>