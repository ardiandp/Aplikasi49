<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 12/22/2017
 * Time: 12:29 AM
 */
?>
<html>
<head>
    <title>My Form</title>
</head>
<body>

<h3>Your form was successfully submitted!</h3>

<p><?php echo anchor('form', 'Try it again!'); ?></p>

</body>
</html>
