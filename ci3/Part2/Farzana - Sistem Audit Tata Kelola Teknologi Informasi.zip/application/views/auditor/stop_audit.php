<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 23/08/2019
 * Time: 19.55
 */?>
<section class="panel">
    <h1 align="center">Selamat Tinggal</h1>
    <center><h2 class="lead">Selesaikan audit yang lama coy</h2></center>
    <div style="height: 100px;width: 600px;margin-left: 380px">
        <hr class="separator" />
            <center><p class="lead">TOP DOWN merupakan Audit yang dilakukan melalui pendekatan yang dilakukan dari tujuan strategis bisnis perusahaan atau visi misi perusahaan</p>        </center>
        <center><p class="lead">BUTTOM UP merupakan pendekatan yang dilakukan dari identifikasi permasalahan dalam pengelolaan teknologi informasi yang ada di perusahaan tersebut</>        </center>
        <center><p class="lead">Mulai Audit ?</p> </center>
 =    </div>

</div>
</section>
</section>
<!-- Vendor -->
<!-- Vendor -->
<script src="<?= base_url() ?>assets/templates/vendor/jquery/jquery.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/bootstrap/js/bootstrap.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/nanoscroller/nanoscroller.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/magnific-popup/magnific-popup.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/jquery-placeholder/jquery.placeholder.js"></script>

<!-- Specific Page Vendor -->
<script src="<?= base_url() ?>assets/templates/vendor/jquery-validation/jquery.validate.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/bootstrap-wizard/jquery.bootstrap.wizard.js"></script>
<script src="<?= base_url() ?>assets/templates/vendor/pnotify/pnotify.custom.js"></script>
<script src="<?= base_url() ?>assets/templates/javascripts/theme.js"></script>

<!-- Theme Custom -->
<script src="<?= base_url() ?>assets/templates/javascripts/theme.custom.js"></script>

<!-- Theme Initialization Files -->
<script src="<?= base_url() ?>assets/templates/javascripts/theme.init.js"></script>


<!-- Examples -->
<script src="<?= base_url() ?>assets/templates/javascripts/forms/examples.wizard.js"></script>
</body>
</html>

