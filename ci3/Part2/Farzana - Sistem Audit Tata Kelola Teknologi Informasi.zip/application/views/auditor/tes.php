<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 30/08/2019
 * Time: 15.13
 */
?>
<div id="w4-bg" class="tab-pane">
    <center><h2 class="panel-title">Korelasi Misi/Tujuan Dengan Bussines Goal</h2></center>
    <hr class="separator" />
    <table class="table table-bordered table-striped" id="datatable-ajax">
        <thead>
        <tr>
            <th>Misi/Tujuan Perusahaan</th>
            <th>Bussines Goals</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td></td>
            <td></td>

        </tr>
        </tbody>
    </table>
</div>
<div id="w4-itg" class="tab-pane">
    <center><h2 class="panel-title">Korelasi Bussines Goals Dengan IT Goal</h2></center>
    <hr class="separator" />
    <table class="table table-bordered table-striped" id="datatable-ajax">
        <thead>
        <tr>
            <th>Bussines Goals</th>
            <th>IT Goals</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td></td>
            <td></td>

        </tr>
        </tbody>
    </table>
</div>
<div id="w4-itp" class="tab-pane">
    <center><h2 class="panel-title">Korelasi IT Goals Dengan IT Proses</h2></center>
    <hr class="separator" />
    <table class="table table-bordered table-striped" id="datatable-ajax">
        <thead>
        <tr>
            <th>IT Goals</th>
            <th>IT Proses</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td></td>
            <td></td>

        </tr>
        </tbody>
    </table>
</div>
