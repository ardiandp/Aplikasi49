<?php

class Pdf
{
    public function __construct()
    {
        include_once APPPATH . '/third_party/fpdf/fpdf.php';
    }
}