<!-- Footer -->
<footer class="content-footer">
    <div>© 2023 Wash - <a href="http://laborasyon.com" target="_blank">Laborasyon</a></div>
    <div>
        <nav class="nav">
            <a href="https://themeforest.net/licenses/standard" class="nav-link">Licenses</a>
            <a href="#" class="nav-link">Change Log</a>
            <a href="#" class="nav-link">Get Help</a>
        </nav>
    </div>
</footer>
<!-- ./ Footer -->
</div>
<!-- ./ Content body -->
</div>
<!-- ./ Content wrapper -->
</div>
<!-- ./ Layout wrapper -->

<!-- Main scripts -->
<script src="<?= base_url('assets_admin/'); ?>vendors/bundle.js"></script>

<!-- Apex chart -->
<script src="<?= base_url('assets_admin/'); ?>vendors/charts/apex/apexcharts.min.js"></script>

<!-- Daterangepicker -->
<script src="<?= base_url('assets_admin/'); ?>vendors/datepicker/daterangepicker.js"></script>

<!-- DataTable -->
<script src="<?= base_url('assets_admin/'); ?>vendors/dataTable/datatables.min.js"></script>

<!-- Lightbox -->
<script src="<?= base_url('assets_admin/'); ?>vendors/lightbox/jquery.magnific-popup.min.js"></script>

<!-- Dashboard scripts -->
<script src="<?= base_url('assets_admin/'); ?>js/examples/pages/dashboard.js"></script>

<!-- App scripts -->
<script src="<?= base_url('assets_admin/'); ?>js/app.min.js"></script>
</body>

</html>
