<script type="text/javascript">
    $(document).ready(function() {
        //show_pemilik(); //call function show all pemilik

        $('#mydata').DataTable({
            responsive: true
        });

    });
</script>