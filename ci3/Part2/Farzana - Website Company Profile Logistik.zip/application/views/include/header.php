<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="Logisti ">
  <link href="<?= base_url(); ?>assets/images/favicon/LOGO Gaffarindo.png" rel="icon">
  <title>PT. Gaffarindo Sukses Logistik | <?php echo $judul; ?></title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700%7cWork+Sans:400,600,700&display=swap">
  <link rel="stylesheet" href="<?= base_url(); ?>assets/css/libraries.css" />
  <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css" />
</head>

<body>
  <div class="wrapper">