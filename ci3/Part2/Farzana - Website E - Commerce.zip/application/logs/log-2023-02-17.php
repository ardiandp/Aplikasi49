<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-17 13:10:10 --> Severity: error --> Exception: Unknown database 'database123' C:\xampp\htdocs\Full-stack\Full-stack-ecommerce-site-with-dashboard-master\system\database\drivers\mysqli\mysqli_driver.php 203
