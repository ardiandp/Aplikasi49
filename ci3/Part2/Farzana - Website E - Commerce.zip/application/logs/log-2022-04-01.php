<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-01 10:30:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-04-01 10:30:09 --> Unable to connect to the database
ERROR - 2022-04-01 12:32:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-04-01 12:32:41 --> Unable to connect to the database
ERROR - 2022-04-01 12:34:39 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:34:50 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:08 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:19 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:20 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:21 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:23 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:28 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:31 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:37 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:40 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:35:42 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:41:36 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:41:49 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:07 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 46
ERROR - 2022-04-01 12:42:10 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:13 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:17 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:23 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:35 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:40 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:43 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:49 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:52 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:42:54 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:45:27 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:45:44 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:45:44 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:45:44 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:53:12 --> 404 Page Not Found: /index
ERROR - 2022-04-01 12:53:39 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:06:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\clothesshop\checkout.php 45
ERROR - 2022-04-01 13:06:13 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:06:13 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:06:13 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:06:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2022-04-01 13:06:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\onepage\checkout.php 48
ERROR - 2022-04-01 13:06:51 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:06:52 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:06:52 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:09:38 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:09:38 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:09:38 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:09:38 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:09:38 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:09:39 --> 404 Page Not Found: /index
ERROR - 2022-04-01 18:49:45 --> 404 Page Not Found: /index
ERROR - 2022-04-01 19:09:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kimanziecomproject\application\views\templates\redlabel\checkout.php 46
ERROR - 2022-04-01 19:10:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kimanziecomproject\application\views\templates\redlabel\checkout.php 46
ERROR - 2022-04-01 19:12:21 --> 404 Page Not Found: /index
ERROR - 2022-04-01 19:12:23 --> 404 Page Not Found: /index
ERROR - 2022-04-01 19:19:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kimanziecomproject\application\views\templates\redlabel\checkout.php 46
ERROR - 2022-04-01 19:23:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kimanziecomproject\application\views\templates\clothesshop\checkout.php 45
ERROR - 2022-04-01 19:23:25 --> 404 Page Not Found: /index
ERROR - 2022-04-01 19:23:26 --> 404 Page Not Found: /index
ERROR - 2022-04-01 19:23:26 --> 404 Page Not Found: /index
ERROR - 2022-04-01 19:23:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kimanziecomproject\application\views\templates\greenlabel\checkout.php 43
