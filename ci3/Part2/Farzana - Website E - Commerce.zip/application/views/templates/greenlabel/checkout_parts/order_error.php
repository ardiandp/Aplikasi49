<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container">
    <div class="alert alert-danger"><?= lang('there_is_payment_error') ?></div>
</div>