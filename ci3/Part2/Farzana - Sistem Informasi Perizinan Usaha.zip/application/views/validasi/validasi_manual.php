
     
<div class="container-fluid">

<!-- Page Heading -->
<h5>Validasi Manual</h5>


<!-- DataTales Example -->
<div class="card shadow mb-4">
  
  <div class="card-body">

</div>
</div>
</div>






