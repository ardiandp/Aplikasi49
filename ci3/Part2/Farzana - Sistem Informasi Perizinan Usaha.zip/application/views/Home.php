<div class="container-fluid">
          <!-- Page Heading -->
          <h3 align="center">SELAMAT DATANG DI SISTEM INFORMASI PELAYANAN PERIZINAN USAHA</h3>
           <h3 align="center">DINAS PERINDUSTRIAN DAN PERDAGANGAN KAB. LEBAK</h3>
        
        <br><br>
 <div class="col-xl-12 col-lg-7">
          
 <!-- Bar Chart -->
              <div class="card shadow mb-12">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Dashboard</h6>
                </div>
                <div class="row">
              
                    <div class="col-xl-4 col-md-6 mb-4">
                    <a href="<?= base_url("Permohonan"); ?>">
                      <div class="card border shadow h-100 py-2" style="background-color:#fc4103;">
                        <h5 align="center">Data Permohonan</h5>
                        <center><img src="<?= base_url('assets/img/form.png'); ?>" style="width: 60px; height: 60px;"></center>
                      </div>
                      </a>
                    </div>
                   
                  <div class="col-xl-4 col-md-6 mb-4">
                   <a href="<?= base_url("Permohonan/tracking"); ?>">
                    <div class="card border shadow h-100 py-2" style="background-color:#0bfc03;">
                      <h5 align="center">Tracking Permohonan</h5>
                       <center><img src="<?= base_url('assets/img/tracking.png'); ?>" style="width: 60px; height: 60px;"></center>
                    </div>
                    </a>
                  </div>

                  <div class="col-xl-4 col-md-6 mb-4">
                   <a href="<?= base_url('Surat/suratterbit'); ?>">
                    <div class="card border shadow h-100 py-2" style="background-color:#03fcdf;">
                      <h5 align="center">Surat Permohonan</h5>
                       <center><img src="<?= base_url('assets/img/surat.png'); ?>" style="width: 60px; height: 60px;"></center>
                    </div>  
                    </a>
                  </div>

              </div>
          </div>
</div>
</div>
          
