<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Hasil Tracking Permohonan</h1>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Hasil Trackinig Permohonan</h6>
            </div>
            <div class="card-body">
             <center><img src="<?= base_url('assets/img/kablebak.png'); ?>" style="width: 60px; height: 60px;"></center>
             <center><h5>DINAS PERINDUSTRIAN DAN PERDAGANGAN KABUPATEN LEBAK</h5></center>
             <hr /><br>
             
	          <h5>
	          	NPWP Tidak Ditemukan / Belum Terdaftar
	          </h5><br>

	          <a href="<?= base_url('Permohonan/tracking'); ?>" class="btn btn-danger">Kembali</a>

            </div>
          </div>
</div>
