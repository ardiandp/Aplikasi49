# sippu
aplikasi sistem informasi perizinan usaha dengan QR code 
