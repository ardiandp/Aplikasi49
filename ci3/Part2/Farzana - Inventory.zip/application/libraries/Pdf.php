<?php
class Pdf {
    function __construct() {
        include_once APPPATH . '/third_party/fpdf184/fpdf.php';
    }
}
