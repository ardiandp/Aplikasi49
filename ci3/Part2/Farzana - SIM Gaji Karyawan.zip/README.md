# Sistem Informasi Gaji Karyawan
Aplikasi sistem informasi gaji karyawan berbasis web dengan menggunakan framework CodeIgniter

## Tampilan Aplikasi
![ss](assets/ss1.png)
![ss](assets/ss2.png)
![ss](assets/ss3.png)
![ss](assets/ss4.png)
![ss](assets/ss5.png)
![ss](assets/ss6.png)

## Login Aplikasi
| Username | Password |
|:--------:|---------:|
|  admin   |  admin   |

## Fitur Aplikasi :
- Halaman FrontEnd
- Login Admin
- Data Karyawan
- Data Jabatan
- Data Absen
- Data Gaji
- Data Pinjaman
- Data Laporan
- Logout
