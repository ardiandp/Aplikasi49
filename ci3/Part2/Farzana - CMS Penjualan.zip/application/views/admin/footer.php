		<footer class="footer">
			<ul class="list-inline">
				<li>2023 © <i>seno</i>-<b>kidal</b>.</li>
				<li><a href="#">Privacy</a></li>
				<li><a href="#">Terms</a></li>
				<li><a href="#">Help</a></li>
			</ul>
		</footer>