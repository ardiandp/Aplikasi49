<?php 
class Pengawas_m extends MY_Model
{

  function __construct()
  {
    parent::__construct();
    $this->data['primary_key'] = 'id_pengawas';
    $this->data['table_name'] = 'pengawas';
  }

 


}

 ?>
