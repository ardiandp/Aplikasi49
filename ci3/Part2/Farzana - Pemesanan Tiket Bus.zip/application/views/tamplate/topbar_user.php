        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-info">
            <!-- toggle sidebar -->
            <a href="#menu" class="btn btn-info btn-lg" id="menu">
                <i class="fas fa-bars"></i>
            </a>
            <!-- akhir toggle -->
            <a href="https://api.whatsapp.com/send?phone=089521649714" class="text-white ml-auto">Contact Us</a>
            <a href="<?= base_url('login/logout'); ?>" class="btn btn-danger rounded-pill ml-auto">Logout</a>
        </nav>
        <!-- akhir Navbar -->