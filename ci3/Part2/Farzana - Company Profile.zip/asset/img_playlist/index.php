<?php
header ('Location:http://mycoding.net/');
?>