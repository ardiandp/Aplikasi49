<div class="container pt-5">
		<div class="row">
            <div class="col-lg-12"> 
                <?php echo $contents; ?> 
            </div> 
    </div>
</div>