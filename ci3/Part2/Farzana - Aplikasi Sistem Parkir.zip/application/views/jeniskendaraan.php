
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $title ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- css -->
  <?php $this->load->view('include/base_css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url('assets') ?>/plugins/datatables/dataTables.bootstrap4.min.css">
</head>
<body class="hold-transition sidebar-mini">
<!-- navbar -->
<?php $this->load->view('include/base_nav'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Jenis Kendaraan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('kendaraan') ?>">Jenis Kendaraan</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="card">
            <div class="card-header">
              <h3 class="card-title"><a href="<?php echo base_url('jeniskendaraan/tambahkendaraan') ?>" class="btn btn-primary">Tambah Jenis</a></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Kode Kendaraan</th>
                  <th>Nama Jenis</th>
                  <th>Katagori</th>
                  <th>Tarif</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
              <?php foreach ($jenis as $row) { ?>
                <tr>
                  <td><?php echo $row['kd_kendaraan'] ?></td>
                  <td><?php echo strtoupper($row['nama_kendaraan']) ?></td>
                  <td><?php if ($row['jenis_kendaraan'] == '1') { ?>
                    <b class="btn-primary">NON MEMBER</b>
                  <?php }else{ ?> 
                    <b class="btn-primary">MEMBER</b>
                  <?php } ?>
                  </td>
                  <td>Rp <?php echo $row['harga_kendaraan'] ?></td>
                  <td align="center"><a href="<?php echo base_url('jeniskendaraan/view/'.$row['kd_kendaraan']) ?>" class="btn btn-default">VIEW</a></td>
                </tr>
              <?php } ?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- footer -->
  <?php $this->load->view('include/base_footer'); ?>

</div>
<!-- ./wrapper -->

<!-- script -->
<!-- DataTables -->

<?php $this->load->view('include/base_js'); ?>
<script src="<?php echo base_url('assets') ?>/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets') ?>/plugins/datatables/dataTables.bootstrap4.min.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
</body>
</html>
