<p align="center"><img src="https://cdn.iconscout.com/icon/premium/png-256-thumb/parking-156-376998.png"></p>

<p align="center">
<a href="https://travis-ci.org/laravel/framework"><img src="https://travis-ci.org/laravel/framework.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/d/total.svg" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/v/stable.svg" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/license.svg" alt="License"></a>
</p>

## Parkirin-Aja

Saya ada aplikasi parkir sederhana berbasis web menggunakan ci 3.1.10

Fitur :
- parkir masuk dan keluar
- jenis kendaraan dan harga perjam
- laporan kendaraan keluar dan total harga
- hak akses untuk owner dan penjaga
- untuk cetak struk menggunakan libabry escpos mike42


semoga bermanfaat tmn tmn 
