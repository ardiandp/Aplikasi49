Saya membagikan aplikasi ini dengan harapan bisa dikembangkan lagi menjadi lebih baik dari yang saya buat.
Kalian bebas menggunakan aplikasi ini.

Tentang Aplikasi :
Menggunakan Framework CI 3

Msmart adalah aplikasi Manajemen Pintar yang di rancang untuk mengelola data karyawan, gaji dan pelanggan. aplikasi yang saya buat ini ketika melakukan project PKL (Praktek kerja Lapangan) dan juga sebagai syarat mata kuliah seminar program.

Msmart terdiri dari 3 Role Acces yaitu : Admin, Supervisor, dan Marketing.
1. Bagian Admin, bagian ini bergerak untuk mengelola data-data manajemen seperti (laporan supervisor, laporan marketing, laporan supervisor, kelola data supervisor, kelola data marketing).
2. Bagian Supervisor, bagian ini bergerak di bidang kepegawaian yang ditujukan untuk marketing dan salah satunya untuk mengelola bagian marketing seperti (laporan pembayaran, laporan pendapatan marketing, laporan pelanggan, kelola data marketing dan kelola data pelanggan)
3. Bagian Marketing, pada bagian ini untuk mengelola harga pembelian produk berupa website dan mencari pelanggan yang membutuhkan produk ini.

Role Acces Aplikasi ini :
Admin
admin@gmail.com
123456

Supervisor
supervisor@gmail.com
123456

Marketing
marketing@gmail.com
123456
