<!-- Load More Javascript -->
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.transit/0.9.12/jquery.transit.min.js" integrity="sha256-rqEXy4JTnKZom8mLVQpvni3QHbynfjPmPxQVsPZgmJY=" crossorigin="anonymous"></script>
		<script src="<?=base_url('public/')?>js/notyf.min.js"></script>
		<!-- Required Overall Script -->
        <script src="<?=base_url('public/')?>js/script.js"></script>
		<!-- Status Updater -->
		<script src="<?=base_url('public/')?>js/status.js"></script>
		<!-- Sample Notifications -->
		<script src="<?=base_url('public/')?>js/notification.js"></script>
    </body>
</html>
