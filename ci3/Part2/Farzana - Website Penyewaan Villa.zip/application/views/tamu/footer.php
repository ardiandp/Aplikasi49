<!-- Sticky Footer -->
<footer >
  <div class="container mx-auto">
    <div class="copyright text-center my-auto">
      <br/><span>Copyright © <a href="http://www.mycoding.net"><?php echo SITE_NAME ."</a> ". Date('Y') ?></span>
    </div>
  </div>
</footer>