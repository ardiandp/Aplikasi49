<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-21 05:18:10 --> 404 Page Not Found: 
ERROR - 2023-02-21 05:20:28 --> 404 Page Not Found: 
ERROR - 2023-02-21 05:22:36 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Users.php 77
ERROR - 2023-02-21 05:22:36 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Users.php 78
ERROR - 2023-02-21 05:22:36 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Users.php 79
ERROR - 2023-02-21 05:24:51 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Users.php 77
ERROR - 2023-02-21 05:24:51 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Users.php 78
ERROR - 2023-02-21 05:24:51 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Users.php 79
ERROR - 2023-02-21 05:30:31 --> Could not find the language line "show_menu"
ERROR - 2023-02-21 05:30:31 --> Could not find the language line "hide_menu"
ERROR - 2023-02-21 05:30:44 --> Could not find the language line "show_menu"
ERROR - 2023-02-21 05:30:44 --> Could not find the language line "hide_menu"
ERROR - 2023-02-21 05:30:56 --> Could not find the language line "show_menu"
ERROR - 2023-02-21 05:30:56 --> Could not find the language line "hide_menu"
ERROR - 2023-02-21 05:31:04 --> Could not find the language line "show_menu"
ERROR - 2023-02-21 05:31:04 --> Could not find the language line "hide_menu"
ERROR - 2023-02-21 05:31:11 --> Could not find the language line "show_menu"
ERROR - 2023-02-21 05:31:11 --> Could not find the language line "hide_menu"
ERROR - 2023-02-21 05:31:22 --> 404 Page Not Found: /index
ERROR - 2023-02-21 05:31:22 --> 404 Page Not Found: /index
