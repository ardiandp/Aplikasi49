<h3>Aplikasi Marketplace Vndrosport</h3>
<p>Dikembangkan untuk perangkat berbasis android, spesifikasinya diantaranya:<p>
<ul>
  <li>Minimal API adalah 24 - Android 7 Nougat</li>
  <li>Terhubung dengan webservice menggunakan retrofit</li>
  <li>Webservice dengan Codeigniter 3.1</li>
  <li>Database MySQL dan SQLite</li>
</ul>


<p>Cara installasi Web CI 3</p>
<ul>
    <li>download dari github: $ git clone https://github.com/alexistdev/vndrosport.git</li>
	<li>Letakkan file di directory local anda, biasa di xampp di htdocs</li>
	<li>buka file dan jalankan "composer install" diterminal</li>
	<li>Buat database dan sesuaikan dengan file yang ada di config/database</li>
	<li>import database dari file vndrosport.sql</li>
	<li>login di URL:admin/login dengan username: admin password admin</li>
</ul>

<p>Cara installasi Android</p>
<ul>
	<li>Buka file android dengan android studio</li>
	<li>Lakukan pengaturan config/Constants.java</li>
	<li>Isi dengan ip localhost vndrosport saat anda menjalankan xampp /wampp</li>
	<li>Jalankan emulator android studio</li>
</ul>

<a href='https://postimg.cc/gnFLMHgf' target='_blank'><img src='https://i.postimg.cc/rFzGwhxF/1.png' border='0' alt='1'/></a>
<a href='https://postimg.cc/Btxnv9CV' target='_blank'><img src='https://i.postimg.cc/VshrDz0m/4.png' border='0' alt='4'/></a>



