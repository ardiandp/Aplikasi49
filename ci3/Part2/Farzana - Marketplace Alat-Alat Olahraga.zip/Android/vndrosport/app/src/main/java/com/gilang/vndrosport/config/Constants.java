package com.gilang.vndrosport.config;

public class Constants {
//	public static final String URL ="https://vndrosport.xyz/";
//	public static final String IMAGES_URL = "https://vndrosport.xyz/gambar/produk/";
    public static final String URL ="http://192.168.56.1/vndrosport/";
	public static final String IMAGES_URL = "http://192.168.56.1/vndrosport/gambar/produk/";

	public static final String KEY_USER_SESSION = "DBSD123";
	public static final String USER_SESSION = "CR19201";
}
