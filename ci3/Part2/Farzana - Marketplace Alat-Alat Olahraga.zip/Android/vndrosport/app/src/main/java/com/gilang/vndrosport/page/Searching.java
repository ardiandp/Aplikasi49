package com.gilang.vndrosport.page;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.gilang.vndrosport.R;

public class Searching extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searching);
    }
}
