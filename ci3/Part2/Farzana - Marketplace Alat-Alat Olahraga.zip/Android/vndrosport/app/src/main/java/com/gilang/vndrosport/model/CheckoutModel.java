package com.gilang.vndrosport.model;

public class CheckoutModel {
	String idUser;

	public String getIdUser() {
		return idUser;
	}
}
