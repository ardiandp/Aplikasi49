<script src="<?php echo base_url() ?>assets/backend/template/assets/js/vendor-all.min.js"></script>
<!-- <link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/fonts/fontawesome/css/fontawesome-all.min.css"> -->
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/animation/css/animate.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/data-tables/css/datatables.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/dropify/css/dropify.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/animation/css/animate.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/bootstrap-datetimepicker/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/css/pages/pages.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/notification/css/notification.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/ekko-lightbox/css/ekko-lightbox.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/lightbox2-master/css/lightbox.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/jQueryUI/css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/owl-carousel/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/multi-select/css/multi-select.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/font-awesome-4.4.0/css/font-awesome.min.css">

<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/fontawesome/css/all.css">

<style>
    .alert span {
        cursor: pointer;
        padding-right: 5px;
    }
</style>
<style>
    .lb-nav a.lb-next,
    .lb-nav a.lb-prev {
        opacity: 1;
    }
</style>
<script>
    var page = {
        bootstrap: 3
    };

    function swap_bs() {
        page.bootstrap = 3;
    }
</script>
<style>
    .datepicker>.datepicker-days {
        display: block;
    }

    ol.linenums {
        margin: 0 0 0 -8px;
    }
</style>
<style>
    .card {
        box-shadow: 0 19px 38px rgba(0, 0, 0, 0.30), 0 15px 12px rgba(0, 0, 0, 0.22);
    }
</style>
<style>
    .dt-buttons {
        left: 35%;
    }
</style>


<link rel="stylesheet" href="<?php echo base_url() ?>assets/backend/template/assets/plugins/jqupload/css/vendor/doka.min.css" />
<!-- Generic page styles -->
<style>
    body {
        padding-top: 60px;
    }

    @media (max-width: 767px) {
        .description {
            display: none;
        }
    }

    #carbonads {
        box-sizing: border-box;
        max-width: 300px;
        min-height: 130px;
        padding: 15px 15px 15px 160px;
        margin: 0;
        border-radius: 4px;
        font-size: 13px;
        line-height: 1.4;
        background-color: rgba(0, 0, 0, 0.05);
    }

    .fade.in {
        opacity: 1
    }
</style>