<div class="card">
    <div class="card-header">
        <h5>Hasil</h5>
    </div>
    <div class="card-body">
        <?= $this->session->flashdata('message'); ?>

    </div>
</div>
