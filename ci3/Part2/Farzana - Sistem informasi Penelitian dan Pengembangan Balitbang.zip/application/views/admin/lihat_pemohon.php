 <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- MAP DATA-->
                                <div class="row">
                                    <h3 class="title-3 m-b-30">
                                        <i class="fas fa-user"></i>Detail Pemohon</h3>
                                  <table class="table">
                                      <tr>
                                          <td>Nama</td>
                                          <td>:<?=$tampil['nama']?></td>
                                      </tr>
                                      <tr>
                                          <td>tanggal lahir</td>
                                          <td>:<?=$tampil['tgl']?></td>
                                      </tr>
                                      <tr>
                                          <td>Alamat</td>
                                          <td>:<?=$tampil['alamat']?></td>
                                      </tr>
                                      <tr>
                                          <td>Email</td>
                                          <td>:<?=$tampil['email']?></td>
                                      </tr>
                                      <tr>
                                          <td>Nomor HP</td>
                                          <td>:<?=$tampil['no_hp']?></td>
                                      </tr>
                                      <tr>
                                          <td>Username</td>
                                          <td>:<?=$tampil['username']?></td>
                                      </tr>
                                      <tr>
                                          <td>Password</td>
                                          <td>:<?=$tampil['pass']?></td>
                                      </tr>
                                  </table>
                                </div>
                                <!-- END MAP DATA-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
