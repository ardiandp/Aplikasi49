
    <!-- END MENU SIDEBAR-->
    <!-- PAGE CONTAINER-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1">Dashborad</h2>

                                </div>
                            </div>
                        </div>
                        <div>
                        <div class="edu-accordion-area mg-b-15">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="tab-content-details mg-b-30">
                                            <h2>Sejarah Balitbang</h2>
                                            <p>sejrah.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="admin-pro-accordion-wrap shadow-inner responsive-mg-b-30">
                                            <div class="alert-title">
                                                <h2>Visi</h2>
                                                <p>These are the Custom bootstrap Animate bounce Accordion style 1</p>
                                            </div>
                                            <div class="panel-group edu-custon-design" id="accordion">
                                                <div class="panel panel-default">
                                                    <div class="panel-heading accordion-head">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                                                                Collapsible Group 1</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse1" class="panel-collapse panel-ic collapse in">
                                                        <div class="panel-body admin-panel-content animated bounce">
                                                            <p>It was popularised in the 1960s with the release of Letraset sheets of the containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions.</p>
                                                            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor incididunt ut labore et dolore magna aliqua of Lorem Ipsum.</p>
                                                            <p> Ut enim adminim veniam, quis nostrud exercitation ullamco laboris nisis ut aliquip ex ea commodo consequat consectetur adipisicing elit.</p>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="admin-pro-accordion-wrap shadow-inner">
                                            <div class="alert-title">
                                                <h2>Misi</h2>
                                                <p>These are the Custom bootstrap Animate flash Accordion style 2</p>
                                            </div>
                                            <div class="panel-group edu-custon-design" id="accordion2">
                                                <div class="panel panel-default">
                                                    <div class="panel-heading accordion-head">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion2" href="#collapse4">
                                                                Collapsible Group 2</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse4" class="panel-collapse panel-ic collapse in">
                                                        <div class="panel-body admin-panel-content animated flash">
                                                            <p>It was popularised in the 1960s with the release of Letraset sheets of the containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions.</p>
                                                            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor incididunt ut labore et dolore magna aliqua of Lorem Ipsum.</p>
                                                            <p> Ut enim adminim veniam, quis nostrud exercitation ullamco laboris nisis ut aliquip ex ea commodo consequat consectetur adipisicing elit.</p>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>


                    </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="<?= base_url() ?>assets/templates/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="<?= base_url() ?>assets/templates/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="<?= base_url() ?>assets/templates/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="<?= base_url() ?>assets/templates/vendor/slick/slick.min.js">
    </script>
    <script src="<?= base_url() ?>assets/templates/vendor/wow/wow.min.js"></script>
    <script src="<?= base_url() ?>assets/templates/vendor/animsition/animsition.min.js"></script>
    <script src="<?= base_url() ?>assets/templates/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="<?= base_url() ?>assets/templates/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="<?= base_url() ?>assets/templates/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="<?= base_url() ?>assets/templates/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="<?= base_url() ?>assets/templates/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="<?= base_url() ?>assets/templates/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="<?= base_url() ?>assets/templates/vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="<?= base_url() ?>assets/templates/js/main.js"></script>

</body>

</html>
<!-- end document-->
