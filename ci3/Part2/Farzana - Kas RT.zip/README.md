# e-kasRT
**Aplication of Kas RT**

The e-kasRT application is a simple cash application that can be used for financial management in the RT area. Here is a view of the program that was created.

# Login View
![image](https://user-images.githubusercontent.com/53107522/128481299-c572ed8e-9f40-43b7-8771-0354ce534d26.png)

# Dashboard View
![image](https://user-images.githubusercontent.com/53107522/128451767-13f818ac-e11a-4640-8e97-5c62be273189.png)

This application is still far from perfect, therefore it is welcome to be developed and used properly. Thanks very much.

Suggestions and constructive input are expected for future improvement: 
* Mail : slametr6@gmail.com, 
* IG : @slametr6, 
* Linkedin : https://www.linkedin.com/in/slamet-riyadi-7b13b5162/
