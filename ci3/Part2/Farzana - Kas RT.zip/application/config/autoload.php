<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('database', 'session', 'form_validation');
$autoload['drivers'] = array();
$autoload['helper'] = array('url', 'file', 'form', 'rupiah');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array('m_auth', 'm_kas');
