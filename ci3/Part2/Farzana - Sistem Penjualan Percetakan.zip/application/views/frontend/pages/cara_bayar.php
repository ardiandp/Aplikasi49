<h3>Cara Bayar</h3>
<p>* Pilih Produk Sesuai Keinginan</h3>
<p>* Ke Menu Keranjang Lalu Check out dan Upload Bukti Pembayaran</p>
<p>* Ke Kasir Untuk Proses Selanjutnya</p>
<h3>&nbsp;</h3>