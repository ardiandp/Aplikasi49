<?php

$lang['title_home'] = 'Electronic invoices, E-mails';
$lang['description_home'] = 'Start issuing and sending electronic invoices';

$lang['title_login'] = 'Sign in and start issuing invoices';
$lang['description_login'] = 'Enter your email and password and sign in to your billing program';

$lang['title_register'] = 'Registration';
$lang['description_register'] = 'Register simply by entering your email and password';

$lang['title_forgotten'] = 'Restore your password';
$lang['description_forgotten'] = 'Change your forgotten password';