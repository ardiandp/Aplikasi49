<?php 
$lang['first'] = 'First';
$lang['last'] = 'Last';
$lang['next'] = 'Next';
$lang['previous'] = 'Previous';
$lang['pagination_last_link'] = 'Last';
$lang['pagination_first_link'] = 'First';
