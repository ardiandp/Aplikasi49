<?php 
$lang['first'] = 'Първа';
$lang['last'] = 'Последна';
$lang['next'] = 'Следваща';
$lang['previous'] = 'Предишна';
$lang['previous'] = 'Предишна';
$lang['pagination_last_link'] = 'Последна';
$lang['pagination_first_link'] = 'Първа';
