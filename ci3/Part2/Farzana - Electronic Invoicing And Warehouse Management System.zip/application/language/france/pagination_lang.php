<?php 
$lang['first'] = 'Premier';
$lang['last'] = 'Dernier';
$lang['next'] = 'Prochain';
$lang['previous'] = 'précédent';
$lang['pagination_last_link'] = 'Dernier';
$lang['pagination_first_link'] = 'Premier';
