<?php

$lang['title_home'] = 'Factures électroniques, E-mails';
$lang['description_home'] = 'Commencer à émettre et à envoyer des factures électroniques';

$lang['title_login'] = 'Connectez-vous et commencez à émettre des factures';
$lang['description_login'] = 'Entrez votre email et votre mot de passe et connectez-vous à votre programme de facturation';

$lang['title_register'] = 'Inscription';
$lang['description_register'] = 'Inscrivez-vous simplement en entrant votre email et votre mot de passe';

$lang['title_forgotten'] = 'Restaurez votre mot de passe';
$lang['description_forgotten'] = 'Changer votre mot de passe oublié';