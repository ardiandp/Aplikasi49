###################
madpharma-pharmacy management system
###################

**I am available for PHP,Laravel,Codeigniter work, check out my Fiverr profile:**

Visit Urls : http://www.fiverr.com/s2/0e44853c56

*******************
summary
*******************
**Pharmacy Management** System is a web-based solution that helps pharmacy to **Stock management** efficiently.This **pharmacy management system** software is developed by PHP and Codeigniter framework. It is designed and developed for pharmacy, **medicine store**, departmental store and **medicine shop**. Handle all of your pharmacy data easily. Here you can handle all of your **pharmacy account management**, **invoice create**, user and data analysis, **stock management**, **store management**, purchase history, **income history**, **pos** and many more.

*******************
Features
*******************
* Medicine Database
* **Point of Sales** (POS)*
* Order module
* **Supplier module**
* **customer management**
* **purchase management**
* barcode
* manage account
* sales return
* **Expense module**
* Email module
* **Expire Alert** Notification
* **Stock Alert** Notification
* Server side Datatables
* Invoicing
* Reporting
* Dynamic Dashboard.
* Alert Stock Management
* Big data Handling by server side datatables.
* Server Side Searching for all the tables
* **Easy Invoice** / sale search by Invoice Id
* Daily Sales Report
* Daily Expense Report
* Current Month Statistics
* Latest Sales , Expense and Medicine
* **Sales Graph**
* **Inventory Stock Managemrnt**
* **Expense Management**
* Date to date report generate
* **Sales report**
* **Expense report**
* Sales Database
* **Easy Settings**
* Partial Payment
* **Due Payment Management**
* Device Responsive

**************************
Authentication
**************************

**admin** :
username: admin@gmail.com
password: abc123

**manager** :
username: example@example.com
password: abc123

**manager** :
username: nawjeshbd@gmail.com
password: abc123


**I am available for PHP,Laravel,Codeigniter work, check out my Fiverr profile:**

Visit Urls : http://www.fiverr.com/s2/0e44853c56
