<input name="id_penjualan" type="hidden" value="<?php echo $penjualan->id_penjualan;?>">
<div class="form-group">
	<label>Alasan Pembatalan</label><br>
	<textarea class="form-control" name="ket" placeholder="Batal Order / Perubahan Produk" required></textarea>
</div>