<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Vendor styles -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/material-design-iconic-font/css/material-design-iconic-font.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/animate.css/animate.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/jquery-scrollbar/jquery.scrollbar.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/fullcalendar/fullcalendar.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/select2/css/select2.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/sweetalert2/sweetalert2.css">
        <link href="<?php echo base_url('assets/fontawesome-free/css/all.min.css') ?>" rel="stylesheet" type="text/css">
        <!-- App styles -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/app.min.css">
		<script src="<?php echo base_url();?>assets/vendors/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/chart.js/Chart.min.js') ?>"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    </head>

    <body data-ma-theme="">
      <main class="main">