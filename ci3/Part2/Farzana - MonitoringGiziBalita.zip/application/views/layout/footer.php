<!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer"> Copyright 2023 © Aplikasi Monitoring Gizi Balita</footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?= base_url() ?>assets/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="<?= base_url() ?>assets/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?= base_url() ?>assets/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="<?= base_url() ?>assets/sticky-kit.min.js"></script>
    <!--Custom JavaScript -->
    <script src="<?= base_url() ?>assets/custom.min.js"></script>

    
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->


    <!-- Select2 -->
    <script src="<?php echo base_url('assets/plugins/select2/js/select2.full.min.js') ?>"></script>

    <!-- DataTables -->
    <script src="<?=base_url()?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?=base_url()?>assets/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="<?=base_url()?>assets/plugins/moment/moment.js"></script>
    <script src="<?=base_url()?>assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Date Picker Plugin JavaScript -->
    <script src="<?=base_url()?>assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>

    <!-- Toast-Master -->
    <script src="<?=base_url()?>assets/plugins/toast-master/js/jquery.toast.js"></script>


    <!--sparkline JavaScript -->
    <script src="<?= base_url() ?>assets/jquery.sparkline.min.js"></script>
    <!--morris JavaScript -->
    <script src="<?= base_url() ?>assets/raphael-min.js"></script>
    <script src="<?= base_url() ?>assets/morris.min.js"></script>
    <!-- Chart JS -->
    <script src="<?= base_url() ?>assets/dashboard1.js"></script>

    <!-- Magnific POPUP JavaScript -->
    <script src="<?= base_url() ?>assets/jquery.magnific-popup.min.js"></script>
    <script src="<?= base_url() ?>assets/jquery.magnific-popup-init.js"></script>
    <!-- ============================================================== -->


    <!-- Sweet-Alert  -->
    <script src="<?= base_url() ?>assets/sweetalert.min.js"></script>
    <script src="<?= base_url() ?>assets/jquery.sweet-alert.custom.js"></script>
    <!-- Style switcher -->
    <!-- ============================================================== -->
    <script src="<?= base_url() ?>assets/jQuery.style.switcher.js"></script>

    
    <!-- Clock Plugin JavaScript -->
    <script src="<?= base_url() ?>assets/jquery-clockpicker.min.js"></script>
    <!-- Color Picker Plugin JavaScript -->
    <script src="<?= base_url() ?>assets/jquery-asColor.js"></script>
    <script src="<?= base_url() ?>assets/jquery-asGradient.js"></script>
    <script src="<?= base_url() ?>assets/jquery-asColorPicker.min.js"></script>
    

    <!-- ============================================================== -->
    <!-- jQuery file upload -->
    <script src="<?= base_url() ?>assets/dropify.min.js"></script>
</body>

</html>