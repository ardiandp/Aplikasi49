versi database = 10.4.24
versi php = 8.0.19
sql sipekan collation = utf8mb4_general_ci
framework codeigniter 3 = versi 3.1.13

<-------------- PANDUAN PENGGUNAAN APLIKASI SIPEKAN --------------->
1.	Import database ‘sipekan.sql’
2.	Run program sipekan
3.	Login pada aplikasi sipekan menggunakan akun yang telah disediakan

AKUN Admin 
email : anggara@gmail.com
password : agnarizky1

Akun Manager
email : agnarizky@gmail.com
password : agnarizky

<------------------------ NOTE -----------------------> 
1. Setiap Role mempunyai tugas dan fitur nya masing-masing, dan terdapat 2 role yaitu Admin dan Manager
2. Level pada persetujuan terdapat 3, yang pertama yaitu 'menunggu' yang artinya menunggu persetujuan atau konfirmasi dari manager
,lalu yang kedua 'proses' yang artinya kendaraan masih dalam proses keberangkatan, dan yang terakhir 'selesai' yang artinya kendaraan
telah kembali (tugas sudah selesai).

