  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark  border-bottom" style="background-color: #007cc2">
      <div class="container-fluid">

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <form class="navbar-search navbar-search-light form-inline mr-sm-3" id="navbar-search-main">
            <a  href="<?=base_url('guru')?>" style="color: white">
                 <b> SMP Islam Al-Azhar 33 Palembang</b>
          </a>
          </form>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            
           
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
           <li class="nav-item ">
              <a class="nav-link pr-0" href="<?=base_url('guru/')?>" >
                <div class="media align-items-center"> 
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold">Dashboard</span>
                  </div>
                </div>
              </a> 
            </li>
           
           
            <li class="nav-item ">
              <a class="nav-link pr-0" href="<?=base_url('guru/profile')?>" >
                <div class="media align-items-center"> 
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold">Profil</span>
                  </div>
                </div>
              </a> 
            </li>
            <li class="nav-item ">
              <a class="nav-link pr-0" href="<?=base_url('logout')?>" >
                <div class="media align-items-center"> 
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold">Logout</span>
                  </div>
                </div>
              </a> 
            </li>

 
          </ul>
        </div>
      </div>
    </nav>
    <!-- Header -->
   