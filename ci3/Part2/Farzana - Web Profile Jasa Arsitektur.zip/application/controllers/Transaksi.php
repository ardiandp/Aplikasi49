<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    public function index()
    {
        
    }

    public function store()
    {
        
    }

}

/* End of file Transaksi.php */
