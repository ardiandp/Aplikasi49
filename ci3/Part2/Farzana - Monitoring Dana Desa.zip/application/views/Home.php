
<div class="container-fluid">
 <h3 align="center">Selamat Datang di sistem informasi monitoring dana desa Pasireurih</h3>
    <br><br>
    <div class="col-xl-12 col-lg-7">
        <div class="card shadow mb-12">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Dashboard</h6>
                </div>
                <div class="row">
              
                    <div class="col-xl-4 col-md-6 mb-4">
                    <a href="<?= base_url("Dana_masuk"); ?>">
                      <div class="card border shadow h-100 py-2" style="background-color:aqua;">
                        <h5 align="center">Dana Masuk</h5>
                       
                      </div>
                      </a>
                    </div>
                   
                  <div class="col-xl-4 col-md-6 mb-4">
                   <a href="<?= base_url("Dana_keluar"); ?>">
                    <div class="card border shadow h-100 py-2" style="background-color:aqua;">
                      <h5 align="center">Dana Keluar</h5>
                       
                    </div>
                    </a>
                  </div>

                  <div class="col-xl-4 col-md-6 mb-4">
                   <a href="<?= base_url('Laporan'); ?>">
                    <div class="card border shadow h-100 py-2" style="background-color:aqua;">
                      <h5 align="center">Laporan Dana Desa</h5>
                     
                    </div>  
                    </a>
                  </div>

              </div>
         
              
          
    </div>
</div>