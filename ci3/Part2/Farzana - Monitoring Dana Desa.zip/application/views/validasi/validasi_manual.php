
     
<div class="container-fluid">

<!-- Page Heading -->
<h5>Validasi Manual</h5>


<!-- DataTales Example -->
<div class="card shadow mb-12">
  
  <div class="card-body">
  <div class="row">
        <div class="col-xl-2 col-md-6 mb-4">
            <label>Id Pelanggan :</label> 
        </div>
        <div class="col-xl-6 col-md-6 mb-4">
            <input type="text" name="id_pel" class="form-control" placeholder="Masukkan Id Pelanggan"> 
        </div>
        <div class="col-xl-2 col-md-6 mb-4">
            <input type="submit" name="cari" class="btn btn-primary" value="Cari"> 
        </div>
  </div>
</div>
</div>
</div>






