<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Edit Instansi</h1>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Edit Instansi</h6>
            </div>
            <div class="card-body">
              <div class="col-md-6">
              <form role="form" action="" method="POST">
                   <div class="form-group" hidden>
                    <label for="exampleInputEmail1">id instansi</label>
                    <input type="text" class="form-control" name="id_instansi" value="<?= $instansi['id_instansi']; ?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Nama Instansi</label>
                    <input type="text" class="form-control" name="nama_instansi" value="<?= $instansi['nama_instansi']; ?>">
                  </div>
                  
                  <div class="form-group">
                    <input type="submit" name="update" class="btn btn-primary" value="Update">
                  </div>
              </form>
            </div>
            </div>
          </div>

</div>