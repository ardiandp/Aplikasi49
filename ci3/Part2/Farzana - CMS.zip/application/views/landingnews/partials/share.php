<div class="social-share">
	Share :
	<script language="javascript">
	document.write("<a href='https://www.facebook.com/share.php?u=" + document.URL + " ' target='_blank' ></a><i class='fa fa-facebook fb' aria-hidden='true'></i></a> "+
	"<a href='https://twitter.com/home/?status=" + document.URL + "' target='_blank' </a></a><i class='fa fa-twitter twitter' aria-hidden='true'></i></a> "+
	"<a href='https://api.whatsapp.com/send?phone={phone_number}&text=" + document.URL + " ' target='_blank' ><i class='fa fa-whatsapp wa' aria-hidden='true'></i></a> ");
	</script>
</div>

