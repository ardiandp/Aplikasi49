# laundry-ci
Silahkan setting database dan bash_url anda terlebih dahulu. Jika ada bug silahkan laporkan
