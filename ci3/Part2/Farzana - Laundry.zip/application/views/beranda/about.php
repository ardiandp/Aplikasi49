<div class="block-header">
    <h2>
        ABOUT
    </h2>
</div>
<!-- Basic Examples -->
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="body">
                <center>
                <H2>NEO LAUNDRY</H2>
                <br>
                <p>Neo Laundry yang terletak pada Jalan Golf No.22 RT01 RW08 Kelurahan Ciriung, Kecamatan Cibinong, <br>Kabupaten Bogor merupakan usaha yang melayani jasa pencucian pakaian dan sejenisnya<br> baik kiloan, satuan, dan masih banyak lainnya. Untuk pemesanan bisa datang ke neo laundry atau bisa <br>telepon ke 0859-2161-1617.</p>
                <br><br>
                <h4>Tampilan Depan Neo Laundry</h4>
                <img src="<?= base_url('assets/images/bg1.jpg') ?>" width="900" height="500"/>
                <br><br>
                <h4>Lokasi</h4>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.418208511373!2d106.86002571450463!3d-6.46858896504639!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69c1d309b3c97d%3A0x5e38037339ffea61!2sJl.%20Golf%20No.22%2C%20Ciriung%2C%20Cibinong%2C%20Bogor%2C%20Jawa%20Barat%2016918!5e0!3m2!1sen!2sid!4v1630601551689!5m2!1sen!2sid" width="900" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                <br><br>
                
                </center>
            </div>
        </div>
    </div>
</div>