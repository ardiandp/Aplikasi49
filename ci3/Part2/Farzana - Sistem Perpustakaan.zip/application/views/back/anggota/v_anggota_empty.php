<?php
$style = 'class="form-control" id="no_induk"';
echo form_dropdown('', array('' => '- Pilih Perguruan Tinggi Dulu -'), '', $style);
?>
