<?php
$style = 'class="form-control" id="no_induk"';
echo form_dropdown("no_induk",$anggota,'',$style);
?>
