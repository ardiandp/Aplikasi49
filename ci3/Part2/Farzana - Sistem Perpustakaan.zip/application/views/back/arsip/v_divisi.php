<?php
$style = 'class="form-control" id="divisi_id"';
echo form_dropdown("divisi_id",$divisi,'',$style);
?>
