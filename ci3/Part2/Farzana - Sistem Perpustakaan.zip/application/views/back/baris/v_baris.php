<?php
$style = 'class="form-control" id="baris_id"';
echo form_dropdown("baris_id",$baris,'',$style);
?>
