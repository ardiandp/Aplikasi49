<?php
$style = 'class="form-control" id="folder_name"';
echo form_dropdown("folder_name",$folder_name,'',$style);
?>