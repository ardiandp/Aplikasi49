<?php
$style = 'class="form-control" id="bagian_id"';
echo form_dropdown("bagian_id",$bagian,'',$style);
?>
