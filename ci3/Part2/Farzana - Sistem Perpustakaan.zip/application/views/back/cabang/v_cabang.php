<?php
$style = 'class="form-control" id="cabang_id"';
echo form_dropdown("cabang_id",$cabang,'',$style);
?>
