</div>
<!--- body 3 !--->
<div class="jumbotron jumbotron-fluid body3">
  <div class="container">
    <h1 class="text-white" style="font-weight: 200;">Supported By Institute Teknology of Indonesia</h1>
    <p class="lead text-white">All Right Reserved. 2020</p>
  </div>

</body>

  <script src="<?= base_url('assets/bootstrap/js/jquery-slim.min.js') ?>"></script>
  
  <script src="<?= base_url('assets/bootstrap/js/popper.min.js') ?>"></script>
	<script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>

  
  
</html>