
<strong>Copyright &copy;  <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com"> RNAStore - Toko Level</a>.</strong> All rights reserved. 