<p class='sidebar-title'><span class='glyphicon glyphicon-ok'></span> <strong>Success Reset Password!</strong></p>
<center style='padding:50px'>
<style>
.lupa {
	width:50%;
}
</style>
<div class='alert alert-success'>Success Reset Password!!</div>
Permintaan Untuk Pergantian password sudah kami terima...<br>
Silahkan cek email anda, kami telah mengirimkan password baru ke <b class='btn btn-xs btn-success'><?php echo $email; ?></b>, salam,.<br>
<br><br>
</center>