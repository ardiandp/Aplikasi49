
<strong>Copyright &copy;  <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com"> RNAStore</a>.</strong> All rights reserved. 