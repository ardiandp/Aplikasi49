<!-- 
  <section class="py-5 text-center bg-light mb-4">
    <div class="container">
      <h2><?php echo $title ?></h2>
      </div>
    </div>
  </section> -->

<div class="container">

  <div class="row text-center">
  </div>
  <!-- /.row -->

</div>
<!-- /.container -->