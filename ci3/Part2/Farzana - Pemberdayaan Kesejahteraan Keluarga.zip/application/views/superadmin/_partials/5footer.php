                <!-- ini bagian footer  -->
                <!-- ini bagian footer  -->
                <!-- ini bagian footer  -->
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div></div>
                            <div class="text-muted">Copyright &copy; <strong>PKK DESA</strong>. System Version <strong><?php echo APP_VERS ?> </strong></div>
                        </div>
                    </div>
                </footer>
                <!-- ini bagian footer  -->
                <!-- ini bagian footer  -->
                <!-- ini bagian footer  -->

                </div>

                </div> <!-- akhir -->