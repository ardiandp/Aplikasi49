<?php
require_once('1head.php');
require_once('2nav.php');
// require_once('3header.php');
require_once('4content.php');
require_once('5footer.php');
