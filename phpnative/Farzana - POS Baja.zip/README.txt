- buat database baru
- dump atau copas query pada file dump.sql
- buka file koneksi.php , edit dan sesuaikan dengan database dan password anda

DONE!

untuk modifikasi sesuai dengan kebutuhan anda, silahkan hubungi saya
Whatsapp: 0813 9024 1937

harga bisa dibicarakan .. hahahaa :D
