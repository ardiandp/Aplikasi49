# SIMPosyandu
--BAHASA--<br>
--Sistem Informasi Manajemen Posyandu--<br>
Implementasi Aplikasi Ini Berupa CRUD Sederhana Untuk Menunjang Perekapan Data Berupa Sistem Informasi Berbasis Web.<br>
Silahkan Custom Tampilan Sesuai Format Yang Anda Inginkan.<br>
Tolong Berikan Credit Dengan Nama IMX Pada Footer (Copyright) Jika Hendak Menggunakan Aplikasi Ini.<br>
Masih Banyak Kekurangan Dalam Pembuatan Aplikasi Ini.<br>
Semoga Bermanfaat.<br>
<br><br>
--ENGLISH--<br>
--Integrated Healthcare Center Web Apps--<br>
The implementation of this application is in the form of a simple CRUD to support data recording in the form of a web-based information system. <br>
Please Custom Display According to the Format You Want.<br>
Please give credit with the IMX name on the footer (copyright) if you want to use this application.<br>
There are still many deficiencies in making this application. <br>
Hopefully Helpful.
