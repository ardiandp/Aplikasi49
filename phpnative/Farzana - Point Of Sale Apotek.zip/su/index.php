<?php include 'sidebar.php'; ?>
<?php

?>
<!-- isinya -->

<h1 class="h3 mb-2">Data Laporan</h1>
<div class="row">

    <div class="col-6 col-sm-6 col-md-3 col-lg-3 m-pr-1 m-mb-1">
        <div class="box-laporan">
            <p class="small mb-0">Jumlah Pengguna Aplikasi</p>
            <h5 class="mb-0">1</h5>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="assets/js/sidebar.js"></script>
    <script src="assets/vendor/datatables/jquery-3.5.1.js"></script>
    <script src="assets/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="assets/vendor/datatables/dataTables.responsive.min.js"></script>
    <script src="assets/vendor/datatables/responsive.bootstrap4.min.js"></script>

    </body>

    </html>