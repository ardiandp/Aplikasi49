
<?php
require_once 'func.php';
?>

        <div class='panel panel-info'>
          <div class='panel-heading'>Form Input rencana_usaha </div>
          <div class='panel-body'>
          <form action='' method='POST'>
          
              <div class="form-group">
                <label for="modal"> modal:</label>
                <input type="text" class="form-control" id="modal" name='modal' placeholder='modal'>
              </div>
              <div class="form-group">
                <label for="saham"> saham:</label>
                <input type="text" class="form-control" id="saham" name='saham' placeholder='saham'>
              </div>
              <div class="form-group">
                <label for="jumlah_tenaga_kerja"> jumlah_tenaga_kerja:</label>
                <input type="text" class="form-control" id="jumlah_tenaga_kerja" name='jumlah_tenaga_kerja' placeholder='jumlah_tenaga_kerja'>
              </div>
              <div class="form-group">
                <label for="nilai_produksi"> nilai_produksi:</label>
                <input type="text" class="form-control" id="nilai_produksi" name='nilai_produksi' placeholder='nilai_produksi'>
              </div>
              <div class="form-group">
                <label for="nilai_investasi"> nilai_investasi:</label>
                <input type="text" class="form-control" id="nilai_investasi" name='nilai_investasi' placeholder='nilai_investasi'>
              </div><input type='submit' name='insert' value='Save' class='btn btn-sm btn-primary'>
          </form>
          </div>
        </div>
   

