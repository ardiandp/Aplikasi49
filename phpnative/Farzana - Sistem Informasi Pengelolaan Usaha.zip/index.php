<?php require_once 'config/conn.php';?>
<?php include 'layouts/header.php'; ?>
<?php include 'layouts/navbar.php'; ?>
<?php include 'layouts/footer.php'; ?>