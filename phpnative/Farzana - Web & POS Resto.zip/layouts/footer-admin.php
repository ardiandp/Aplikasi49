<!-- footer -->
<!--**********************************
            Content body end
        ***********************************-->


<!--**********************************
            Footer start
        ***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright &copy; 2023</p>
    </div>
</div>
<!--**********************************
            Footer end
        ***********************************-->
</div>
<!--**********************************
        Main wrapper end
    ***********************************-->

<!--**********************************
        Scripts
    ***********************************-->
<script src="public/assets/plugins/common/common.min.js"></script>
<script src="public/assets/js/custom.min.js"></script>
<script src="public/assets/js/settings.js"></script>
<script src="public/assets/js/gleek.js"></script>
<script src="public/assets/js/styleSwitcher.js"></script>
<script src="public/assets/plugins/tables/js/jquery.dataTables.min.js"></script>
<script src="public/assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
<script src="public/assets/plugins/tables/js/datatable-init/datatable-basic.min.js"></script>
<script src="public/assets/plugins/summernote/dist/summernote.min.js"></script>
<script src="public/assets/plugins/summernote/dist/summernote-init.js"></script>

</body>

</html>