<li class="nav-item">
    <a href="index.php?hal=beli" class="nav-link">
        <i class="nav-icon fas fa-store"></i>
        <p>
            Pembelian
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-file"></i>
        <p>
            Laporan
        </p>
    </a>
</li>