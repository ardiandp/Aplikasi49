<?php

return [
    'name'          =>  'Apotek Ranap',
    'description'   =>  'Modul apotek rawat inap untuk mLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '2023',
    'icon'          =>  'shopping-cart',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
