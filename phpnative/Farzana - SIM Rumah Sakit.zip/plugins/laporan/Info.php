<?php

return [
    'name'          =>  'Laporan-Laporan',
    'description'   =>  'Data laporan-laporan mLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '2023',
    'icon'          =>  'bolt',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
