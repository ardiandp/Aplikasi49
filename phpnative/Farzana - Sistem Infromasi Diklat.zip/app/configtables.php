<?php
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'db_si_diklat',
    'host' => 'localhost'
);

$con = $sql_details;
