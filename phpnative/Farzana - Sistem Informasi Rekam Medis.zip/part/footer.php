<footer class="main-footer">
  <div class="footer-left">
    Copyright &copy; 2020 <div class="bullet"></div> Aplikasi Rekam Medis



  </div>
  <div class="footer-right">

  </div>
</footer>