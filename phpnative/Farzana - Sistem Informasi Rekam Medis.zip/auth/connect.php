<?php
	#urutane "localhost", "username mu", "password mu", "jeneng db mu"
	
	$conn = mysqli_connect("localhost", "root", "", "rekam_mediss");
?>