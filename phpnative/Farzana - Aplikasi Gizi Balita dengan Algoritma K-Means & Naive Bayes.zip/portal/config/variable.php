<?php 
$project_case = array(1=>'Build','Bug','Feature','Doc & Adm');
$tracking     = array(1=>'back log (queue)','analisa desain sistem','pengerjaan','testing','deploy','finish');
$priority     = array(1=>'low','normal','high','urgent');
?>