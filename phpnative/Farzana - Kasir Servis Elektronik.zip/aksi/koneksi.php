<?php 
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "Kasir-Servis-Elektronik";

	$conn = new mysqli($servername, $username, $password, $db);
?>