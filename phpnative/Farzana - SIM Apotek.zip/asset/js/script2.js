$('.nav-item').on('click',  function () {
	$('.nav-item').removeClass('active');
});