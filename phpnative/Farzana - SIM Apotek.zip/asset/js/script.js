// $('#clicksift').on('click',  function () {
// 	$('#data-shift').removeClass('sembunyikan');
// });