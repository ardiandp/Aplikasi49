<?php
include("adminheader.php");
include("sidenav.php");
include("koneksi.php");

?>
<style>
	.main {
		margin-top: 40px;
		margin-left: 120px;
		padding: 0px 10px;
	}
</style>
<?php
include_once('cekadmin.php');
?>

<div class="main">
	<center>
		<div class="container">
			<div class="content">
				<br>
				<div class="jumbotron">
					<h1>Selamat Datang </h1>

					<img src="img/jjj.png" style="width:200px">

					<h2>SIAP (Sistem Informasi Aspirasi dan Pengaduan) Kabupaten Aceh utara.</h2>

				</div>
			</div>
		</div>
	</center>
</div>