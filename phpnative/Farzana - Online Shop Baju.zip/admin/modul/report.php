 
<h2>Laporan</h2>
 <form class="form-inline" action="modul/cetaklaporan.php" method="POST" target="_blank">

      <div class="form-group">
    
          <input type="text" data-beatpicker="true" class="form-control" placeholder="tanggal awal" name="tgl1" >
      </div>
            <div class="form-group">
          
          <input type="text" data-beatpicker="true" class="form-control" placeholder="tanggal akhir" name="tgl2" >
                </div>
                 <div class="form-group">
      <input type="submit" class="btn  btn-primary" value="cetak">
</div>
    </form>