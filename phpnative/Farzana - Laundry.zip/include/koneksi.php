<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "loundry";

$conn = mysqli_connect($server, $username, $password, $database);

//mysqli_select_db($database) or die("Datebase tidak bisa dibuka");
?>
