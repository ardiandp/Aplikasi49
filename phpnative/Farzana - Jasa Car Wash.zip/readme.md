# Aplikasi Jasa Cucian Mobil
Aplikasi jasa cucian mobil berbasis web ini memiliki tampilan yang sederhana dan fitur yang mampu berfungsi dengan baik.

To access admin page, add url /admin. Example http://localhost/jasa/login

## Tampilan Aplikasi
![ss](images/ss1.png)
![ss](images/ss2.png)
![ss](images/ss3.png)
![ss](images/ss4.png)
![ss](images/ss5.png)

## Admin Account
|   Level   | Username | Password |
|:---------:|:--------:|---------:|
| Admin     |  admin   | admin    |
| Admin     |  rianto  | rianto   |

## Sistem Requirement
- Database MySQL
- XAMPP / PHP 5.6
