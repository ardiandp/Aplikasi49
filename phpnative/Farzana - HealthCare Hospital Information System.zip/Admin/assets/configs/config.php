<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="OHCMIS";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>
