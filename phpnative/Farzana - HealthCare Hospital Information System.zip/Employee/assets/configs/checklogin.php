<?php
function check_login()
{
if(strlen($_SESSION['em_id'])==0)
	{	
		$host = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra="employee_login.php";		
		$_SESSION["em_id"]="";
		header("Location: http://$host$uri/$extra");
	}
}
?>