$(document).ready(function () {
  $("#swdatatable").dataTable({
    iDisplayLength: 20,
    aLengthMenu: [
      [20, 30, 50, -1],
      [20, 30, 50, "All"],
    ],
  });

  function loading() {
    $(".loading").show();
    $(".loading").delay(1500).fadeOut(500);
  }

  /* ----------- Add ------------*/
  $(".add-lokasi").submit(function (e) {
    if (
      $("input[type=text]").val() == "" &&
      $("textarea.address").val() == ""
    ) {
      swal({
        title: "Oops!",
        text: "Harap bidang inputan tidak boleh ada yang kosong.!",
        icon: "error",
        timer: 1500,
      });
      return false;
      loading();
    } else {
      loading();
      e.preventDefault();
      $.ajax({
        url: "mod/lokasi/proses.php?action=add",
        type: "POST",
        data: new FormData(this),
        processData: false,
        contentType: false,
        cache: false,
        async: false,
        beforeSend: function () {
          loading();
        },
        success: function (data) {
          if (data == "success") {
            swal({
              title: "Berhasil!",
              text: "Data lokasi  berhasil disimpan.!",
              icon: "success",
              timer: 1500,
            });
            $("#modalAdd").modal("hide");
            setTimeout(function () {
              location.reload();
            }, 1500);
          } else {
            swal({ title: "Oops!", text: data, icon: "error", timer: 1500 });
          }
        },
        complete: function () {
          $(".loading").hide();
        },
      });
    }
  });

  /* -------------------- Edit ------------------- */
  $(".update-lokasi").submit(function (e) {
    if ($("#txtname").val() == "") {
      swal({
        title: "Oops!",
        text: "Harap bidang inputan tidak boleh ada yang kosong.!",
        icon: "error",
        timer: 1500,
      });
      loading();
      return false;
    } else {
      loading();
      e.preventDefault();
      $.ajax({
        url: "mod/lokasi/proses.php?action=update",
        type: "POST",
        data: new FormData(this),
        processData: false,
        contentType: false,
        cache: false,
        async: false,
        beforeSend: function () {
          loading();
        },
        success: function (data) {
          if (data == "success") {
            swal({
              title: "Berhasil!",
              text: "Data Lokasi berhasil disimpan.!",
              icon: "success",
              timer: 1500,
            });
            $("#modalEdit").modal("hide");
            setTimeout(function () {
              location.reload();
            }, 1500);
          } else {
            swal({ title: "Oops!", text: data, icon: "error", timer: 1500 });
          }
        },
        complete: function () {
          $(".loading").hide();
        },
      });
    }
  });

  /*------------ Delete -------------*/
  $(document).on("click", ".delete", function () {
    var id = $(this).attr("data-id");
    swal({
      text: "Anda yakin menghapus data ini?",
      icon: "warning",
      buttons: {
        cancel: true,
        confirm: true,
      },
      value: "delete",
    }).then((value) => {
      if (value) {
        loading();
        $.ajax({
          url: "mod/lokasi/proses.php?action=delete",
          type: "POST",
          data: { id: id },
          success: function (data) {
            if (data == "success") {
              swal({
                title: "Berhasil!",
                text: "Data berhasil dihapus.!",
                icon: "success",
                timer: 1500,
              });
              setTimeout(function () {
                location.reload();
              }, 1500);
            } else {
              swal({ title: "Gagal!", text: data, icon: "error", timer: 1500 });
            }
          },
        });
      } else {
        return false;
      }
    });
  });

  $(".btn-print").on("click", function () {
    $("#printarea").show();
    window.print();
  });
});

$(document).on('click', '.btn-modal', function(){
    console.log('oke')
    $('#modal-location').modal();
    var latitude  = $(this).attr("data-latitude");
    var longitude = $(this).attr("data-longitude");
    var name = $(this).attr("data-kantor");
    $(".modal-title-name").html(name);
    document.getElementById("iframe-map").innerHTML ='<iframe src="mod/lokasi/map.php?latitude='+latitude+'&longitude='+longitude+'&name='+name+'" frameborder="0" width="100%" height="400px" marginwidth="0" marginheight="0" scrolling="no">';
});