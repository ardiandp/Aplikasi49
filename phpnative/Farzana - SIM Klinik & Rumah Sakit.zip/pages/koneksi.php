<?php
$host       =   "localhost";
$user       =   "root";
$password   =   "";
$database   =   "penjualan_obat";
$conn = mysqli_connect($host, $user, $password, $database);

// query SQL untuk insert data
?>
