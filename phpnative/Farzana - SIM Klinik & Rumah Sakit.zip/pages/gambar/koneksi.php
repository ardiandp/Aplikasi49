<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB1', 'aplika69_medical');
 
// Buat Koneksinya
$db1 = new mysqli(HOST, USER, PASS, DB1);
?>