<?php
$host       =   "localhost";
$user       =   "root";
$password   =   "";
$database   =   "aplika69_medical";
$conn = mysqli_connect($host, $user, $password, $database);

// query SQL untuk insert data
?>
