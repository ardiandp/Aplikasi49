<footer style="background-color: black;" class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 5.11
    </div>
    <strong>Copyright &copy; 2019 <a href="https://adminlte.io">Aditya Syaifuddin</a>.</strong> All rights
    reserved.
  </footer>
