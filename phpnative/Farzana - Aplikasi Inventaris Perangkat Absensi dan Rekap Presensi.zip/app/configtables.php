<?php
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'db_presensi',
    'host' => 'localhost'
);

$con = $sql_details;
