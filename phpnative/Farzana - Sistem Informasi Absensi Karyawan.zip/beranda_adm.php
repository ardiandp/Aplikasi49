<div class="container">
    <div class="row">
        <div class ="col-xs-12">

            <div class="alert alert-info">
                Selamat datang kembali <strong>Developer Razor</strong>
            </div>
        </div>
    </div>
    <div class="row">
        <!--colomn kedua-->
        <div class="col-sm-12 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><marquee scrolldelay="50" direction="left"  behavior="slide">Halaman Administrator Sistem Informasi Absensi Karyawan PT. Sintong Abadi</marquee></h3>
                </div>
                <div class="panel-body">
                     <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                       <thead>
                          <p align="center"><img src="img/sg.jpeg"></img></p>


                          <p class="label-title" align="center"><strong><font size="5">Absensi Karyawan PT. Sintong Abadi</font></strong></p>
                          <p class="col-sm-12 col-xs-12" align="center">
                            Selamat datang di halaman administrator Sistem Informasi Absensi <br>
                            Melalui halaman ini dapat dilakukan pengelolaan data <br>
                            Akses menu  Data pada bagian atas sistem untuk pengelolaan data absen.<br>
                            Akses menu User untuk mengelola informasi tentang user yang login.<br><br><br>

                          </p>

                         </thead


                    </table>
                </div>
            </div>
        </div>
</div>
