<div class="container">
    <div class="row">
        <div class="col-xs-12">
            Copyright &COPY; <?= date('Y')?> Developer Razor |
            <a href="#">Sistem</a>
			<a href="#">Informasi</a>
            <a href="#">Absensi</a>
        </div>
    </div>
</div>
