<?php
// mysqli_connect("hostname","user database","password","nama")
$koneksi= mysqli_connect("localhost","root","","abs_04") or die("Tidak bisa terhubungan ke database");


