<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> About</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <label class="col-sm-12 control-label"><center><strong><font size ="6">DAFTAR NAMA KELOMPOK</font></strong></center></label>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
							<thead>
							<tr>
								<td>No.</td>
								<td>Nama</td>
								<td>Nim</td>
								<td>Kelas</td>
								<td>No.Telp</td>
								<td>Alamat</td>
							
							</tr>
							
							<tr>
								<td>1</td>
								<td>Gading Amnesty</td>
								<td>18220689</td>
								<td>Source5</td>
								<td>082116482405</td>
								<td>Pulo Bandring</td>
				
							</tr>
							<tr>
								<td>2</td>
								<td>Hadi Sastra</td>
								<td>18220689</td>
								<td>Source5</td>
								<td>081234567890</td>
								<td>Tanah Rakyat</td>
							
							
							</tr>
							<tr>
								<td>3</td>
								<td>Muhammad Basirun</td>
								<td>18220547</td>
								<td>Source5</td>
								<td>081234567890</td>
								<td>Simpang Kawat</td>
							
							
							</tr>
							<tr>
								<td>4</td>
								<td>Teuku Reza Fahrio</td>
								<td>18220553</td>
								<td>Source5</td>
								<td>081234567890</td>
								<td>Sei Kamah 2</td>
							
							
							</tr>
							</thead>
                            
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
