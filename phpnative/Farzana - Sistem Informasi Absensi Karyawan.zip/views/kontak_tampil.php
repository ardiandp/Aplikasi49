<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> Kontak</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <label class="col-sm-12 control-label"><center><strong>Sistem Informasi Absensi Karyawan</strong></center></label>
                            <p align="center">
                              Jl. Duku, Kedai Ledang, Kec.Kisaran Tim.,<br>
                              Kabupaten Asahan, Sumatera Utara, Kode Pos : 21222
                            </p>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            Telp. 082251219646<br>
                            Email : sintongabadi@webmail.com<br>
                            Fax : 12345676<br>
                            Website : sintongabadi.go.id<br>
                            <br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
