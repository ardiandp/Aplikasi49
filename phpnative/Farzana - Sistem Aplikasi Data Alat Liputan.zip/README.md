# sikadal
Sistem Aplikasi Data Alat Liputan
by IRVAN RAMADHAN

Login menggunakan user admin :
Username : admin
Password : 12345678
