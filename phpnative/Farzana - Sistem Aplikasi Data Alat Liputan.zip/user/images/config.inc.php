<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "tester";
$mysqli = new mysqli($host,$username,$password, $db) or die('koneksi error');

?>