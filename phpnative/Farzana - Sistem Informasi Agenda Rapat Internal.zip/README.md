# SIARIN
SISTEM INFORMASI AGENDA RAPAT INTERNAL (SIARIN) Berbasis Web Dengan Menggunakan Bahasa Pemrograman PHP.
# AKUN PENGGUNA
Karena Memiliki Login Multi User, Maka Ada 2 Aktor (Pengguna) yang terlibat didalam aplikasi, Admin(Sekertaris) dan User(Seluruh Pegawai)
1. Admin (Sekertaris)

   -Username : admin
   
   -Password : admin
   
2. User (Pegawai)

   Username : titon
   
   Password : titon
   
#PENJELASAN HAK AKSES MASING-MASING PENGGUNA
1. Admin

   - Mengelola Data User
   - Mengelola Agenda Rapat
   - Mengelola Notulen Rapat
   - Mengelola Absensi Rapat
   - Mengelola Peserta
   - Mengelola Ruangan
 
2. User
  
   - Melihat Agenda Rapat
   - Melihat Notulen Rapat
   - Melihat Absensi Rapat
   - Melihat Peserta
   - Melihat Ruangan
   
 #CARA INSTALASI DAN MENJALANKANNYA
 1. Exstrak Filenya
 2. Pindahkan file agendarapat ke folder xampp/htdocs/agendarapat
 3. Jalankan Xampp
 4. Buka di Browser dan ketik, localhost/agendarapat
 
 //SELAMAT MENCOBA//
