<?php
$con = mysql_connect("localhost","root","", "surat") or die (mysql_error());
mysql_select_db("surat",$con) or die (mysql_error());
?>

