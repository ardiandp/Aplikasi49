<script type="text/html" id="form-calon">
	<form action="surat-nikah.php" method="post"></form>	
		<div class="form-group">
			<label>Nama Calon Suami :</label>
			<input name="namaCalonSuami" type="text" class="form-control" placeholder="Namasuami ..">
		</div>
		<div class="form-group" name="namaCalonIstri">
			<label>Nama Calon Istri  :</label>
			<input name="namaCalonIstri" type="text" class="form-control" placeholder="Namaistri ..">
		</div>
		<div class="form-group" name="hariTanggalJam">
			<label>Hari/Tanggal/Jam  :</label>
			<input name="hariTanggalJam" type="text" class="form-control" placeholder="Waktu..">
		</div>
		<div class="form-group" name="tempatAkad">
			<label>Tempat Akad  :</label>
			<input name="tempatAkad" type="text" class="form-control" placeholder="Tempat ..">
		</div>
		<div class="form-group" name="tanggal">
			<label>Tanggal :</label>
			<input name="tanggal" type="date" class="form-control" placeholder="Tanggal Nikah">
		</div>
</script>