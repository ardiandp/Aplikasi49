
<script type="text/html" id="form-suami-tak-terdaftar">
<form action="persetujuan-nikah.php" method="post"></form>
	<div class="form-group">
		<label>Nama  :</label>
		<input name="namaSuami" type="text" class="form-control" placeholder="Nama ..">
	</div>
	<div class="form-group">
		<label>Bin  :</label>
		<input name="binSuami" type="text" class="form-control" placeholder="BIN ..">
	</div>
	<div class="form-group">
		<label>Tempat dan Tanggal Lahir  :</label>
		<input name="ttlSuami" type="text" class="form-control" placeholder="TTL ..">
	</div>
	<div class="form-group">
		<label>Warganegara  :</label>
		<input name="wrgSuamitakterdaftar" type="text" class="form-control" placeholder="Warganegara ..">
	</div>
	<div class="form-group">
		<label>NIK  :</label>
		<input name="nikSuamitakterdaftar" type="number" class="form-control" placeholder="NIK ..">
	</div>
	<div class="form-group">
		<label>Agama  :</label>
		<input name="agamaSuamitakterdaftar" type="text" class="form-control" placeholder="Agama ..">
	</div>
	<div class="form-group">
		<label>Pekerjaan  :</label>
		<input name="pekerjaanSuami" type="text" class="form-control" placeholder="Pekerjaan ..">
	</div>
	<div class="form-group">
		<label>Tempat Tinggal :</label>
		<input name="alamatSuami" type="text" class="form-control" placeholder="Tempat Tinggal ..">
	</div>
</script>