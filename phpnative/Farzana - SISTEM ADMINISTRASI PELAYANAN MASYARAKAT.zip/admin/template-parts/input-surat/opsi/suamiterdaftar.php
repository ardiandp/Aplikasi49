
<script type="text/html" id="form-suami-terdaftar">
	<div class="form-group">
		<label>NIK  :</label>
		<input name="nikSuamiterdaftar" type="number" class="form-control" placeholder="NIK ..">
	</div>
	<div class="form-group">
		<label>Agama  :</label>
		<input name="agamaSuamiterdaftar" type="text" class="form-control" placeholder="Agama ..">
	</div>
	<div class="form-group">
		<label>Warganegara :</label>
		<input name="wrgSuamiterdaftar" type="text" class="form-control" placeholder="Warganegara ..">
	</div>
</script>