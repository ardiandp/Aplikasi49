
<script type="text/html" id="form-istri-tak-terdaftar">
<form action="persetujuan-nikah.php" method="post"></form>

	<div class="form-group">
		<label>Nama  :</label>
		<input name="namaIstri" type="text" class="form-control" placeholder="Nama ..">
	</div>
	<div class="form-group">
		<label>Bin  :</label>
		<input name="binIstri" type="text" class="form-control" placeholder="BIN ..">
	</div>
	<div class="form-group">
		<label>Tempat dan Tanggal Lahir  :</label>
		<input name="ttlIstri" type="text" class="form-control" placeholder="TTL ..">
	</div>
	<div class="form-group">
		<label>Warganegara  :</label>
		<input name="wrgIstritakterdaftar" type="text" class="form-control" placeholder="Warganegara ..">
	</div>
	<div class="form-group">
		<label>NIK  :</label>
		<input name="nikIstritakterdaftar" type="number" class="form-control" placeholder="NIK ..">
	</div>
	<div class="form-group">
		<label>Agama  :</label>
		<input name="agamaIstritakterdaftar" type="text" class="form-control" placeholder="Agama ..">
	</div>
	<div class="form-group">
		<label>Pekerjaan  :</label>
		<input name="pekerjaanIstri" type="text" class="form-control" placeholder="Pekerjaan ..">
	</div>
	<div class="form-group">
		<label>Tempat Tinggal :</label>
		<input name="alamatIstri" type="text" class="form-control" placeholder="Tempat Tinggal ..">
	</div>
</script>