<?php
session_start();
$_SESSION["namaPejabat"] = $_POST["namaPejabat"];

?>
