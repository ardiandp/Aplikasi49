<div>
    <h1>Ini Format surat kesehatan</h1>
    <p>Dengan Nomor : <?= $nomor ?></p>
    <p>Tanggal terima : <?= $tanggal ?></p>
    <p>Perihal : <?= $perihal ?></p>
</div>