<html>
<head>
<title>Undanagan orang tua</title>
</head>

<body>
<table align="center" border="0" cellpadding="1" style="width: 700px;"><tbody>
<tr>     <td colspan="3"><div align="center">
<span style="font-family: Verdana; font-size: x-small;"><b>SMK INFORMATIKA SUMEDANG

jln. Anggrek situ no.19 telp.(0261) 202767</b></span>
<hr />
</div>
</td>   </tr>
<tr>     <td colspan="2"><table border="0" cellpadding="1" style="width: 400px;"><tbody>
<tr>         <td width="93"><span style="font-size: x-small;">No</span></td>         <td width="8"><span style="font-size: x-small;">:</span></td>         <td width="200"><span style="font-size: x-small;">005/ smk-if/ yps/ IV/ 2011</span></td>       </tr>
<tr>         <td><span style="font-size: x-small;">Lampiran</span></td>         <td><span style="font-size: x-small;">:</span></td>         <td><span style="font-size: x-small;">-</span></td>       </tr>
<tr>         <td><span style="font-size: x-small;">Perihal</span></td>         <td><span style="font-size: x-small;">:</span></td>         <td><span style="font-size: x-small;">Rapat orangtua siswa</span></td>       </tr>
</tbody></table>
</td>     <td valign="top"><div align="right">
<span style="font-size: x-small;">Sumedang, 03 mei 2011</span></div>
</td>   </tr>
<tr>     <td width="302"></td>     <td width="343"></td>     <td width="339"></td>   </tr>
<tr>     <td><table border="0" style="width: 239px;"><tbody>
<tr>         <td width="74"><span style="font-size: x-small;">kepada yth</span></td>         <td width="11">
</td>         <td width="140"></td>       </tr>
<tr>         <td><span style="font-size: x-small;">orangtua/wali siswa</span></td>         <td></td>         <td>
</td>       </tr>
<tr>         <td><span style="font-size: x-small;">di</span></td>         <td></td>         <td>
</td>       </tr>
<tr>         <td><span style="font-size: x-small;">tempat</span></td>         <td></td>         <td>
</td>       </tr>
</tbody></table>
</td>     <td></td>     <td></td>   </tr>
<tr>     <td></td>     <td></td>     <td></td>   </tr>
<tr>     <td colspan="3" height="270" valign="top"><div align="justify">
<pre><span style="font-size: x-small;">Dengan hormat,
Sehubungan akan diadakannya Praktek kerja industri (Prakerin) siswa kelas XI maka kami selaku pihak sekolah akan membicarakan mengenai
pelaksanaan prakerin yang akan dilaksanakan pada :</span></pre>
<table border="0" style="width: 352px;"><tbody>
<tr>           <td width="80"><span style="font-size: x-small;">hari/tanggal</span></td>           <td width="10"><span style="font-size: x-small;">:</span></td>           <td width="248"><span style="font-size: x-small;">Rabu, 11 mei 2011</span></td>         </tr>
<tr>           <td><span style="font-size: x-small;">waktu</span></td>           <td><span style="font-size: x-small;">:</span></td>           <td><span style="font-size: x-small;">08.00 - selesai</span></td>         </tr>
<tr>           <td><span style="font-size: x-small;">tempat</span></td>           <td><span style="font-size: x-small;">:</span></td>           <td><span style="font-size: x-small;">Aula SMK Informatika Sumedang </span></td>         </tr>
</tbody></table>
<div align="justify">
<span style="font-size: x-small;">

Demikian surat ini kami sampaikan, kami harap ibu/bapa dapat menghadiri rapat ini. sekian dan terima kasih.</span> </div>
</div>
<div align="center">
<span style="font-size: x-small;">Mengetahui</span></div>
</td>   </tr>
<tr>     <td><div align="center">
<span style="font-size: x-small;">Sekertaris,</span></div>
<div align="center">

</div>
<div align="center">
<span style="font-size: x-small;">Ai komala sari </span></div>
</td>     <td></td>     <td valign="top"><div align="center">
<span style="font-size: x-small;">Kepala Sekolah, </span></div>
<div align="center">

</div>
<div align="center">
<span style="font-size: x-small;">E.Sulyati Dra,M.pd.</span></div>
</td>   </tr>
</tbody></table></body>
</html>