<!-- NAVBAR -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="brand">
				<a href="index.php"><img src="../assets/ico/gkk.png" height="50" width="35" alt="Klorofil Logo" class="img-responsive logo"></a>
			</div>
			<div class="container-fluid">
				<div class="navbar-btn">
					<button type="button" class="btn-toggle-fullwidth"><i class="lnr lnr-arrow-left-circle"></i></button>
				</div>
				
				

				<div id="navbar-menu">
					<ul class="nav navbar-nav navbar-right">
					
 						
					

				 <li><a href="index.php"><i class="fa fa-home"></i> Beranda</a></li>
      			 <li><a href="javascript:;" class="" data-toggle="modal" data-target="#confirmModal"><i class="fa fa-sign-out"></i> <span>Keluar</span></li></a>
							</ul>
						</li>
						
					</ul>
				</div>
		
		</nav>
		<!-- END NAVBAR -->