<footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Sistem Informasi Pelayanan Kepegawaian 
                                            <b>Politeknik Negeri Ketapang</b></span>
                    </div>
                </div>
            </footer>