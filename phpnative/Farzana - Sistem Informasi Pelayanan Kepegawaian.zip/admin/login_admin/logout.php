<?php
session_start();
session_destroy();
?>
<script type="text/javascript">
	alert("Berhasil Keluar, Terimakasih atas Kunjungan Anda... :)");
	window.location = "../";
</script>