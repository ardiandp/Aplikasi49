# IT Help Desk System
This system provides IT company buildings to handle any computer or hardware based system problems; problems can be easily entered into the system, and one person will reach the problem to get it solved. 
