// UK lang variables

tinyMCE.addToLang('youtube',{
title : 'YouTube Film invoegen / bewerken',
desc : 'YouTube Film invoegen / bewerken',
file : 'YouTube URL link',
size : 'Afmetingen',
general : 'Algemeen'
});
