  <?php 
  // error_reporting(0);
  ?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml">
  
  <HEAD>
  
   <!-- Script Facebook -->
  <div id="fb-root"></div>
  <script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/id_ID/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script>
  <!-- Akhir Script Facebook -->
  
   <!-- Script Copyright -->
   <script type="text/javascript">
   if(document.location.protocol=='http:'){
   var Tynt=Tynt||[];Tynt.push('accswOR5Kr4yaUacwqm_6r');Tynt.i={"ap":"<br/><b>Sumber Berita: www.teraskreasi.com</b><hr>"};
   (function(){var s=document.createElement('script');s.async="async";s.type="text/javascript";s.src='http://tcr.tynt.com/ti.js'; 
   var h=document.getElementsByTagName('script')[0];h.parentNode.insertBefore(s,h);})();
   }
   </script>
   <!-- Akhir Script Copyright -->

  <title><?php include "teraskreasi_titel.php"; ?></title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow">
  <meta name="description" content="<?php include "teraskreasi1.php"; ?>">
  <meta name="keywords" content="<?php include "teraskreasi2.php"; ?>">
  <meta http-equiv="Copyright" content="Rizal Faizal" "rizal_fzl@yahoo.com">
  <meta name="author" content="Rizal Faizal" "http://teraskreasi.com">
  <meta http-equiv="imagetoolbar" content="no">
  <meta name="language" content="Betawi-Indonesia">
  <meta name="revisit-after" content="7">
  <meta name="webcrawlers" content="all">
  <meta name="rating" content="general">
  <meta name="spiders" content="all">

  <link rel="shortcut icon" href="favicon.png" />
  <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="rss.xml" />

 
  <!-- Bagian Stylesheets -->
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/main-stylesheet.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/jquery.fancybox.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/shortcodes.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/ddsmoothmenu.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/style_slider.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/infinitecarousel.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/ticker.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/paging.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/tags.css" ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo "$f[folder]/css/jquery.ad-gallery.css" ?>" type="text/css" />
  
  <!-- Bagian JavaScripts -->
  <script type="text/javascript" src="<?php echo "$f[folder]/js/flowplayer-3.2.4.min.js" ?>"></script>
  <script src="<?php echo "$f[folder]/js/jquery.min.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/jquery.placeholder.min.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/cufon-yui.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/cufon-replace.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/font.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/jquery.fancybox.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/text-scroller.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/scripts.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/ticker.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/newsticker.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js/tags.js" ?>" type="text/javascript"></script>

  <script type="text/javascript">
  $(document).ready(function(){
  $(function () {
  $(window).scroll(function () { });
  $('.back-to-top a').click(function () {
  $('body,html').animate({
  scrollTop: 0
  }, 800);
  return false;
  });
  });
  });
  </script>
  
  
  
  <script src="<?php echo "$f[folder]/js3/ddsmoothmenu.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js3/menu.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js2/jquery.easing.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js2/script.js" ?>" type="text/javascript"></script>
  <script src="<?php echo "$f[folder]/js4/infinitecarousel.js" ?>" type="text/javascript"></script>


  
  <script type="text/javascript">
  $(document).ready( function(){	
  $('#lofslidecontent45').lofJSidernews( { interval:5000,
  easing:'easeInOutElastic',
  duration:3500,
  auto:true } );						
  });
  </script>
		
		
  <script src="<?php echo "$f[folder]/js/easy.js" ?>" type="text/javascript"></script>
  <script type="text/javascript">
  $(document).ready(function(){		
  $.easy.tooltip();	
  });</script>
		
		
 
	<script type="text/javascript">
		$(document).ready(function() {

			$("a#example1").fancybox();

			$("a#example2").fancybox({
				'overlayShow'	: false,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'elastic'
			});

			$("a#example3").fancybox({
				'transitionIn'	: 'none',
				'transitionOut'	: 'none'	
			});

			$("a#example4").fancybox({
				'opacity'		: true,
				'overlayShow'	: false,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'none'
			});

			$("a#example5").fancybox();

			$("a#example6").fancybox({
				'titlePosition'		: 'outside',
				'overlayColor'		: '#000',
				'overlayOpacity'	: 0.9
			});

			$("a#example7").fancybox({
				'titlePosition'	: 'inside'
			});

			$("a#example8").fancybox({
				'titlePosition'	: 'over'
			});

			$("a[rel=example_group]").fancybox({
				'transitionIn'		: 'none',
				'transitionOut'		: 'none',
				'titlePosition' 	: 'over',
				'titleFormat'		: function(title, currentArray, currentIndex, currentOpts) {
					return '<span id="fancybox-title-over"><span class style=\"color:#008C43;\">foto ' + (currentIndex + 1) + ' / ' + currentArray.length + (title.length ? ' &nbsp;</span> ' + title : '') + '</span>';
				}
			});

			/*
			*   Examples - various
			*/

			$("#various1").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});

			$("#various2").fancybox();

			$("#various3").fancybox({
				'width'				: '75%',
				'height'			: '75%',
				'autoScale'			: false,
				'transitionIn'		: 'none',
				'transitionOut'		: 'none',
				'type'				: 'iframe'
			});

			$("#various4").fancybox({
				'padding'			: 0,
				'autoScale'			: false,
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
		});
	</script>
		


		
  <script src="<?php echo "$f[folder]/js5/libs/modernizr-2.0.6.min.js" ?>" type="text/javascript"></script>
  <script>window.jQuery || document.write('<script src="js5/libs/jquery-1.6.2.min.js"><\/script>')</script>
  <script src="<?php echo "$f[folder]/js5/jquery.cycle.all.latest.js" ?>" type="text/javascript"></script>
  <script type="text/javascript">
  $('#test-widget ul').cycle({ fx: 'scrollUp', speed: 800, timeout: 5000, next: '#next_test', prev: '#prev_test',
  cleartype: true, cleartypeNoBg: true });</script>
		
  <script src="<?php echo "$f[folder]/js6/jquery.ad-gallery.js?rand=995" ?>" type="text/javascript"></script>
  
  <script type="text/javascript">
  $(function() {
    $('img.image1').data('ad-desc', 'Whoa! This description is set through elm.data("ad-desc") instead of using the longdesc attribute.<br>And it contains <strong>H</strong>ow <strong>T</strong>o <strong>M</strong>eet <strong>L</strong>adies... <em>What?</em> That aint what HTML stands for? Man...');
    $('img.image1').data('ad-title', 'Title through $.data');
    $('img.image4').data('ad-desc', 'This image is wider than the wrapper, so it has been scaled down');
    $('img.image5').data('ad-desc', 'This image is higher than the wrapper, so it has been scaled down');
    var galleries = $('.ad-gallery').adGallery();
    $('#switch-effect').change(
      function() {
        galleries[0].settings.effect = $(this).val();
        return false;
      }
    );
    $('#toggle-slideshow').click(
      function() {
        galleries[0].slideshow.toggle();
        return false;
      }
    );
  });
  </script>
	
		
  <meta charset="UTF-8">
  
  <style type="text/css">
  .style2 {
  color: #008C43;
  font-weight: bold;}
  </style>
  
  </head>
  
  <!--========= BACKGROUND================================-->
  <?php
  $r=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM background"));
  echo "<body style='background: url(img_background/$r[gambar]) top center repeat-y;'>";
  ?>
  <!--========= AKHIR BACKGROUND================================-->
  
  <body class="top">
  
  <div class="main-content-wrapper">
  <div class="main-content">


  <!------------------------ ATAS ------------------------------>
  
  <div class="main-header">
	
  <!---------------------------- LOGO ---------------------------------->			
  <div class="logo"><?php
  $logo=mysqli_query($conn,"SELECT * FROM logo ORDER BY id_logo DESC LIMIT 1");
  $iden=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM identitas"));
  while($b=mysqli_fetch_array($logo)){
  echo "<a href='$iden[url]'><img height=59 src='logo/$b[gambar]'/></a>";}
  ?></div>
  <!------------------------- AKHIR LOGO --------------------------------->	

 <!------------------------- SEARCH --------------------------------->	 				
  <div class="iklanatas">
  <?php
  $iklantengah=mysqli_query($conn,"SELECT * FROM iklantengah  WHERE id_iklantengah ='31' ORDER BY id_iklantengah DESC LIMIT 1");
  while($b=mysqli_fetch_array($iklantengah)){
  echo "<div class='iklantengah'>
  <a href='$b[url]' title='$b[judul]'>
  <img src='foto_iklantengah/$b[gambar]' border=0 width=450 height=70></a>
  </div>";}?>
  </div>
   <!------------------------- AKHIR SEARCH --------------------------------->	 				
			
  </div>
  <!------------------------ AKHIR ATAS ------------------------------>
  


  <!------------------------ MENU ------------------------------>
  <div class="navigation">
  <div id="smoothmenu1" class="ddsmoothmenu">
  <ul>
  <?php
  function get_menu($data, $parent = 0) {
  static $i = 1;
  $tab = str_repeat(" ", $i);
  $data[$parent] = isset($data[$parent]) ? $data[$parent]:'';
  if ($data[$parent]) {
  $html = "$tab<li>";
  $i++;
  foreach ($data[$parent] as $v) {
  $child = get_menu($data, $v->id_menu);
  $html .= "$tab<li class='last'>";
  $css = isset($css) ? $css:'';
  $html .= '<a class="'.$css.'" href="'.$v->link.'">'.$v->nama_menu.'</a>';
  if ($child) {
  $i--;
  $html .= "<ul>$child";
  $html .= "$tab</ul>";}
  $html .= '</li>';}
  $html .= "$tab</li>";
  return $html;}
  else {
  return false;}}
  
  $result = mysqli_query($conn,"SELECT * FROM menu WHERE aktif='Ya' ORDER BY id_menu");
  while ($row = mysqli_fetch_object($result)) {
  $data[$row->id_parent][] = $row; }
  $menu = get_menu($data);
  echo "$menu";
  ?>
  </ul>
  </div></div>
  <!------------------------ AKHIR MENU ------------------------------>		
  
  
  <!------------------------ NEWS UPDATE ------------------------------>	
  <div class="breaking-wrapper">  
  <p><b>NEWS UPDATE</b></p><div class='horizontal-scroller'><div id='scrollingtext'>
  <?php
  $terkini=mysqli_query($conn,"SELECT * FROM berita ORDER BY id_berita  DESC LIMIT 10");
  while($p=mysqli_fetch_array($terkini)){
  $baca = $p['dibaca']+1;
  $isi_berita = strip_tags($p['isi_berita']); 
  $isi = substr($isi_berita,0,100); 
  $isi = substr($isi_berita,0,strrpos($isi," ")); 
  $tgl = tgl_indo($p['tanggal']);
  
  echo " 
  <img src='$f[folder]/images/ico-list-bullet-1.png' width='7' height='6'/>
  <a href=berita-$p[judul_seo].html>$p[judul]</a>";}
  ?>
  </div>
  </div> 
  <span class="search">
 <form method="POST" action="hasil-pencarian.html">
  <input name="kata" type="text" class="input-text" placeholder="pencarian berita" />
  <input type="submit" class="input-submit" value="" />
  </form></span> 
  </div>
  <!------------------------ AKHIR NEWS UPDATE ------------------------------>	

  <!--------- KONTEN ------------>	
  <?php
  include "$f[folder]/isi.php";      
  ?>
  <!--------- AKHIR KONTEN -------->	
 
  <div class="mascot-euro">
  <div class="mascot">
 <?php
  $logo=mysqli_query($conn,"SELECT * FROM logo ORDER BY id_logo DESC LIMIT 1");
  $iden=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM identitas"));
  while($b=mysqli_fetch_array($logo)){
  echo "<a href='$iden[url]'><img height=24 width=120 src='logo/$b[gambar]'/></a>";}
  ?>
  </div>
 
 
  <!----------- BAGIAN BAWAH ------------------------>
  <div class="main-footer">

  <!----------- COPYRIGHT ------------------------>
  <div class="copyright">
  <div class="back-to-top"><a href="#top"><span class='tooltip' title='ke atas'>&nbsp;&nbsp;</span></a></div>
 
  Copyright © <?php $tahun=date("Y"); echo "$tahun. "; include "nama_web.php"; ?>. Developed by <?php include "nama_pemilik.php";?>
  </div> 
  
  
  <div class="social">
  <a href="hal-tentang-kami.html">
  Tentang Kami</a> <span class style=\"color:#EA1C1C;\">|</span>
  
  <a href="hubungi-kami.html">
  Hubungi Redaksi</a> <span class style=\"color:#EA1C1C;\">|</span>
    
  <a href="rss.xml" target="_blank" class="rss">RSS Feeds</a></div>
  
  <?php
  // Statistik user
  $ip      = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP komputer user
  $tanggal = date("Ymd"); // Mendapatkan tanggal sekarang
  $waktu   = time(); // 

  // Mencek berdasarkan IPnya, apakah user sudah pernah mengakses hari ini 
  $s = mysqli_query($conn,"SELECT * FROM statistik WHERE ip='$ip' AND tanggal='$tanggal'");
  // Kalau belum ada, simpan data user tersebut ke database
  if(mysqli_num_rows($s) == 0){
    mysqli_query($conn,"INSERT INTO statistik(ip, tanggal, hits, online) VALUES('$ip','$tanggal','1','$waktu')");
  } 
  else{
    mysqli_query($conn,"UPDATE statistik SET hits=hits+1, online='$waktu' WHERE ip='$ip' AND tanggal='$tanggal'");
  }

  $pengunjung       = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM statistik WHERE tanggal='$tanggal' GROUP BY ip"));
  $totalpengunjung  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(hits) as hits FROM statistik"))['hits']; 
  $hits             = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(hits) as hitstoday FROM statistik WHERE tanggal='$tanggal' GROUP BY tanggal")); 
  $totalhits        = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(hits) as hits FROM statistik"))['hits']; 
  $tothitsgbr       = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(hits) as hits FROM statistik"))['hits']; 
  $bataswaktu       = time() - 300;
  $pengunjungonline = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM statistik WHERE online > '$bataswaktu'"));

  $path = "counter/";
  $ext = ".png";

  $tothitsgbr = sprintf("%06d", $tothitsgbr);
  for ( $i = 0; $i <= 9; $i++ ){
	   $tothitsgbr = str_replace($i, "<img src='$path$i$ext' alt='$i'>", $tothitsgbr);
  }

  echo "
  <li><class='user'>Online: <span class style=\"color:#008C43;\">$pengunjungonline </span>
  <class='hits'>Hits: <span class style=\"color:#008C43;\">$hits[hitstoday]</span> / $totalhits </li>";
  ?>
  <!----------- AKHIR COPYRIGHT  ------------------------>


  <!----------- AKHIR BAGIAN BAWAH ------------------------>
		
  </div>
  </div>
  </div>
  </body>
  </html>
  
  
  <?php 
  $iyasrini = isset($iyasrini) ? $iyasrini:'';
  if ($iyasrini==2){
  ?>

  <script>
  flowplayer("player", "<?php echo "$f[folder]/flash/flowplayer-3.2.5.swf" ?>", {
  clip:  {
  autoPlay: false,
  autoBuffering: true,},

  onLoad: function() {	// called when player has finished loading
  this.setVolume(35);	// set volume property
  }
  });
  </script>

  <?php
  }
  elseif ($iyasrini==1){
  ?>

  <script>
  function showRelatedList(gdata, container) {
  var relatedVideos = gdata.relatedVideos;
  var content = '<em>Related Videos:</em>';
  content += '<a class="go up"></a><div class="playlist"><div class="clips low">';    

  jQuery.each( relatedVideos, function(index, item){
  content += '<a href="'+ item.url +'" '+ (index==0 ? 'class="first"' : "") +'>';
  content += item.title + "<br/>";
  content += "<em>" + Math.round(item.duration / 60) + " min</em></a>";});    

  content += '</div></div><a class="go down"></a>';
  $(container).html(content);
  $("div.playlist").scrollable({
  items:'div.clips',
  vertical:true,
  next:'a.down',
  prev:'a.up'
  });}

  $f("youtube", "<?php echo "$f[folder]/flash/flowplayer-3.2.5.swf" ?>", {
  plugins:  {
  youtube: {
  url:'flowplayer.youtube-3.2.1.swf',
  enableGdata: true,            

  onApiData: function(gdata) {
  console.log(gdata);               

  showRelatedList(gdata, "#playlistContainer");
  }}},
	
  onLoad: function() {	
  this.setVolume(35); },

  clip: {
  autoPlay: false,
  autoBuffering: true,
  provider: 'youtube',
  urlResolvers: 'youtube'}

  }).playlist("div.clips");
  </script>

  <?php 
  } 
  ?>
  
  <!--========= Copyright © 2012. Developed by: Rizal Faizal  ========================-->	