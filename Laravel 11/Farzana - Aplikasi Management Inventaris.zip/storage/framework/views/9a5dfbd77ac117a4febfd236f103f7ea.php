<div>
<link
      rel="stylesheet"
      href="<?php echo e(asset('theme/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>"
    />
    <link
      rel="stylesheet"
      href="<?php echo e(asset('theme/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>"
    />
    <link
      rel="stylesheet"
      href="<?php echo e(asset('theme/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>"
    />
</div><?php /**PATH C:\Users\USER\Downloads\Compressed\Aplikasi-Management-Inventaris-main\resources\views/components/head-datatable.blade.php ENDPATH**/ ?>