<!-- <footer class="main-footer">
    <strong>Copyright &copy; 2024 <a href="https://github.com/ryugenxd">ryugenxd</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>{{config('app.name')}} Version</b> 0.1
    </div>
  </footer> -->