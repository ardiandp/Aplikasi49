## Aplikasi Management Inventaris LARAVEL 11

## setup 
- change database configuration in file `.env`
- `` composer update``
- ``php artisan migrate --seed``
- ``php artisan serve``
- open url http://localhost:8000 in your browser


👾 bug : in chart transaction 😴

- Full Ajax
- Datatable Server Side
- 3 role : super_admin,admin,andstaff
- Support print report document,export to PDF and Excel
- management customer
- management employee
- management supplier
- management transaction GootOut  and GoodIn
  
