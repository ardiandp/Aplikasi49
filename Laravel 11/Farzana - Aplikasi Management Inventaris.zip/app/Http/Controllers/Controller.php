<?php

namespace App\Http\Controllers;

abstract class Controller
{ 
    public function IDRToInteger():int
    {
        return 1;
    }

}
