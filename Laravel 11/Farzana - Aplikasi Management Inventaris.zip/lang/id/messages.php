<?php

return [
  "login" => "Masuk",
  "logout" => "Keluar",
  "oops" => "Opps !",
  "redirect-to" => "Anda akan di arahkan ke :dest",
  "server-error" => "Mohon maaf server sedang gangguan, coba lagi nanti.",
  "more-info" => "Selengkapnya.",
  "export-to" => "cetak ke :file.",
  "setting-label" => "pengaturan :name",
];