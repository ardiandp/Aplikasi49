<?php

return [
  "login" => "Login",
  "logout" => "Logout",
  "oops" => "Opps !",
  "redirect-to" => "you will be redirected to :dest",
  "server-error" => "server error, please try again later.",
  "more-info" => "More info.",
  "export-to" => "export to :file.",
  "setting-label" => ":name setting",
];