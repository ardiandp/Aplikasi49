<div class="loading-bar" wire:loading></div>
