<div>
	<?php if (isset($component)) { $__componentOriginal84bc13f46ede078ae58666238de3da00 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84bc13f46ede078ae58666238de3da00 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84bc13f46ede078ae58666238de3da00)): ?>
<?php $attributes = $__attributesOriginal84bc13f46ede078ae58666238de3da00; ?>
<?php unset($__attributesOriginal84bc13f46ede078ae58666238de3da00); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84bc13f46ede078ae58666238de3da00)): ?>
<?php $component = $__componentOriginal84bc13f46ede078ae58666238de3da00; ?>
<?php unset($__componentOriginal84bc13f46ede078ae58666238de3da00); ?>
<?php endif; ?>
	<div class="content-container mt-4">
		<h5 class="mb-3">Laporan</h5>
		<div class="row">
			<div class="col-4">
				<button class="btn btn-success w-100 mb-2" wire:click='pilihLaporan("stok")'>Laporan Stok Barang</button>
				<button class="btn btn-warning w-100 mb-2" wire:click='pilihLaporan("barangmasuk")'>Laporan Barang Masuk</button>
				<button class="btn btn-primary w-100 mb-2" wire:click='pilihLaporan("barangkeluar")'>Laporan Barang Keluar</button>
				<button class="btn btn-pink w-100 mb-2" wire:click='pilihLaporan("penjualan")'>Laporan Penjualan</button>
				<button class="btn btn-danger w-100 mb-2" wire:click='pilihLaporan("pembelian")'>Laporan Pembelian</button>
			</div>
			<hr />
			<div class="row">
				<div class="col-12">
					<!--[if BLOCK]><![endif]--><?php if($pilihanLaporan == 'stok'): ?>
						<h2>Laporan Stok Barang</h2>
						<div class="d-flex justify-content-between mb-3">

							<div class="d-flex">
								<select class="form-control" wire:model.live='bulan'>
									<option value="0">Semua Bulan</option>
									<option value="1">Januari</option>
									<option value="2">Februari</option>
									<option value="3">Maret</option>
									<option value="4">April</option>
									<option value="5">Mei</option>
									<option value="6">Juni</option>
									<option value="7">Juli</option>
									<option value="8">Agustus</option>
									<option value="9">September</option>
									<option value="10">Oktober</option>
									<option value="11">November</option>
									<option value="12">Desember</option>
								</select>

							</div>

							<a class="btn btn-success" href="<?php echo e(url('/cetak/stok')); ?>" target="_blank">PDF</a>

						</div>
						<table class="table-striped table-bordered table">
							<thead class="thead-light">
								<tr>
									<th>No.</th>
									<th>Nama Barang</th>
									<th>Jumlah</th>
									<th>Ukuran</th>
									<th>Foto Nota</th>
									<th>Tanggal Penjualan</th>

								</tr>
							</thead>
							<tbody>
								<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $semuabarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($barang->nama); ?></td>
										<td><?php echo e($barang->jumlah); ?></td>
										<td><?php echo e($barang->ukuran); ?></td>
										<td>
											<img class="img-fluid" src="<?php echo e(asset('/storage/gambarbarang/' . $barang->foto)); ?>"
												alt="<?php echo e($barang->nama_barang); ?>" style="max-width: 100px">
										</td>
										<td><?php echo e($barang->tanggal_masuk); ?></td>

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
							</tbody>
						</table>
					<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
					<!--[if BLOCK]><![endif]--><?php if($pilihanLaporan == 'barangmasuk'): ?>
						<h2>Laporan Barang Masuk</h2>
						<div class="d-flex justify-content-between mb-3">
							<div class="d-flex">
								<select class="form-control" wire:model.live='bulan'>
									<option value="0">Semua Bulan</option>
									<option value="1">Januari</option>
									<option value="2">Februari</option>
									<option value="3">Maret</option>
									<option value="4">April</option>
									<option value="5">Mei</option>
									<option value="6">Juni</option>
									<option value="7">Juli</option>
									<option value="8">Agustus</option>
									<option value="9">September</option>
									<option value="10">Oktober</option>
									<option value="11">November</option>
									<option value="12">Desember</option>
								</select>

							</div>

							<a class="btn btn-success" href="<?php echo e(url('/cetak/barangmasuk')); ?>" target="_blank">PDF</a>

						</div>
						<table class="table-striped table-bordered table">
							<thead class="thead-light">
								<tr>
									<th>No.</th>
									<th>Nama Barang</th>
									<th>Jumlah</th>
									<th>Ukuran</th>
									<th>Foto Nota</th>
									<th>Tanggal Penjualan</th>

								</tr>
							</thead>
							<tbody>
								<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $semuabarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($barang->nama); ?></td>
										<td><?php echo e($barang->jumlah); ?></td>
										<td><?php echo e($barang->ukuran); ?></td>
										<td>
											<img class="img-fluid" src="<?php echo e(asset('/storage/gambarbarang/' . $barang->foto)); ?>"
												alt="<?php echo e($barang->nama_barang); ?>" style="max-width: 100px">
										</td>
										<td><?php echo e($barang->tanggal_masuk); ?></td>

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
							</tbody>
						</table>
					<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
					<!--[if BLOCK]><![endif]--><?php if($pilihanLaporan == 'barangkeluar'): ?>
						<h2>Laporan Barang Keluar</h2>
						<div class="d-flex justify-content-between mb-3">

							<div class="d-flex">
								<select class="form-control" wire:model.live='bulan'>
									<option value="0">Semua Bulan</option>
									<option value="1">Januari</option>
									<option value="2">Februari</option>
									<option value="3">Maret</option>
									<option value="4">April</option>
									<option value="5">Mei</option>
									<option value="6">Juni</option>
									<option value="7">Juli</option>
									<option value="8">Agustus</option>
									<option value="9">September</option>
									<option value="10">Oktober</option>
									<option value="11">November</option>
									<option value="12">Desember</option>
								</select>

							</div>

							<a class="btn btn-success" href="<?php echo e(url('/cetak/barangkeluar')); ?>" target="_blank">PDF</a>

						</div>
						<table class="table-striped table-bordered table">
							<thead class="thead-light">
								<tr>
									<th>No.</th>
									<th>Nama Barang</th>
									<th>Jumlah</th>
									<th>Ukuran</th>
									<th>Foto</th>
									<th>Tanggal Penjualan</th>

								</tr>
							</thead>
							<tbody>
								<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $semuakeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($barang->nama); ?></td>
										<td><?php echo e($barang->jumlah); ?></td>
										<td><?php echo e($barang->ukuran); ?></td>
										<td>
											<img class="img-fluid" src="<?php echo e(asset('/storage/gambarbarang/' . $barang->foto)); ?>"
												alt="<?php echo e($barang->nama_barang); ?>" style="max-width: 100px">
										</td>
										<td><?php echo e($barang->tanggal_masuk); ?></td>

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
							</tbody>
						</table>
					<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
					<!--[if BLOCK]><![endif]--><?php if($pilihanLaporan == 'penjualan'): ?>
						<h2>Laporan Penjualan</h2>
						<div class="d-flex justify-content-between mb-3">

							<div class="d-flex">
								<select class="form-control" wire:model.live='bulan'>
									<option value="0">Semua Bulan</option>
									<option value="1">Januari</option>
									<option value="2">Februari</option>
									<option value="3">Maret</option>
									<option value="4">April</option>
									<option value="5">Mei</option>
									<option value="6">Juni</option>
									<option value="7">Juli</option>
									<option value="8">Agustus</option>
									<option value="9">September</option>
									<option value="10">Oktober</option>
									<option value="11">November</option>
									<option value="12">Desember</option>
								</select>

							</div>
							<div class="d-flex">
								<a class="btn btn-pink" href="<?php echo e(url('/excel/penjualan')); ?>" target="_blank">excel</a>
								<a class="btn btn-success" href="<?php echo e(url('/cetak/penjualan')); ?>" target="_blank">PDF</a>"
							</div>

						</div>
						<table class="table-striped table-bordered table">
							<thead class="thead-light">
								<tr>
									<th>No.</th>
									<th>Nama Barang</th>
									<th>Jumlah</th>
									<th>Ukuran</th>
									<th>Foto Nota</th>
									<th>Tanggal Penjualan</th>
									<th>Harga</th>
								</tr>
							</thead>
							<tbody>
								<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $semuapenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($barang->nama); ?></td>
										<td><?php echo e($barang->jumlah); ?></td>
										<td><?php echo e($barang->ukuran); ?></td>
										<td>
											<img class="img-fluid" src="<?php echo e(asset('/storage/gambarbarang/' . $barang->foto)); ?>"
												alt="<?php echo e($barang->nama_barang); ?>" style="max-width: 100px">
										</td>
										<td><?php echo e($barang->tanggal_masuk); ?></td>
										<td><?php echo e($barang->harga); ?></td>

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
							</tbody>
						</table>
					<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
					<!--[if BLOCK]><![endif]--><?php if($pilihanLaporan == 'pembelian'): ?>
						<h2>Laporan Pembelian</h2>
						<div class="d-flex justify-content-between mb-3">

							<div class="d-flex">
								<select class="form-control" wire:model.live='bulan'>
									<option value="0">Semua Bulan</option>
									<option value="1">Januari</option>
									<option value="2">Februari</option>
									<option value="3">Maret</option>
									<option value="4">April</option>
									<option value="5">Mei</option>
									<option value="6">Juni</option>
									<option value="7">Juli</option>
									<option value="8">Agustus</option>
									<option value="9">September</option>
									<option value="10">Oktober</option>
									<option value="11">November</option>
									<option value="12">Desember</option>
								</select>

							</div>

							<div class="d-flex">
								<a class="btn btn-pink" href="<?php echo e(url('/excel/pembelian')); ?>" target="_blank">excel</a>
								<a class="btn btn-success" href="<?php echo e(url('/cetak/pembelian')); ?>" target="_blank">PDF</a>"
							</div>

						</div>
						<table class="table-striped table-bordered table">
							<thead class="thead-light">
								<tr>
									<th>No.</th>
									<th>Nama Barang</th>
									<th>Jumlah</th>
									<th>Ukuran</th>
									<th>Foto Nota</th>
									<th>Tanggal Penjualan</th>
									<th>Harga</th>
								</tr>
							</thead>
							<tbody>
								<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $semuapembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($barang->nama); ?></td>
										<td><?php echo e($barang->jumlah); ?></td>
										<td><?php echo e($barang->ukuran); ?></td>
										<td>
											<img class="img-fluid" src="<?php echo e(asset('/storage/gambarbarang/' . $barang->foto)); ?>"
												alt="<?php echo e($barang->nama_barang); ?>" style="max-width: 100px">
										</td>
										<td><?php echo e($barang->tanggal_masuk); ?></td>
										<td><?php echo e($barang->harga); ?></td>

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
							</tbody>
						</table>
					<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
				</div>
			</div>

		</div>

	</div>
</div>
<?php /**PATH C:\Users\USER\Downloads\Compressed\invenpt-main\resources\views/livewire/laporan.blade.php ENDPATH**/ ?>