<div class="loading-bar" wire:loading></div>
<?php /**PATH C:\Users\USER\Downloads\Compressed\invenpt-main\resources\views/components/loading.blade.php ENDPATH**/ ?>