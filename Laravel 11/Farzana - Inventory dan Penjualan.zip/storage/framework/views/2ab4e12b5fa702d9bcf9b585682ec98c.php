<div>
	<?php if (isset($component)) { $__componentOriginal84bc13f46ede078ae58666238de3da00 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84bc13f46ede078ae58666238de3da00 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84bc13f46ede078ae58666238de3da00)): ?>
<?php $attributes = $__attributesOriginal84bc13f46ede078ae58666238de3da00; ?>
<?php unset($__attributesOriginal84bc13f46ede078ae58666238de3da00); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84bc13f46ede078ae58666238de3da00)): ?>
<?php $component = $__componentOriginal84bc13f46ede078ae58666238de3da00; ?>
<?php unset($__componentOriginal84bc13f46ede078ae58666238de3da00); ?>
<?php endif; ?>
	<div class="table-container mt-4">
		<h5 class="mb-3">Transaksi Penjualan</h5>
		<div class="d-flex justify-content-between mb-3">
			<!--[if BLOCK]><![endif]--><?php if($selectedMode == 'tambah'): ?>
				<button class="btn btn-success" wire:click='batal'>Batal</button>
			<?php else: ?>
				<button class="btn btn-pink" wire:click='tambah'>+ Tambah Transaksi Penjualan</button>
			<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

			<div class="d-flex">
				<input class="form-control me-2" type="text" placeholder="Cari Barang">
				<button class="btn btn-success">Cari</button>
			</div>
		</div>
		<!--[if BLOCK]><![endif]--><?php if($selectedMode == 'tambah' || $selectedMode == 'edit'): ?>
			<form wire:submit="simpan">
				<div class="row align-items-center mb-3">
					<label class="col-sm-2 form-label" for="nama_barang">Nama Barang</label>
					<div class="col-sm-10">
						<input class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_barang" type="text"
							wire:model="nama_barang" placeholder="Masukkan nama barang">
						<!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								Nama barang harus diisi
							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
					</div>
				</div>
				<div class="row align-items-center mb-3">
					<label class="col-sm-2 form-label" for="jumlah">Jumlah</label>
					<div class="col-sm-10">
						<input class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah" type="number"
							wire:model="jumlah" placeholder="Masukkan jumlah barang">
						<!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								Jumlah harus diisi dengan angka
							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
					</div>
				</div>
				<div class="row align-items-center mb-3">
					<label class="col-sm-2 form-label" for="ukuran">Ukuran</label>
					<div class="col-sm-10">
						<input class="form-control <?php $__errorArgs = ['ukuran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ukuran" type="text"
							wire:model="ukuran" placeholder="Masukkan ukuran barang">
						<!--[if BLOCK]><![endif]--><?php $__errorArgs = ['ukuran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								Ukuran harus diisi
							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
					</div>
				</div>
				<div class="row align-items-center mb-3" wire:key='foto'>
					<label class="col-sm-2 form-label" for="foto_barang">Foto Barang</label>
					<div class="col-sm-10">
						<input class="form-control <?php $__errorArgs = ['foto_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto_barang" type="file"
							wire:model.defer="foto_barang" accept="image/*">
						<!--[if BLOCK]><![endif]--><?php $__errorArgs = ['foto_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								Foto barang harus diunggah
							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
					</div>
				</div>
				<div class="row align-items-center mb-3">
					<label class="col-sm-2 form-label" for="tanggal_masuk">Tanggal Masuk</label>
					<div class="col-sm-10">
						<input class="form-control <?php $__errorArgs = ['tanggal_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_masuk" type="date"
							wire:model="tanggal_masuk">
						<!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tanggal_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								Tanggal masuk harus diisi
							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
					</div>
				</div>
				<div class="row align-items-center mb-3">
					<label class="col-sm-2 form-label" for="harga">Harga</label>
					<div class="col-sm-10">
						<input class="form-control <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga" type="text" wire:model="harga">
						<!--[if BLOCK]><![endif]--><?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								Tanggal masuk harus diisi
							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
					</div>
				</div>
				<div class="row">
					<div class="col-sm-10 offset-sm-2">
						<button class="btn btn-primary" type="submit" wire:loading.attr='disabled'>Simpan</button>
					</div>
				</div>
			</form>
		<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
		<hr />
		<table class="table-striped table-bordered table">
			<thead class="thead-light">
				<tr>
					<th>No.</th>
					<th>Nama Barang</th>
					<th>Jumlah</th>
					<th>Ukuran</th>
					<th>Foto Nota</th>
					<th>Tanggal Penjualan</th>
					<th>Harga</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($barang->nama); ?></td>
						<td><?php echo e($barang->jumlah); ?></td>
						<td><?php echo e($barang->ukuran); ?></td>
						<td>
							<img class="img-fluid" src="<?php echo e(asset('/storage/gambarbarang/' . $barang->foto)); ?>"
								alt="<?php echo e($barang->nama_barang); ?>" style="max-width: 100px">
						</td>
						<td><?php echo e($barang->tanggal_masuk); ?></td>
						<td><?php echo e($barang->harga); ?></td>
						<td>
							<div class="d-flex">
								<button class="btn btn-warning me-2" wire:click='edit(<?php echo e($barang->id); ?>)'>Edit</button>
								<button class="btn btn-danger" wire:click='hapus(<?php echo e($barang->id); ?>)'
									wire:confirm='Anda akan menghapus Barang :: <?php echo e($barang->nama); ?> ::'>Hapus</button>
							</div>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
			</tbody>
		</table>
	</div>
</div>
<?php /**PATH C:\Users\USER\Downloads\Compressed\invenpt-main\resources\views/livewire/penjualan.blade.php ENDPATH**/ ?>