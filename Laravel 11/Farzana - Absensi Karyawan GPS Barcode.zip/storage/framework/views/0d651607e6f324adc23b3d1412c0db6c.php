<div class="flex min-h-screen flex-col items-center bg-gray-100 pt-6 dark:bg-gray-900 sm:justify-center sm:pt-0">
  <div>
    <?php echo e($logo); ?>

  </div>

  <div class="mt-6 w-full overflow-hidden bg-white px-6 py-4 shadow-md dark:bg-gray-800 sm:max-w-md sm:rounded-lg">
    <?php echo e($slot); ?>

  </div>
</div>
<?php /**PATH C:\Users\USER\Downloads\Compressed\absensi-karyawan-gps-barcode-master\absensi-karyawan-gps-barcode-master\resources\views/components/authentication-card.blade.php ENDPATH**/ ?>