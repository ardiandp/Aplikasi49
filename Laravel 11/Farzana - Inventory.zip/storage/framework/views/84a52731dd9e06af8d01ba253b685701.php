<footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
      <div class="row">
        <nav class="footer-nav">
          <ul>
            <li><a href="#" target="_blank">Depon Parid</a></li>
          </ul>
        </nav>
        <div class="credits ml-auto">
          
        </div>
      </div>
    </div>
  </footer>
<?php /**PATH C:\Users\USER\Downloads\Compressed\app-inventoryy-main\resources\views/footer.blade.php ENDPATH**/ ?>