# Kasir-Kit - The Best Code to Learn How Cashier Application Works
<center><img src="https://kasirkit.github.io/img/mb2.png"></center>
<br />Default Account
<br /><b>Username:</b> yuranions
<br /><b>Password:</b> 62569621144
<br />
<h3><b>Donasi</h3></b>
Bagi yang ingin mendukung saya agar tetap berkembang, silahkan donasi secara sukarela pada nomor berikut:
<br /><b>0895343919913</b> (Tri)
