param($installPath, $toolsPath, $package, $project)

$project.DTE.ItemOperations.Navigate('https://unity.codeplex.com/wikipage?title=Unity3ReleaseNotes')