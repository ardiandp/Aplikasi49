﻿namespace StokBarangApp
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bunifuFlatButton1 = new ns1.BunifuFlatButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.userTeks = new MetroFramework.Controls.MetroTextBox();
            this.pwdTeks = new MetroFramework.Controls.MetroTextBox();
            this.SuspendLayout();
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Register";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(57, 200);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(200, 46);
            this.bunifuFlatButton1.TabIndex = 2;
            this.bunifuFlatButton1.Text = "Register";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(57, 253);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(131, 19);
            this.metroLabel1.TabIndex = 3;
            this.metroLabel1.Text = "Sudah Punya Akun ? ";
            this.metroLabel1.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // metroLink1
            // 
            this.metroLink1.Location = new System.Drawing.Point(182, 253);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(75, 23);
            this.metroLink1.TabIndex = 4;
            this.metroLink1.Text = "Login";
            this.metroLink1.UseSelectable = true;
            this.metroLink1.Click += new System.EventHandler(this.metroLink1_Click);
            // 
            // userTeks
            // 
            // 
            // 
            // 
            this.userTeks.CustomButton.Image = null;
            this.userTeks.CustomButton.Location = new System.Drawing.Point(164, 1);
            this.userTeks.CustomButton.Name = "";
            this.userTeks.CustomButton.Size = new System.Drawing.Size(35, 35);
            this.userTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.userTeks.CustomButton.TabIndex = 1;
            this.userTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.userTeks.CustomButton.UseSelectable = true;
            this.userTeks.CustomButton.Visible = false;
            this.userTeks.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.userTeks.Lines = new string[0];
            this.userTeks.Location = new System.Drawing.Point(57, 91);
            this.userTeks.MaxLength = 32767;
            this.userTeks.Multiline = true;
            this.userTeks.Name = "userTeks";
            this.userTeks.PasswordChar = '\0';
            this.userTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.userTeks.SelectedText = "";
            this.userTeks.SelectionLength = 0;
            this.userTeks.SelectionStart = 0;
            this.userTeks.ShortcutsEnabled = true;
            this.userTeks.Size = new System.Drawing.Size(200, 37);
            this.userTeks.TabIndex = 5;
            this.userTeks.UseSelectable = true;
            this.userTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.userTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pwdTeks
            // 
            // 
            // 
            // 
            this.pwdTeks.CustomButton.Image = null;
            this.pwdTeks.CustomButton.Location = new System.Drawing.Point(174, 2);
            this.pwdTeks.CustomButton.Name = "";
            this.pwdTeks.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.pwdTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.pwdTeks.CustomButton.TabIndex = 1;
            this.pwdTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.pwdTeks.CustomButton.UseSelectable = true;
            this.pwdTeks.CustomButton.Visible = false;
            this.pwdTeks.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.pwdTeks.Lines = new string[0];
            this.pwdTeks.Location = new System.Drawing.Point(57, 147);
            this.pwdTeks.MaxLength = 32767;
            this.pwdTeks.Multiline = true;
            this.pwdTeks.Name = "pwdTeks";
            this.pwdTeks.PasswordChar = '*';
            this.pwdTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.pwdTeks.SelectedText = "";
            this.pwdTeks.SelectionLength = 0;
            this.pwdTeks.SelectionStart = 0;
            this.pwdTeks.ShortcutsEnabled = true;
            this.pwdTeks.Size = new System.Drawing.Size(200, 28);
            this.pwdTeks.TabIndex = 6;
            this.pwdTeks.UseSelectable = true;
            this.pwdTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.pwdTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 303);
            this.Controls.Add(this.pwdTeks);
            this.Controls.Add(this.userTeks);
            this.Controls.Add(this.metroLink1);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Name = "Register";
            this.Text = "Register";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.Register_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ns1.BunifuFlatButton bunifuFlatButton1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Controls.MetroTextBox userTeks;
        private MetroFramework.Controls.MetroTextBox pwdTeks;
    }
}