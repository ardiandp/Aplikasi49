﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StokBarangApp
{
    public class StokPenjualan
    {
        public string nama_pembeli { get; set; }
        public int total_harga { get; set; }

    }
}
