﻿namespace StokBarangApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bunifuFlatButton1 = new ns1.BunifuFlatButton();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.passwordTeks = new MetroFramework.Controls.MetroTextBox();
            this.usernameTeks = new MetroFramework.Controls.MetroTextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Login";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(65, 195);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(200, 46);
            this.bunifuFlatButton1.TabIndex = 5;
            this.bunifuFlatButton1.Text = "Login";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // metroLink1
            // 
            this.metroLink1.ForeColor = System.Drawing.Color.Blue;
            this.metroLink1.Location = new System.Drawing.Point(190, 247);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(75, 19);
            this.metroLink1.TabIndex = 7;
            this.metroLink1.Text = "Register";
            this.metroLink1.UseSelectable = true;
            this.metroLink1.Click += new System.EventHandler(this.metroLink1_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(65, 247);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(128, 19);
            this.metroLabel1.TabIndex = 6;
            this.metroLabel1.Text = "Belum Punya Akun ?";
            // 
            // passwordTeks
            // 
            // 
            // 
            // 
            this.passwordTeks.CustomButton.Image = null;
            this.passwordTeks.CustomButton.Location = new System.Drawing.Point(174, 2);
            this.passwordTeks.CustomButton.Name = "";
            this.passwordTeks.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.passwordTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.passwordTeks.CustomButton.TabIndex = 1;
            this.passwordTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.passwordTeks.CustomButton.UseSelectable = true;
            this.passwordTeks.CustomButton.Visible = false;
            this.passwordTeks.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.passwordTeks.Lines = new string[0];
            this.passwordTeks.Location = new System.Drawing.Point(65, 145);
            this.passwordTeks.MaxLength = 32767;
            this.passwordTeks.Multiline = true;
            this.passwordTeks.Name = "passwordTeks";
            this.passwordTeks.PasswordChar = '*';
            this.passwordTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.passwordTeks.SelectedText = "";
            this.passwordTeks.SelectionLength = 0;
            this.passwordTeks.SelectionStart = 0;
            this.passwordTeks.ShortcutsEnabled = true;
            this.passwordTeks.Size = new System.Drawing.Size(200, 28);
            this.passwordTeks.TabIndex = 8;
            this.passwordTeks.UseSelectable = true;
            this.passwordTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.passwordTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // usernameTeks
            // 
            // 
            // 
            // 
            this.usernameTeks.CustomButton.Image = null;
            this.usernameTeks.CustomButton.Location = new System.Drawing.Point(166, 1);
            this.usernameTeks.CustomButton.Name = "";
            this.usernameTeks.CustomButton.Size = new System.Drawing.Size(33, 33);
            this.usernameTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.usernameTeks.CustomButton.TabIndex = 1;
            this.usernameTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.usernameTeks.CustomButton.UseSelectable = true;
            this.usernameTeks.CustomButton.Visible = false;
            this.usernameTeks.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.usernameTeks.Lines = new string[0];
            this.usernameTeks.Location = new System.Drawing.Point(65, 95);
            this.usernameTeks.MaxLength = 32767;
            this.usernameTeks.Multiline = true;
            this.usernameTeks.Name = "usernameTeks";
            this.usernameTeks.PasswordChar = '\0';
            this.usernameTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.usernameTeks.SelectedText = "";
            this.usernameTeks.SelectionLength = 0;
            this.usernameTeks.SelectionStart = 0;
            this.usernameTeks.ShortcutsEnabled = true;
            this.usernameTeks.Size = new System.Drawing.Size(200, 35);
            this.usernameTeks.TabIndex = 9;
            this.usernameTeks.UseSelectable = true;
            this.usernameTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.usernameTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(12, 293);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(94, 13);
            this.linkLabel1.TabIndex = 10;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Database Settings";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 318);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.usernameTeks);
            this.Controls.Add(this.passwordTeks);
            this.Controls.Add(this.metroLink1);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Name = "Form1";
            this.Text = "StokBarangApp";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ns1.BunifuFlatButton bunifuFlatButton1;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox passwordTeks;
        private MetroFramework.Controls.MetroTextBox usernameTeks;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}

