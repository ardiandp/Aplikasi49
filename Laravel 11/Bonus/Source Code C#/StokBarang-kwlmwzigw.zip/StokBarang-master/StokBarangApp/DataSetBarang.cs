﻿namespace StokBarangApp
{


    partial class DataSetBarang
    {
    }
}
