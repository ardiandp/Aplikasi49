﻿namespace StokBarangApp
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.KodeSupplierTeks = new MetroFramework.Controls.MetroComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.JumlahBeliTeks = new MetroFramework.Controls.MetroTextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.TanggalBeliTeks = new MetroFramework.Controls.MetroDateTime();
            this.HargaBeliTeks = new MetroFramework.Controls.MetroTextBox();
            this.HapusButton = new ns1.BunifuFlatButton();
            this.UbahButton = new ns1.BunifuFlatButton();
            this.bunifuFlatButton2 = new ns1.BunifuFlatButton();
            this.HargaProdukTeks = new MetroFramework.Controls.MetroTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TanggalKadaluarsaTeks = new MetroFramework.Controls.MetroDateTime();
            this.JumlahProdukTeks = new MetroFramework.Controls.MetroTextBox();
            this.MerekProdukTeks = new MetroFramework.Controls.MetroTextBox();
            this.JenisProdukTeks = new MetroFramework.Controls.MetroTextBox();
            this.NamaProdukTeks = new MetroFramework.Controls.MetroTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.JualButton = new ns1.BunifuFlatButton();
            this.TotalHargaTeks = new MetroFramework.Controls.MetroTextBox();
            this.NamaPembeliTeks = new MetroFramework.Controls.MetroTextBox();
            this.Jumlah = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.PrintBtnJual = new MetroFramework.Controls.MetroButton();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.JumlahTerjual = new MetroFramework.Controls.MetroTextBox();
            this.bunifuFlatButton1 = new ns1.BunifuFlatButton();
            this.HargaProduk = new MetroFramework.Controls.MetroTextBox();
            this.TombolHapus = new ns1.BunifuFlatButton();
            this.JenisProduk = new MetroFramework.Controls.MetroTextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.TanggalPenjualan = new MetroFramework.Controls.MetroDateTime();
            this.MerekProduk = new MetroFramework.Controls.MetroTextBox();
            this.NamaProduk = new MetroFramework.Controls.MetroTextBox();
            this.TotalHarga = new MetroFramework.Controls.MetroTextBox();
            this.NamaPembeli = new MetroFramework.Controls.MetroTextBox();
            this.metroGrid2 = new MetroFramework.Controls.MetroGrid();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.KodeSupplier = new MetroFramework.Controls.MetroTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.metroButton9 = new MetroFramework.Controls.MetroButton();
            this.metroButton8 = new MetroFramework.Controls.MetroButton();
            this.HapusSup = new MetroFramework.Controls.MetroButton();
            this.UbahSup = new MetroFramework.Controls.MetroButton();
            this.TambahSup = new MetroFramework.Controls.MetroButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.TanggalDaftar = new MetroFramework.Controls.MetroDateTime();
            this.EmailSupplier = new MetroFramework.Controls.MetroTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.TeleponSupplier = new MetroFramework.Controls.MetroTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.AlamatSupplier = new MetroFramework.Controls.MetroTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.NamaSupplier = new MetroFramework.Controls.MetroTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.metroGrid4 = new MetroFramework.Controls.MetroGrid();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.JualComboSecond = new MetroFramework.Controls.MetroComboBox();
            this.JualCombo = new MetroFramework.Controls.MetroComboBox();
            this.FindRangeJual = new ns1.BunifuFlatButton();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.RefreshChartJualBtn = new ns1.BunifuFlatButton();
            this.GrafikJual = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.BeliComboSecond = new MetroFramework.Controls.MetroComboBox();
            this.BeliCombo = new MetroFramework.Controls.MetroComboBox();
            this.FindRangeBeli = new ns1.BunifuFlatButton();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.RefreshChartBeliBtn = new ns1.BunifuFlatButton();
            this.GrafikBeli = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.bunifuFlatButton4 = new ns1.BunifuFlatButton();
            this.bunifuFlatButton3 = new ns1.BunifuFlatButton();
            this.HapusUser = new ns1.BunifuFlatButton();
            this.UbahUser = new ns1.BunifuFlatButton();
            this.TambahUser = new ns1.BunifuFlatButton();
            this.label16 = new System.Windows.Forms.Label();
            this.PasswordTeks = new MetroFramework.Controls.MetroTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.UsernameTeks = new MetroFramework.Controls.MetroTextBox();
            this.metroGrid3 = new MetroFramework.Controls.MetroGrid();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.metroButton12 = new MetroFramework.Controls.MetroButton();
            this.metroButton11 = new MetroFramework.Controls.MetroButton();
            this.StatusBulan = new System.Windows.Forms.Label();
            this.LabelUntungHari = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label43 = new System.Windows.Forms.Label();
            this.metroButton10 = new MetroFramework.Controls.MetroButton();
            this.ChartUntungRugi = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.HitungTotalButton = new MetroFramework.Controls.MetroButton();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.TotalPengeluaran = new MetroFramework.Controls.MetroTextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.PengeluaranTeks = new MetroFramework.Controls.MetroTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.InternetTeks = new MetroFramework.Controls.MetroTextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.GajiKaryawanTeks = new MetroFramework.Controls.MetroTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.AirTeks = new MetroFramework.Controls.MetroTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ListrikTeks = new MetroFramework.Controls.MetroTextBox();
            this.metroButton7 = new MetroFramework.Controls.MetroButton();
            this.metroButton6 = new MetroFramework.Controls.MetroButton();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.AlamatLabel = new System.Windows.Forms.Label();
            this.NamaLabel = new System.Windows.Forms.Label();
            this.KeteranganLabel = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.TeleponLabel = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.metroButton13 = new MetroFramework.Controls.MetroButton();
            this.label48 = new System.Windows.Forms.Label();
            this.KeteranganUsaha = new MetroFramework.Controls.MetroTextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.EmailUsaha = new MetroFramework.Controls.MetroTextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.TeleponUsaha = new MetroFramework.Controls.MetroTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.AlamatUsaha = new MetroFramework.Controls.MetroTextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.NamaUsaha = new MetroFramework.Controls.MetroTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid4)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrafikJual)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrafikBeli)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartUntungRugi)).BeginInit();
            this.groupBox13.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(24, 64);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1094, 462);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.metroGrid1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1086, 436);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pembelian / Stok";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.KodeSupplierTeks);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.JumlahBeliTeks);
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.HargaBeliTeks);
            this.groupBox2.Controls.Add(this.HapusButton);
            this.groupBox2.Controls.Add(this.UbahButton);
            this.groupBox2.Controls.Add(this.bunifuFlatButton2);
            this.groupBox2.Controls.Add(this.HargaProdukTeks);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.JumlahProdukTeks);
            this.groupBox2.Controls.Add(this.MerekProdukTeks);
            this.groupBox2.Controls.Add(this.JenisProdukTeks);
            this.groupBox2.Controls.Add(this.NamaProdukTeks);
            this.groupBox2.Location = new System.Drawing.Point(750, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(320, 424);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tambah Minuman / Makanan";
            // 
            // KodeSupplierTeks
            // 
            this.KodeSupplierTeks.FormattingEnabled = true;
            this.KodeSupplierTeks.IntegralHeight = false;
            this.KodeSupplierTeks.ItemHeight = 23;
            this.KodeSupplierTeks.Location = new System.Drawing.Point(124, 30);
            this.KodeSupplierTeks.Name = "KodeSupplierTeks";
            this.KodeSupplierTeks.Size = new System.Drawing.Size(190, 29);
            this.KodeSupplierTeks.TabIndex = 26;
            this.KodeSupplierTeks.UseSelectable = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(21, 36);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(93, 16);
            this.label26.TabIndex = 25;
            this.label26.Text = "Kode Supplier";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(21, 244);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 16);
            this.label7.TabIndex = 24;
            this.label7.Text = "Jumlah Beli";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(21, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "Jumlah Produk";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "Harga Produk";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(21, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Harga Beli";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "Merek Produk";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "Jenis Produk";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "Nama  Produk ";
            // 
            // JumlahBeliTeks
            // 
            // 
            // 
            // 
            this.JumlahBeliTeks.CustomButton.Image = null;
            this.JumlahBeliTeks.CustomButton.Location = new System.Drawing.Point(168, 1);
            this.JumlahBeliTeks.CustomButton.Name = "";
            this.JumlahBeliTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.JumlahBeliTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.JumlahBeliTeks.CustomButton.TabIndex = 1;
            this.JumlahBeliTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.JumlahBeliTeks.CustomButton.UseSelectable = true;
            this.JumlahBeliTeks.CustomButton.Visible = false;
            this.JumlahBeliTeks.Lines = new string[0];
            this.JumlahBeliTeks.Location = new System.Drawing.Point(124, 237);
            this.JumlahBeliTeks.MaxLength = 32767;
            this.JumlahBeliTeks.Name = "JumlahBeliTeks";
            this.JumlahBeliTeks.PasswordChar = '\0';
            this.JumlahBeliTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.JumlahBeliTeks.SelectedText = "";
            this.JumlahBeliTeks.SelectionLength = 0;
            this.JumlahBeliTeks.SelectionStart = 0;
            this.JumlahBeliTeks.ShortcutsEnabled = true;
            this.JumlahBeliTeks.Size = new System.Drawing.Size(190, 23);
            this.JumlahBeliTeks.TabIndex = 17;
            this.JumlahBeliTeks.UseSelectable = true;
            this.JumlahBeliTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.JumlahBeliTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.JumlahBeliTeks.Click += new System.EventHandler(this.JumlahBeliTeks_Click);
            this.JumlahBeliTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.JumlahBeliTeks_KeyPress);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.TanggalBeliTeks);
            this.groupBox6.Location = new System.Drawing.Point(171, 275);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(143, 61);
            this.groupBox6.TabIndex = 16;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Tanggal Beli";
            // 
            // TanggalBeliTeks
            // 
            this.TanggalBeliTeks.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TanggalBeliTeks.Location = new System.Drawing.Point(6, 19);
            this.TanggalBeliTeks.MinimumSize = new System.Drawing.Size(0, 29);
            this.TanggalBeliTeks.Name = "TanggalBeliTeks";
            this.TanggalBeliTeks.Size = new System.Drawing.Size(131, 29);
            this.TanggalBeliTeks.TabIndex = 8;
            // 
            // HargaBeliTeks
            // 
            // 
            // 
            // 
            this.HargaBeliTeks.CustomButton.Image = null;
            this.HargaBeliTeks.CustomButton.Location = new System.Drawing.Point(168, 1);
            this.HargaBeliTeks.CustomButton.Name = "";
            this.HargaBeliTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.HargaBeliTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.HargaBeliTeks.CustomButton.TabIndex = 1;
            this.HargaBeliTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.HargaBeliTeks.CustomButton.UseSelectable = true;
            this.HargaBeliTeks.CustomButton.Visible = false;
            this.HargaBeliTeks.Lines = new string[0];
            this.HargaBeliTeks.Location = new System.Drawing.Point(124, 150);
            this.HargaBeliTeks.MaxLength = 32767;
            this.HargaBeliTeks.Name = "HargaBeliTeks";
            this.HargaBeliTeks.PasswordChar = '\0';
            this.HargaBeliTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.HargaBeliTeks.SelectedText = "";
            this.HargaBeliTeks.SelectionLength = 0;
            this.HargaBeliTeks.SelectionStart = 0;
            this.HargaBeliTeks.ShortcutsEnabled = true;
            this.HargaBeliTeks.Size = new System.Drawing.Size(190, 23);
            this.HargaBeliTeks.TabIndex = 15;
            this.HargaBeliTeks.UseSelectable = true;
            this.HargaBeliTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.HargaBeliTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.HargaBeliTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.HargaBeliTeks_KeyPress);
            // 
            // HapusButton
            // 
            this.HapusButton.Activecolor = System.Drawing.Color.Red;
            this.HapusButton.BackColor = System.Drawing.Color.Red;
            this.HapusButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.HapusButton.BorderRadius = 7;
            this.HapusButton.ButtonText = "Hapus";
            this.HapusButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HapusButton.DisabledColor = System.Drawing.Color.DimGray;
            this.HapusButton.Enabled = false;
            this.HapusButton.Iconcolor = System.Drawing.Color.Transparent;
            this.HapusButton.Iconimage = null;
            this.HapusButton.Iconimage_right = null;
            this.HapusButton.Iconimage_right_Selected = null;
            this.HapusButton.Iconimage_Selected = null;
            this.HapusButton.IconMarginLeft = 0;
            this.HapusButton.IconMarginRight = 0;
            this.HapusButton.IconRightVisible = false;
            this.HapusButton.IconRightZoom = 0D;
            this.HapusButton.IconVisible = false;
            this.HapusButton.IconZoom = 90D;
            this.HapusButton.IsTab = false;
            this.HapusButton.Location = new System.Drawing.Point(18, 388);
            this.HapusButton.Name = "HapusButton";
            this.HapusButton.Normalcolor = System.Drawing.Color.Red;
            this.HapusButton.OnHovercolor = System.Drawing.Color.Tomato;
            this.HapusButton.OnHoverTextColor = System.Drawing.Color.White;
            this.HapusButton.selected = false;
            this.HapusButton.Size = new System.Drawing.Size(296, 32);
            this.HapusButton.TabIndex = 14;
            this.HapusButton.Text = "Hapus";
            this.HapusButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.HapusButton.Textcolor = System.Drawing.Color.White;
            this.HapusButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HapusButton.Click += new System.EventHandler(this.HapusButton_Click);
            // 
            // UbahButton
            // 
            this.UbahButton.Activecolor = System.Drawing.Color.RoyalBlue;
            this.UbahButton.BackColor = System.Drawing.Color.RoyalBlue;
            this.UbahButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.UbahButton.BorderRadius = 7;
            this.UbahButton.ButtonText = "Ubah";
            this.UbahButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UbahButton.DisabledColor = System.Drawing.Color.DimGray;
            this.UbahButton.Enabled = false;
            this.UbahButton.Iconcolor = System.Drawing.Color.Transparent;
            this.UbahButton.Iconimage = null;
            this.UbahButton.Iconimage_right = null;
            this.UbahButton.Iconimage_right_Selected = null;
            this.UbahButton.Iconimage_Selected = null;
            this.UbahButton.IconMarginLeft = 0;
            this.UbahButton.IconMarginRight = 0;
            this.UbahButton.IconRightVisible = false;
            this.UbahButton.IconRightZoom = 0D;
            this.UbahButton.IconVisible = false;
            this.UbahButton.IconZoom = 90D;
            this.UbahButton.IsTab = false;
            this.UbahButton.Location = new System.Drawing.Point(171, 342);
            this.UbahButton.Name = "UbahButton";
            this.UbahButton.Normalcolor = System.Drawing.Color.RoyalBlue;
            this.UbahButton.OnHovercolor = System.Drawing.Color.LightSkyBlue;
            this.UbahButton.OnHoverTextColor = System.Drawing.Color.White;
            this.UbahButton.selected = false;
            this.UbahButton.Size = new System.Drawing.Size(143, 40);
            this.UbahButton.TabIndex = 13;
            this.UbahButton.Text = "Ubah";
            this.UbahButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.UbahButton.Textcolor = System.Drawing.Color.White;
            this.UbahButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UbahButton.Click += new System.EventHandler(this.UbahButton_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.ForestGreen;
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.ForestGreen;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 7;
            this.bunifuFlatButton2.ButtonText = "Simpan";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = false;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = false;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(18, 342);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.ForestGreen;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.LimeGreen;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(147, 40);
            this.bunifuFlatButton2.TabIndex = 6;
            this.bunifuFlatButton2.Text = "Simpan";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click_1);
            // 
            // HargaProdukTeks
            // 
            // 
            // 
            // 
            this.HargaProdukTeks.CustomButton.Image = null;
            this.HargaProdukTeks.CustomButton.Location = new System.Drawing.Point(168, 1);
            this.HargaProdukTeks.CustomButton.Name = "";
            this.HargaProdukTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.HargaProdukTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.HargaProdukTeks.CustomButton.TabIndex = 1;
            this.HargaProdukTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.HargaProdukTeks.CustomButton.UseSelectable = true;
            this.HargaProdukTeks.CustomButton.Visible = false;
            this.HargaProdukTeks.Lines = new string[0];
            this.HargaProdukTeks.Location = new System.Drawing.Point(124, 179);
            this.HargaProdukTeks.MaxLength = 32767;
            this.HargaProdukTeks.Name = "HargaProdukTeks";
            this.HargaProdukTeks.PasswordChar = '\0';
            this.HargaProdukTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.HargaProdukTeks.SelectedText = "";
            this.HargaProdukTeks.SelectionLength = 0;
            this.HargaProdukTeks.SelectionStart = 0;
            this.HargaProdukTeks.ShortcutsEnabled = true;
            this.HargaProdukTeks.Size = new System.Drawing.Size(190, 23);
            this.HargaProdukTeks.TabIndex = 12;
            this.HargaProdukTeks.UseSelectable = true;
            this.HargaProdukTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.HargaProdukTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.HargaProdukTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.HargaProdukTeks_KeyPress);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.TanggalKadaluarsaTeks);
            this.groupBox3.Location = new System.Drawing.Point(18, 275);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(147, 61);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tanggal Kadaluarsa";
            // 
            // TanggalKadaluarsaTeks
            // 
            this.TanggalKadaluarsaTeks.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TanggalKadaluarsaTeks.Location = new System.Drawing.Point(6, 19);
            this.TanggalKadaluarsaTeks.MinimumSize = new System.Drawing.Size(0, 29);
            this.TanggalKadaluarsaTeks.Name = "TanggalKadaluarsaTeks";
            this.TanggalKadaluarsaTeks.Size = new System.Drawing.Size(135, 29);
            this.TanggalKadaluarsaTeks.TabIndex = 8;
            // 
            // JumlahProdukTeks
            // 
            // 
            // 
            // 
            this.JumlahProdukTeks.CustomButton.Image = null;
            this.JumlahProdukTeks.CustomButton.Location = new System.Drawing.Point(168, 1);
            this.JumlahProdukTeks.CustomButton.Name = "";
            this.JumlahProdukTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.JumlahProdukTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.JumlahProdukTeks.CustomButton.TabIndex = 1;
            this.JumlahProdukTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.JumlahProdukTeks.CustomButton.UseSelectable = true;
            this.JumlahProdukTeks.CustomButton.Visible = false;
            this.JumlahProdukTeks.Lines = new string[0];
            this.JumlahProdukTeks.Location = new System.Drawing.Point(124, 208);
            this.JumlahProdukTeks.MaxLength = 32767;
            this.JumlahProdukTeks.Name = "JumlahProdukTeks";
            this.JumlahProdukTeks.PasswordChar = '\0';
            this.JumlahProdukTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.JumlahProdukTeks.SelectedText = "";
            this.JumlahProdukTeks.SelectionLength = 0;
            this.JumlahProdukTeks.SelectionStart = 0;
            this.JumlahProdukTeks.ShortcutsEnabled = true;
            this.JumlahProdukTeks.Size = new System.Drawing.Size(190, 23);
            this.JumlahProdukTeks.TabIndex = 6;
            this.JumlahProdukTeks.UseSelectable = true;
            this.JumlahProdukTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.JumlahProdukTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.JumlahProdukTeks.Click += new System.EventHandler(this.JumlahProdukTeks_Click);
            this.JumlahProdukTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.JumlahProdukTeks_KeyPress);
            // 
            // MerekProdukTeks
            // 
            // 
            // 
            // 
            this.MerekProdukTeks.CustomButton.Image = null;
            this.MerekProdukTeks.CustomButton.Location = new System.Drawing.Point(168, 1);
            this.MerekProdukTeks.CustomButton.Name = "";
            this.MerekProdukTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.MerekProdukTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.MerekProdukTeks.CustomButton.TabIndex = 1;
            this.MerekProdukTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.MerekProdukTeks.CustomButton.UseSelectable = true;
            this.MerekProdukTeks.CustomButton.Visible = false;
            this.MerekProdukTeks.Lines = new string[0];
            this.MerekProdukTeks.Location = new System.Drawing.Point(124, 121);
            this.MerekProdukTeks.MaxLength = 32767;
            this.MerekProdukTeks.Name = "MerekProdukTeks";
            this.MerekProdukTeks.PasswordChar = '\0';
            this.MerekProdukTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.MerekProdukTeks.SelectedText = "";
            this.MerekProdukTeks.SelectionLength = 0;
            this.MerekProdukTeks.SelectionStart = 0;
            this.MerekProdukTeks.ShortcutsEnabled = true;
            this.MerekProdukTeks.Size = new System.Drawing.Size(190, 23);
            this.MerekProdukTeks.TabIndex = 5;
            this.MerekProdukTeks.UseSelectable = true;
            this.MerekProdukTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.MerekProdukTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // JenisProdukTeks
            // 
            // 
            // 
            // 
            this.JenisProdukTeks.CustomButton.Image = null;
            this.JenisProdukTeks.CustomButton.Location = new System.Drawing.Point(168, 1);
            this.JenisProdukTeks.CustomButton.Name = "";
            this.JenisProdukTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.JenisProdukTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.JenisProdukTeks.CustomButton.TabIndex = 1;
            this.JenisProdukTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.JenisProdukTeks.CustomButton.UseSelectable = true;
            this.JenisProdukTeks.CustomButton.Visible = false;
            this.JenisProdukTeks.Lines = new string[0];
            this.JenisProdukTeks.Location = new System.Drawing.Point(124, 92);
            this.JenisProdukTeks.MaxLength = 32767;
            this.JenisProdukTeks.Name = "JenisProdukTeks";
            this.JenisProdukTeks.PasswordChar = '\0';
            this.JenisProdukTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.JenisProdukTeks.SelectedText = "";
            this.JenisProdukTeks.SelectionLength = 0;
            this.JenisProdukTeks.SelectionStart = 0;
            this.JenisProdukTeks.ShortcutsEnabled = true;
            this.JenisProdukTeks.Size = new System.Drawing.Size(190, 23);
            this.JenisProdukTeks.TabIndex = 4;
            this.JenisProdukTeks.UseSelectable = true;
            this.JenisProdukTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.JenisProdukTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // NamaProdukTeks
            // 
            // 
            // 
            // 
            this.NamaProdukTeks.CustomButton.Image = null;
            this.NamaProdukTeks.CustomButton.Location = new System.Drawing.Point(168, 1);
            this.NamaProdukTeks.CustomButton.Name = "";
            this.NamaProdukTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NamaProdukTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NamaProdukTeks.CustomButton.TabIndex = 1;
            this.NamaProdukTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NamaProdukTeks.CustomButton.UseSelectable = true;
            this.NamaProdukTeks.CustomButton.Visible = false;
            this.NamaProdukTeks.Lines = new string[0];
            this.NamaProdukTeks.Location = new System.Drawing.Point(124, 63);
            this.NamaProdukTeks.MaxLength = 32767;
            this.NamaProdukTeks.Name = "NamaProdukTeks";
            this.NamaProdukTeks.PasswordChar = '\0';
            this.NamaProdukTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NamaProdukTeks.SelectedText = "";
            this.NamaProdukTeks.SelectionLength = 0;
            this.NamaProdukTeks.SelectionStart = 0;
            this.NamaProdukTeks.ShortcutsEnabled = true;
            this.NamaProdukTeks.Size = new System.Drawing.Size(190, 23);
            this.NamaProdukTeks.TabIndex = 3;
            this.NamaProdukTeks.UseSelectable = true;
            this.NamaProdukTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NamaProdukTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.metroLabel2);
            this.groupBox1.Controls.Add(this.metroButton2);
            this.groupBox1.Controls.Add(this.metroButton1);
            this.groupBox1.Controls.Add(this.JualButton);
            this.groupBox1.Controls.Add(this.TotalHargaTeks);
            this.groupBox1.Controls.Add(this.NamaPembeliTeks);
            this.groupBox1.Controls.Add(this.Jumlah);
            this.groupBox1.Controls.Add(this.metroLabel1);
            this.groupBox1.Location = new System.Drawing.Point(552, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(192, 424);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Jual Minuman / Makanan";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.Location = new System.Drawing.Point(37, 225);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(129, 25);
            this.metroLabel2.TabIndex = 8;
            this.metroLabel2.Text = "StokBarangApp";
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(15, 363);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(167, 37);
            this.metroButton2.TabIndex = 7;
            this.metroButton2.Text = "Bersihkan";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(15, 320);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(167, 37);
            this.metroButton1.TabIndex = 6;
            this.metroButton1.Text = "Segarkan Data";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // JualButton
            // 
            this.JualButton.Activecolor = System.Drawing.Color.Red;
            this.JualButton.BackColor = System.Drawing.Color.Red;
            this.JualButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.JualButton.BorderRadius = 0;
            this.JualButton.ButtonText = "Jual";
            this.JualButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.JualButton.DisabledColor = System.Drawing.Color.DimGray;
            this.JualButton.Iconcolor = System.Drawing.Color.Transparent;
            this.JualButton.Iconimage = null;
            this.JualButton.Iconimage_right = null;
            this.JualButton.Iconimage_right_Selected = null;
            this.JualButton.Iconimage_Selected = null;
            this.JualButton.IconMarginLeft = 0;
            this.JualButton.IconMarginRight = 0;
            this.JualButton.IconRightVisible = false;
            this.JualButton.IconRightZoom = 0D;
            this.JualButton.IconVisible = false;
            this.JualButton.IconZoom = 90D;
            this.JualButton.IsTab = false;
            this.JualButton.Location = new System.Drawing.Point(14, 161);
            this.JualButton.Name = "JualButton";
            this.JualButton.Normalcolor = System.Drawing.Color.Red;
            this.JualButton.OnHovercolor = System.Drawing.Color.RoyalBlue;
            this.JualButton.OnHoverTextColor = System.Drawing.Color.White;
            this.JualButton.selected = false;
            this.JualButton.Size = new System.Drawing.Size(168, 34);
            this.JualButton.TabIndex = 5;
            this.JualButton.Text = "Jual";
            this.JualButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.JualButton.Textcolor = System.Drawing.Color.White;
            this.JualButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JualButton.Click += new System.EventHandler(this.JualButton_Click);
            // 
            // TotalHargaTeks
            // 
            // 
            // 
            // 
            this.TotalHargaTeks.CustomButton.Image = null;
            this.TotalHargaTeks.CustomButton.Location = new System.Drawing.Point(145, 1);
            this.TotalHargaTeks.CustomButton.Name = "";
            this.TotalHargaTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TotalHargaTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TotalHargaTeks.CustomButton.TabIndex = 1;
            this.TotalHargaTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TotalHargaTeks.CustomButton.UseSelectable = true;
            this.TotalHargaTeks.CustomButton.Visible = false;
            this.TotalHargaTeks.Enabled = false;
            this.TotalHargaTeks.Lines = new string[0];
            this.TotalHargaTeks.Location = new System.Drawing.Point(15, 119);
            this.TotalHargaTeks.MaxLength = 32767;
            this.TotalHargaTeks.Name = "TotalHargaTeks";
            this.TotalHargaTeks.PasswordChar = '\0';
            this.TotalHargaTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TotalHargaTeks.SelectedText = "";
            this.TotalHargaTeks.SelectionLength = 0;
            this.TotalHargaTeks.SelectionStart = 0;
            this.TotalHargaTeks.ShortcutsEnabled = true;
            this.TotalHargaTeks.Size = new System.Drawing.Size(167, 23);
            this.TotalHargaTeks.TabIndex = 4;
            this.TotalHargaTeks.UseSelectable = true;
            this.TotalHargaTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TotalHargaTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // NamaPembeliTeks
            // 
            // 
            // 
            // 
            this.NamaPembeliTeks.CustomButton.Image = null;
            this.NamaPembeliTeks.CustomButton.Location = new System.Drawing.Point(145, 1);
            this.NamaPembeliTeks.CustomButton.Name = "";
            this.NamaPembeliTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NamaPembeliTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NamaPembeliTeks.CustomButton.TabIndex = 1;
            this.NamaPembeliTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NamaPembeliTeks.CustomButton.UseSelectable = true;
            this.NamaPembeliTeks.CustomButton.Visible = false;
            this.NamaPembeliTeks.Enabled = false;
            this.NamaPembeliTeks.Lines = new string[0];
            this.NamaPembeliTeks.Location = new System.Drawing.Point(15, 36);
            this.NamaPembeliTeks.MaxLength = 32767;
            this.NamaPembeliTeks.Name = "NamaPembeliTeks";
            this.NamaPembeliTeks.PasswordChar = '\0';
            this.NamaPembeliTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NamaPembeliTeks.SelectedText = "";
            this.NamaPembeliTeks.SelectionLength = 0;
            this.NamaPembeliTeks.SelectionStart = 0;
            this.NamaPembeliTeks.ShortcutsEnabled = true;
            this.NamaPembeliTeks.Size = new System.Drawing.Size(167, 23);
            this.NamaPembeliTeks.TabIndex = 2;
            this.NamaPembeliTeks.UseSelectable = true;
            this.NamaPembeliTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NamaPembeliTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Jumlah
            // 
            this.Jumlah.Enabled = false;
            this.Jumlah.FormattingEnabled = true;
            this.Jumlah.ItemHeight = 23;
            this.Jumlah.Location = new System.Drawing.Point(86, 75);
            this.Jumlah.Name = "Jumlah";
            this.Jumlah.Size = new System.Drawing.Size(54, 29);
            this.Jumlah.TabIndex = 1;
            this.Jumlah.UseSelectable = true;
            this.Jumlah.SelectedValueChanged += new System.EventHandler(this.Jumlah_SelectedValueChanged);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.Location = new System.Drawing.Point(14, 75);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(66, 25);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Jumlah";
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.Silver;
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(16, 9);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.ReadOnly = true;
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(530, 424);
            this.metroGrid1.TabIndex = 0;
            this.metroGrid1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.metroGrid1_CellContentClick);
            this.metroGrid1.Click += new System.EventHandler(this.metroGrid1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.metroGrid2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1086, 436);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Penjualan / Pembelian";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.PrintBtnJual);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.metroButton3);
            this.groupBox4.Controls.Add(this.JumlahTerjual);
            this.groupBox4.Controls.Add(this.bunifuFlatButton1);
            this.groupBox4.Controls.Add(this.HargaProduk);
            this.groupBox4.Controls.Add(this.TombolHapus);
            this.groupBox4.Controls.Add(this.JenisProduk);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.MerekProduk);
            this.groupBox4.Controls.Add(this.NamaProduk);
            this.groupBox4.Controls.Add(this.TotalHarga);
            this.groupBox4.Controls.Add(this.NamaPembeli);
            this.groupBox4.Location = new System.Drawing.Point(772, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(308, 424);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Detail Data";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // PrintBtnJual
            // 
            this.PrintBtnJual.Enabled = false;
            this.PrintBtnJual.Location = new System.Drawing.Point(17, 381);
            this.PrintBtnJual.Name = "PrintBtnJual";
            this.PrintBtnJual.Size = new System.Drawing.Size(264, 37);
            this.PrintBtnJual.TabIndex = 26;
            this.PrintBtnJual.Text = "Print Report";
            this.PrintBtnJual.UseSelectable = true;
            this.PrintBtnJual.Click += new System.EventHandler(this.metroButton10_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(14, 219);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 16);
            this.label14.TabIndex = 25;
            this.label14.Text = "Jumlah Terjual";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(14, 190);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 16);
            this.label11.TabIndex = 24;
            this.label11.Text = "Harga Produk";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 161);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 16);
            this.label12.TabIndex = 23;
            this.label12.Text = "Merek Produk";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(14, 132);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 16);
            this.label13.TabIndex = 22;
            this.label13.Text = "Jenis Produk";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(14, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "Nama  Produk ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 16);
            this.label9.TabIndex = 20;
            this.label9.Text = "Total Harga";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "Nama  Produk ";
            // 
            // metroButton3
            // 
            this.metroButton3.Location = new System.Drawing.Point(17, 328);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(81, 37);
            this.metroButton3.TabIndex = 18;
            this.metroButton3.Text = "Bersihkan";
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // JumlahTerjual
            // 
            // 
            // 
            // 
            this.JumlahTerjual.CustomButton.Image = null;
            this.JumlahTerjual.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.JumlahTerjual.CustomButton.Name = "";
            this.JumlahTerjual.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.JumlahTerjual.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.JumlahTerjual.CustomButton.TabIndex = 1;
            this.JumlahTerjual.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.JumlahTerjual.CustomButton.UseSelectable = true;
            this.JumlahTerjual.CustomButton.Visible = false;
            this.JumlahTerjual.Enabled = false;
            this.JumlahTerjual.Lines = new string[0];
            this.JumlahTerjual.Location = new System.Drawing.Point(117, 212);
            this.JumlahTerjual.MaxLength = 32767;
            this.JumlahTerjual.Name = "JumlahTerjual";
            this.JumlahTerjual.PasswordChar = '\0';
            this.JumlahTerjual.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.JumlahTerjual.SelectedText = "";
            this.JumlahTerjual.SelectionLength = 0;
            this.JumlahTerjual.SelectionStart = 0;
            this.JumlahTerjual.ShortcutsEnabled = true;
            this.JumlahTerjual.Size = new System.Drawing.Size(164, 23);
            this.JumlahTerjual.TabIndex = 17;
            this.JumlahTerjual.UseSelectable = true;
            this.JumlahTerjual.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.JumlahTerjual.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 7;
            this.bunifuFlatButton1.ButtonText = "Segar";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.DimGray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = false;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = false;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(117, 328);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.Blue;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(69, 37);
            this.bunifuFlatButton1.TabIndex = 16;
            this.bunifuFlatButton1.Text = "Segar";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // HargaProduk
            // 
            // 
            // 
            // 
            this.HargaProduk.CustomButton.Image = null;
            this.HargaProduk.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.HargaProduk.CustomButton.Name = "";
            this.HargaProduk.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.HargaProduk.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.HargaProduk.CustomButton.TabIndex = 1;
            this.HargaProduk.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.HargaProduk.CustomButton.UseSelectable = true;
            this.HargaProduk.CustomButton.Visible = false;
            this.HargaProduk.Enabled = false;
            this.HargaProduk.Lines = new string[0];
            this.HargaProduk.Location = new System.Drawing.Point(117, 183);
            this.HargaProduk.MaxLength = 32767;
            this.HargaProduk.Name = "HargaProduk";
            this.HargaProduk.PasswordChar = '\0';
            this.HargaProduk.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.HargaProduk.SelectedText = "";
            this.HargaProduk.SelectionLength = 0;
            this.HargaProduk.SelectionStart = 0;
            this.HargaProduk.ShortcutsEnabled = true;
            this.HargaProduk.Size = new System.Drawing.Size(164, 23);
            this.HargaProduk.TabIndex = 15;
            this.HargaProduk.UseSelectable = true;
            this.HargaProduk.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.HargaProduk.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // TombolHapus
            // 
            this.TombolHapus.Activecolor = System.Drawing.Color.Red;
            this.TombolHapus.BackColor = System.Drawing.Color.Red;
            this.TombolHapus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TombolHapus.BorderRadius = 0;
            this.TombolHapus.ButtonText = "Hapus";
            this.TombolHapus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TombolHapus.DisabledColor = System.Drawing.Color.DimGray;
            this.TombolHapus.Enabled = false;
            this.TombolHapus.Iconcolor = System.Drawing.Color.Transparent;
            this.TombolHapus.Iconimage = null;
            this.TombolHapus.Iconimage_right = null;
            this.TombolHapus.Iconimage_right_Selected = null;
            this.TombolHapus.Iconimage_Selected = null;
            this.TombolHapus.IconMarginLeft = 0;
            this.TombolHapus.IconMarginRight = 0;
            this.TombolHapus.IconRightVisible = false;
            this.TombolHapus.IconRightZoom = 0D;
            this.TombolHapus.IconVisible = false;
            this.TombolHapus.IconZoom = 90D;
            this.TombolHapus.IsTab = false;
            this.TombolHapus.Location = new System.Drawing.Point(202, 328);
            this.TombolHapus.Name = "TombolHapus";
            this.TombolHapus.Normalcolor = System.Drawing.Color.Red;
            this.TombolHapus.OnHovercolor = System.Drawing.Color.Tomato;
            this.TombolHapus.OnHoverTextColor = System.Drawing.Color.White;
            this.TombolHapus.selected = false;
            this.TombolHapus.Size = new System.Drawing.Size(79, 37);
            this.TombolHapus.TabIndex = 14;
            this.TombolHapus.Text = "Hapus";
            this.TombolHapus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.TombolHapus.Textcolor = System.Drawing.Color.White;
            this.TombolHapus.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TombolHapus.Click += new System.EventHandler(this.TombolHapus_Click);
            // 
            // JenisProduk
            // 
            // 
            // 
            // 
            this.JenisProduk.CustomButton.Image = null;
            this.JenisProduk.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.JenisProduk.CustomButton.Name = "";
            this.JenisProduk.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.JenisProduk.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.JenisProduk.CustomButton.TabIndex = 1;
            this.JenisProduk.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.JenisProduk.CustomButton.UseSelectable = true;
            this.JenisProduk.CustomButton.Visible = false;
            this.JenisProduk.Enabled = false;
            this.JenisProduk.Lines = new string[0];
            this.JenisProduk.Location = new System.Drawing.Point(117, 125);
            this.JenisProduk.MaxLength = 32767;
            this.JenisProduk.Name = "JenisProduk";
            this.JenisProduk.PasswordChar = '\0';
            this.JenisProduk.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.JenisProduk.SelectedText = "";
            this.JenisProduk.SelectionLength = 0;
            this.JenisProduk.SelectionStart = 0;
            this.JenisProduk.ShortcutsEnabled = true;
            this.JenisProduk.Size = new System.Drawing.Size(164, 23);
            this.JenisProduk.TabIndex = 12;
            this.JenisProduk.UseSelectable = true;
            this.JenisProduk.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.JenisProduk.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.TanggalPenjualan);
            this.groupBox5.Location = new System.Drawing.Point(17, 252);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(264, 61);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tanggal Penjualan";
            // 
            // TanggalPenjualan
            // 
            this.TanggalPenjualan.Enabled = false;
            this.TanggalPenjualan.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TanggalPenjualan.Location = new System.Drawing.Point(6, 19);
            this.TanggalPenjualan.MinimumSize = new System.Drawing.Size(0, 29);
            this.TanggalPenjualan.Name = "TanggalPenjualan";
            this.TanggalPenjualan.Size = new System.Drawing.Size(252, 29);
            this.TanggalPenjualan.TabIndex = 8;
            // 
            // MerekProduk
            // 
            // 
            // 
            // 
            this.MerekProduk.CustomButton.Image = null;
            this.MerekProduk.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.MerekProduk.CustomButton.Name = "";
            this.MerekProduk.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.MerekProduk.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.MerekProduk.CustomButton.TabIndex = 1;
            this.MerekProduk.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.MerekProduk.CustomButton.UseSelectable = true;
            this.MerekProduk.CustomButton.Visible = false;
            this.MerekProduk.Enabled = false;
            this.MerekProduk.Lines = new string[0];
            this.MerekProduk.Location = new System.Drawing.Point(117, 154);
            this.MerekProduk.MaxLength = 32767;
            this.MerekProduk.Name = "MerekProduk";
            this.MerekProduk.PasswordChar = '\0';
            this.MerekProduk.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.MerekProduk.SelectedText = "";
            this.MerekProduk.SelectionLength = 0;
            this.MerekProduk.SelectionStart = 0;
            this.MerekProduk.ShortcutsEnabled = true;
            this.MerekProduk.Size = new System.Drawing.Size(164, 23);
            this.MerekProduk.TabIndex = 6;
            this.MerekProduk.UseSelectable = true;
            this.MerekProduk.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.MerekProduk.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // NamaProduk
            // 
            // 
            // 
            // 
            this.NamaProduk.CustomButton.Image = null;
            this.NamaProduk.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.NamaProduk.CustomButton.Name = "";
            this.NamaProduk.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NamaProduk.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NamaProduk.CustomButton.TabIndex = 1;
            this.NamaProduk.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NamaProduk.CustomButton.UseSelectable = true;
            this.NamaProduk.CustomButton.Visible = false;
            this.NamaProduk.Enabled = false;
            this.NamaProduk.Lines = new string[0];
            this.NamaProduk.Location = new System.Drawing.Point(117, 96);
            this.NamaProduk.MaxLength = 32767;
            this.NamaProduk.Name = "NamaProduk";
            this.NamaProduk.PasswordChar = '\0';
            this.NamaProduk.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NamaProduk.SelectedText = "";
            this.NamaProduk.SelectionLength = 0;
            this.NamaProduk.SelectionStart = 0;
            this.NamaProduk.ShortcutsEnabled = true;
            this.NamaProduk.Size = new System.Drawing.Size(164, 23);
            this.NamaProduk.TabIndex = 5;
            this.NamaProduk.UseSelectable = true;
            this.NamaProduk.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NamaProduk.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // TotalHarga
            // 
            // 
            // 
            // 
            this.TotalHarga.CustomButton.Image = null;
            this.TotalHarga.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.TotalHarga.CustomButton.Name = "";
            this.TotalHarga.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TotalHarga.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TotalHarga.CustomButton.TabIndex = 1;
            this.TotalHarga.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TotalHarga.CustomButton.UseSelectable = true;
            this.TotalHarga.CustomButton.Visible = false;
            this.TotalHarga.Enabled = false;
            this.TotalHarga.Lines = new string[0];
            this.TotalHarga.Location = new System.Drawing.Point(117, 67);
            this.TotalHarga.MaxLength = 32767;
            this.TotalHarga.Name = "TotalHarga";
            this.TotalHarga.PasswordChar = '\0';
            this.TotalHarga.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TotalHarga.SelectedText = "";
            this.TotalHarga.SelectionLength = 0;
            this.TotalHarga.SelectionStart = 0;
            this.TotalHarga.ShortcutsEnabled = true;
            this.TotalHarga.Size = new System.Drawing.Size(164, 23);
            this.TotalHarga.TabIndex = 4;
            this.TotalHarga.UseSelectable = true;
            this.TotalHarga.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TotalHarga.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // NamaPembeli
            // 
            // 
            // 
            // 
            this.NamaPembeli.CustomButton.Image = null;
            this.NamaPembeli.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.NamaPembeli.CustomButton.Name = "";
            this.NamaPembeli.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NamaPembeli.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NamaPembeli.CustomButton.TabIndex = 1;
            this.NamaPembeli.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NamaPembeli.CustomButton.UseSelectable = true;
            this.NamaPembeli.CustomButton.Visible = false;
            this.NamaPembeli.Enabled = false;
            this.NamaPembeli.Lines = new string[0];
            this.NamaPembeli.Location = new System.Drawing.Point(117, 38);
            this.NamaPembeli.MaxLength = 32767;
            this.NamaPembeli.Name = "NamaPembeli";
            this.NamaPembeli.PasswordChar = '\0';
            this.NamaPembeli.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NamaPembeli.SelectedText = "";
            this.NamaPembeli.SelectionLength = 0;
            this.NamaPembeli.SelectionStart = 0;
            this.NamaPembeli.ShortcutsEnabled = true;
            this.NamaPembeli.Size = new System.Drawing.Size(164, 23);
            this.NamaPembeli.TabIndex = 3;
            this.NamaPembeli.UseSelectable = true;
            this.NamaPembeli.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NamaPembeli.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.NamaPembeli.Click += new System.EventHandler(this.NamaPembeli_Click);
            // 
            // metroGrid2
            // 
            this.metroGrid2.AllowUserToResizeRows = false;
            this.metroGrid2.BackgroundColor = System.Drawing.Color.Silver;
            this.metroGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.metroGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid2.DefaultCellStyle = dataGridViewCellStyle5;
            this.metroGrid2.EnableHeadersVisualStyles = false;
            this.metroGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.Location = new System.Drawing.Point(6, 6);
            this.metroGrid2.Name = "metroGrid2";
            this.metroGrid2.ReadOnly = true;
            this.metroGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.metroGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid2.Size = new System.Drawing.Size(760, 424);
            this.metroGrid2.TabIndex = 1;
            this.metroGrid2.Click += new System.EventHandler(this.metroGrid2_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Controls.Add(this.metroGrid4);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1086, 436);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Supplier";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.KodeSupplier);
            this.groupBox10.Controls.Add(this.label25);
            this.groupBox10.Controls.Add(this.metroButton9);
            this.groupBox10.Controls.Add(this.metroButton8);
            this.groupBox10.Controls.Add(this.HapusSup);
            this.groupBox10.Controls.Add(this.UbahSup);
            this.groupBox10.Controls.Add(this.TambahSup);
            this.groupBox10.Controls.Add(this.groupBox11);
            this.groupBox10.Controls.Add(this.EmailSupplier);
            this.groupBox10.Controls.Add(this.label24);
            this.groupBox10.Controls.Add(this.TeleponSupplier);
            this.groupBox10.Controls.Add(this.label23);
            this.groupBox10.Controls.Add(this.AlamatSupplier);
            this.groupBox10.Controls.Add(this.label21);
            this.groupBox10.Controls.Add(this.NamaSupplier);
            this.groupBox10.Controls.Add(this.label22);
            this.groupBox10.Location = new System.Drawing.Point(758, 7);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(322, 423);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Supplier";
            // 
            // KodeSupplier
            // 
            // 
            // 
            // 
            this.KodeSupplier.CustomButton.Image = null;
            this.KodeSupplier.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.KodeSupplier.CustomButton.Name = "";
            this.KodeSupplier.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.KodeSupplier.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.KodeSupplier.CustomButton.TabIndex = 1;
            this.KodeSupplier.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.KodeSupplier.CustomButton.UseSelectable = true;
            this.KodeSupplier.CustomButton.Visible = false;
            this.KodeSupplier.Lines = new string[0];
            this.KodeSupplier.Location = new System.Drawing.Point(128, 19);
            this.KodeSupplier.MaxLength = 32767;
            this.KodeSupplier.Name = "KodeSupplier";
            this.KodeSupplier.PasswordChar = '\0';
            this.KodeSupplier.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.KodeSupplier.SelectedText = "";
            this.KodeSupplier.SelectionLength = 0;
            this.KodeSupplier.SelectionStart = 0;
            this.KodeSupplier.ShortcutsEnabled = true;
            this.KodeSupplier.Size = new System.Drawing.Size(164, 23);
            this.KodeSupplier.TabIndex = 35;
            this.KodeSupplier.UseSelectable = true;
            this.KodeSupplier.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.KodeSupplier.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(14, 26);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 16);
            this.label25.TabIndex = 34;
            this.label25.Text = "Kode Supplier";
            // 
            // metroButton9
            // 
            this.metroButton9.Location = new System.Drawing.Point(168, 371);
            this.metroButton9.Name = "metroButton9";
            this.metroButton9.Size = new System.Drawing.Size(135, 36);
            this.metroButton9.TabIndex = 33;
            this.metroButton9.Text = "Segarkan";
            this.metroButton9.UseSelectable = true;
            this.metroButton9.Click += new System.EventHandler(this.metroButton9_Click);
            // 
            // metroButton8
            // 
            this.metroButton8.Location = new System.Drawing.Point(19, 371);
            this.metroButton8.Name = "metroButton8";
            this.metroButton8.Size = new System.Drawing.Size(135, 36);
            this.metroButton8.TabIndex = 32;
            this.metroButton8.Text = "Bersihkan";
            this.metroButton8.UseSelectable = true;
            this.metroButton8.Click += new System.EventHandler(this.metroButton8_Click);
            // 
            // HapusSup
            // 
            this.HapusSup.Enabled = false;
            this.HapusSup.Location = new System.Drawing.Point(19, 329);
            this.HapusSup.Name = "HapusSup";
            this.HapusSup.Size = new System.Drawing.Size(284, 36);
            this.HapusSup.TabIndex = 31;
            this.HapusSup.Text = "Hapus";
            this.HapusSup.UseSelectable = true;
            this.HapusSup.Click += new System.EventHandler(this.HapusSup_Click);
            // 
            // UbahSup
            // 
            this.UbahSup.Enabled = false;
            this.UbahSup.Location = new System.Drawing.Point(168, 287);
            this.UbahSup.Name = "UbahSup";
            this.UbahSup.Size = new System.Drawing.Size(135, 36);
            this.UbahSup.TabIndex = 30;
            this.UbahSup.Text = "Ubah ";
            this.UbahSup.UseSelectable = true;
            this.UbahSup.Click += new System.EventHandler(this.UbahSup_Click);
            // 
            // TambahSup
            // 
            this.TambahSup.Location = new System.Drawing.Point(19, 287);
            this.TambahSup.Name = "TambahSup";
            this.TambahSup.Size = new System.Drawing.Size(135, 36);
            this.TambahSup.TabIndex = 29;
            this.TambahSup.Text = "Tambah";
            this.TambahSup.UseSelectable = true;
            this.TambahSup.Click += new System.EventHandler(this.TambahSup_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.TanggalDaftar);
            this.groupBox11.Location = new System.Drawing.Point(17, 219);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(284, 61);
            this.groupBox11.TabIndex = 28;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Tanggal Daftar";
            // 
            // TanggalDaftar
            // 
            this.TanggalDaftar.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TanggalDaftar.Location = new System.Drawing.Point(5, 20);
            this.TanggalDaftar.MinimumSize = new System.Drawing.Size(4, 29);
            this.TanggalDaftar.Name = "TanggalDaftar";
            this.TanggalDaftar.Size = new System.Drawing.Size(269, 29);
            this.TanggalDaftar.TabIndex = 8;
            // 
            // EmailSupplier
            // 
            // 
            // 
            // 
            this.EmailSupplier.CustomButton.Image = null;
            this.EmailSupplier.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.EmailSupplier.CustomButton.Name = "";
            this.EmailSupplier.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.EmailSupplier.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.EmailSupplier.CustomButton.TabIndex = 1;
            this.EmailSupplier.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.EmailSupplier.CustomButton.UseSelectable = true;
            this.EmailSupplier.CustomButton.Visible = false;
            this.EmailSupplier.Lines = new string[0];
            this.EmailSupplier.Location = new System.Drawing.Point(128, 189);
            this.EmailSupplier.MaxLength = 32767;
            this.EmailSupplier.Name = "EmailSupplier";
            this.EmailSupplier.PasswordChar = '\0';
            this.EmailSupplier.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.EmailSupplier.SelectedText = "";
            this.EmailSupplier.SelectionLength = 0;
            this.EmailSupplier.SelectionStart = 0;
            this.EmailSupplier.ShortcutsEnabled = true;
            this.EmailSupplier.Size = new System.Drawing.Size(164, 23);
            this.EmailSupplier.TabIndex = 27;
            this.EmailSupplier.UseSelectable = true;
            this.EmailSupplier.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.EmailSupplier.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(14, 196);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 16);
            this.label24.TabIndex = 26;
            this.label24.Text = "Email Supplier";
            // 
            // TeleponSupplier
            // 
            // 
            // 
            // 
            this.TeleponSupplier.CustomButton.Image = null;
            this.TeleponSupplier.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.TeleponSupplier.CustomButton.Name = "";
            this.TeleponSupplier.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TeleponSupplier.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TeleponSupplier.CustomButton.TabIndex = 1;
            this.TeleponSupplier.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TeleponSupplier.CustomButton.UseSelectable = true;
            this.TeleponSupplier.CustomButton.Visible = false;
            this.TeleponSupplier.Lines = new string[0];
            this.TeleponSupplier.Location = new System.Drawing.Point(128, 144);
            this.TeleponSupplier.MaxLength = 32767;
            this.TeleponSupplier.Name = "TeleponSupplier";
            this.TeleponSupplier.PasswordChar = '\0';
            this.TeleponSupplier.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TeleponSupplier.SelectedText = "";
            this.TeleponSupplier.SelectionLength = 0;
            this.TeleponSupplier.SelectionStart = 0;
            this.TeleponSupplier.ShortcutsEnabled = true;
            this.TeleponSupplier.Size = new System.Drawing.Size(164, 23);
            this.TeleponSupplier.TabIndex = 25;
            this.TeleponSupplier.UseSelectable = true;
            this.TeleponSupplier.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TeleponSupplier.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(14, 151);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(112, 16);
            this.label23.TabIndex = 24;
            this.label23.Text = "Telepon Supplier";
            // 
            // AlamatSupplier
            // 
            // 
            // 
            // 
            this.AlamatSupplier.CustomButton.Image = null;
            this.AlamatSupplier.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.AlamatSupplier.CustomButton.Name = "";
            this.AlamatSupplier.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.AlamatSupplier.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.AlamatSupplier.CustomButton.TabIndex = 1;
            this.AlamatSupplier.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.AlamatSupplier.CustomButton.UseSelectable = true;
            this.AlamatSupplier.CustomButton.Visible = false;
            this.AlamatSupplier.Lines = new string[0];
            this.AlamatSupplier.Location = new System.Drawing.Point(128, 98);
            this.AlamatSupplier.MaxLength = 32767;
            this.AlamatSupplier.Name = "AlamatSupplier";
            this.AlamatSupplier.PasswordChar = '\0';
            this.AlamatSupplier.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.AlamatSupplier.SelectedText = "";
            this.AlamatSupplier.SelectionLength = 0;
            this.AlamatSupplier.SelectionStart = 0;
            this.AlamatSupplier.ShortcutsEnabled = true;
            this.AlamatSupplier.Size = new System.Drawing.Size(164, 23);
            this.AlamatSupplier.TabIndex = 23;
            this.AlamatSupplier.UseSelectable = true;
            this.AlamatSupplier.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.AlamatSupplier.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(14, 105);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 16);
            this.label21.TabIndex = 22;
            this.label21.Text = "Alamat Supplier";
            // 
            // NamaSupplier
            // 
            // 
            // 
            // 
            this.NamaSupplier.CustomButton.Image = null;
            this.NamaSupplier.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.NamaSupplier.CustomButton.Name = "";
            this.NamaSupplier.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NamaSupplier.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NamaSupplier.CustomButton.TabIndex = 1;
            this.NamaSupplier.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NamaSupplier.CustomButton.UseSelectable = true;
            this.NamaSupplier.CustomButton.Visible = false;
            this.NamaSupplier.Lines = new string[0];
            this.NamaSupplier.Location = new System.Drawing.Point(128, 55);
            this.NamaSupplier.MaxLength = 32767;
            this.NamaSupplier.Name = "NamaSupplier";
            this.NamaSupplier.PasswordChar = '\0';
            this.NamaSupplier.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NamaSupplier.SelectedText = "";
            this.NamaSupplier.SelectionLength = 0;
            this.NamaSupplier.SelectionStart = 0;
            this.NamaSupplier.ShortcutsEnabled = true;
            this.NamaSupplier.Size = new System.Drawing.Size(164, 23);
            this.NamaSupplier.TabIndex = 21;
            this.NamaSupplier.UseSelectable = true;
            this.NamaSupplier.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NamaSupplier.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(14, 62);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(98, 16);
            this.label22.TabIndex = 20;
            this.label22.Text = "Nama Supplier";
            // 
            // metroGrid4
            // 
            this.metroGrid4.AllowUserToResizeRows = false;
            this.metroGrid4.BackgroundColor = System.Drawing.Color.Silver;
            this.metroGrid4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.metroGrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid4.DefaultCellStyle = dataGridViewCellStyle8;
            this.metroGrid4.EnableHeadersVisualStyles = false;
            this.metroGrid4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid4.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid4.Location = new System.Drawing.Point(6, 7);
            this.metroGrid4.Name = "metroGrid4";
            this.metroGrid4.ReadOnly = true;
            this.metroGrid4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid4.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.metroGrid4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid4.Size = new System.Drawing.Size(745, 424);
            this.metroGrid4.TabIndex = 0;
            this.metroGrid4.Click += new System.EventHandler(this.metroGrid4_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1086, 436);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "User / Laporan";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.JualComboSecond);
            this.groupBox9.Controls.Add(this.JualCombo);
            this.groupBox9.Controls.Add(this.FindRangeJual);
            this.groupBox9.Controls.Add(this.label19);
            this.groupBox9.Controls.Add(this.label20);
            this.groupBox9.Controls.Add(this.RefreshChartJualBtn);
            this.groupBox9.Controls.Add(this.GrafikJual);
            this.groupBox9.Location = new System.Drawing.Point(527, 7);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(553, 426);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Grafik Penjualan";
            // 
            // JualComboSecond
            // 
            this.JualComboSecond.FormattingEnabled = true;
            this.JualComboSecond.ItemHeight = 23;
            this.JualComboSecond.Location = new System.Drawing.Point(277, 21);
            this.JualComboSecond.Name = "JualComboSecond";
            this.JualComboSecond.Size = new System.Drawing.Size(173, 29);
            this.JualComboSecond.TabIndex = 39;
            this.JualComboSecond.UseSelectable = true;
            // 
            // JualCombo
            // 
            this.JualCombo.FormattingEnabled = true;
            this.JualCombo.ItemHeight = 23;
            this.JualCombo.Location = new System.Drawing.Point(50, 21);
            this.JualCombo.Name = "JualCombo";
            this.JualCombo.Size = new System.Drawing.Size(149, 29);
            this.JualCombo.TabIndex = 38;
            this.JualCombo.UseSelectable = true;
            // 
            // FindRangeJual
            // 
            this.FindRangeJual.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.FindRangeJual.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.FindRangeJual.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FindRangeJual.BorderRadius = 7;
            this.FindRangeJual.ButtonText = "Cari";
            this.FindRangeJual.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FindRangeJual.DisabledColor = System.Drawing.Color.DimGray;
            this.FindRangeJual.Iconcolor = System.Drawing.Color.Transparent;
            this.FindRangeJual.Iconimage = null;
            this.FindRangeJual.Iconimage_right = null;
            this.FindRangeJual.Iconimage_right_Selected = null;
            this.FindRangeJual.Iconimage_Selected = null;
            this.FindRangeJual.IconMarginLeft = 0;
            this.FindRangeJual.IconMarginRight = 0;
            this.FindRangeJual.IconRightVisible = false;
            this.FindRangeJual.IconRightZoom = 0D;
            this.FindRangeJual.IconVisible = false;
            this.FindRangeJual.IconZoom = 90D;
            this.FindRangeJual.IsTab = false;
            this.FindRangeJual.Location = new System.Drawing.Point(456, 21);
            this.FindRangeJual.Name = "FindRangeJual";
            this.FindRangeJual.Normalcolor = System.Drawing.Color.DeepSkyBlue;
            this.FindRangeJual.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.FindRangeJual.OnHoverTextColor = System.Drawing.Color.White;
            this.FindRangeJual.selected = false;
            this.FindRangeJual.Size = new System.Drawing.Size(68, 29);
            this.FindRangeJual.TabIndex = 35;
            this.FindRangeJual.Text = "Cari";
            this.FindRangeJual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FindRangeJual.Textcolor = System.Drawing.Color.White;
            this.FindRangeJual.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindRangeJual.Click += new System.EventHandler(this.FindRangeJual_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(205, 27);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 18);
            this.label19.TabIndex = 37;
            this.label19.Text = "Sampai :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(9, 27);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 18);
            this.label20.TabIndex = 36;
            this.label20.Text = "Dari : ";
            // 
            // RefreshChartJualBtn
            // 
            this.RefreshChartJualBtn.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.RefreshChartJualBtn.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.RefreshChartJualBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RefreshChartJualBtn.BorderRadius = 7;
            this.RefreshChartJualBtn.ButtonText = "Segar";
            this.RefreshChartJualBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RefreshChartJualBtn.DisabledColor = System.Drawing.Color.DimGray;
            this.RefreshChartJualBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.RefreshChartJualBtn.Iconimage = null;
            this.RefreshChartJualBtn.Iconimage_right = null;
            this.RefreshChartJualBtn.Iconimage_right_Selected = null;
            this.RefreshChartJualBtn.Iconimage_Selected = null;
            this.RefreshChartJualBtn.IconMarginLeft = 0;
            this.RefreshChartJualBtn.IconMarginRight = 0;
            this.RefreshChartJualBtn.IconRightVisible = false;
            this.RefreshChartJualBtn.IconRightZoom = 0D;
            this.RefreshChartJualBtn.IconVisible = false;
            this.RefreshChartJualBtn.IconZoom = 90D;
            this.RefreshChartJualBtn.IsTab = false;
            this.RefreshChartJualBtn.Location = new System.Drawing.Point(6, 391);
            this.RefreshChartJualBtn.Name = "RefreshChartJualBtn";
            this.RefreshChartJualBtn.Normalcolor = System.Drawing.Color.DeepSkyBlue;
            this.RefreshChartJualBtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.RefreshChartJualBtn.OnHoverTextColor = System.Drawing.Color.White;
            this.RefreshChartJualBtn.selected = false;
            this.RefreshChartJualBtn.Size = new System.Drawing.Size(68, 32);
            this.RefreshChartJualBtn.TabIndex = 27;
            this.RefreshChartJualBtn.Text = "Segar";
            this.RefreshChartJualBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RefreshChartJualBtn.Textcolor = System.Drawing.Color.White;
            this.RefreshChartJualBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RefreshChartJualBtn.Click += new System.EventHandler(this.RefreshChartJualBtn_Click);
            // 
            // GrafikJual
            // 
            chartArea1.Name = "ChartArea1";
            this.GrafikJual.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.GrafikJual.Legends.Add(legend1);
            this.GrafikJual.Location = new System.Drawing.Point(6, 63);
            this.GrafikJual.Name = "GrafikJual";
            series1.ChartArea = "ChartArea1";
            series1.IsValueShownAsLabel = true;
            series1.Legend = "Legend1";
            series1.Name = "Penjualan";
            this.GrafikJual.Series.Add(series1);
            this.GrafikJual.Size = new System.Drawing.Size(541, 313);
            this.GrafikJual.TabIndex = 0;
            this.GrafikJual.Text = "chart2";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.BeliComboSecond);
            this.groupBox8.Controls.Add(this.BeliCombo);
            this.groupBox8.Controls.Add(this.FindRangeBeli);
            this.groupBox8.Controls.Add(this.label18);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.RefreshChartBeliBtn);
            this.groupBox8.Controls.Add(this.GrafikBeli);
            this.groupBox8.Location = new System.Drawing.Point(7, 191);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(514, 239);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Grafik Pembelian";
            // 
            // BeliComboSecond
            // 
            this.BeliComboSecond.FormattingEnabled = true;
            this.BeliComboSecond.ItemHeight = 23;
            this.BeliComboSecond.Location = new System.Drawing.Point(272, 19);
            this.BeliComboSecond.Name = "BeliComboSecond";
            this.BeliComboSecond.Size = new System.Drawing.Size(149, 29);
            this.BeliComboSecond.TabIndex = 36;
            this.BeliComboSecond.UseSelectable = true;
            // 
            // BeliCombo
            // 
            this.BeliCombo.FormattingEnabled = true;
            this.BeliCombo.ItemHeight = 23;
            this.BeliCombo.Location = new System.Drawing.Point(45, 19);
            this.BeliCombo.Name = "BeliCombo";
            this.BeliCombo.Size = new System.Drawing.Size(149, 29);
            this.BeliCombo.TabIndex = 35;
            this.BeliCombo.UseSelectable = true;
            // 
            // FindRangeBeli
            // 
            this.FindRangeBeli.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.FindRangeBeli.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.FindRangeBeli.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FindRangeBeli.BorderRadius = 7;
            this.FindRangeBeli.ButtonText = "Cari";
            this.FindRangeBeli.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FindRangeBeli.DisabledColor = System.Drawing.Color.DimGray;
            this.FindRangeBeli.Iconcolor = System.Drawing.Color.Transparent;
            this.FindRangeBeli.Iconimage = null;
            this.FindRangeBeli.Iconimage_right = null;
            this.FindRangeBeli.Iconimage_right_Selected = null;
            this.FindRangeBeli.Iconimage_Selected = null;
            this.FindRangeBeli.IconMarginLeft = 0;
            this.FindRangeBeli.IconMarginRight = 0;
            this.FindRangeBeli.IconRightVisible = false;
            this.FindRangeBeli.IconRightZoom = 0D;
            this.FindRangeBeli.IconVisible = false;
            this.FindRangeBeli.IconZoom = 90D;
            this.FindRangeBeli.IsTab = false;
            this.FindRangeBeli.Location = new System.Drawing.Point(440, 19);
            this.FindRangeBeli.Name = "FindRangeBeli";
            this.FindRangeBeli.Normalcolor = System.Drawing.Color.DeepSkyBlue;
            this.FindRangeBeli.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.FindRangeBeli.OnHoverTextColor = System.Drawing.Color.White;
            this.FindRangeBeli.selected = false;
            this.FindRangeBeli.Size = new System.Drawing.Size(68, 29);
            this.FindRangeBeli.TabIndex = 34;
            this.FindRangeBeli.Text = "Cari";
            this.FindRangeBeli.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FindRangeBeli.Textcolor = System.Drawing.Color.White;
            this.FindRangeBeli.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindRangeBeli.Click += new System.EventHandler(this.FindRangeBeli_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(200, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 18);
            this.label18.TabIndex = 33;
            this.label18.Text = "Sampai :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(4, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 18);
            this.label17.TabIndex = 32;
            this.label17.Text = "Dari : ";
            // 
            // RefreshChartBeliBtn
            // 
            this.RefreshChartBeliBtn.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.RefreshChartBeliBtn.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.RefreshChartBeliBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RefreshChartBeliBtn.BorderRadius = 7;
            this.RefreshChartBeliBtn.ButtonText = "Segar";
            this.RefreshChartBeliBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RefreshChartBeliBtn.DisabledColor = System.Drawing.Color.DimGray;
            this.RefreshChartBeliBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.RefreshChartBeliBtn.Iconimage = null;
            this.RefreshChartBeliBtn.Iconimage_right = null;
            this.RefreshChartBeliBtn.Iconimage_right_Selected = null;
            this.RefreshChartBeliBtn.Iconimage_Selected = null;
            this.RefreshChartBeliBtn.IconMarginLeft = 0;
            this.RefreshChartBeliBtn.IconMarginRight = 0;
            this.RefreshChartBeliBtn.IconRightVisible = false;
            this.RefreshChartBeliBtn.IconRightZoom = 0D;
            this.RefreshChartBeliBtn.IconVisible = false;
            this.RefreshChartBeliBtn.IconZoom = 90D;
            this.RefreshChartBeliBtn.IsTab = false;
            this.RefreshChartBeliBtn.Location = new System.Drawing.Point(14, 207);
            this.RefreshChartBeliBtn.Name = "RefreshChartBeliBtn";
            this.RefreshChartBeliBtn.Normalcolor = System.Drawing.Color.DeepSkyBlue;
            this.RefreshChartBeliBtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.RefreshChartBeliBtn.OnHoverTextColor = System.Drawing.Color.White;
            this.RefreshChartBeliBtn.selected = false;
            this.RefreshChartBeliBtn.Size = new System.Drawing.Size(72, 26);
            this.RefreshChartBeliBtn.TabIndex = 30;
            this.RefreshChartBeliBtn.Text = "Segar";
            this.RefreshChartBeliBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RefreshChartBeliBtn.Textcolor = System.Drawing.Color.White;
            this.RefreshChartBeliBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RefreshChartBeliBtn.Click += new System.EventHandler(this.bunifuFlatButton6_Click);
            // 
            // GrafikBeli
            // 
            chartArea2.Name = "ChartArea1";
            this.GrafikBeli.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.GrafikBeli.Legends.Add(legend2);
            this.GrafikBeli.Location = new System.Drawing.Point(6, 54);
            this.GrafikBeli.Name = "GrafikBeli";
            series2.BorderWidth = 8;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.IsValueShownAsLabel = true;
            series2.LabelBorderWidth = 5;
            series2.Legend = "Legend1";
            series2.MarkerBorderWidth = 5;
            series2.MarkerColor = System.Drawing.Color.Red;
            series2.Name = "Pembelian";
            this.GrafikBeli.Series.Add(series2);
            this.GrafikBeli.Size = new System.Drawing.Size(500, 147);
            this.GrafikBeli.TabIndex = 0;
            this.GrafikBeli.Text = "chart1";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.bunifuFlatButton4);
            this.groupBox7.Controls.Add(this.bunifuFlatButton3);
            this.groupBox7.Controls.Add(this.HapusUser);
            this.groupBox7.Controls.Add(this.UbahUser);
            this.groupBox7.Controls.Add(this.TambahUser);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Controls.Add(this.PasswordTeks);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.UsernameTeks);
            this.groupBox7.Controls.Add(this.metroGrid3);
            this.groupBox7.Location = new System.Drawing.Point(7, 7);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(513, 187);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Manajemen User";
            this.groupBox7.Enter += new System.EventHandler(this.groupBox7_Enter);
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 7;
            this.bunifuFlatButton4.ButtonText = "Bersih";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.DimGray;
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = null;
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = false;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = false;
            this.bunifuFlatButton4.IconZoom = 90D;
            this.bunifuFlatButton4.IsTab = false;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(433, 146);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.Gainsboro;
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(68, 32);
            this.bunifuFlatButton4.TabIndex = 27;
            this.bunifuFlatButton4.Text = "Bersih";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton4.Click += new System.EventHandler(this.bunifuFlatButton4_Click);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 7;
            this.bunifuFlatButton3.ButtonText = "Segar";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.DimGray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = null;
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = false;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = false;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(362, 146);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(68, 32);
            this.bunifuFlatButton3.TabIndex = 26;
            this.bunifuFlatButton3.Text = "Segar";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // HapusUser
            // 
            this.HapusUser.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.HapusUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.HapusUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.HapusUser.BorderRadius = 7;
            this.HapusUser.ButtonText = "Hapus";
            this.HapusUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HapusUser.DisabledColor = System.Drawing.Color.DimGray;
            this.HapusUser.Enabled = false;
            this.HapusUser.Iconcolor = System.Drawing.Color.Transparent;
            this.HapusUser.Iconimage = null;
            this.HapusUser.Iconimage_right = null;
            this.HapusUser.Iconimage_right_Selected = null;
            this.HapusUser.Iconimage_Selected = null;
            this.HapusUser.IconMarginLeft = 0;
            this.HapusUser.IconMarginRight = 0;
            this.HapusUser.IconRightVisible = false;
            this.HapusUser.IconRightZoom = 0D;
            this.HapusUser.IconVisible = false;
            this.HapusUser.IconZoom = 90D;
            this.HapusUser.IsTab = false;
            this.HapusUser.Location = new System.Drawing.Point(288, 146);
            this.HapusUser.Name = "HapusUser";
            this.HapusUser.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.HapusUser.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.HapusUser.OnHoverTextColor = System.Drawing.Color.White;
            this.HapusUser.selected = false;
            this.HapusUser.Size = new System.Drawing.Size(68, 32);
            this.HapusUser.TabIndex = 25;
            this.HapusUser.Text = "Hapus";
            this.HapusUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.HapusUser.Textcolor = System.Drawing.Color.White;
            this.HapusUser.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HapusUser.Click += new System.EventHandler(this.HapusUser_Click);
            // 
            // UbahUser
            // 
            this.UbahUser.Activecolor = System.Drawing.Color.Blue;
            this.UbahUser.BackColor = System.Drawing.Color.Blue;
            this.UbahUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.UbahUser.BorderRadius = 7;
            this.UbahUser.ButtonText = "Ubah";
            this.UbahUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UbahUser.DisabledColor = System.Drawing.Color.DimGray;
            this.UbahUser.Enabled = false;
            this.UbahUser.Iconcolor = System.Drawing.Color.Transparent;
            this.UbahUser.Iconimage = null;
            this.UbahUser.Iconimage_right = null;
            this.UbahUser.Iconimage_right_Selected = null;
            this.UbahUser.Iconimage_Selected = null;
            this.UbahUser.IconMarginLeft = 0;
            this.UbahUser.IconMarginRight = 0;
            this.UbahUser.IconRightVisible = false;
            this.UbahUser.IconRightZoom = 0D;
            this.UbahUser.IconVisible = false;
            this.UbahUser.IconZoom = 90D;
            this.UbahUser.IsTab = false;
            this.UbahUser.Location = new System.Drawing.Point(396, 108);
            this.UbahUser.Name = "UbahUser";
            this.UbahUser.Normalcolor = System.Drawing.Color.Blue;
            this.UbahUser.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.UbahUser.OnHoverTextColor = System.Drawing.Color.White;
            this.UbahUser.selected = false;
            this.UbahUser.Size = new System.Drawing.Size(105, 32);
            this.UbahUser.TabIndex = 24;
            this.UbahUser.Text = "Ubah";
            this.UbahUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.UbahUser.Textcolor = System.Drawing.Color.White;
            this.UbahUser.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UbahUser.Click += new System.EventHandler(this.UbahUser_Click);
            // 
            // TambahUser
            // 
            this.TambahUser.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.TambahUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.TambahUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TambahUser.BorderRadius = 7;
            this.TambahUser.ButtonText = "Tambah";
            this.TambahUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TambahUser.DisabledColor = System.Drawing.Color.DimGray;
            this.TambahUser.Iconcolor = System.Drawing.Color.Transparent;
            this.TambahUser.Iconimage = null;
            this.TambahUser.Iconimage_right = null;
            this.TambahUser.Iconimage_right_Selected = null;
            this.TambahUser.Iconimage_Selected = null;
            this.TambahUser.IconMarginLeft = 0;
            this.TambahUser.IconMarginRight = 0;
            this.TambahUser.IconRightVisible = false;
            this.TambahUser.IconRightZoom = 0D;
            this.TambahUser.IconVisible = false;
            this.TambahUser.IconZoom = 90D;
            this.TambahUser.IsTab = false;
            this.TambahUser.Location = new System.Drawing.Point(288, 108);
            this.TambahUser.Name = "TambahUser";
            this.TambahUser.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.TambahUser.OnHovercolor = System.Drawing.Color.Lime;
            this.TambahUser.OnHoverTextColor = System.Drawing.Color.White;
            this.TambahUser.selected = false;
            this.TambahUser.Size = new System.Drawing.Size(102, 32);
            this.TambahUser.TabIndex = 23;
            this.TambahUser.Text = "Tambah";
            this.TambahUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.TambahUser.Textcolor = System.Drawing.Color.White;
            this.TambahUser.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TambahUser.Click += new System.EventHandler(this.TambahUser_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(285, 63);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 16);
            this.label16.TabIndex = 22;
            this.label16.Text = "Password";
            // 
            // PasswordTeks
            // 
            // 
            // 
            // 
            this.PasswordTeks.CustomButton.Image = null;
            this.PasswordTeks.CustomButton.Location = new System.Drawing.Point(117, 1);
            this.PasswordTeks.CustomButton.Name = "";
            this.PasswordTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PasswordTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PasswordTeks.CustomButton.TabIndex = 1;
            this.PasswordTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PasswordTeks.CustomButton.UseSelectable = true;
            this.PasswordTeks.CustomButton.Visible = false;
            this.PasswordTeks.Lines = new string[0];
            this.PasswordTeks.Location = new System.Drawing.Point(362, 63);
            this.PasswordTeks.MaxLength = 32767;
            this.PasswordTeks.Name = "PasswordTeks";
            this.PasswordTeks.PasswordChar = '\0';
            this.PasswordTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PasswordTeks.SelectedText = "";
            this.PasswordTeks.SelectionLength = 0;
            this.PasswordTeks.SelectionStart = 0;
            this.PasswordTeks.ShortcutsEnabled = true;
            this.PasswordTeks.Size = new System.Drawing.Size(139, 23);
            this.PasswordTeks.TabIndex = 21;
            this.PasswordTeks.UseSelectable = true;
            this.PasswordTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PasswordTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(285, 34);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 16);
            this.label15.TabIndex = 20;
            this.label15.Text = "Username";
            // 
            // UsernameTeks
            // 
            // 
            // 
            // 
            this.UsernameTeks.CustomButton.Image = null;
            this.UsernameTeks.CustomButton.Location = new System.Drawing.Point(117, 1);
            this.UsernameTeks.CustomButton.Name = "";
            this.UsernameTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.UsernameTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.UsernameTeks.CustomButton.TabIndex = 1;
            this.UsernameTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.UsernameTeks.CustomButton.UseSelectable = true;
            this.UsernameTeks.CustomButton.Visible = false;
            this.UsernameTeks.Lines = new string[0];
            this.UsernameTeks.Location = new System.Drawing.Point(362, 34);
            this.UsernameTeks.MaxLength = 32767;
            this.UsernameTeks.Name = "UsernameTeks";
            this.UsernameTeks.PasswordChar = '\0';
            this.UsernameTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.UsernameTeks.SelectedText = "";
            this.UsernameTeks.SelectionLength = 0;
            this.UsernameTeks.SelectionStart = 0;
            this.UsernameTeks.ShortcutsEnabled = true;
            this.UsernameTeks.Size = new System.Drawing.Size(139, 23);
            this.UsernameTeks.TabIndex = 1;
            this.UsernameTeks.UseSelectable = true;
            this.UsernameTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.UsernameTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroGrid3
            // 
            this.metroGrid3.AllowUserToResizeRows = false;
            this.metroGrid3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.metroGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.metroGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid3.DefaultCellStyle = dataGridViewCellStyle11;
            this.metroGrid3.EnableHeadersVisualStyles = false;
            this.metroGrid3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.Location = new System.Drawing.Point(7, 20);
            this.metroGrid3.Name = "metroGrid3";
            this.metroGrid3.ReadOnly = true;
            this.metroGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.metroGrid3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid3.Size = new System.Drawing.Size(272, 158);
            this.metroGrid3.TabIndex = 0;
            this.metroGrid3.Click += new System.EventHandler(this.metroGrid3_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.metroButton12);
            this.tabPage4.Controls.Add(this.metroButton11);
            this.tabPage4.Controls.Add(this.StatusBulan);
            this.tabPage4.Controls.Add(this.LabelUntungHari);
            this.tabPage4.Controls.Add(this.label42);
            this.tabPage4.Controls.Add(this.label41);
            this.tabPage4.Controls.Add(this.label40);
            this.tabPage4.Controls.Add(this.label39);
            this.tabPage4.Controls.Add(this.groupBox12);
            this.tabPage4.Controls.Add(this.metroButton7);
            this.tabPage4.Controls.Add(this.metroButton6);
            this.tabPage4.Controls.Add(this.metroButton5);
            this.tabPage4.Controls.Add(this.metroButton4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1086, 436);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Laporan Barang";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // metroButton12
            // 
            this.metroButton12.Location = new System.Drawing.Point(900, 80);
            this.metroButton12.Name = "metroButton12";
            this.metroButton12.Size = new System.Drawing.Size(74, 20);
            this.metroButton12.TabIndex = 21;
            this.metroButton12.Text = "Segarkan";
            this.metroButton12.UseSelectable = true;
            this.metroButton12.Click += new System.EventHandler(this.metroButton12_Click);
            // 
            // metroButton11
            // 
            this.metroButton11.Location = new System.Drawing.Point(516, 81);
            this.metroButton11.Name = "metroButton11";
            this.metroButton11.Size = new System.Drawing.Size(74, 20);
            this.metroButton11.TabIndex = 20;
            this.metroButton11.Text = "Segarkan";
            this.metroButton11.UseSelectable = true;
            this.metroButton11.Click += new System.EventHandler(this.metroButton11_Click);
            // 
            // StatusBulan
            // 
            this.StatusBulan.AutoSize = true;
            this.StatusBulan.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusBulan.Location = new System.Drawing.Point(727, 81);
            this.StatusBulan.Name = "StatusBulan";
            this.StatusBulan.Size = new System.Drawing.Size(19, 21);
            this.StatusBulan.TabIndex = 10;
            this.StatusBulan.Text = "0";
            // 
            // LabelUntungHari
            // 
            this.LabelUntungHari.AutoSize = true;
            this.LabelUntungHari.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelUntungHari.Location = new System.Drawing.Point(242, 81);
            this.LabelUntungHari.Name = "LabelUntungHari";
            this.LabelUntungHari.Size = new System.Drawing.Size(17, 19);
            this.LabelUntungHari.TabIndex = 9;
            this.LabelUntungHari.Text = "0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(717, 80);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(14, 21);
            this.label42.TabIndex = 8;
            this.label42.Text = ":";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(596, 80);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(127, 21);
            this.label41.TabIndex = 7;
            this.label41.Text = "Status Bulan Ini";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(232, 80);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(14, 21);
            this.label40.TabIndex = 6;
            this.label40.Text = ":";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(75, 80);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(158, 21);
            this.label39.TabIndex = 5;
            this.label39.Text = "Keuntungan Hari Ini";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label43);
            this.groupBox12.Controls.Add(this.metroButton10);
            this.groupBox12.Controls.Add(this.ChartUntungRugi);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Location = new System.Drawing.Point(79, 107);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(895, 329);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Untung / Rugi";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(7, 304);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(0, 13);
            this.label43.TabIndex = 20;
            // 
            // metroButton10
            // 
            this.metroButton10.Location = new System.Drawing.Point(6, 277);
            this.metroButton10.Name = "metroButton10";
            this.metroButton10.Size = new System.Drawing.Size(174, 20);
            this.metroButton10.TabIndex = 19;
            this.metroButton10.Text = "Segarkan Chart";
            this.metroButton10.UseSelectable = true;
            this.metroButton10.Click += new System.EventHandler(this.metroButton10_Click_1);
            // 
            // ChartUntungRugi
            // 
            chartArea3.Name = "ChartArea1";
            this.ChartUntungRugi.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.ChartUntungRugi.Legends.Add(legend3);
            this.ChartUntungRugi.Location = new System.Drawing.Point(6, 19);
            this.ChartUntungRugi.Name = "ChartUntungRugi";
            this.ChartUntungRugi.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series3.BorderWidth = 8;
            series3.ChartArea = "ChartArea1";
            series3.IsValueShownAsLabel = true;
            series3.Legend = "Legend1";
            series3.Name = "Laporan";
            this.ChartUntungRugi.Series.Add(series3);
            this.ChartUntungRugi.Size = new System.Drawing.Size(537, 252);
            this.ChartUntungRugi.TabIndex = 1;
            this.ChartUntungRugi.Text = "chart1";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.HitungTotalButton);
            this.groupBox13.Controls.Add(this.label37);
            this.groupBox13.Controls.Add(this.label38);
            this.groupBox13.Controls.Add(this.TotalPengeluaran);
            this.groupBox13.Controls.Add(this.label36);
            this.groupBox13.Controls.Add(this.label35);
            this.groupBox13.Controls.Add(this.label34);
            this.groupBox13.Controls.Add(this.label33);
            this.groupBox13.Controls.Add(this.label32);
            this.groupBox13.Controls.Add(this.label31);
            this.groupBox13.Controls.Add(this.PengeluaranTeks);
            this.groupBox13.Controls.Add(this.label30);
            this.groupBox13.Controls.Add(this.InternetTeks);
            this.groupBox13.Controls.Add(this.label29);
            this.groupBox13.Controls.Add(this.GajiKaryawanTeks);
            this.groupBox13.Controls.Add(this.label28);
            this.groupBox13.Controls.Add(this.AirTeks);
            this.groupBox13.Controls.Add(this.label27);
            this.groupBox13.Controls.Add(this.ListrikTeks);
            this.groupBox13.Location = new System.Drawing.Point(549, 20);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(340, 304);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Pengeluaran Selama Sebulan";
            // 
            // HitungTotalButton
            // 
            this.HitungTotalButton.Location = new System.Drawing.Point(156, 231);
            this.HitungTotalButton.Name = "HitungTotalButton";
            this.HitungTotalButton.Size = new System.Drawing.Size(174, 20);
            this.HitungTotalButton.TabIndex = 18;
            this.HitungTotalButton.Text = "Hitung Total";
            this.HitungTotalButton.UseSelectable = true;
            this.HitungTotalButton.Click += new System.EventHandler(this.HitungTotalButton_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(138, 257);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(12, 19);
            this.label37.TabIndex = 17;
            this.label37.Text = ":";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(6, 257);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(39, 19);
            this.label38.TabIndex = 16;
            this.label38.Text = "Total";
            // 
            // TotalPengeluaran
            // 
            // 
            // 
            // 
            this.TotalPengeluaran.CustomButton.Image = null;
            this.TotalPengeluaran.CustomButton.Location = new System.Drawing.Point(153, 1);
            this.TotalPengeluaran.CustomButton.Name = "";
            this.TotalPengeluaran.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TotalPengeluaran.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TotalPengeluaran.CustomButton.TabIndex = 1;
            this.TotalPengeluaran.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TotalPengeluaran.CustomButton.UseSelectable = true;
            this.TotalPengeluaran.CustomButton.Visible = false;
            this.TotalPengeluaran.Lines = new string[0];
            this.TotalPengeluaran.Location = new System.Drawing.Point(156, 257);
            this.TotalPengeluaran.MaxLength = 32767;
            this.TotalPengeluaran.Name = "TotalPengeluaran";
            this.TotalPengeluaran.PasswordChar = '\0';
            this.TotalPengeluaran.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TotalPengeluaran.SelectedText = "";
            this.TotalPengeluaran.SelectionLength = 0;
            this.TotalPengeluaran.SelectionStart = 0;
            this.TotalPengeluaran.ShortcutsEnabled = true;
            this.TotalPengeluaran.Size = new System.Drawing.Size(175, 23);
            this.TotalPengeluaran.TabIndex = 15;
            this.TotalPengeluaran.UseSelectable = true;
            this.TotalPengeluaran.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TotalPengeluaran.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.TotalPengeluaran.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TotalPengeluaran_KeyPress);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(138, 201);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(12, 19);
            this.label36.TabIndex = 14;
            this.label36.Text = ":";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(138, 161);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(12, 19);
            this.label35.TabIndex = 13;
            this.label35.Text = ":";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(138, 43);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(12, 19);
            this.label34.TabIndex = 12;
            this.label34.Text = ":";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(138, 83);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(12, 19);
            this.label33.TabIndex = 11;
            this.label33.Text = ":";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(138, 125);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(12, 19);
            this.label32.TabIndex = 10;
            this.label32.Text = ":";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(6, 201);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(112, 19);
            this.label31.TabIndex = 9;
            this.label31.Text = "Pengeluaran Lain";
            // 
            // PengeluaranTeks
            // 
            // 
            // 
            // 
            this.PengeluaranTeks.CustomButton.Image = null;
            this.PengeluaranTeks.CustomButton.Location = new System.Drawing.Point(153, 1);
            this.PengeluaranTeks.CustomButton.Name = "";
            this.PengeluaranTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PengeluaranTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PengeluaranTeks.CustomButton.TabIndex = 1;
            this.PengeluaranTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PengeluaranTeks.CustomButton.UseSelectable = true;
            this.PengeluaranTeks.CustomButton.Visible = false;
            this.PengeluaranTeks.Lines = new string[0];
            this.PengeluaranTeks.Location = new System.Drawing.Point(156, 201);
            this.PengeluaranTeks.MaxLength = 32767;
            this.PengeluaranTeks.Name = "PengeluaranTeks";
            this.PengeluaranTeks.PasswordChar = '\0';
            this.PengeluaranTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PengeluaranTeks.SelectedText = "";
            this.PengeluaranTeks.SelectionLength = 0;
            this.PengeluaranTeks.SelectionStart = 0;
            this.PengeluaranTeks.ShortcutsEnabled = true;
            this.PengeluaranTeks.Size = new System.Drawing.Size(175, 23);
            this.PengeluaranTeks.TabIndex = 8;
            this.PengeluaranTeks.UseSelectable = true;
            this.PengeluaranTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PengeluaranTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.PengeluaranTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PengeluaranTeks_KeyPress);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 161);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 19);
            this.label30.TabIndex = 7;
            this.label30.Text = "Internet";
            // 
            // InternetTeks
            // 
            // 
            // 
            // 
            this.InternetTeks.CustomButton.Image = null;
            this.InternetTeks.CustomButton.Location = new System.Drawing.Point(153, 1);
            this.InternetTeks.CustomButton.Name = "";
            this.InternetTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.InternetTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.InternetTeks.CustomButton.TabIndex = 1;
            this.InternetTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.InternetTeks.CustomButton.UseSelectable = true;
            this.InternetTeks.CustomButton.Visible = false;
            this.InternetTeks.Lines = new string[0];
            this.InternetTeks.Location = new System.Drawing.Point(156, 161);
            this.InternetTeks.MaxLength = 32767;
            this.InternetTeks.Name = "InternetTeks";
            this.InternetTeks.PasswordChar = '\0';
            this.InternetTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.InternetTeks.SelectedText = "";
            this.InternetTeks.SelectionLength = 0;
            this.InternetTeks.SelectionStart = 0;
            this.InternetTeks.ShortcutsEnabled = true;
            this.InternetTeks.Size = new System.Drawing.Size(175, 23);
            this.InternetTeks.TabIndex = 6;
            this.InternetTeks.UseSelectable = true;
            this.InternetTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.InternetTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.InternetTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.InternetTeks_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(6, 125);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(135, 19);
            this.label29.TabIndex = 5;
            this.label29.Text = "Total Gaji Karyawan";
            // 
            // GajiKaryawanTeks
            // 
            // 
            // 
            // 
            this.GajiKaryawanTeks.CustomButton.Image = null;
            this.GajiKaryawanTeks.CustomButton.Location = new System.Drawing.Point(153, 1);
            this.GajiKaryawanTeks.CustomButton.Name = "";
            this.GajiKaryawanTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.GajiKaryawanTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.GajiKaryawanTeks.CustomButton.TabIndex = 1;
            this.GajiKaryawanTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.GajiKaryawanTeks.CustomButton.UseSelectable = true;
            this.GajiKaryawanTeks.CustomButton.Visible = false;
            this.GajiKaryawanTeks.Lines = new string[0];
            this.GajiKaryawanTeks.Location = new System.Drawing.Point(156, 121);
            this.GajiKaryawanTeks.MaxLength = 32767;
            this.GajiKaryawanTeks.Name = "GajiKaryawanTeks";
            this.GajiKaryawanTeks.PasswordChar = '\0';
            this.GajiKaryawanTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.GajiKaryawanTeks.SelectedText = "";
            this.GajiKaryawanTeks.SelectionLength = 0;
            this.GajiKaryawanTeks.SelectionStart = 0;
            this.GajiKaryawanTeks.ShortcutsEnabled = true;
            this.GajiKaryawanTeks.Size = new System.Drawing.Size(175, 23);
            this.GajiKaryawanTeks.TabIndex = 4;
            this.GajiKaryawanTeks.UseSelectable = true;
            this.GajiKaryawanTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.GajiKaryawanTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.GajiKaryawanTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GajiKaryawanTeks_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(6, 83);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(28, 19);
            this.label28.TabIndex = 3;
            this.label28.Text = "Air";
            // 
            // AirTeks
            // 
            // 
            // 
            // 
            this.AirTeks.CustomButton.Image = null;
            this.AirTeks.CustomButton.Location = new System.Drawing.Point(153, 1);
            this.AirTeks.CustomButton.Name = "";
            this.AirTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.AirTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.AirTeks.CustomButton.TabIndex = 1;
            this.AirTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.AirTeks.CustomButton.UseSelectable = true;
            this.AirTeks.CustomButton.Visible = false;
            this.AirTeks.Lines = new string[0];
            this.AirTeks.Location = new System.Drawing.Point(156, 79);
            this.AirTeks.MaxLength = 32767;
            this.AirTeks.Name = "AirTeks";
            this.AirTeks.PasswordChar = '\0';
            this.AirTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.AirTeks.SelectedText = "";
            this.AirTeks.SelectionLength = 0;
            this.AirTeks.SelectionStart = 0;
            this.AirTeks.ShortcutsEnabled = true;
            this.AirTeks.Size = new System.Drawing.Size(175, 23);
            this.AirTeks.TabIndex = 2;
            this.AirTeks.UseSelectable = true;
            this.AirTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.AirTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.AirTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AirTeks_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(6, 43);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 19);
            this.label27.TabIndex = 1;
            this.label27.Text = "Listrik";
            // 
            // ListrikTeks
            // 
            // 
            // 
            // 
            this.ListrikTeks.CustomButton.Image = null;
            this.ListrikTeks.CustomButton.Location = new System.Drawing.Point(153, 1);
            this.ListrikTeks.CustomButton.Name = "";
            this.ListrikTeks.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.ListrikTeks.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.ListrikTeks.CustomButton.TabIndex = 1;
            this.ListrikTeks.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.ListrikTeks.CustomButton.UseSelectable = true;
            this.ListrikTeks.CustomButton.Visible = false;
            this.ListrikTeks.Lines = new string[0];
            this.ListrikTeks.Location = new System.Drawing.Point(156, 39);
            this.ListrikTeks.MaxLength = 32767;
            this.ListrikTeks.Name = "ListrikTeks";
            this.ListrikTeks.PasswordChar = '\0';
            this.ListrikTeks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ListrikTeks.SelectedText = "";
            this.ListrikTeks.SelectionLength = 0;
            this.ListrikTeks.SelectionStart = 0;
            this.ListrikTeks.ShortcutsEnabled = true;
            this.ListrikTeks.Size = new System.Drawing.Size(175, 23);
            this.ListrikTeks.TabIndex = 0;
            this.ListrikTeks.UseSelectable = true;
            this.ListrikTeks.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.ListrikTeks.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.ListrikTeks.Click += new System.EventHandler(this.metroTextBox1_Click);
            this.ListrikTeks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListrikTeks_KeyPress);
            // 
            // metroButton7
            // 
            this.metroButton7.Location = new System.Drawing.Point(755, 19);
            this.metroButton7.Name = "metroButton7";
            this.metroButton7.Size = new System.Drawing.Size(175, 47);
            this.metroButton7.TabIndex = 3;
            this.metroButton7.Text = "Print Supplier";
            this.metroButton7.UseSelectable = true;
            this.metroButton7.Click += new System.EventHandler(this.metroButton7_Click);
            // 
            // metroButton6
            // 
            this.metroButton6.Location = new System.Drawing.Point(541, 19);
            this.metroButton6.Name = "metroButton6";
            this.metroButton6.Size = new System.Drawing.Size(175, 47);
            this.metroButton6.TabIndex = 2;
            this.metroButton6.Text = "Print Laporan Pembelian";
            this.metroButton6.UseSelectable = true;
            this.metroButton6.Click += new System.EventHandler(this.metroButton6_Click);
            // 
            // metroButton5
            // 
            this.metroButton5.Location = new System.Drawing.Point(325, 19);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(175, 47);
            this.metroButton5.TabIndex = 1;
            this.metroButton5.Text = "Print Laporan Penjualan";
            this.metroButton5.UseSelectable = true;
            this.metroButton5.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // metroButton4
            // 
            this.metroButton4.Location = new System.Drawing.Point(109, 19);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(175, 47);
            this.metroButton4.TabIndex = 0;
            this.metroButton4.Text = "Print Laporan Stok Barang";
            this.metroButton4.UseSelectable = true;
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox15);
            this.tabPage6.Controls.Add(this.groupBox14);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1086, 436);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Profil Usaha";
            this.tabPage6.UseVisualStyleBackColor = true;
            this.tabPage6.Click += new System.EventHandler(this.tabPage6_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.groupBox16);
            this.groupBox15.Controls.Add(this.NamaLabel);
            this.groupBox15.Controls.Add(this.KeteranganLabel);
            this.groupBox15.Controls.Add(this.EmailLabel);
            this.groupBox15.Controls.Add(this.TeleponLabel);
            this.groupBox15.Location = new System.Drawing.Point(390, 26);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(690, 410);
            this.groupBox15.TabIndex = 49;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Profil";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.AlamatLabel);
            this.groupBox16.Location = new System.Drawing.Point(6, 214);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(678, 43);
            this.groupBox16.TabIndex = 49;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Alamat";
            // 
            // AlamatLabel
            // 
            this.AlamatLabel.AutoSize = true;
            this.AlamatLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AlamatLabel.Location = new System.Drawing.Point(9, 16);
            this.AlamatLabel.Name = "AlamatLabel";
            this.AlamatLabel.Size = new System.Drawing.Size(186, 20);
            this.AlamatLabel.TabIndex = 48;
            this.AlamatLabel.Text = "*(Alamat Usaha Disini)*";
            this.AlamatLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NamaLabel
            // 
            this.NamaLabel.AutoSize = true;
            this.NamaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamaLabel.Location = new System.Drawing.Point(213, 53);
            this.NamaLabel.Name = "NamaLabel";
            this.NamaLabel.Size = new System.Drawing.Size(253, 29);
            this.NamaLabel.TabIndex = 45;
            this.NamaLabel.Text = "*(Nama Usaha Disini)*";
            this.NamaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // KeteranganLabel
            // 
            this.KeteranganLabel.AutoSize = true;
            this.KeteranganLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeteranganLabel.Location = new System.Drawing.Point(201, 270);
            this.KeteranganLabel.Name = "KeteranganLabel";
            this.KeteranganLabel.Size = new System.Drawing.Size(0, 25);
            this.KeteranganLabel.TabIndex = 46;
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailLabel.Location = new System.Drawing.Point(377, 138);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(176, 20);
            this.EmailLabel.TabIndex = 47;
            this.EmailLabel.Text = "*(Email Usaha Disini)*";
            this.EmailLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TeleponLabel
            // 
            this.TeleponLabel.AutoSize = true;
            this.TeleponLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleponLabel.Location = new System.Drawing.Point(134, 138);
            this.TeleponLabel.Name = "TeleponLabel";
            this.TeleponLabel.Size = new System.Drawing.Size(193, 20);
            this.TeleponLabel.TabIndex = 46;
            this.TeleponLabel.Text = "*(Telepon Usaha Disini)*";
            this.TeleponLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.metroButton13);
            this.groupBox14.Controls.Add(this.label48);
            this.groupBox14.Controls.Add(this.KeteranganUsaha);
            this.groupBox14.Controls.Add(this.label47);
            this.groupBox14.Controls.Add(this.EmailUsaha);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Controls.Add(this.TeleponUsaha);
            this.groupBox14.Controls.Add(this.label45);
            this.groupBox14.Controls.Add(this.AlamatUsaha);
            this.groupBox14.Controls.Add(this.label44);
            this.groupBox14.Controls.Add(this.NamaUsaha);
            this.groupBox14.Location = new System.Drawing.Point(27, 26);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(357, 388);
            this.groupBox14.TabIndex = 0;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Profil Usaha";
            // 
            // metroButton13
            // 
            this.metroButton13.Location = new System.Drawing.Point(162, 353);
            this.metroButton13.Name = "metroButton13";
            this.metroButton13.Size = new System.Drawing.Size(188, 23);
            this.metroButton13.TabIndex = 44;
            this.metroButton13.Text = "Simpan";
            this.metroButton13.UseSelectable = true;
            this.metroButton13.Click += new System.EventHandler(this.metroButton13_Click);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(17, 251);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(92, 20);
            this.label48.TabIndex = 43;
            this.label48.Text = "Keterangan";
            // 
            // KeteranganUsaha
            // 
            // 
            // 
            // 
            this.KeteranganUsaha.CustomButton.Image = null;
            this.KeteranganUsaha.CustomButton.Location = new System.Drawing.Point(101, 2);
            this.KeteranganUsaha.CustomButton.Name = "";
            this.KeteranganUsaha.CustomButton.Size = new System.Drawing.Size(85, 85);
            this.KeteranganUsaha.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.KeteranganUsaha.CustomButton.TabIndex = 1;
            this.KeteranganUsaha.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.KeteranganUsaha.CustomButton.UseSelectable = true;
            this.KeteranganUsaha.CustomButton.Visible = false;
            this.KeteranganUsaha.Lines = new string[0];
            this.KeteranganUsaha.Location = new System.Drawing.Point(162, 248);
            this.KeteranganUsaha.MaxLength = 32767;
            this.KeteranganUsaha.Multiline = true;
            this.KeteranganUsaha.Name = "KeteranganUsaha";
            this.KeteranganUsaha.PasswordChar = '\0';
            this.KeteranganUsaha.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.KeteranganUsaha.SelectedText = "";
            this.KeteranganUsaha.SelectionLength = 0;
            this.KeteranganUsaha.SelectionStart = 0;
            this.KeteranganUsaha.ShortcutsEnabled = true;
            this.KeteranganUsaha.Size = new System.Drawing.Size(189, 90);
            this.KeteranganUsaha.TabIndex = 42;
            this.KeteranganUsaha.UseSelectable = true;
            this.KeteranganUsaha.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.KeteranganUsaha.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(17, 199);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(99, 20);
            this.label47.TabIndex = 41;
            this.label47.Text = "Email Usaha";
            // 
            // EmailUsaha
            // 
            // 
            // 
            // 
            this.EmailUsaha.CustomButton.Image = null;
            this.EmailUsaha.CustomButton.Location = new System.Drawing.Point(167, 1);
            this.EmailUsaha.CustomButton.Name = "";
            this.EmailUsaha.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.EmailUsaha.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.EmailUsaha.CustomButton.TabIndex = 1;
            this.EmailUsaha.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.EmailUsaha.CustomButton.UseSelectable = true;
            this.EmailUsaha.CustomButton.Visible = false;
            this.EmailUsaha.Lines = new string[0];
            this.EmailUsaha.Location = new System.Drawing.Point(162, 196);
            this.EmailUsaha.MaxLength = 32767;
            this.EmailUsaha.Name = "EmailUsaha";
            this.EmailUsaha.PasswordChar = '\0';
            this.EmailUsaha.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.EmailUsaha.SelectedText = "";
            this.EmailUsaha.SelectionLength = 0;
            this.EmailUsaha.SelectionStart = 0;
            this.EmailUsaha.ShortcutsEnabled = true;
            this.EmailUsaha.Size = new System.Drawing.Size(189, 23);
            this.EmailUsaha.TabIndex = 40;
            this.EmailUsaha.UseSelectable = true;
            this.EmailUsaha.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.EmailUsaha.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(17, 141);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(117, 20);
            this.label46.TabIndex = 39;
            this.label46.Text = "Telepon Usaha";
            // 
            // TeleponUsaha
            // 
            // 
            // 
            // 
            this.TeleponUsaha.CustomButton.Image = null;
            this.TeleponUsaha.CustomButton.Location = new System.Drawing.Point(167, 1);
            this.TeleponUsaha.CustomButton.Name = "";
            this.TeleponUsaha.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TeleponUsaha.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TeleponUsaha.CustomButton.TabIndex = 1;
            this.TeleponUsaha.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TeleponUsaha.CustomButton.UseSelectable = true;
            this.TeleponUsaha.CustomButton.Visible = false;
            this.TeleponUsaha.Lines = new string[0];
            this.TeleponUsaha.Location = new System.Drawing.Point(162, 138);
            this.TeleponUsaha.MaxLength = 32767;
            this.TeleponUsaha.Name = "TeleponUsaha";
            this.TeleponUsaha.PasswordChar = '\0';
            this.TeleponUsaha.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TeleponUsaha.SelectedText = "";
            this.TeleponUsaha.SelectionLength = 0;
            this.TeleponUsaha.SelectionStart = 0;
            this.TeleponUsaha.ShortcutsEnabled = true;
            this.TeleponUsaha.Size = new System.Drawing.Size(189, 23);
            this.TeleponUsaha.TabIndex = 38;
            this.TeleponUsaha.UseSelectable = true;
            this.TeleponUsaha.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TeleponUsaha.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(17, 82);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(110, 20);
            this.label45.TabIndex = 37;
            this.label45.Text = "Alamat Usaha";
            // 
            // AlamatUsaha
            // 
            // 
            // 
            // 
            this.AlamatUsaha.CustomButton.Image = null;
            this.AlamatUsaha.CustomButton.Location = new System.Drawing.Point(167, 1);
            this.AlamatUsaha.CustomButton.Name = "";
            this.AlamatUsaha.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.AlamatUsaha.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.AlamatUsaha.CustomButton.TabIndex = 1;
            this.AlamatUsaha.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.AlamatUsaha.CustomButton.UseSelectable = true;
            this.AlamatUsaha.CustomButton.Visible = false;
            this.AlamatUsaha.Lines = new string[0];
            this.AlamatUsaha.Location = new System.Drawing.Point(162, 79);
            this.AlamatUsaha.MaxLength = 32767;
            this.AlamatUsaha.Name = "AlamatUsaha";
            this.AlamatUsaha.PasswordChar = '\0';
            this.AlamatUsaha.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.AlamatUsaha.SelectedText = "";
            this.AlamatUsaha.SelectionLength = 0;
            this.AlamatUsaha.SelectionStart = 0;
            this.AlamatUsaha.ShortcutsEnabled = true;
            this.AlamatUsaha.Size = new System.Drawing.Size(189, 23);
            this.AlamatUsaha.TabIndex = 36;
            this.AlamatUsaha.UseSelectable = true;
            this.AlamatUsaha.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.AlamatUsaha.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(17, 32);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(102, 20);
            this.label44.TabIndex = 35;
            this.label44.Text = "Nama Usaha";
            // 
            // NamaUsaha
            // 
            // 
            // 
            // 
            this.NamaUsaha.CustomButton.Image = null;
            this.NamaUsaha.CustomButton.Location = new System.Drawing.Point(167, 1);
            this.NamaUsaha.CustomButton.Name = "";
            this.NamaUsaha.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NamaUsaha.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NamaUsaha.CustomButton.TabIndex = 1;
            this.NamaUsaha.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NamaUsaha.CustomButton.UseSelectable = true;
            this.NamaUsaha.CustomButton.Visible = false;
            this.NamaUsaha.Lines = new string[0];
            this.NamaUsaha.Location = new System.Drawing.Point(162, 29);
            this.NamaUsaha.MaxLength = 32767;
            this.NamaUsaha.Name = "NamaUsaha";
            this.NamaUsaha.PasswordChar = '\0';
            this.NamaUsaha.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NamaUsaha.SelectedText = "";
            this.NamaUsaha.SelectionLength = 0;
            this.NamaUsaha.SelectionStart = 0;
            this.NamaUsaha.ShortcutsEnabled = true;
            this.NamaUsaha.Size = new System.Drawing.Size(189, 23);
            this.NamaUsaha.TabIndex = 0;
            this.NamaUsaha.UseSelectable = true;
            this.NamaUsaha.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NamaUsaha.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // timer1
            // 
            this.timer1.Interval = 4000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1141, 540);
            this.Controls.Add(this.tabControl1);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid4)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrafikJual)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrafikBeli)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartUntungRugi)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private MetroFramework.Controls.MetroTextBox JumlahProdukTeks;
        private MetroFramework.Controls.MetroTextBox MerekProdukTeks;
        private MetroFramework.Controls.MetroTextBox JenisProdukTeks;
        private MetroFramework.Controls.MetroTextBox NamaProdukTeks;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroTextBox TotalHargaTeks;
        private MetroFramework.Controls.MetroTextBox NamaPembeliTeks;
        private MetroFramework.Controls.MetroComboBox Jumlah;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private MetroFramework.Controls.MetroDateTime TanggalKadaluarsaTeks;
        private MetroFramework.Controls.MetroTextBox HargaProdukTeks;
        private ns1.BunifuFlatButton JualButton;
        private ns1.BunifuFlatButton HapusButton;
        private ns1.BunifuFlatButton UbahButton;
        private ns1.BunifuFlatButton bunifuFlatButton2;
        private System.Windows.Forms.GroupBox groupBox4;
        private MetroFramework.Controls.MetroTextBox HargaProduk;
        private ns1.BunifuFlatButton TombolHapus;
        private MetroFramework.Controls.MetroTextBox JenisProduk;
        private System.Windows.Forms.GroupBox groupBox5;
        private MetroFramework.Controls.MetroDateTime TanggalPenjualan;
        private MetroFramework.Controls.MetroTextBox MerekProduk;
        private MetroFramework.Controls.MetroTextBox NamaProduk;
        private MetroFramework.Controls.MetroTextBox TotalHarga;
        private MetroFramework.Controls.MetroTextBox NamaPembeli;
        private MetroFramework.Controls.MetroGrid metroGrid2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroTextBox HargaBeliTeks;
        private ns1.BunifuFlatButton bunifuFlatButton1;
        private MetroFramework.Controls.MetroTextBox JumlahTerjual;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox JumlahBeliTeks;
        private System.Windows.Forms.GroupBox groupBox6;
        private MetroFramework.Controls.MetroDateTime TanggalBeliTeks;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label16;
        private MetroFramework.Controls.MetroTextBox PasswordTeks;
        private System.Windows.Forms.Label label15;
        private MetroFramework.Controls.MetroTextBox UsernameTeks;
        private MetroFramework.Controls.MetroGrid metroGrid3;
        private ns1.BunifuFlatButton HapusUser;
        private ns1.BunifuFlatButton UbahUser;
        private ns1.BunifuFlatButton TambahUser;
        private ns1.BunifuFlatButton bunifuFlatButton4;
        private ns1.BunifuFlatButton bunifuFlatButton3;
        private System.Windows.Forms.GroupBox groupBox9;
        private ns1.BunifuFlatButton RefreshChartJualBtn;
        private System.Windows.Forms.DataVisualization.Charting.Chart GrafikJual;
        private System.Windows.Forms.GroupBox groupBox8;
        private ns1.BunifuFlatButton RefreshChartBeliBtn;
        private System.Windows.Forms.DataVisualization.Charting.Chart GrafikBeli;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private ns1.BunifuFlatButton FindRangeJual;
        private ns1.BunifuFlatButton FindRangeBeli;
        private MetroFramework.Controls.MetroComboBox JualComboSecond;
        private MetroFramework.Controls.MetroComboBox JualCombo;
        private MetroFramework.Controls.MetroComboBox BeliComboSecond;
        private MetroFramework.Controls.MetroComboBox BeliCombo;
        private System.Windows.Forms.TabPage tabPage4;
        private MetroFramework.Controls.MetroButton metroButton7;
        private MetroFramework.Controls.MetroButton metroButton6;
        private MetroFramework.Controls.MetroButton metroButton5;
        private MetroFramework.Controls.MetroButton metroButton4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox10;
        private MetroFramework.Controls.MetroButton metroButton9;
        private MetroFramework.Controls.MetroButton metroButton8;
        private MetroFramework.Controls.MetroButton HapusSup;
        private MetroFramework.Controls.MetroButton UbahSup;
        private MetroFramework.Controls.MetroButton TambahSup;
        private System.Windows.Forms.GroupBox groupBox11;
        private MetroFramework.Controls.MetroDateTime TanggalDaftar;
        private MetroFramework.Controls.MetroTextBox EmailSupplier;
        private System.Windows.Forms.Label label24;
        private MetroFramework.Controls.MetroTextBox TeleponSupplier;
        private System.Windows.Forms.Label label23;
        private MetroFramework.Controls.MetroTextBox AlamatSupplier;
        private System.Windows.Forms.Label label21;
        private MetroFramework.Controls.MetroTextBox NamaSupplier;
        private System.Windows.Forms.Label label22;
        private MetroFramework.Controls.MetroGrid metroGrid4;
        private MetroFramework.Controls.MetroComboBox KodeSupplierTeks;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private MetroFramework.Controls.MetroTextBox KodeSupplier;
        private MetroFramework.Controls.MetroButton PrintBtnJual;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label27;
        private MetroFramework.Controls.MetroTextBox ListrikTeks;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private MetroFramework.Controls.MetroTextBox TotalPengeluaran;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private MetroFramework.Controls.MetroTextBox PengeluaranTeks;
        private System.Windows.Forms.Label label30;
        private MetroFramework.Controls.MetroTextBox InternetTeks;
        private System.Windows.Forms.Label label29;
        private MetroFramework.Controls.MetroTextBox GajiKaryawanTeks;
        private System.Windows.Forms.Label label28;
        private MetroFramework.Controls.MetroTextBox AirTeks;
        private System.Windows.Forms.Label StatusBulan;
        private System.Windows.Forms.Label LabelUntungHari;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartUntungRugi;
        private MetroFramework.Controls.MetroButton HitungTotalButton;
        private MetroFramework.Controls.MetroButton metroButton10;
        private MetroFramework.Controls.MetroButton metroButton12;
        private MetroFramework.Controls.MetroButton metroButton11;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label48;
        private MetroFramework.Controls.MetroTextBox KeteranganUsaha;
        private System.Windows.Forms.Label label47;
        private MetroFramework.Controls.MetroTextBox EmailUsaha;
        private System.Windows.Forms.Label label46;
        private MetroFramework.Controls.MetroTextBox TeleponUsaha;
        private System.Windows.Forms.Label label45;
        private MetroFramework.Controls.MetroTextBox AlamatUsaha;
        private System.Windows.Forms.Label label44;
        private MetroFramework.Controls.MetroTextBox NamaUsaha;
        private MetroFramework.Controls.MetroButton metroButton13;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label NamaLabel;
        private System.Windows.Forms.Label AlamatLabel;
        private System.Windows.Forms.Label KeteranganLabel;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.Label TeleponLabel;
        private System.Windows.Forms.GroupBox groupBox16;
    }
}