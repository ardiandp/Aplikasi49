﻿namespace ProfilNotes
{
    partial class InputProfilNotes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbUmur = new System.Windows.Forms.TextBox();
            this.tbPenyakit = new System.Windows.Forms.TextBox();
            this.tbAlergi = new System.Windows.Forms.TextBox();
            this.tbNadi = new System.Windows.Forms.TextBox();
            this.tbNafas = new System.Windows.Forms.TextBox();
            this.tbDiagnosa = new System.Windows.Forms.TextBox();
            this.tbKeluhan = new System.Windows.Forms.TextBox();
            this.tbKejadian = new System.Windows.Forms.TextBox();
            this.tbObat = new System.Windows.Forms.TextBox();
            this.tbNama = new System.Windows.Forms.TextBox();
            this.lblUmur = new System.Windows.Forms.Label();
            this.lblPenyakit = new System.Windows.Forms.Label();
            this.lblAlergi = new System.Windows.Forms.Label();
            this.lblKejadian = new System.Windows.Forms.Label();
            this.lblKeluhan = new System.Windows.Forms.Label();
            this.lblObat = new System.Windows.Forms.Label();
            this.lblDiagnosa = new System.Windows.Forms.Label();
            this.lblNafas = new System.Windows.Forms.Label();
            this.lblNadi = new System.Windows.Forms.Label();
            this.lblNama = new System.Windows.Forms.Label();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbUmur
            // 
            this.tbUmur.Location = new System.Drawing.Point(93, 48);
            this.tbUmur.Margin = new System.Windows.Forms.Padding(2);
            this.tbUmur.Name = "tbUmur";
            this.tbUmur.Size = new System.Drawing.Size(286, 20);
            this.tbUmur.TabIndex = 40;
            // 
            // tbPenyakit
            // 
            this.tbPenyakit.Location = new System.Drawing.Point(93, 73);
            this.tbPenyakit.Margin = new System.Windows.Forms.Padding(2);
            this.tbPenyakit.Name = "tbPenyakit";
            this.tbPenyakit.Size = new System.Drawing.Size(286, 20);
            this.tbPenyakit.TabIndex = 39;
            // 
            // tbAlergi
            // 
            this.tbAlergi.Location = new System.Drawing.Point(93, 100);
            this.tbAlergi.Margin = new System.Windows.Forms.Padding(2);
            this.tbAlergi.Name = "tbAlergi";
            this.tbAlergi.Size = new System.Drawing.Size(286, 20);
            this.tbAlergi.TabIndex = 38;
            // 
            // tbNadi
            // 
            this.tbNadi.Location = new System.Drawing.Point(93, 251);
            this.tbNadi.Margin = new System.Windows.Forms.Padding(2);
            this.tbNadi.Name = "tbNadi";
            this.tbNadi.Size = new System.Drawing.Size(235, 20);
            this.tbNadi.TabIndex = 37;
            // 
            // tbNafas
            // 
            this.tbNafas.Location = new System.Drawing.Point(93, 226);
            this.tbNafas.Margin = new System.Windows.Forms.Padding(2);
            this.tbNafas.Name = "tbNafas";
            this.tbNafas.Size = new System.Drawing.Size(235, 20);
            this.tbNafas.TabIndex = 36;
            this.tbNafas.TextChanged += new System.EventHandler(this.TbNafas_TextChanged);
            // 
            // tbDiagnosa
            // 
            this.tbDiagnosa.Location = new System.Drawing.Point(93, 200);
            this.tbDiagnosa.Margin = new System.Windows.Forms.Padding(2);
            this.tbDiagnosa.Name = "tbDiagnosa";
            this.tbDiagnosa.Size = new System.Drawing.Size(286, 20);
            this.tbDiagnosa.TabIndex = 35;
            // 
            // tbKeluhan
            // 
            this.tbKeluhan.Location = new System.Drawing.Point(93, 174);
            this.tbKeluhan.Margin = new System.Windows.Forms.Padding(2);
            this.tbKeluhan.Name = "tbKeluhan";
            this.tbKeluhan.Size = new System.Drawing.Size(286, 20);
            this.tbKeluhan.TabIndex = 34;
            // 
            // tbKejadian
            // 
            this.tbKejadian.Location = new System.Drawing.Point(93, 150);
            this.tbKejadian.Margin = new System.Windows.Forms.Padding(2);
            this.tbKejadian.Name = "tbKejadian";
            this.tbKejadian.Size = new System.Drawing.Size(286, 20);
            this.tbKejadian.TabIndex = 33;
            // 
            // tbObat
            // 
            this.tbObat.Location = new System.Drawing.Point(93, 125);
            this.tbObat.Margin = new System.Windows.Forms.Padding(2);
            this.tbObat.Name = "tbObat";
            this.tbObat.Size = new System.Drawing.Size(286, 20);
            this.tbObat.TabIndex = 32;
            // 
            // tbNama
            // 
            this.tbNama.Location = new System.Drawing.Point(93, 22);
            this.tbNama.Margin = new System.Windows.Forms.Padding(2);
            this.tbNama.Name = "tbNama";
            this.tbNama.Size = new System.Drawing.Size(286, 20);
            this.tbNama.TabIndex = 31;
            // 
            // lblUmur
            // 
            this.lblUmur.AutoSize = true;
            this.lblUmur.Location = new System.Drawing.Point(19, 52);
            this.lblUmur.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUmur.Name = "lblUmur";
            this.lblUmur.Size = new System.Drawing.Size(32, 13);
            this.lblUmur.TabIndex = 30;
            this.lblUmur.Text = "Umur";
            // 
            // lblPenyakit
            // 
            this.lblPenyakit.AutoSize = true;
            this.lblPenyakit.Location = new System.Drawing.Point(19, 77);
            this.lblPenyakit.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPenyakit.Name = "lblPenyakit";
            this.lblPenyakit.Size = new System.Drawing.Size(48, 13);
            this.lblPenyakit.TabIndex = 29;
            this.lblPenyakit.Text = "Penyakit";
            // 
            // lblAlergi
            // 
            this.lblAlergi.AutoSize = true;
            this.lblAlergi.Location = new System.Drawing.Point(19, 104);
            this.lblAlergi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAlergi.Name = "lblAlergi";
            this.lblAlergi.Size = new System.Drawing.Size(33, 13);
            this.lblAlergi.TabIndex = 28;
            this.lblAlergi.Text = "Alergi";
            // 
            // lblKejadian
            // 
            this.lblKejadian.AutoSize = true;
            this.lblKejadian.Location = new System.Drawing.Point(19, 154);
            this.lblKejadian.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKejadian.Name = "lblKejadian";
            this.lblKejadian.Size = new System.Drawing.Size(51, 13);
            this.lblKejadian.TabIndex = 27;
            this.lblKejadian.Text = "Kronologi";
            // 
            // lblKeluhan
            // 
            this.lblKeluhan.AutoSize = true;
            this.lblKeluhan.Location = new System.Drawing.Point(19, 178);
            this.lblKeluhan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKeluhan.Name = "lblKeluhan";
            this.lblKeluhan.Size = new System.Drawing.Size(46, 13);
            this.lblKeluhan.TabIndex = 26;
            this.lblKeluhan.Text = "Keluhan";
            // 
            // lblObat
            // 
            this.lblObat.AutoSize = true;
            this.lblObat.Location = new System.Drawing.Point(19, 129);
            this.lblObat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblObat.Name = "lblObat";
            this.lblObat.Size = new System.Drawing.Size(30, 13);
            this.lblObat.TabIndex = 25;
            this.lblObat.Text = "Obat";
            // 
            // lblDiagnosa
            // 
            this.lblDiagnosa.AutoSize = true;
            this.lblDiagnosa.Location = new System.Drawing.Point(19, 204);
            this.lblDiagnosa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDiagnosa.Name = "lblDiagnosa";
            this.lblDiagnosa.Size = new System.Drawing.Size(52, 13);
            this.lblDiagnosa.TabIndex = 24;
            this.lblDiagnosa.Text = "Diagnosa";
            // 
            // lblNafas
            // 
            this.lblNafas.AutoSize = true;
            this.lblNafas.Location = new System.Drawing.Point(19, 230);
            this.lblNafas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNafas.Name = "lblNafas";
            this.lblNafas.Size = new System.Drawing.Size(35, 13);
            this.lblNafas.TabIndex = 23;
            this.lblNafas.Text = "Nafas";
            // 
            // lblNadi
            // 
            this.lblNadi.AutoSize = true;
            this.lblNadi.Location = new System.Drawing.Point(19, 255);
            this.lblNadi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNadi.Name = "lblNadi";
            this.lblNadi.Size = new System.Drawing.Size(29, 13);
            this.lblNadi.TabIndex = 22;
            this.lblNadi.Text = "Nadi";
            // 
            // lblNama
            // 
            this.lblNama.AutoSize = true;
            this.lblNama.Location = new System.Drawing.Point(19, 26);
            this.lblNama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNama.Name = "lblNama";
            this.lblNama.Size = new System.Drawing.Size(35, 13);
            this.lblNama.TabIndex = 21;
            this.lblNama.Text = "Nama";
            // 
            // btnSimpan
            // 
            this.btnSimpan.Location = new System.Drawing.Point(105, 288);
            this.btnSimpan.Margin = new System.Windows.Forms.Padding(2);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(72, 28);
            this.btnSimpan.TabIndex = 41;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.BtnSimpan_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(333, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 65;
            this.label2.Text = "/15 detik";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(333, 255);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 66;
            this.label1.Text = "/15 detik";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(212, 288);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 28);
            this.button1.TabIndex = 67;
            this.button1.Text = "Tutup";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // InputProfilNotes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 327);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.tbUmur);
            this.Controls.Add(this.tbPenyakit);
            this.Controls.Add(this.tbAlergi);
            this.Controls.Add(this.tbNadi);
            this.Controls.Add(this.tbNafas);
            this.Controls.Add(this.tbDiagnosa);
            this.Controls.Add(this.tbKeluhan);
            this.Controls.Add(this.tbKejadian);
            this.Controls.Add(this.tbObat);
            this.Controls.Add(this.tbNama);
            this.Controls.Add(this.lblUmur);
            this.Controls.Add(this.lblPenyakit);
            this.Controls.Add(this.lblAlergi);
            this.Controls.Add(this.lblKejadian);
            this.Controls.Add(this.lblKeluhan);
            this.Controls.Add(this.lblObat);
            this.Controls.Add(this.lblDiagnosa);
            this.Controls.Add(this.lblNafas);
            this.Controls.Add(this.lblNadi);
            this.Controls.Add(this.lblNama);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "InputProfilNotes";
            this.Text = "InputProfilNotesForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbUmur;
        private System.Windows.Forms.TextBox tbPenyakit;
        private System.Windows.Forms.TextBox tbAlergi;
        private System.Windows.Forms.TextBox tbNadi;
        private System.Windows.Forms.TextBox tbNafas;
        private System.Windows.Forms.TextBox tbDiagnosa;
        private System.Windows.Forms.TextBox tbKeluhan;
        private System.Windows.Forms.TextBox tbKejadian;
        private System.Windows.Forms.TextBox tbObat;
        private System.Windows.Forms.TextBox tbNama;
        private System.Windows.Forms.Label lblUmur;
        private System.Windows.Forms.Label lblPenyakit;
        private System.Windows.Forms.Label lblAlergi;
        private System.Windows.Forms.Label lblKejadian;
        private System.Windows.Forms.Label lblKeluhan;
        private System.Windows.Forms.Label lblObat;
        private System.Windows.Forms.Label lblDiagnosa;
        private System.Windows.Forms.Label lblNafas;
        private System.Windows.Forms.Label lblNadi;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}

