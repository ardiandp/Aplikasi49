﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace domain.model.enumerasi
{
    public enum StatusTruk
    {
        Tersedia, Sedang_Beroperasi
    }
}
