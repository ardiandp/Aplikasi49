belajar-sistem-aplikasi-penyewaan-truk-desktop-csharp
=====================================================

Database: MySql (ada di dalem folder db)
Bahasa: c# NET. Framework 4.0
3rd Party: BetterListView Express
Crystal Report

TESSSSSSSSSSSSSss

ok

u