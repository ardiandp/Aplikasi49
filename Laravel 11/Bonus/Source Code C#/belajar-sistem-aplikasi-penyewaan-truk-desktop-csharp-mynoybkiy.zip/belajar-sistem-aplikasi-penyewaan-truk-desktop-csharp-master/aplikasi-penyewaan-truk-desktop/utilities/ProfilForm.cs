﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace desktop.utilities
{
    public enum ProfilForm
    {
        Menu, Unknow
    }
}
