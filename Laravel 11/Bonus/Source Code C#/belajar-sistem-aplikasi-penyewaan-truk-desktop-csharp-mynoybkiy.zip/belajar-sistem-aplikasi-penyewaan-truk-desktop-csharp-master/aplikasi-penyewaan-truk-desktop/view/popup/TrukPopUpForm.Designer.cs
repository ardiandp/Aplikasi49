﻿namespace desktop.view.popup
{
    partial class TrukPopUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Rute");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrukPopUpForm));
            this.lvHargaRuteTruk = new ComponentOwl.BetterListView.BetterListView();
            this.betterListViewColumnHeader1 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader2 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader3 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader4 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader11 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader12 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader5 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader6 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader10 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader13 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader7 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader8 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader9 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.tvRute = new System.Windows.Forms.TreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPilih = new System.Windows.Forms.Button();
            this.btnBatal = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.lvHargaRuteTruk)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvHargaRuteTruk
            // 
            this.lvHargaRuteTruk.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader1);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader2);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader3);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader4);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader11);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader12);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader5);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader6);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader10);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader13);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader7);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader8);
            this.lvHargaRuteTruk.Columns.Add(this.betterListViewColumnHeader9);
            this.lvHargaRuteTruk.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvHargaRuteTruk.Location = new System.Drawing.Point(139, 12);
            this.lvHargaRuteTruk.MultiSelect = false;
            this.lvHargaRuteTruk.Name = "lvHargaRuteTruk";
            this.lvHargaRuteTruk.Size = new System.Drawing.Size(449, 291);
            this.lvHargaRuteTruk.TabIndex = 0;
            this.lvHargaRuteTruk.SelectedIndexChanged += new System.EventHandler(this.lvHargaRuteTruk_SelectedIndexChanged);
            this.lvHargaRuteTruk.DoubleClick += new System.EventHandler(this.lvHargaRuteTruk_DoubleClick);
            // 
            // betterListViewColumnHeader1
            // 
            this.betterListViewColumnHeader1.Name = "betterListViewColumnHeader1";
            this.betterListViewColumnHeader1.Text = "HargaRuteTrukId";
            // 
            // betterListViewColumnHeader2
            // 
            this.betterListViewColumnHeader2.Name = "betterListViewColumnHeader2";
            this.betterListViewColumnHeader2.Text = "Truk ID";
            // 
            // betterListViewColumnHeader3
            // 
            this.betterListViewColumnHeader3.Name = "betterListViewColumnHeader3";
            this.betterListViewColumnHeader3.Text = "Nomor Polisi";
            // 
            // betterListViewColumnHeader4
            // 
            this.betterListViewColumnHeader4.Name = "betterListViewColumnHeader4";
            this.betterListViewColumnHeader4.Text = "Status";
            // 
            // betterListViewColumnHeader11
            // 
            this.betterListViewColumnHeader11.Name = "betterListViewColumnHeader11";
            this.betterListViewColumnHeader11.Text = "Rute ID";
            // 
            // betterListViewColumnHeader12
            // 
            this.betterListViewColumnHeader12.Name = "betterListViewColumnHeader12";
            this.betterListViewColumnHeader12.Text = "Nama Rute";
            // 
            // betterListViewColumnHeader5
            // 
            this.betterListViewColumnHeader5.Name = "betterListViewColumnHeader5";
            this.betterListViewColumnHeader5.Text = "Jenis Truk ID";
            // 
            // betterListViewColumnHeader6
            // 
            this.betterListViewColumnHeader6.Name = "betterListViewColumnHeader6";
            this.betterListViewColumnHeader6.Text = "Nama Jenis Truk";
            // 
            // betterListViewColumnHeader10
            // 
            this.betterListViewColumnHeader10.Name = "betterListViewColumnHeader10";
            this.betterListViewColumnHeader10.Text = "Harga";
            // 
            // betterListViewColumnHeader13
            // 
            this.betterListViewColumnHeader13.Name = "betterListViewColumnHeader13";
            this.betterListViewColumnHeader13.Text = "Harga Supir";
            // 
            // betterListViewColumnHeader7
            // 
            this.betterListViewColumnHeader7.Name = "betterListViewColumnHeader7";
            this.betterListViewColumnHeader7.Text = "Supir ID";
            // 
            // betterListViewColumnHeader8
            // 
            this.betterListViewColumnHeader8.Name = "betterListViewColumnHeader8";
            this.betterListViewColumnHeader8.Text = "Nama Supir";
            // 
            // betterListViewColumnHeader9
            // 
            this.betterListViewColumnHeader9.Name = "betterListViewColumnHeader9";
            this.betterListViewColumnHeader9.Text = "Kernet ID";
            // 
            // tvRute
            // 
            this.tvRute.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.tvRute.Location = new System.Drawing.Point(12, 12);
            this.tvRute.Name = "tvRute";
            treeNode1.Name = "Node4";
            treeNode1.Text = "Rute";
            this.tvRute.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.tvRute.Size = new System.Drawing.Size(121, 291);
            this.tvRute.TabIndex = 1;
            this.tvRute.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvRute_AfterSelect);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnPilih);
            this.panel1.Controls.Add(this.btnBatal);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 316);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 63);
            this.panel1.TabIndex = 15;
            // 
            // btnPilih
            // 
            this.btnPilih.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPilih.Location = new System.Drawing.Point(432, 19);
            this.btnPilih.Name = "btnPilih";
            this.btnPilih.Size = new System.Drawing.Size(75, 23);
            this.btnPilih.TabIndex = 17;
            this.btnPilih.Text = "Pilih";
            this.btnPilih.UseVisualStyleBackColor = true;
            this.btnPilih.Visible = false;
            this.btnPilih.Click += new System.EventHandler(this.btnPilih_Click);
            // 
            // btnBatal
            // 
            this.btnBatal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBatal.Location = new System.Drawing.Point(513, 19);
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Size = new System.Drawing.Size(75, 23);
            this.btnBatal.TabIndex = 16;
            this.btnBatal.Text = "Batal";
            this.btnBatal.UseVisualStyleBackColor = true;
            this.btnBatal.Click += new System.EventHandler(this.btnBatal_Click);
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(600, 1);
            this.label6.TabIndex = 15;
            this.label6.Text = "label6";
            // 
            // TrukPopUpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 379);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tvRute);
            this.Controls.Add(this.lvHargaRuteTruk);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TrukPopUpForm";
            this.Text = "TrukPopUpForm";
            ((System.ComponentModel.ISupportInitialize)(this.lvHargaRuteTruk)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentOwl.BetterListView.BetterListView lvHargaRuteTruk;
        private System.Windows.Forms.TreeView tvRute;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnPilih;
        private System.Windows.Forms.Button btnBatal;
        private System.Windows.Forms.Label label6;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader1;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader2;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader3;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader4;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader5;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader6;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader7;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader8;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader9;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader10;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader11;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader12;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader13;
    }
}