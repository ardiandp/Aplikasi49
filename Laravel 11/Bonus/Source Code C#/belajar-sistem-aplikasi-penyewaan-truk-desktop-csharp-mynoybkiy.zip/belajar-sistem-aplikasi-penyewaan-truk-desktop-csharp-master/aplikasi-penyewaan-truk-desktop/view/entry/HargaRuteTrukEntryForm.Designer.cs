﻿namespace desktop.view.entry
{
    partial class HargaRuteTrukEntryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HargaRuteTrukEntryForm));
            this.betterListViewColumnHeader6 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader7 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader1 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader2 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader3 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader4 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader5 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lvHargaRute = new ComponentOwl.BetterListView.BetterListView();
            this.betterListViewColumnHeader8 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader9 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader10 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader11 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader14 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.betterListViewColumnHeader13 = new ComponentOwl.BetterListView.BetterListViewColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtJenisTrukNama = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomorPolisi = new System.Windows.Forms.TextBox();
            this.txtTrukId = new System.Windows.Forms.TextBox();
            this.lblTrukId = new System.Windows.Forms.Label();
            this.lblJenisTrukId = new System.Windows.Forms.Label();
            this.txtJenisTrukId = new System.Windows.Forms.TextBox();
            this.btnTambah = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.btnBatal = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lvHargaRute)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // betterListViewColumnHeader6
            // 
            this.betterListViewColumnHeader6.AllowResize = false;
            this.betterListViewColumnHeader6.Name = "betterListViewColumnHeader6";
            this.betterListViewColumnHeader6.Text = "ID";
            this.betterListViewColumnHeader6.Width = 0;
            // 
            // betterListViewColumnHeader7
            // 
            this.betterListViewColumnHeader7.AllowResize = false;
            this.betterListViewColumnHeader7.Name = "betterListViewColumnHeader7";
            this.betterListViewColumnHeader7.Width = 44;
            // 
            // betterListViewColumnHeader1
            // 
            this.betterListViewColumnHeader1.AllowResize = false;
            this.betterListViewColumnHeader1.Name = "betterListViewColumnHeader1";
            this.betterListViewColumnHeader1.Text = "Rute ID";
            this.betterListViewColumnHeader1.Width = 0;
            // 
            // betterListViewColumnHeader2
            // 
            this.betterListViewColumnHeader2.Name = "betterListViewColumnHeader2";
            this.betterListViewColumnHeader2.Text = "Rute";
            this.betterListViewColumnHeader2.Width = 108;
            // 
            // betterListViewColumnHeader3
            // 
            this.betterListViewColumnHeader3.Name = "betterListViewColumnHeader3";
            this.betterListViewColumnHeader3.Text = "Harga";
            this.betterListViewColumnHeader3.Width = 122;
            // 
            // betterListViewColumnHeader4
            // 
            this.betterListViewColumnHeader4.Name = "betterListViewColumnHeader4";
            this.betterListViewColumnHeader4.Text = "Icon Info";
            this.betterListViewColumnHeader4.Width = 46;
            // 
            // betterListViewColumnHeader5
            // 
            this.betterListViewColumnHeader5.Name = "betterListViewColumnHeader5";
            this.betterListViewColumnHeader5.Text = "Enum Info";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.lvHargaRute, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnEdit, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtJenisTrukNama, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtNomorPolisi, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtTrukId, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblTrukId, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblJenisTrukId, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtJenisTrukId, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnTambah, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.btnDelete, 2, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(601, 352);
            this.tableLayoutPanel1.TabIndex = 16;
            // 
            // lvHargaRute
            // 
            this.lvHargaRute.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lvHargaRute.Columns.Add(this.betterListViewColumnHeader8);
            this.lvHargaRute.Columns.Add(this.betterListViewColumnHeader9);
            this.lvHargaRute.Columns.Add(this.betterListViewColumnHeader10);
            this.lvHargaRute.Columns.Add(this.betterListViewColumnHeader11);
            this.lvHargaRute.Columns.Add(this.betterListViewColumnHeader14);
            this.lvHargaRute.Columns.Add(this.betterListViewColumnHeader13);
            this.lvHargaRute.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvHargaRute.Location = new System.Drawing.Point(88, 123);
            this.lvHargaRute.Name = "lvHargaRute";
            this.tableLayoutPanel1.SetRowSpan(this.lvHargaRute, 3);
            this.lvHargaRute.Size = new System.Drawing.Size(419, 218);
            this.lvHargaRute.TabIndex = 18;
            this.lvHargaRute.SelectedIndexChanged += new System.EventHandler(this.lvHargaRute_SelectedIndexChanged);
            // 
            // betterListViewColumnHeader8
            // 
            this.betterListViewColumnHeader8.AllowResize = false;
            this.betterListViewColumnHeader8.Name = "betterListViewColumnHeader8";
            this.betterListViewColumnHeader8.Text = "HargaRuteTrukId";
            this.betterListViewColumnHeader8.Width = 0;
            // 
            // betterListViewColumnHeader9
            // 
            this.betterListViewColumnHeader9.AllowResize = false;
            this.betterListViewColumnHeader9.Name = "betterListViewColumnHeader9";
            this.betterListViewColumnHeader9.Text = "Rute ID";
            this.betterListViewColumnHeader9.Width = 0;
            // 
            // betterListViewColumnHeader10
            // 
            this.betterListViewColumnHeader10.Name = "betterListViewColumnHeader10";
            this.betterListViewColumnHeader10.Text = "Nama Rute";
            // 
            // betterListViewColumnHeader11
            // 
            this.betterListViewColumnHeader11.Name = "betterListViewColumnHeader11";
            this.betterListViewColumnHeader11.Text = "Harga Truk";
            this.betterListViewColumnHeader11.Width = 96;
            // 
            // betterListViewColumnHeader14
            // 
            this.betterListViewColumnHeader14.Name = "betterListViewColumnHeader14";
            this.betterListViewColumnHeader14.Text = "Harga Supir";
            // 
            // betterListViewColumnHeader13
            // 
            this.betterListViewColumnHeader13.Name = "betterListViewColumnHeader13";
            this.betterListViewColumnHeader13.Text = "Status";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rute Truk";
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Location = new System.Drawing.Point(513, 152);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 20;
            this.btnEdit.Text = "Harga Truk";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Jenis Truk";
            // 
            // txtJenisTrukNama
            // 
            this.txtJenisTrukNama.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtJenisTrukNama.Location = new System.Drawing.Point(88, 95);
            this.txtJenisTrukNama.Name = "txtJenisTrukNama";
            this.txtJenisTrukNama.ReadOnly = true;
            this.txtJenisTrukNama.Size = new System.Drawing.Size(419, 21);
            this.txtJenisTrukNama.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Nomor Polisi:";
            // 
            // txtNomorPolisi
            // 
            this.txtNomorPolisi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNomorPolisi.Location = new System.Drawing.Point(88, 40);
            this.txtNomorPolisi.Name = "txtNomorPolisi";
            this.txtNomorPolisi.ReadOnly = true;
            this.txtNomorPolisi.Size = new System.Drawing.Size(419, 21);
            this.txtNomorPolisi.TabIndex = 25;
            // 
            // txtTrukId
            // 
            this.txtTrukId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTrukId.Location = new System.Drawing.Point(88, 13);
            this.txtTrukId.Name = "txtTrukId";
            this.txtTrukId.ReadOnly = true;
            this.txtTrukId.Size = new System.Drawing.Size(419, 21);
            this.txtTrukId.TabIndex = 26;
            this.txtTrukId.Visible = false;
            // 
            // lblTrukId
            // 
            this.lblTrukId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblTrukId.AutoSize = true;
            this.lblTrukId.Location = new System.Drawing.Point(13, 17);
            this.lblTrukId.Name = "lblTrukId";
            this.lblTrukId.Size = new System.Drawing.Size(46, 13);
            this.lblTrukId.TabIndex = 27;
            this.lblTrukId.Text = "Truk ID:";
            this.lblTrukId.Visible = false;
            // 
            // lblJenisTrukId
            // 
            this.lblJenisTrukId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblJenisTrukId.AutoSize = true;
            this.lblJenisTrukId.Location = new System.Drawing.Point(13, 71);
            this.lblJenisTrukId.Name = "lblJenisTrukId";
            this.lblJenisTrukId.Size = new System.Drawing.Size(69, 13);
            this.lblJenisTrukId.TabIndex = 28;
            this.lblJenisTrukId.Text = "Jenis Truk ID";
            this.lblJenisTrukId.Visible = false;
            // 
            // txtJenisTrukId
            // 
            this.txtJenisTrukId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtJenisTrukId.Location = new System.Drawing.Point(88, 67);
            this.txtJenisTrukId.Name = "txtJenisTrukId";
            this.txtJenisTrukId.ReadOnly = true;
            this.txtJenisTrukId.Size = new System.Drawing.Size(419, 21);
            this.txtJenisTrukId.TabIndex = 29;
            this.txtJenisTrukId.Visible = false;
            // 
            // btnTambah
            // 
            this.btnTambah.Location = new System.Drawing.Point(513, 94);
            this.btnTambah.Name = "btnTambah";
            this.btnTambah.Size = new System.Drawing.Size(75, 23);
            this.btnTambah.TabIndex = 19;
            this.btnTambah.Text = "Tambah";
            this.btnTambah.UseVisualStyleBackColor = true;
            this.btnTambah.Click += new System.EventHandler(this.btnTambah_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(513, 181);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "Harga Supir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new System.Drawing.Point(513, 123);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 21;
            this.btnDelete.Text = "Hapus";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnSimpan);
            this.panel1.Controls.Add(this.btnBatal);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 352);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(601, 63);
            this.panel1.TabIndex = 19;
            // 
            // btnSimpan
            // 
            this.btnSimpan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSimpan.Location = new System.Drawing.Point(433, 19);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(75, 23);
            this.btnSimpan.TabIndex = 17;
            this.btnSimpan.Text = "Ubah";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // btnBatal
            // 
            this.btnBatal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBatal.Location = new System.Drawing.Point(514, 19);
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Size = new System.Drawing.Size(75, 23);
            this.btnBatal.TabIndex = 16;
            this.btnBatal.Text = "Batal";
            this.btnBatal.UseVisualStyleBackColor = true;
            this.btnBatal.Click += new System.EventHandler(this.btnBatal_Click);
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(601, 1);
            this.label6.TabIndex = 15;
            this.label6.Text = "label6";
            // 
            // HargaRuteTrukEntryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 415);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HargaRuteTrukEntryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HargaRuteTrukEntryForm";
            this.Load += new System.EventHandler(this.HargaRuteTrukEntryForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lvHargaRute)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader6;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader7;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader1;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader2;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader3;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader4;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private ComponentOwl.BetterListView.BetterListView lvHargaRute;
        private System.Windows.Forms.Button btnTambah;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtJenisTrukNama;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomorPolisi;
        private System.Windows.Forms.TextBox txtTrukId;
        private System.Windows.Forms.Label lblTrukId;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader8;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader9;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader10;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader11;
        private System.Windows.Forms.Label lblJenisTrukId;
        private System.Windows.Forms.TextBox txtJenisTrukId;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Button btnBatal;
        private System.Windows.Forms.Label label6;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader14;
        private ComponentOwl.BetterListView.BetterListViewColumnHeader betterListViewColumnHeader13;
        private System.Windows.Forms.Button button1;
    }
}