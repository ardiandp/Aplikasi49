﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimkapSmartServer.simkap.smart.server.view
{
    public partial class FrmTentangSimkap : DevComponents.DotNetBar.Metro.MetroForm
    {
        public FrmTentangSimkap()
        {
            InitializeComponent();
        }
    }
}
