﻿using SimkapSmartLibrary.simkap.smart.library.log.server;

namespace SimkapSmartServer.simkap.smart.server.view
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            this.styleManager1 = new DevComponents.DotNetBar.StyleManager(this.components);
            this.metroStatusBar1 = new DevComponents.DotNetBar.Metro.MetroStatusBar();
            this.labelItem6 = new DevComponents.DotNetBar.LabelItem();
            this.labelItem11 = new DevComponents.DotNetBar.LabelItem();
            this.lblTanggal = new DevComponents.DotNetBar.LabelItem();
            this.labelItem1 = new DevComponents.DotNetBar.LabelItem();
            this.lblJam = new DevComponents.DotNetBar.LabelItem();
            this.labelItem12 = new DevComponents.DotNetBar.LabelItem();
            this.lblIpServer = new DevComponents.DotNetBar.LabelItem();
            this.labelItem5 = new DevComponents.DotNetBar.LabelItem();
            this.lblHostServer = new DevComponents.DotNetBar.LabelItem();
            this.labelItem15 = new DevComponents.DotNetBar.LabelItem();
            this.lblNama = new DevComponents.DotNetBar.LabelItem();
            this.labelItem8 = new DevComponents.DotNetBar.LabelItem();
            this.label = new DevComponents.DotNetBar.LabelItem();
            this.labelItem3 = new DevComponents.DotNetBar.LabelItem();
            this.labelItem9 = new DevComponents.DotNetBar.LabelItem();
            this.labelItem45 = new DevComponents.DotNetBar.LabelItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelItem16 = new DevComponents.DotNetBar.LabelItem();
            this.labelItem17 = new DevComponents.DotNetBar.LabelItem();
            this.labelItem2 = new DevComponents.DotNetBar.LabelItem();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer2 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer3 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem4 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem5 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem6 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem7 = new DevComponents.DotNetBar.ButtonItem();
            this.galleryContainer1 = new DevComponents.DotNetBar.GalleryContainer();
            this.buttonItem8 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem9 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem10 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem11 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer4 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem12 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem13 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer5 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer6 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer2 = new DevComponents.DotNetBar.GalleryContainer();
            this.buttonItem14 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem15 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem16 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer7 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem17 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem18 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer8 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer9 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer3 = new DevComponents.DotNetBar.GalleryContainer();
            this.buttonItem19 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer10 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem20 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem21 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer11 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer12 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer4 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer13 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem22 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer14 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer15 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer5 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer16 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer17 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer18 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer6 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer19 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer20 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer21 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer7 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer22 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer23 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer24 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer8 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer25 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer26 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer27 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer9 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer28 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer29 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer30 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer10 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer31 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer32 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer33 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer11 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer34 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer35 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer36 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer12 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer37 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer38 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer39 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer13 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer40 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer41 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer42 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer14 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer43 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem2 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer44 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer45 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem3 = new DevComponents.DotNetBar.ButtonItem();
            this.galleryContainer15 = new DevComponents.DotNetBar.GalleryContainer();
            this.itemContainer46 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer47 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer16 = new DevComponents.DotNetBar.GalleryContainer();
            this.ribbonControl1 = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel1 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar9 = new DevComponents.DotNetBar.RibbonBar();
            this.btnLoginPegawai = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar5 = new DevComponents.DotNetBar.RibbonBar();
            this.btnAdmin = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar4 = new DevComponents.DotNetBar.RibbonBar();
            this.btnUnitKerja = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar3 = new DevComponents.DotNetBar.RibbonBar();
            this.btnKegiatan = new DevComponents.DotNetBar.ButtonItem();
            this.btnJenisKegiatan = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar2 = new DevComponents.DotNetBar.RibbonBar();
            this.btnAtasanPenilai = new DevComponents.DotNetBar.ButtonItem();
            this.btnPejabatPenilai = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.btnPegawai = new DevComponents.DotNetBar.ButtonItem();
            this.btnKegiatanPegawai = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel4 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar11 = new DevComponents.DotNetBar.RibbonBar();
            this.btnTentangSimkap = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel2 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar7 = new DevComponents.DotNetBar.RibbonBar();
            this.btnCPU = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar6 = new DevComponents.DotNetBar.RibbonBar();
            this.btnServer = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonTabItem2 = new DevComponents.DotNetBar.RibbonTabItem();
            this.lblKelola = new DevComponents.DotNetBar.RibbonTabItem();
            this.btnBantuan = new DevComponents.DotNetBar.RibbonTabItem();
            this.btnClose = new DevComponents.DotNetBar.ButtonItem();
            this.labelItem4 = new DevComponents.DotNetBar.LabelItem();
            this.qatCustomizeItem1 = new DevComponents.DotNetBar.QatCustomizeItem();
            this.applicationButton1 = new DevComponents.DotNetBar.ApplicationButton();
            this.itemContainer1 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer48 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer49 = new DevComponents.DotNetBar.ItemContainer();
            this.galleryContainer17 = new DevComponents.DotNetBar.GalleryContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.ribbonControl1.SuspendLayout();
            this.ribbonPanel1.SuspendLayout();
            this.ribbonPanel4.SuspendLayout();
            this.ribbonPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // styleManager1
            // 
            this.styleManager1.ManagerColorTint = System.Drawing.Color.Black;
            this.styleManager1.ManagerStyle = DevComponents.DotNetBar.eStyle.Metro;
            this.styleManager1.MetroColorParameters = new DevComponents.DotNetBar.Metro.ColorTables.MetroColorGeneratorParameters(System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198))))));
            // 
            // metroStatusBar1
            // 
            this.metroStatusBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.metroStatusBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroStatusBar1.ContainerControlProcessDialogKey = true;
            this.metroStatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroStatusBar1.Font = new System.Drawing.Font("Segoe UI", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroStatusBar1.ForeColor = System.Drawing.Color.Black;
            this.metroStatusBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem6,
            this.labelItem11,
            this.lblTanggal,
            this.labelItem1,
            this.lblJam,
            this.labelItem12,
            this.lblIpServer,
            this.labelItem5,
            this.lblHostServer,
            this.labelItem15,
            this.lblNama,
            this.labelItem8,
            this.label,
            this.labelItem3,
            this.labelItem9});
            this.metroStatusBar1.Location = new System.Drawing.Point(0, 424);
            this.metroStatusBar1.Name = "metroStatusBar1";
            this.metroStatusBar1.Size = new System.Drawing.Size(827, 22);
            this.metroStatusBar1.TabIndex = 6;
            this.metroStatusBar1.Text = "metroStatusBar1";
            // 
            // labelItem6
            // 
            this.labelItem6.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem6.Name = "labelItem6";
            this.labelItem6.Symbol = "";
            this.labelItem6.SymbolColor = System.Drawing.Color.Lime;
            this.labelItem6.Text = "Aplikasi Siap";
            // 
            // labelItem11
            // 
            this.labelItem11.Name = "labelItem11";
            this.labelItem11.Text = "                                ";
            // 
            // lblTanggal
            // 
            this.lblTanggal.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTanggal.Name = "lblTanggal";
            this.lblTanggal.SingleLineColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblTanggal.Text = "Tanggal";
            // 
            // labelItem1
            // 
            this.labelItem1.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem1.Name = "labelItem1";
            this.labelItem1.Text = "|";
            // 
            // lblJam
            // 
            this.lblJam.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJam.Name = "lblJam";
            this.lblJam.Text = "jam";
            // 
            // labelItem12
            // 
            this.labelItem12.Name = "labelItem12";
            this.labelItem12.Stretch = true;
            this.labelItem12.Text = "                                         ";
            // 
            // lblIpServer
            // 
            this.lblIpServer.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIpServer.Name = "lblIpServer";
            this.lblIpServer.Text = "IP Address";
            // 
            // labelItem5
            // 
            this.labelItem5.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem5.Name = "labelItem5";
            this.labelItem5.Text = "|";
            // 
            // lblHostServer
            // 
            this.lblHostServer.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHostServer.Name = "lblHostServer";
            this.lblHostServer.Text = "Host Name";
            // 
            // labelItem15
            // 
            this.labelItem15.Name = "labelItem15";
            this.labelItem15.Stretch = true;
            this.labelItem15.Text = "                        ";
            // 
            // lblNama
            // 
            this.lblNama.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNama.Name = "lblNama";
            this.lblNama.Text = "nama";
            // 
            // labelItem8
            // 
            this.labelItem8.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem8.Name = "labelItem8";
            this.labelItem8.Text = "|";
            // 
            // label
            // 
            this.label.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Name = "label";
            this.label.Text = "Administrator";
            // 
            // labelItem3
            // 
            this.labelItem3.Name = "labelItem3";
            this.labelItem3.Stretch = true;
            this.labelItem3.Text = "                            ";
            // 
            // labelItem9
            // 
            this.labelItem9.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem9.Name = "labelItem9";
            this.labelItem9.Text = "Versi 1.0.0";
            // 
            // labelItem45
            // 
            this.labelItem45.Name = "labelItem45";
            this.labelItem45.Stretch = true;
            this.labelItem45.Text = "Versi 1.0.0";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelItem16
            // 
            this.labelItem16.Name = "labelItem16";
            this.labelItem16.Text = "   ";
            // 
            // labelItem17
            // 
            this.labelItem17.Name = "labelItem17";
            this.labelItem17.Text = "   ";
            // 
            // labelItem2
            // 
            this.labelItem2.Name = "labelItem2";
            this.labelItem2.Stretch = true;
            this.labelItem2.Text = "labelItem2";
            // 
            // buttonItem1
            // 
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.Text = "buttonItem1";
            // 
            // itemContainer2
            // 
            // 
            // 
            // 
            this.itemContainer2.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer2.ItemSpacing = 0;
            this.itemContainer2.Name = "itemContainer2";
            this.itemContainer2.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer3,
            this.galleryContainer1});
            // 
            // 
            // 
            this.itemContainer2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer3
            // 
            // 
            // 
            // 
            this.itemContainer3.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer3.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer3.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer3.Name = "itemContainer3";
            this.itemContainer3.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem4,
            this.buttonItem5,
            this.buttonItem6,
            this.buttonItem7});
            // 
            // 
            // 
            this.itemContainer3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem4
            // 
            this.buttonItem4.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem4.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem4.Image")));
            this.buttonItem4.Name = "buttonItem4";
            this.buttonItem4.SubItemsExpandWidth = 24;
            this.buttonItem4.Text = "&Save...";
            // 
            // buttonItem5
            // 
            this.buttonItem5.BeginGroup = true;
            this.buttonItem5.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem5.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem5.Image")));
            this.buttonItem5.Name = "buttonItem5";
            this.buttonItem5.SubItemsExpandWidth = 24;
            this.buttonItem5.Text = "S&hare...";
            // 
            // buttonItem6
            // 
            this.buttonItem6.BeginGroup = true;
            this.buttonItem6.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem6.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem6.Image")));
            this.buttonItem6.Name = "buttonItem6";
            this.buttonItem6.SubItemsExpandWidth = 24;
            this.buttonItem6.Text = "&Print...";
            // 
            // buttonItem7
            // 
            this.buttonItem7.BeginGroup = true;
            this.buttonItem7.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem7.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem7.Image")));
            this.buttonItem7.Name = "buttonItem7";
            this.buttonItem7.SubItemsExpandWidth = 24;
            this.buttonItem7.Text = "&Close";
            // 
            // galleryContainer1
            // 
            // 
            // 
            // 
            this.galleryContainer1.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer1.EnableGalleryPopup = false;
            this.galleryContainer1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer1.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer1.MultiLine = false;
            this.galleryContainer1.Name = "galleryContainer1";
            this.galleryContainer1.PopupUsesStandardScrollbars = false;
            this.galleryContainer1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem8,
            this.buttonItem9,
            this.buttonItem10,
            this.buttonItem11});
            // 
            // 
            // 
            this.galleryContainer1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem8
            // 
            this.buttonItem8.Name = "buttonItem8";
            this.buttonItem8.Text = "&1. Short News 5-7.rtf";
            // 
            // buttonItem9
            // 
            this.buttonItem9.Name = "buttonItem9";
            this.buttonItem9.Text = "&2. Prospect Email.rtf";
            // 
            // buttonItem10
            // 
            this.buttonItem10.Name = "buttonItem10";
            this.buttonItem10.Text = "&3. Customer Email.rtf";
            // 
            // buttonItem11
            // 
            this.buttonItem11.Name = "buttonItem11";
            this.buttonItem11.Text = "&4. example.rtf";
            // 
            // itemContainer4
            // 
            // 
            // 
            // 
            this.itemContainer4.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer4.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer4.Name = "itemContainer4";
            this.itemContainer4.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem12,
            this.buttonItem13});
            // 
            // 
            // 
            this.itemContainer4.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem12
            // 
            this.buttonItem12.BeginGroup = true;
            this.buttonItem12.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem12.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem12.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem12.Image")));
            this.buttonItem12.Name = "buttonItem12";
            this.buttonItem12.SubItemsExpandWidth = 24;
            this.buttonItem12.Text = "Opt&ions";
            // 
            // buttonItem13
            // 
            this.buttonItem13.BeginGroup = true;
            this.buttonItem13.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem13.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem13.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem13.Image")));
            this.buttonItem13.Name = "buttonItem13";
            this.buttonItem13.SubItemsExpandWidth = 24;
            this.buttonItem13.Text = "E&xit";
            // 
            // itemContainer5
            // 
            // 
            // 
            // 
            this.itemContainer5.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer5.ItemSpacing = 0;
            this.itemContainer5.Name = "itemContainer5";
            this.itemContainer5.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer6,
            this.galleryContainer2});
            // 
            // 
            // 
            this.itemContainer5.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer6
            // 
            // 
            // 
            // 
            this.itemContainer6.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer6.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer6.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer6.Name = "itemContainer6";
            // 
            // 
            // 
            this.itemContainer6.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer2
            // 
            // 
            // 
            // 
            this.galleryContainer2.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer2.EnableGalleryPopup = false;
            this.galleryContainer2.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer2.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer2.MultiLine = false;
            this.galleryContainer2.Name = "galleryContainer2";
            this.galleryContainer2.PopupUsesStandardScrollbars = false;
            this.galleryContainer2.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem14,
            this.buttonItem15,
            this.buttonItem16});
            // 
            // 
            // 
            this.galleryContainer2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem14
            // 
            this.buttonItem14.Name = "buttonItem14";
            this.buttonItem14.Text = "&2. Prospect Email.rtf";
            // 
            // buttonItem15
            // 
            this.buttonItem15.Name = "buttonItem15";
            this.buttonItem15.Text = "&3. Customer Email.rtf";
            // 
            // buttonItem16
            // 
            this.buttonItem16.Name = "buttonItem16";
            this.buttonItem16.Text = "&4. example.rtf";
            // 
            // itemContainer7
            // 
            // 
            // 
            // 
            this.itemContainer7.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer7.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer7.Name = "itemContainer7";
            this.itemContainer7.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem17,
            this.buttonItem18});
            // 
            // 
            // 
            this.itemContainer7.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem17
            // 
            this.buttonItem17.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem17.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem17.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem17.Image")));
            this.buttonItem17.Name = "buttonItem17";
            this.buttonItem17.SubItemsExpandWidth = 24;
            this.buttonItem17.Text = "Opt&ions";
            // 
            // buttonItem18
            // 
            this.buttonItem18.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem18.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem18.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem18.Image")));
            this.buttonItem18.Name = "buttonItem18";
            this.buttonItem18.SubItemsExpandWidth = 24;
            this.buttonItem18.Text = "E&xit";
            // 
            // itemContainer8
            // 
            // 
            // 
            // 
            this.itemContainer8.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer8.ItemSpacing = 0;
            this.itemContainer8.Name = "itemContainer8";
            this.itemContainer8.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer9,
            this.galleryContainer3});
            // 
            // 
            // 
            this.itemContainer8.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer9
            // 
            // 
            // 
            // 
            this.itemContainer9.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer9.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer9.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer9.Name = "itemContainer9";
            // 
            // 
            // 
            this.itemContainer9.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer3
            // 
            // 
            // 
            // 
            this.galleryContainer3.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer3.EnableGalleryPopup = false;
            this.galleryContainer3.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer3.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer3.MultiLine = false;
            this.galleryContainer3.Name = "galleryContainer3";
            this.galleryContainer3.PopupUsesStandardScrollbars = false;
            this.galleryContainer3.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem19});
            // 
            // 
            // 
            this.galleryContainer3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem19
            // 
            this.buttonItem19.Name = "buttonItem19";
            this.buttonItem19.Text = "&4. example.rtf";
            // 
            // itemContainer10
            // 
            // 
            // 
            // 
            this.itemContainer10.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer10.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer10.Name = "itemContainer10";
            this.itemContainer10.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem20,
            this.buttonItem21});
            // 
            // 
            // 
            this.itemContainer10.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem20
            // 
            this.buttonItem20.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem20.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem20.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem20.Image")));
            this.buttonItem20.Name = "buttonItem20";
            this.buttonItem20.SubItemsExpandWidth = 24;
            this.buttonItem20.Text = "Opt&ions";
            // 
            // buttonItem21
            // 
            this.buttonItem21.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem21.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem21.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem21.Image")));
            this.buttonItem21.Name = "buttonItem21";
            this.buttonItem21.SubItemsExpandWidth = 24;
            this.buttonItem21.Text = "E&xit";
            // 
            // itemContainer11
            // 
            // 
            // 
            // 
            this.itemContainer11.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer11.ItemSpacing = 0;
            this.itemContainer11.Name = "itemContainer11";
            this.itemContainer11.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer12,
            this.galleryContainer4});
            // 
            // 
            // 
            this.itemContainer11.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer12
            // 
            // 
            // 
            // 
            this.itemContainer12.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer12.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer12.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer12.Name = "itemContainer12";
            // 
            // 
            // 
            this.itemContainer12.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer4
            // 
            // 
            // 
            // 
            this.galleryContainer4.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer4.EnableGalleryPopup = false;
            this.galleryContainer4.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer4.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer4.MultiLine = false;
            this.galleryContainer4.Name = "galleryContainer4";
            this.galleryContainer4.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer4.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer13
            // 
            // 
            // 
            // 
            this.itemContainer13.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer13.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer13.Name = "itemContainer13";
            this.itemContainer13.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem22});
            // 
            // 
            // 
            this.itemContainer13.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem22
            // 
            this.buttonItem22.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem22.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem22.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem22.Image")));
            this.buttonItem22.Name = "buttonItem22";
            this.buttonItem22.SubItemsExpandWidth = 24;
            this.buttonItem22.Text = "E&xit";
            // 
            // itemContainer14
            // 
            // 
            // 
            // 
            this.itemContainer14.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer14.ItemSpacing = 0;
            this.itemContainer14.Name = "itemContainer14";
            this.itemContainer14.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer15,
            this.galleryContainer5});
            // 
            // 
            // 
            this.itemContainer14.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer15
            // 
            // 
            // 
            // 
            this.itemContainer15.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer15.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer15.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer15.Name = "itemContainer15";
            // 
            // 
            // 
            this.itemContainer15.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer5
            // 
            // 
            // 
            // 
            this.galleryContainer5.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer5.EnableGalleryPopup = false;
            this.galleryContainer5.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer5.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer5.MultiLine = false;
            this.galleryContainer5.Name = "galleryContainer5";
            this.galleryContainer5.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer5.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer16
            // 
            // 
            // 
            // 
            this.itemContainer16.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer16.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer16.Name = "itemContainer16";
            // 
            // 
            // 
            this.itemContainer16.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer17
            // 
            // 
            // 
            // 
            this.itemContainer17.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer17.ItemSpacing = 0;
            this.itemContainer17.Name = "itemContainer17";
            this.itemContainer17.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer18,
            this.galleryContainer6});
            // 
            // 
            // 
            this.itemContainer17.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer18
            // 
            // 
            // 
            // 
            this.itemContainer18.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer18.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer18.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer18.Name = "itemContainer18";
            // 
            // 
            // 
            this.itemContainer18.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer6
            // 
            // 
            // 
            // 
            this.galleryContainer6.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer6.EnableGalleryPopup = false;
            this.galleryContainer6.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer6.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer6.MultiLine = false;
            this.galleryContainer6.Name = "galleryContainer6";
            this.galleryContainer6.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer6.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer19
            // 
            // 
            // 
            // 
            this.itemContainer19.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer19.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer19.Name = "itemContainer19";
            // 
            // 
            // 
            this.itemContainer19.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer20
            // 
            // 
            // 
            // 
            this.itemContainer20.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer20.ItemSpacing = 0;
            this.itemContainer20.Name = "itemContainer20";
            this.itemContainer20.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer21,
            this.galleryContainer7});
            // 
            // 
            // 
            this.itemContainer20.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer21
            // 
            // 
            // 
            // 
            this.itemContainer21.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer21.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer21.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer21.Name = "itemContainer21";
            // 
            // 
            // 
            this.itemContainer21.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer7
            // 
            // 
            // 
            // 
            this.galleryContainer7.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer7.EnableGalleryPopup = false;
            this.galleryContainer7.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer7.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer7.MultiLine = false;
            this.galleryContainer7.Name = "galleryContainer7";
            this.galleryContainer7.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer7.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer22
            // 
            // 
            // 
            // 
            this.itemContainer22.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer22.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer22.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer22.Name = "itemContainer22";
            // 
            // 
            // 
            this.itemContainer22.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer23
            // 
            // 
            // 
            // 
            this.itemContainer23.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer23.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer23.ItemSpacing = 0;
            this.itemContainer23.Name = "itemContainer23";
            this.itemContainer23.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer24,
            this.galleryContainer8});
            // 
            // 
            // 
            this.itemContainer23.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer24
            // 
            // 
            // 
            // 
            this.itemContainer24.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer24.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer24.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer24.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer24.Name = "itemContainer24";
            // 
            // 
            // 
            this.itemContainer24.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer8
            // 
            // 
            // 
            // 
            this.galleryContainer8.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer8.EnableGalleryPopup = false;
            this.galleryContainer8.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer8.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer8.MultiLine = false;
            this.galleryContainer8.Name = "galleryContainer8";
            this.galleryContainer8.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer8.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer25
            // 
            // 
            // 
            // 
            this.itemContainer25.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer25.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer25.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer25.Name = "itemContainer25";
            // 
            // 
            // 
            this.itemContainer25.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer26
            // 
            // 
            // 
            // 
            this.itemContainer26.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer26.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer26.ItemSpacing = 0;
            this.itemContainer26.Name = "itemContainer26";
            this.itemContainer26.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer27,
            this.galleryContainer9});
            // 
            // 
            // 
            this.itemContainer26.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer27
            // 
            // 
            // 
            // 
            this.itemContainer27.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer27.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer27.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer27.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer27.Name = "itemContainer27";
            // 
            // 
            // 
            this.itemContainer27.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer9
            // 
            // 
            // 
            // 
            this.galleryContainer9.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer9.EnableGalleryPopup = false;
            this.galleryContainer9.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer9.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer9.MultiLine = false;
            this.galleryContainer9.Name = "galleryContainer9";
            this.galleryContainer9.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer9.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer28
            // 
            // 
            // 
            // 
            this.itemContainer28.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer28.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer28.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer28.Name = "itemContainer28";
            // 
            // 
            // 
            this.itemContainer28.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer29
            // 
            // 
            // 
            // 
            this.itemContainer29.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer29.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer29.ItemSpacing = 0;
            this.itemContainer29.Name = "itemContainer29";
            this.itemContainer29.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer30,
            this.galleryContainer10});
            // 
            // 
            // 
            this.itemContainer29.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer30
            // 
            // 
            // 
            // 
            this.itemContainer30.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer30.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer30.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer30.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer30.Name = "itemContainer30";
            // 
            // 
            // 
            this.itemContainer30.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer10
            // 
            // 
            // 
            // 
            this.galleryContainer10.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer10.EnableGalleryPopup = false;
            this.galleryContainer10.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer10.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer10.MultiLine = false;
            this.galleryContainer10.Name = "galleryContainer10";
            this.galleryContainer10.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer10.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer31
            // 
            // 
            // 
            // 
            this.itemContainer31.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer31.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer31.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer31.Name = "itemContainer31";
            // 
            // 
            // 
            this.itemContainer31.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer32
            // 
            // 
            // 
            // 
            this.itemContainer32.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer32.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer32.ItemSpacing = 0;
            this.itemContainer32.Name = "itemContainer32";
            this.itemContainer32.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer33,
            this.galleryContainer11});
            // 
            // 
            // 
            this.itemContainer32.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer33
            // 
            // 
            // 
            // 
            this.itemContainer33.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer33.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer33.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer33.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer33.Name = "itemContainer33";
            // 
            // 
            // 
            this.itemContainer33.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer11
            // 
            // 
            // 
            // 
            this.galleryContainer11.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer11.EnableGalleryPopup = false;
            this.galleryContainer11.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer11.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer11.MultiLine = false;
            this.galleryContainer11.Name = "galleryContainer11";
            this.galleryContainer11.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer11.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer34
            // 
            // 
            // 
            // 
            this.itemContainer34.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer34.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer34.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer34.Name = "itemContainer34";
            // 
            // 
            // 
            this.itemContainer34.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer35
            // 
            // 
            // 
            // 
            this.itemContainer35.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer35.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer35.ItemSpacing = 0;
            this.itemContainer35.Name = "itemContainer35";
            this.itemContainer35.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer36,
            this.galleryContainer12});
            // 
            // 
            // 
            this.itemContainer35.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer36
            // 
            // 
            // 
            // 
            this.itemContainer36.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer36.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer36.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer36.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer36.Name = "itemContainer36";
            // 
            // 
            // 
            this.itemContainer36.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer12
            // 
            // 
            // 
            // 
            this.galleryContainer12.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer12.EnableGalleryPopup = false;
            this.galleryContainer12.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer12.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer12.MultiLine = false;
            this.galleryContainer12.Name = "galleryContainer12";
            this.galleryContainer12.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer12.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer37
            // 
            // 
            // 
            // 
            this.itemContainer37.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer37.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer37.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer37.Name = "itemContainer37";
            // 
            // 
            // 
            this.itemContainer37.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer38
            // 
            // 
            // 
            // 
            this.itemContainer38.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer38.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer38.ItemSpacing = 0;
            this.itemContainer38.Name = "itemContainer38";
            this.itemContainer38.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer39,
            this.galleryContainer13});
            // 
            // 
            // 
            this.itemContainer38.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer39
            // 
            // 
            // 
            // 
            this.itemContainer39.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer39.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer39.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer39.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer39.Name = "itemContainer39";
            // 
            // 
            // 
            this.itemContainer39.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer13
            // 
            // 
            // 
            // 
            this.galleryContainer13.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer13.EnableGalleryPopup = false;
            this.galleryContainer13.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer13.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer13.MultiLine = false;
            this.galleryContainer13.Name = "galleryContainer13";
            this.galleryContainer13.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer13.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer40
            // 
            // 
            // 
            // 
            this.itemContainer40.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer40.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer40.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer40.Name = "itemContainer40";
            // 
            // 
            // 
            this.itemContainer40.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer41
            // 
            // 
            // 
            // 
            this.itemContainer41.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer41.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer41.ItemSpacing = 0;
            this.itemContainer41.Name = "itemContainer41";
            this.itemContainer41.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer42,
            this.galleryContainer14});
            // 
            // 
            // 
            this.itemContainer41.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer42
            // 
            // 
            // 
            // 
            this.itemContainer42.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer42.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer42.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer42.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer42.Name = "itemContainer42";
            // 
            // 
            // 
            this.itemContainer42.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer14
            // 
            // 
            // 
            // 
            this.galleryContainer14.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer14.EnableGalleryPopup = false;
            this.galleryContainer14.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer14.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer14.MultiLine = false;
            this.galleryContainer14.Name = "galleryContainer14";
            this.galleryContainer14.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer14.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer43
            // 
            // 
            // 
            // 
            this.itemContainer43.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer43.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer43.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer43.Name = "itemContainer43";
            // 
            // 
            // 
            this.itemContainer43.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem2
            // 
            this.buttonItem2.Name = "buttonItem2";
            this.buttonItem2.Text = "buttonItem2";
            // 
            // itemContainer44
            // 
            // 
            // 
            // 
            this.itemContainer44.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer44.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer44.ItemSpacing = 0;
            this.itemContainer44.Name = "itemContainer44";
            this.itemContainer44.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer45});
            // 
            // 
            // 
            this.itemContainer44.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer45
            // 
            // 
            // 
            // 
            this.itemContainer45.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer45.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer45.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer45.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer45.Name = "itemContainer45";
            this.itemContainer45.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem3});
            // 
            // 
            // 
            this.itemContainer45.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem3
            // 
            this.buttonItem3.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem3.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem3.Image")));
            this.buttonItem3.Name = "buttonItem3";
            this.buttonItem3.SubItemsExpandWidth = 24;
            this.buttonItem3.Text = "&New";
            // 
            // galleryContainer15
            // 
            // 
            // 
            // 
            this.galleryContainer15.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer15.EnableGalleryPopup = false;
            this.galleryContainer15.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer15.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer15.MultiLine = false;
            this.galleryContainer15.Name = "galleryContainer15";
            this.galleryContainer15.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer15.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer46
            // 
            // 
            // 
            // 
            this.itemContainer46.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer46.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer46.ItemSpacing = 0;
            this.itemContainer46.Name = "itemContainer46";
            this.itemContainer46.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer47});
            // 
            // 
            // 
            this.itemContainer46.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer47
            // 
            // 
            // 
            // 
            this.itemContainer47.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer47.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer47.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer47.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer47.Name = "itemContainer47";
            // 
            // 
            // 
            this.itemContainer47.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer16
            // 
            // 
            // 
            // 
            this.galleryContainer16.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer16.EnableGalleryPopup = false;
            this.galleryContainer16.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer16.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer16.MultiLine = false;
            this.galleryContainer16.Name = "galleryContainer16";
            this.galleryContainer16.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer16.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ribbonControl1.BackgroundImage = global::SimkapSmartServer.Properties.Resources.bg_menu_ribbon;
            this.ribbonControl1.BackgroundImagePosition = DevComponents.DotNetBar.eBackgroundImagePosition.Stretch;
            // 
            // 
            // 
            this.ribbonControl1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonControl1.CaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribbonControl1.CaptionVisible = true;
            this.ribbonControl1.Controls.Add(this.ribbonPanel1);
            this.ribbonControl1.Controls.Add(this.ribbonPanel2);
            this.ribbonControl1.Controls.Add(this.ribbonPanel4);
            this.ribbonControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonControl1.Font = new System.Drawing.Font("Roboto Condensed", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribbonControl1.ForeColor = System.Drawing.Color.Black;
            this.ribbonControl1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ribbonTabItem2,
            this.lblKelola,
            this.btnBantuan,
            this.btnClose});
            this.ribbonControl1.KeyTipsFont = new System.Drawing.Font("Tahoma", 7F);
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.ribbonControl1.QuickToolbarItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem4,
            this.qatCustomizeItem1});
            this.ribbonControl1.RibbonStripFont = new System.Drawing.Font("Roboto Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribbonControl1.Size = new System.Drawing.Size(827, 174);
            this.ribbonControl1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonControl1.SystemText.MaximizeRibbonText = "&Maximize the Ribbon";
            this.ribbonControl1.SystemText.MinimizeRibbonText = "Mi&nimize the Ribbon";
            this.ribbonControl1.SystemText.QatAddItemText = "&Add to Quick Access Toolbar";
            this.ribbonControl1.SystemText.QatCustomizeMenuLabel = "<b>Customize Quick Access Toolbar</b>";
            this.ribbonControl1.SystemText.QatCustomizeText = "&Customize Quick Access Toolbar...";
            this.ribbonControl1.SystemText.QatDialogAddButton = "&Add >>";
            this.ribbonControl1.SystemText.QatDialogCancelButton = "Cancel";
            this.ribbonControl1.SystemText.QatDialogCaption = "Customize Quick Access Toolbar";
            this.ribbonControl1.SystemText.QatDialogCategoriesLabel = "&Choose commands from:";
            this.ribbonControl1.SystemText.QatDialogOkButton = "OK";
            this.ribbonControl1.SystemText.QatDialogPlacementCheckbox = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl1.SystemText.QatDialogRemoveButton = "&Remove";
            this.ribbonControl1.SystemText.QatPlaceAboveRibbonText = "&Place Quick Access Toolbar above the Ribbon";
            this.ribbonControl1.SystemText.QatPlaceBelowRibbonText = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl1.SystemText.QatRemoveItemText = "&Remove from Quick Access Toolbar";
            this.ribbonControl1.TabGroupHeight = 14;
            this.ribbonControl1.TabIndex = 0;
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel1.Controls.Add(this.ribbonBar9);
            this.ribbonPanel1.Controls.Add(this.ribbonBar5);
            this.ribbonPanel1.Controls.Add(this.ribbonBar4);
            this.ribbonPanel1.Controls.Add(this.ribbonBar3);
            this.ribbonPanel1.Controls.Add(this.ribbonBar2);
            this.ribbonPanel1.Controls.Add(this.ribbonBar1);
            this.ribbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel1.Font = new System.Drawing.Font("Roboto Condensed", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 55);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel1.Size = new System.Drawing.Size(827, 116);
            // 
            // 
            // 
            this.ribbonPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel1.TabIndex = 1;
            // 
            // ribbonBar9
            // 
            this.ribbonBar9.AutoOverflowEnabled = true;
            this.ribbonBar9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar9.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar9.ContainerControlProcessDialogKey = true;
            this.ribbonBar9.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar9.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar9.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnLoginPegawai});
            this.ribbonBar9.Location = new System.Drawing.Point(541, 0);
            this.ribbonBar9.Name = "ribbonBar9";
            this.ribbonBar9.Size = new System.Drawing.Size(72, 113);
            this.ribbonBar9.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar9.TabIndex = 5;
            // 
            // 
            // 
            this.ribbonBar9.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar9.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnLoginPegawai
            // 
            this.btnLoginPegawai.Image = global::SimkapSmartServer.Properties.Resources.login_pegawai;
            this.btnLoginPegawai.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnLoginPegawai.Name = "btnLoginPegawai";
            this.btnLoginPegawai.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnLoginPegawai.SubItemsExpandWidth = 14;
            this.btnLoginPegawai.Text = "Login Pegawai";
            this.btnLoginPegawai.Tooltip = "Login Pegawai";
            this.btnLoginPegawai.Click += new System.EventHandler(this.btnLoginPegawai_Click);
            // 
            // ribbonBar5
            // 
            this.ribbonBar5.AutoOverflowEnabled = true;
            this.ribbonBar5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar5.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar5.ContainerControlProcessDialogKey = true;
            this.ribbonBar5.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar5.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar5.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnAdmin});
            this.ribbonBar5.Location = new System.Drawing.Point(457, 0);
            this.ribbonBar5.Name = "ribbonBar5";
            this.ribbonBar5.Size = new System.Drawing.Size(84, 113);
            this.ribbonBar5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar5.TabIndex = 4;
            // 
            // 
            // 
            this.ribbonBar5.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnAdmin
            // 
            this.btnAdmin.Image = global::SimkapSmartServer.Properties.Resources.admin;
            this.btnAdmin.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnAdmin.SubItemsExpandWidth = 14;
            this.btnAdmin.Text = "Administrator";
            this.btnAdmin.Tooltip = "Administrator";
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // ribbonBar4
            // 
            this.ribbonBar4.AutoOverflowEnabled = true;
            this.ribbonBar4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar4.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar4.ContainerControlProcessDialogKey = true;
            this.ribbonBar4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar4.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar4.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnUnitKerja});
            this.ribbonBar4.Location = new System.Drawing.Point(390, 0);
            this.ribbonBar4.Name = "ribbonBar4";
            this.ribbonBar4.Size = new System.Drawing.Size(67, 113);
            this.ribbonBar4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar4.TabIndex = 3;
            // 
            // 
            // 
            this.ribbonBar4.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnUnitKerja
            // 
            this.btnUnitKerja.Image = global::SimkapSmartServer.Properties.Resources.unit_kerja;
            this.btnUnitKerja.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnUnitKerja.Name = "btnUnitKerja";
            this.btnUnitKerja.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnUnitKerja.SubItemsExpandWidth = 14;
            this.btnUnitKerja.Text = "Unit Kerja";
            this.btnUnitKerja.Tooltip = "Unit Kerja";
            this.btnUnitKerja.Click += new System.EventHandler(this.btnUnitKerja_Click);
            // 
            // ribbonBar3
            // 
            this.ribbonBar3.AutoOverflowEnabled = true;
            this.ribbonBar3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar3.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar3.ContainerControlProcessDialogKey = true;
            this.ribbonBar3.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar3.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar3.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnKegiatan,
            this.btnJenisKegiatan});
            this.ribbonBar3.Location = new System.Drawing.Point(255, 0);
            this.ribbonBar3.Name = "ribbonBar3";
            this.ribbonBar3.Size = new System.Drawing.Size(135, 113);
            this.ribbonBar3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar3.TabIndex = 2;
            // 
            // 
            // 
            this.ribbonBar3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar3.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnKegiatan
            // 
            this.btnKegiatan.Image = global::SimkapSmartServer.Properties.Resources.kegiatan;
            this.btnKegiatan.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnKegiatan.Name = "btnKegiatan";
            this.btnKegiatan.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnKegiatan.SubItemsExpandWidth = 14;
            this.btnKegiatan.Text = "Kegiatan";
            this.btnKegiatan.Tooltip = "Kegiatan";
            this.btnKegiatan.Click += new System.EventHandler(this.btnKegiatan_Click);
            // 
            // btnJenisKegiatan
            // 
            this.btnJenisKegiatan.Image = global::SimkapSmartServer.Properties.Resources.jenis_kegiatan;
            this.btnJenisKegiatan.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnJenisKegiatan.Name = "btnJenisKegiatan";
            this.btnJenisKegiatan.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnJenisKegiatan.SubItemsExpandWidth = 14;
            this.btnJenisKegiatan.Text = "Jenis Kegiatan";
            this.btnJenisKegiatan.Tooltip = "Jenis Kegiatan";
            this.btnJenisKegiatan.Click += new System.EventHandler(this.btnJenisKegiatan_Click);
            // 
            // ribbonBar2
            // 
            this.ribbonBar2.AutoOverflowEnabled = true;
            this.ribbonBar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar2.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.ContainerControlProcessDialogKey = true;
            this.ribbonBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar2.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnAtasanPenilai,
            this.btnPejabatPenilai});
            this.ribbonBar2.Location = new System.Drawing.Point(135, 0);
            this.ribbonBar2.Name = "ribbonBar2";
            this.ribbonBar2.Size = new System.Drawing.Size(120, 113);
            this.ribbonBar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar2.TabIndex = 1;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnAtasanPenilai
            // 
            this.btnAtasanPenilai.Image = global::SimkapSmartServer.Properties.Resources.atasan_penilai;
            this.btnAtasanPenilai.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnAtasanPenilai.Name = "btnAtasanPenilai";
            this.btnAtasanPenilai.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnAtasanPenilai.SubItemsExpandWidth = 14;
            this.btnAtasanPenilai.Text = "Atasan Penilai";
            this.btnAtasanPenilai.Tooltip = "Atasan Penilai";
            this.btnAtasanPenilai.Click += new System.EventHandler(this.btnAtasanPenilai_Click);
            // 
            // btnPejabatPenilai
            // 
            this.btnPejabatPenilai.Image = global::SimkapSmartServer.Properties.Resources.penilai;
            this.btnPejabatPenilai.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnPejabatPenilai.Name = "btnPejabatPenilai";
            this.btnPejabatPenilai.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnPejabatPenilai.SubItemsExpandWidth = 14;
            this.btnPejabatPenilai.Text = "Penilai";
            this.btnPejabatPenilai.Tooltip = "Penilai";
            this.btnPejabatPenilai.Click += new System.EventHandler(this.btnPejabatPenilai_Click);
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            this.ribbonBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar1.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar1.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Center;
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnPegawai,
            this.btnKegiatanPegawai});
            this.ribbonBar1.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(132, 113);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar1.TabIndex = 0;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnPegawai
            // 
            this.btnPegawai.Image = global::SimkapSmartServer.Properties.Resources.pegawai;
            this.btnPegawai.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnPegawai.Name = "btnPegawai";
            this.btnPegawai.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnPegawai.SubItemsExpandWidth = 14;
            this.btnPegawai.Text = "Pegawai";
            this.btnPegawai.Tooltip = "Data Pegawai";
            this.btnPegawai.Click += new System.EventHandler(this.btnPegawai_Click);
            // 
            // btnKegiatanPegawai
            // 
            this.btnKegiatanPegawai.Image = global::SimkapSmartServer.Properties.Resources.kegiatan_pegawai;
            this.btnKegiatanPegawai.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnKegiatanPegawai.Name = "btnKegiatanPegawai";
            this.btnKegiatanPegawai.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnKegiatanPegawai.SubItemsExpandWidth = 14;
            this.btnKegiatanPegawai.Text = "Kegiatan Pegawai";
            this.btnKegiatanPegawai.Tooltip = "Kegiatan Pegawai";
            this.btnKegiatanPegawai.Click += new System.EventHandler(this.btnKegiatanPegawai_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel4.Controls.Add(this.ribbonBar11);
            this.ribbonPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel4.Location = new System.Drawing.Point(0, 55);
            this.ribbonPanel4.Name = "ribbonPanel4";
            this.ribbonPanel4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel4.Size = new System.Drawing.Size(827, 116);
            // 
            // 
            // 
            this.ribbonPanel4.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel4.TabIndex = 4;
            this.ribbonPanel4.Visible = false;
            // 
            // ribbonBar11
            // 
            this.ribbonBar11.AutoOverflowEnabled = true;
            this.ribbonBar11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar11.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar11.ContainerControlProcessDialogKey = true;
            this.ribbonBar11.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar11.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar11.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnTentangSimkap});
            this.ribbonBar11.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar11.Name = "ribbonBar11";
            this.ribbonBar11.Size = new System.Drawing.Size(87, 113);
            this.ribbonBar11.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar11.TabIndex = 0;
            // 
            // 
            // 
            this.ribbonBar11.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar11.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnTentangSimkap
            // 
            this.btnTentangSimkap.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnTentangSimkap.Image = global::SimkapSmartServer.Properties.Resources.simkap;
            this.btnTentangSimkap.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnTentangSimkap.Name = "btnTentangSimkap";
            this.btnTentangSimkap.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnTentangSimkap.SubItemsExpandWidth = 14;
            this.btnTentangSimkap.Text = "Tentang SIMKAP";
            this.btnTentangSimkap.Tooltip = "Tentang SIMKAP";
            this.btnTentangSimkap.Click += new System.EventHandler(this.btnTentangSimkap_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel2.Controls.Add(this.ribbonBar7);
            this.ribbonPanel2.Controls.Add(this.ribbonBar6);
            this.ribbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel2.Location = new System.Drawing.Point(0, 55);
            this.ribbonPanel2.Name = "ribbonPanel2";
            this.ribbonPanel2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel2.Size = new System.Drawing.Size(827, 116);
            // 
            // 
            // 
            this.ribbonPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel2.TabIndex = 2;
            this.ribbonPanel2.Visible = false;
            // 
            // ribbonBar7
            // 
            this.ribbonBar7.AutoOverflowEnabled = true;
            this.ribbonBar7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar7.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar7.ContainerControlProcessDialogKey = true;
            this.ribbonBar7.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar7.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar7.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnCPU});
            this.ribbonBar7.Location = new System.Drawing.Point(81, 0);
            this.ribbonBar7.Name = "ribbonBar7";
            this.ribbonBar7.Size = new System.Drawing.Size(74, 113);
            this.ribbonBar7.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar7.TabIndex = 1;
            // 
            // 
            // 
            this.ribbonBar7.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar7.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnCPU
            // 
            this.btnCPU.Image = global::SimkapSmartServer.Properties.Resources.CPU;
            this.btnCPU.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCPU.Name = "btnCPU";
            this.btnCPU.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnCPU.SubItemsExpandWidth = 14;
            this.btnCPU.Text = "Monitor CPU";
            this.btnCPU.Click += new System.EventHandler(this.btnCPU_Click);
            // 
            // ribbonBar6
            // 
            this.ribbonBar6.AutoOverflowEnabled = true;
            this.ribbonBar6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.ribbonBar6.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar6.ContainerControlProcessDialogKey = true;
            this.ribbonBar6.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar6.ForeColor = System.Drawing.Color.Black;
            this.ribbonBar6.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnServer});
            this.ribbonBar6.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar6.Name = "ribbonBar6";
            this.ribbonBar6.Size = new System.Drawing.Size(78, 113);
            this.ribbonBar6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar6.TabIndex = 0;
            // 
            // 
            // 
            this.ribbonBar6.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnServer
            // 
            this.btnServer.Image = global::SimkapSmartServer.Properties.Resources.server;
            this.btnServer.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnServer.Name = "btnServer";
            this.btnServer.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8);
            this.btnServer.SubItemsExpandWidth = 14;
            this.btnServer.Text = "Pengaturan Server";
            this.btnServer.Tooltip = "Server";
            this.btnServer.Click += new System.EventHandler(this.btnServer_Click);
            // 
            // ribbonTabItem2
            // 
            this.ribbonTabItem2.Name = "ribbonTabItem2";
            this.ribbonTabItem2.Panel = this.ribbonPanel2;
            this.ribbonTabItem2.Text = "Panel Kontrol";
            // 
            // lblKelola
            // 
            this.lblKelola.Checked = true;
            this.lblKelola.Name = "lblKelola";
            this.lblKelola.Panel = this.ribbonPanel1;
            this.lblKelola.Text = "Kelola Data";
            // 
            // btnBantuan
            // 
            this.btnBantuan.Name = "btnBantuan";
            this.btnBantuan.Panel = this.ribbonPanel4;
            this.btnBantuan.Text = "Bantuan";
            // 
            // btnClose
            // 
            this.btnClose.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.HotForeColor = System.Drawing.Color.Transparent;
            this.btnClose.Name = "btnClose";
            this.btnClose.Symbol = "";
            this.btnClose.Tooltip = "Keluar";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // labelItem4
            // 
            this.labelItem4.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.labelItem4.CanCustomize = false;
            this.labelItem4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelItem4.Name = "labelItem4";
            this.labelItem4.Text = "Menu - Sistem Informasi Manajemen Kegiatan Pegawai 1.0.0";
            // 
            // qatCustomizeItem1
            // 
            this.qatCustomizeItem1.Name = "qatCustomizeItem1";
            this.qatCustomizeItem1.Visible = false;
            // 
            // applicationButton1
            // 
            this.applicationButton1.AutoExpandOnClick = true;
            this.applicationButton1.CanCustomize = false;
            this.applicationButton1.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.applicationButton1.Image = ((System.Drawing.Image)(resources.GetObject("applicationButton1.Image")));
            this.applicationButton1.ImagePaddingHorizontal = 2;
            this.applicationButton1.ImagePaddingVertical = 2;
            this.applicationButton1.Name = "applicationButton1";
            this.applicationButton1.ShowSubItems = false;
            this.applicationButton1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer1});
            this.applicationButton1.Text = "&File";
            // 
            // itemContainer1
            // 
            // 
            // 
            // 
            this.itemContainer1.BackgroundStyle.Class = "RibbonFileMenuContainer";
            this.itemContainer1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer1.Name = "itemContainer1";
            this.itemContainer1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer2,
            this.itemContainer4});
            // 
            // 
            // 
            this.itemContainer1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer48
            // 
            // 
            // 
            // 
            this.itemContainer48.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer48.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer48.ItemSpacing = 0;
            this.itemContainer48.Name = "itemContainer48";
            this.itemContainer48.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer49});
            // 
            // 
            // 
            this.itemContainer48.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer49
            // 
            // 
            // 
            // 
            this.itemContainer49.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer49.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer49.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer49.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer49.Name = "itemContainer49";
            // 
            // 
            // 
            this.itemContainer49.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // galleryContainer17
            // 
            // 
            // 
            // 
            this.galleryContainer17.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.galleryContainer17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.galleryContainer17.EnableGalleryPopup = false;
            this.galleryContainer17.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.galleryContainer17.MinimumSize = new System.Drawing.Size(180, 240);
            this.galleryContainer17.MultiLine = false;
            this.galleryContainer17.Name = "galleryContainer17";
            this.galleryContainer17.PopupUsesStandardScrollbars = false;
            // 
            // 
            // 
            this.galleryContainer17.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 174);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Panel1Collapsed = true;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackgroundImage = global::SimkapSmartServer.Properties.Resources.bg_menu;
            this.splitContainer1.Size = new System.Drawing.Size(827, 250);
            this.splitContainer1.SplitterDistance = 275;
            this.splitContainer1.TabIndex = 7;
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(827, 446);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.metroStatusBar1);
            this.Controls.Add(this.ribbonControl1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "    ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMenu_FormClosing);
            this.ribbonControl1.ResumeLayout(false);
            this.ribbonControl1.PerformLayout();
            this.ribbonPanel1.ResumeLayout(false);
            this.ribbonPanel4.ResumeLayout(false);
            this.ribbonPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl ribbonControl1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel2;
        private DevComponents.DotNetBar.RibbonTabItem lblKelola;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem2;
        private DevComponents.DotNetBar.QatCustomizeItem qatCustomizeItem1;
        private DevComponents.DotNetBar.StyleManager styleManager1;
        private DevComponents.DotNetBar.Metro.MetroStatusBar metroStatusBar1;
        private DevComponents.DotNetBar.LabelItem lblTanggal;
        private DevComponents.DotNetBar.LabelItem lblIpServer;
        private DevComponents.DotNetBar.LabelItem labelItem5;
        private DevComponents.DotNetBar.LabelItem lblHostServer;
        private DevComponents.DotNetBar.LabelItem labelItem4;
        private System.Windows.Forms.Timer timer1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar4;
        private DevComponents.DotNetBar.RibbonBar ribbonBar3;
        private DevComponents.DotNetBar.ButtonItem btnKegiatan;
        private DevComponents.DotNetBar.ButtonItem btnJenisKegiatan;
        private DevComponents.DotNetBar.RibbonBar ribbonBar2;
        private DevComponents.DotNetBar.ButtonItem btnAtasanPenilai;
        private DevComponents.DotNetBar.ButtonItem btnPejabatPenilai;
        private DevComponents.DotNetBar.ButtonItem btnPegawai;
        private DevComponents.DotNetBar.RibbonBar ribbonBar5;
        private DevComponents.DotNetBar.ButtonItem btnAdmin;
        private DevComponents.DotNetBar.ButtonItem btnUnitKerja;
        private DevComponents.DotNetBar.ButtonItem btnKegiatanPegawai;
        private DevComponents.DotNetBar.RibbonBar ribbonBar7;
        private DevComponents.DotNetBar.ButtonItem btnCPU;
        private DevComponents.DotNetBar.RibbonBar ribbonBar6;
        private DevComponents.DotNetBar.ButtonItem btnServer;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel4;
        private DevComponents.DotNetBar.RibbonBar ribbonBar11;
        private DevComponents.DotNetBar.ButtonItem btnTentangSimkap;
        private DevComponents.DotNetBar.RibbonTabItem btnBantuan;
        private DevComponents.DotNetBar.LabelItem labelItem45;
        private DevComponents.DotNetBar.LabelItem labelItem16;
        private DevComponents.DotNetBar.LabelItem labelItem17;
        private DevComponents.DotNetBar.LabelItem lblJam;
        private DevComponents.DotNetBar.LabelItem labelItem6;
        private DevComponents.DotNetBar.LabelItem labelItem2;
        private DevComponents.DotNetBar.LabelItem label;
        private DevComponents.DotNetBar.LabelItem labelItem1;
        private DevComponents.DotNetBar.LabelItem labelItem9;
        private DevComponents.DotNetBar.LabelItem labelItem3;
        private DevComponents.DotNetBar.LabelItem labelItem11;
        private DevComponents.DotNetBar.LabelItem labelItem12;
        private DevComponents.DotNetBar.LabelItem labelItem15;
        private DevComponents.DotNetBar.ApplicationButton applicationButton1;
        private DevComponents.DotNetBar.ItemContainer itemContainer1;
        private DevComponents.DotNetBar.ItemContainer itemContainer2;
        private DevComponents.DotNetBar.ItemContainer itemContainer3;
        private DevComponents.DotNetBar.ButtonItem buttonItem4;
        private DevComponents.DotNetBar.ButtonItem buttonItem5;
        private DevComponents.DotNetBar.ButtonItem buttonItem6;
        private DevComponents.DotNetBar.ButtonItem buttonItem7;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer1;
        private DevComponents.DotNetBar.ButtonItem buttonItem8;
        private DevComponents.DotNetBar.ButtonItem buttonItem9;
        private DevComponents.DotNetBar.ButtonItem buttonItem10;
        private DevComponents.DotNetBar.ButtonItem buttonItem11;
        private DevComponents.DotNetBar.ItemContainer itemContainer4;
        private DevComponents.DotNetBar.ButtonItem buttonItem12;
        private DevComponents.DotNetBar.ButtonItem buttonItem13;
        private DevComponents.DotNetBar.ButtonItem buttonItem1;
        private DevComponents.DotNetBar.ItemContainer itemContainer5;
        private DevComponents.DotNetBar.ItemContainer itemContainer6;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer2;
        private DevComponents.DotNetBar.ButtonItem buttonItem14;
        private DevComponents.DotNetBar.ButtonItem buttonItem15;
        private DevComponents.DotNetBar.ButtonItem buttonItem16;
        private DevComponents.DotNetBar.ItemContainer itemContainer7;
        private DevComponents.DotNetBar.ButtonItem buttonItem17;
        private DevComponents.DotNetBar.ButtonItem buttonItem18;
        private DevComponents.DotNetBar.ItemContainer itemContainer8;
        private DevComponents.DotNetBar.ItemContainer itemContainer9;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer3;
        private DevComponents.DotNetBar.ButtonItem buttonItem19;
        private DevComponents.DotNetBar.ItemContainer itemContainer10;
        private DevComponents.DotNetBar.ButtonItem buttonItem20;
        private DevComponents.DotNetBar.ButtonItem buttonItem21;
        private DevComponents.DotNetBar.ItemContainer itemContainer11;
        private DevComponents.DotNetBar.ItemContainer itemContainer12;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer4;
        private DevComponents.DotNetBar.ItemContainer itemContainer13;
        private DevComponents.DotNetBar.ButtonItem buttonItem22;
        private DevComponents.DotNetBar.ItemContainer itemContainer14;
        private DevComponents.DotNetBar.ItemContainer itemContainer15;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer5;
        private DevComponents.DotNetBar.ItemContainer itemContainer16;
        private DevComponents.DotNetBar.ItemContainer itemContainer17;
        private DevComponents.DotNetBar.ItemContainer itemContainer18;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer6;
        private DevComponents.DotNetBar.ItemContainer itemContainer19;
        private DevComponents.DotNetBar.ItemContainer itemContainer20;
        private DevComponents.DotNetBar.ItemContainer itemContainer21;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer7;
        private DevComponents.DotNetBar.ItemContainer itemContainer22;
        private DevComponents.DotNetBar.ItemContainer itemContainer23;
        private DevComponents.DotNetBar.ItemContainer itemContainer24;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer8;
        private DevComponents.DotNetBar.ItemContainer itemContainer25;
        private DevComponents.DotNetBar.ItemContainer itemContainer26;
        private DevComponents.DotNetBar.ItemContainer itemContainer27;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer9;
        private DevComponents.DotNetBar.ItemContainer itemContainer28;
        private DevComponents.DotNetBar.ItemContainer itemContainer29;
        private DevComponents.DotNetBar.ItemContainer itemContainer30;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer10;
        private DevComponents.DotNetBar.ItemContainer itemContainer31;
        private DevComponents.DotNetBar.ItemContainer itemContainer32;
        private DevComponents.DotNetBar.ItemContainer itemContainer33;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer11;
        private DevComponents.DotNetBar.ItemContainer itemContainer34;
        private DevComponents.DotNetBar.ItemContainer itemContainer35;
        private DevComponents.DotNetBar.ItemContainer itemContainer36;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer12;
        private DevComponents.DotNetBar.ItemContainer itemContainer37;
        private DevComponents.DotNetBar.ItemContainer itemContainer38;
        private DevComponents.DotNetBar.ItemContainer itemContainer39;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer13;
        private DevComponents.DotNetBar.ItemContainer itemContainer40;
        private DevComponents.DotNetBar.ItemContainer itemContainer41;
        private DevComponents.DotNetBar.ItemContainer itemContainer42;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer14;
        private DevComponents.DotNetBar.ItemContainer itemContainer43;
        private DevComponents.DotNetBar.ButtonItem btnClose;
        private DevComponents.DotNetBar.LabelItem lblNama;
        private DevComponents.DotNetBar.LabelItem labelItem8;
        private DevComponents.DotNetBar.RibbonBar ribbonBar9;
        private DevComponents.DotNetBar.ButtonItem btnLoginPegawai;
        private DevComponents.DotNetBar.ButtonItem buttonItem2;
        private DevComponents.DotNetBar.ItemContainer itemContainer44;
        private DevComponents.DotNetBar.ItemContainer itemContainer45;
        private DevComponents.DotNetBar.ButtonItem buttonItem3;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer15;
        private DevComponents.DotNetBar.ItemContainer itemContainer46;
        private DevComponents.DotNetBar.ItemContainer itemContainer47;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer16;
        private DevComponents.DotNetBar.ItemContainer itemContainer48;
        private DevComponents.DotNetBar.ItemContainer itemContainer49;
        private DevComponents.DotNetBar.GalleryContainer galleryContainer17;

        private IntLogServer ls;
        private string log;
        private string message;
        private System.Windows.Forms.SplitContainer splitContainer1;
    }
}