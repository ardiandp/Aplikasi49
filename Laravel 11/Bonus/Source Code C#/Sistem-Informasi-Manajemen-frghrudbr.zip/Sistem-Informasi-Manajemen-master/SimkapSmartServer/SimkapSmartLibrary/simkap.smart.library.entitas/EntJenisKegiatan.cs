﻿
namespace SimkapSmartLibrary.simkap.smart.library.entitas
{
    public class EntJenisKegiatan
    {
        private string idjenis;
        private string jenis;

        public string Idjenis
        {
            get
            {
                return idjenis;
            }

            set
            {
                idjenis = value;
            }
        }

        public string Jenis
        {
            get
            {
                return jenis;
            }

            set
            {
                jenis = value;
            }
        }
    }
}
