﻿
namespace SimkapSmartLibrary.simkap.smart.library.entitas
{
    public class EntAdministrator
    {
        private string idadmin;
        private string nama;
        private string jekel;
        private string namapengguna;
        private string passwordpengguna;

        public string Idadmin
        {
            get
            {
                return idadmin;
            }

            set
            {
                idadmin = value;
            }
        }

        public string Nama
        {
            get
            {
                return nama;
            }

            set
            {
                nama = value;
            }
        }

        public string Jekel
        {
            get
            {
                return jekel;
            }

            set
            {
                jekel = value;
            }
        }

        public string Namapengguna
        {
            get
            {
                return namapengguna;
            }

            set
            {
                namapengguna = value;
            }
        }

        public string Passwordpengguna
        {
            get
            {
                return passwordpengguna;
            }

            set
            {
                passwordpengguna = value;
            }
        }
    }
}
