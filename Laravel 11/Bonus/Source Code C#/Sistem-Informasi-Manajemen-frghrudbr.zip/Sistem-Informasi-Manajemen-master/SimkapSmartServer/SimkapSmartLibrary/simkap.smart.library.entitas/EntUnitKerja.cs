﻿
namespace SimkapSmartLibrary.simkap.smart.library.entitas
{
    public class EntUnitKerja
    {
        private string idunit;
        private string unitkerja;
        private string alamatunit;

        public string Idunit
        {
            get
            {
                return idunit;
            }

            set
            {
                idunit = value;
            }
        }

        public string Unitkerja
        {
            get
            {
                return unitkerja;
            }

            set
            {
                unitkerja = value;
            }
        }

        public string Alamatunit
        {
            get
            {
                return alamatunit;
            }

            set
            {
                alamatunit = value;
            }
        }
    }
}
