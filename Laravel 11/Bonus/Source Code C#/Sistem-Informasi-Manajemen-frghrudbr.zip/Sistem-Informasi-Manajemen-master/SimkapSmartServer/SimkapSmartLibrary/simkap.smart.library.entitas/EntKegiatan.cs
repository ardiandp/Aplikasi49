﻿
namespace SimkapSmartLibrary.simkap.smart.library.entitas
{
    public class EntKegiatan
    {
        private string idkegiatan;
        private string kegiatan;
        private string outputkegiatan;
        private string satuan;
        private string idjenis;
        private string status;
        private string keterangan;

        public string Idkegiatan
        {
            get
            {
                return idkegiatan;
            }

            set
            {
                idkegiatan = value;
            }
        }

        public string Kegiatan
        {
            get
            {
                return kegiatan;
            }

            set
            {
                kegiatan = value;
            }
        }

        public string Outputkegiatan
        {
            get
            {
                return outputkegiatan;
            }

            set
            {
                outputkegiatan = value;
            }
        }

        public string Satuan
        {
            get
            {
                return satuan;
            }

            set
            {
                satuan = value;
            }
        }

        public string Idjenis
        {
            get
            {
                return idjenis;
            }

            set
            {
                idjenis = value;
            }
        }

        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public string Keterangan
        {
            get
            {
                return keterangan;
            }

            set
            {
                keterangan = value;
            }
        }
    }
}
