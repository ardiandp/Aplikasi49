﻿
namespace SimkapSmartLibrary.simkap.smart.library.entitas
{
    public class EntPejabatPenilai
    {
        private string idpejabatpenilai;
        private string idpegawai;

        public string Idpejabatpenilai
        {
            get
            {
                return idpejabatpenilai;
            }

            set
            {
                idpejabatpenilai = value;
            }
        }

        public string Idpegawai
        {
            get
            {
                return idpegawai;
            }

            set
            {
                idpegawai = value;
            }
        }
    }
}
