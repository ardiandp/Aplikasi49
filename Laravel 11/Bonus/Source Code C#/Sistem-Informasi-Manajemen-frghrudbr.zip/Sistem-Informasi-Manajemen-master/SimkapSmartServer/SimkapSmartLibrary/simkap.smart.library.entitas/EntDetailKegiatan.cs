﻿
namespace SimkapSmartLibrary.simkap.smart.library.entitas
{
    public class EntDetailKegiatan
    {
        private string iddetailkegiatan;
        private string nip;
        private string idkegiatan;

        public string Iddetailkegiatan
        {
            get
            {
                return iddetailkegiatan;
            }

            set
            {
                iddetailkegiatan = value;
            }
        }

        public string Nip
        {
            get
            {
                return nip;
            }

            set
            {
                nip = value;
            }
        }

        public string Idkegiatan
        {
            get
            {
                return idkegiatan;
            }

            set
            {
                idkegiatan = value;
            }
        }
    }
}
