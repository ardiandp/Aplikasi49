﻿
namespace SimkapSmartLibrary.simkap.smart.library.entitas
{
    public class EntAtasanPejabatPenilai
    {
        private string idatasanpenilai;
        private string idpegawai;

        public string Idatasanpenilai
        {
            get
            {
                return idatasanpenilai;
            }

            set
            {
                idatasanpenilai = value;
            }
        }

        public string Idpegawai
        {
            get
            {
                return idpegawai;
            }

            set
            {
                idpegawai = value;
            }
        }
    }
}
