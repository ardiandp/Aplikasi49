﻿using SimkapSmartLibrary.simkap.smart.library.entitas;

namespace SimkapSmartLibrary.simkap.smart.library.interfaces
{
    public interface IntLoginServer
    {
        bool loginUser(EntAdministrator et, string dt);
    }
}
