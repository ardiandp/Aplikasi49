﻿
namespace SimkapSmartLibrary.simkap.smart.library.interfaces
{
    public interface IntGetValidation <T>
    {
        bool validationInsert(T et);
    }
}
