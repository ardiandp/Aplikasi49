﻿using System.Data;

namespace SimkapSmartLibrary.simkap.smart.library.interfaces
{
    public interface IntGetComboBox
    {
        DataTable setComboBox();
    }
}
