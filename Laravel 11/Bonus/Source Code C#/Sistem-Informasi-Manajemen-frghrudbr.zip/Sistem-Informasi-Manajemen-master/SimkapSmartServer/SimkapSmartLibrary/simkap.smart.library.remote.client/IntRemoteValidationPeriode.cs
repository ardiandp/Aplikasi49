﻿using SimkapSmartLibrary.simkap.smart.library.entitas;

namespace SimkapSmartLibrary.simkap.smart.library.remote.client
{
    public interface IntRemoteValidationPeriode
    {
        bool selectPeriode(EntValidationPeriode et);
    }
}
