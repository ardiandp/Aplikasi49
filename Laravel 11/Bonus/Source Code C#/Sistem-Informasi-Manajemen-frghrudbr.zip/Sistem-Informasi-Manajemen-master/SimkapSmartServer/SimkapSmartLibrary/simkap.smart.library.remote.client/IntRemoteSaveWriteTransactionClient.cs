﻿
namespace SimkapSmartLibrary.simkap.smart.library.remote.client
{
    public interface IntRemoteSaveWriteTransactionClient
    {
        void writeSaveLogTransactionClient(string text);
    }
}
