﻿
namespace SimkapSmartLibrary.simkap.smart.library.remote.client
{
    public interface IntRemoteWriteTransactionClient
    {
        void writeLogTransactionClient(string dt, string ip, int port);
    }
}
