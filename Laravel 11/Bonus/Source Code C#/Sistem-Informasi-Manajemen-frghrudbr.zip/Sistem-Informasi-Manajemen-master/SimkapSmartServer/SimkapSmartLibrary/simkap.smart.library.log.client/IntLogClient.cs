﻿
namespace SimkapSmartLibrary.simkap.smart.library.log.client
{
    public interface IntLogClient
    {
        byte[] readTransactionClient(object client);
    }
}
