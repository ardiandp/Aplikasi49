﻿namespace SimkapSmartClient.simkap.smart.client.dataset
{

    partial class Report
    {
    }
}
