﻿namespace APDRequestBoardLibrary
{
    public  class HealthEquipmentEx
    {

        public System.Int64 Id { get; set; }
        public System.Int64 Category { get; set; }
        public System.Int64 EquipmentCount { get; set; }
        public System.Int64 PersonId { get; set; }
    }
}