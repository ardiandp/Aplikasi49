# APDRequestBoard
Aplikasi sederhana menggunakan WPF untuk mencatat daftar orang yang membutuhkan dan memiliki kelebihan Alat Pelindung Diri (APD). Terinspirasi dari wabah COVID-19 di tahun 2020
