-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Nov 2024 pada 13.57
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravelsipeta`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `asets`
--

CREATE TABLE `asets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warga_id` bigint(20) UNSIGNED NOT NULL,
  `jenis_barang` enum('tanah','bangunan') NOT NULL,
  `luas` decimal(8,2) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `asets`
--

INSERT INTO `asets` (`id`, `warga_id`, `jenis_barang`, `luas`, `alamat`, `lampiran`, `created_at`, `updated_at`) VALUES
(1, 1, 'tanah', 99.44, '112 Hassan Fork\nEllsworthmouth, DC 38346-1456', 'maiores', '2024-11-22 05:53:59', '2024-11-22 05:53:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_07_22_133645_create_wargas_table', 1),
(5, '2024_07_22_134937_create_asets_table', 1),
(6, '2024_08_16_033945_create_pengajuans_table', 1),
(7, '2024_08_16_135745_create_pbbs_table', 1),
(8, '2024_08_16_141238_create_sporadiks_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `username` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pbbs`
--

CREATE TABLE `pbbs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `jenis_barang` enum('tanah','bangunan') NOT NULL,
  `luas` decimal(8,2) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_surat` varchar(25) NOT NULL,
  `tanggal_surat` date NOT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `pengajuan_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pbbs`
--

INSERT INTO `pbbs` (`id`, `jenis_barang`, `luas`, `alamat`, `no_surat`, `tanggal_surat`, `lampiran`, `pengajuan_id`, `created_at`, `updated_at`) VALUES
(1, 'tanah', 53.39, 'provident', 'quos', '1990-03-31', 'optio', 1, '2024-11-22 05:53:59', '2024-11-22 05:53:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengajuans`
--

CREATE TABLE `pengajuans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warga_id` bigint(20) UNSIGNED NOT NULL,
  `jenis_surat` enum('pbb','sporadik') NOT NULL,
  `tanggal` date NOT NULL,
  `perihal` varchar(50) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `lampiran` varchar(255) NOT NULL,
  `status` enum('Diterima','Ditolak','Diproses') NOT NULL,
  `pesan` varchar(150) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengajuans`
--

INSERT INTO `pengajuans` (`id`, `warga_id`, `jenis_surat`, `tanggal`, `perihal`, `keterangan`, `lampiran`, `status`, `pesan`, `created_at`, `updated_at`) VALUES
(1, 2, 'pbb', '1984-09-26', 'sint', 'sit', 'sequi', 'Diproses', 'dignissimos', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(2, 3, 'sporadik', '2019-05-21', 'dolores', 'cumque', 'eaque', 'Diterima', 'aperiam', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(3, 6, 'sporadik', '2010-11-02', 'rerum', 'voluptate', 'vel', 'Diproses', 'qui', '2024-11-22 05:55:43', '2024-11-22 05:55:43'),
(4, 9, 'sporadik', '2007-04-06', 'beatae', 'magni', 'nemo', 'Ditolak', 'deleniti', '2024-11-22 05:56:11', '2024-11-22 05:56:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('Z9Z3Wckmvm5UHi3gAWw0f1HLyIMbADmwGIPZ9pUR', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoibEpnVFpLSWJnOTVRYzdZOHVyQ3NFNXRqSmVXb0FZT2xxb1Y0QVJZYyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1732280182);

-- --------------------------------------------------------

--
-- Struktur dari tabel `sporadiks`
--

CREATE TABLE `sporadiks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pengajuan_id` bigint(20) UNSIGNED NOT NULL,
  `pemilik_lama_id` bigint(20) UNSIGNED NOT NULL,
  `pemilik_baru_id` bigint(20) UNSIGNED NOT NULL,
  `jenis_barang` enum('tanah','bangunan') NOT NULL,
  `luas` decimal(8,2) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_surat` varchar(25) NOT NULL,
  `tanggal_surat` date NOT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sporadiks`
--

INSERT INTO `sporadiks` (`id`, `pengajuan_id`, `pemilik_lama_id`, `pemilik_baru_id`, `jenis_barang`, `luas`, `alamat`, `no_surat`, `tanggal_surat`, `lampiran`, `created_at`, `updated_at`) VALUES
(1, 4, 10, 11, 'tanah', 762.43, 'nemo', 'eligendi', '1970-09-11', 'esse', '2024-11-22 05:56:11', '2024-11-22 05:56:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nik` varchar(16) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('warga','admin') NOT NULL DEFAULT 'warga',
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nik`, `password`, `role`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, '3127208210359764', '$2y$12$bOj3pL0tWkBv//6WowdX5.bixovl5ZFJUzrMtNqLEI5HFPrbl1dfu', 'admin', 1, 'UpLppDeQC7', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(2, '2896569963641231', '$2y$12$bOj3pL0tWkBv//6WowdX5.bixovl5ZFJUzrMtNqLEI5HFPrbl1dfu', 'warga', 1, 'qc4vvJX9hc', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(3, '3986445854141236', '$2y$12$bOj3pL0tWkBv//6WowdX5.bixovl5ZFJUzrMtNqLEI5HFPrbl1dfu', 'warga', 1, 'guCl9peiYF', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(4, '5102476501240016', '$2y$12$bOj3pL0tWkBv//6WowdX5.bixovl5ZFJUzrMtNqLEI5HFPrbl1dfu', 'warga', 1, 'EIRFOXziln', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(5, '7022115271016974', '$2y$12$bOj3pL0tWkBv//6WowdX5.bixovl5ZFJUzrMtNqLEI5HFPrbl1dfu', 'warga', 1, 'sfwFZ0UHlj', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(6, '3214230497628526', '$2y$12$bOj3pL0tWkBv//6WowdX5.bixovl5ZFJUzrMtNqLEI5HFPrbl1dfu', 'warga', 1, 'MmoBgFaa75', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(7, '5109909600403718', '$2y$12$EpAaC8cL6Rq3KEr8xSI0D.kwvz991sf4JfXpS8xBLJMc4WLdtojYa', 'warga', 1, 'y3ZbIHvHvv', '2024-11-22 05:55:43', '2024-11-22 05:55:43'),
(8, '1710004397666185', '$2y$12$EpAaC8cL6Rq3KEr8xSI0D.kwvz991sf4JfXpS8xBLJMc4WLdtojYa', 'warga', 1, 'uTJuiSfp2c', '2024-11-22 05:55:43', '2024-11-22 05:55:43'),
(9, '0498168561469291', '$2y$12$EpAaC8cL6Rq3KEr8xSI0D.kwvz991sf4JfXpS8xBLJMc4WLdtojYa', 'warga', 1, 'WFqI7kkb88', '2024-11-22 05:55:43', '2024-11-22 05:55:43'),
(10, '1850633417417572', '$2y$12$slnjOG94z7TgoygWk1kcUePqggnKvWUKwF/mz5Rg/vGmaC96A/CP6', 'warga', 1, 'LujsYSGxyD', '2024-11-22 05:56:11', '2024-11-22 05:56:11'),
(11, '6641932178091603', '$2y$12$slnjOG94z7TgoygWk1kcUePqggnKvWUKwF/mz5Rg/vGmaC96A/CP6', 'warga', 1, 'Vnst6IvhxD', '2024-11-22 05:56:11', '2024-11-22 05:56:11'),
(12, '6558332376182423', '$2y$12$slnjOG94z7TgoygWk1kcUePqggnKvWUKwF/mz5Rg/vGmaC96A/CP6', 'warga', 1, 'Uy2gUO1MgD', '2024-11-22 05:56:11', '2024-11-22 05:56:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `wargas`
--

CREATE TABLE `wargas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(25) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` varchar(16) NOT NULL,
  `jenis_kelamin` enum('laki-laki','perempuan') NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `wargas`
--

INSERT INTO `wargas` (`id`, `user_id`, `nama`, `alamat`, `no_telp`, `jenis_kelamin`, `tanggal_lahir`, `lampiran`, `created_at`, `updated_at`) VALUES
(1, 2, 'Orn', 'Molestiae perferendis.', '+19139571490', 'perempuan', '1984-07-28', 'qui', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(2, 3, 'Rodriguez', 'Reprehenderit inventore illo.', '+12628744531', 'perempuan', '1991-04-29', 'odit', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(3, 4, 'Schmitt', 'Est rerum temporibus.', '+14697969222', 'perempuan', '2008-09-14', 'consequatur', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(4, 5, 'Hill', 'Commodi et saepe.', '+16829020554', 'laki-laki', '2007-04-13', 'quis', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(5, 6, 'Weimann', 'Est quia.', '+14142522295', 'perempuan', '1981-04-13', 'similique', '2024-11-22 05:53:59', '2024-11-22 05:53:59'),
(6, 7, 'Thiel', 'Aut rem.', '+13513571983', 'laki-laki', '1972-08-05', 'atque', '2024-11-22 05:55:43', '2024-11-22 05:55:43'),
(7, 8, 'Corwin', 'Inventore officia.', '+13515595180', 'laki-laki', '2001-12-02', 'qui', '2024-11-22 05:55:43', '2024-11-22 05:55:43'),
(8, 9, 'Casper', 'Voluptatem sit aspernatur.', '+14144327341', 'laki-laki', '2017-11-06', 'unde', '2024-11-22 05:55:43', '2024-11-22 05:55:43'),
(9, 10, 'Beier', 'Facilis et.', '+19794455592', 'laki-laki', '2002-06-18', 'dignissimos', '2024-11-22 05:56:11', '2024-11-22 05:56:11'),
(10, 11, 'Hettinger', 'Accusantium eligendi.', '+18209093919', 'perempuan', '2008-02-23', 'beatae', '2024-11-22 05:56:11', '2024-11-22 05:56:11'),
(11, 12, 'Quigley', 'Ut repellendus tenetur.', '+15512849077', 'laki-laki', '2006-03-06', 'odit', '2024-11-22 05:56:11', '2024-11-22 05:56:11');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `asets`
--
ALTER TABLE `asets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asets_warga_id_foreign` (`warga_id`);

--
-- Indeks untuk tabel `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indeks untuk tabel `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `pbbs`
--
ALTER TABLE `pbbs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pbbs_pengajuan_id_foreign` (`pengajuan_id`);

--
-- Indeks untuk tabel `pengajuans`
--
ALTER TABLE `pengajuans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengajuans_warga_id_foreign` (`warga_id`);

--
-- Indeks untuk tabel `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indeks untuk tabel `sporadiks`
--
ALTER TABLE `sporadiks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sporadiks_pengajuan_id_foreign` (`pengajuan_id`),
  ADD KEY `sporadiks_pemilik_lama_id_foreign` (`pemilik_lama_id`),
  ADD KEY `sporadiks_pemilik_baru_id_foreign` (`pemilik_baru_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_nik_unique` (`nik`);

--
-- Indeks untuk tabel `wargas`
--
ALTER TABLE `wargas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wargas_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `asets`
--
ALTER TABLE `asets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `pbbs`
--
ALTER TABLE `pbbs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pengajuans`
--
ALTER TABLE `pengajuans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `sporadiks`
--
ALTER TABLE `sporadiks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `wargas`
--
ALTER TABLE `wargas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `asets`
--
ALTER TABLE `asets`
  ADD CONSTRAINT `asets_warga_id_foreign` FOREIGN KEY (`warga_id`) REFERENCES `wargas` (`id`);

--
-- Ketidakleluasaan untuk tabel `pbbs`
--
ALTER TABLE `pbbs`
  ADD CONSTRAINT `pbbs_pengajuan_id_foreign` FOREIGN KEY (`pengajuan_id`) REFERENCES `pengajuans` (`id`);

--
-- Ketidakleluasaan untuk tabel `pengajuans`
--
ALTER TABLE `pengajuans`
  ADD CONSTRAINT `pengajuans_warga_id_foreign` FOREIGN KEY (`warga_id`) REFERENCES `wargas` (`id`);

--
-- Ketidakleluasaan untuk tabel `sporadiks`
--
ALTER TABLE `sporadiks`
  ADD CONSTRAINT `sporadiks_pemilik_baru_id_foreign` FOREIGN KEY (`pemilik_baru_id`) REFERENCES `wargas` (`id`),
  ADD CONSTRAINT `sporadiks_pemilik_lama_id_foreign` FOREIGN KEY (`pemilik_lama_id`) REFERENCES `wargas` (`id`),
  ADD CONSTRAINT `sporadiks_pengajuan_id_foreign` FOREIGN KEY (`pengajuan_id`) REFERENCES `pengajuans` (`id`);

--
-- Ketidakleluasaan untuk tabel `wargas`
--
ALTER TABLE `wargas`
  ADD CONSTRAINT `wargas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
