<div class="flex justify-center items-center gap-5 mb-10">
    <img src="{{ asset('img/logo_jambi2.png') }}" alt="logo_jambi" width="70px">
    <span class="text-4xl font-bold">Kantor Kelurahan Sengeti</span>
    <img src="{{ asset('img/logo_jambi2.png') }}" alt="logo_jambi" width="70px">
</div>
