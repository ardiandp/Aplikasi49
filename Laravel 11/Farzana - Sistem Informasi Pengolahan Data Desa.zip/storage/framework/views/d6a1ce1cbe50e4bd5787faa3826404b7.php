<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="pagetitle">
        <h1>Data Surat Permohonan Pajak Bumi Bangunan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item">Surat Permohonan</li>
                <li class="breadcrumb-item">Pajak Bumi Bangunan</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title">
                                <a href="<?php echo e(route('admin.pbb.create')); ?>" class="btn btn-primary">Buat Surat Baru</a>
                            </h5>
                            
                        </div>
                        <!-- Table with stripped rows -->
                        <table id="listTable" class="table datatable">
                            <thead>
                                <tr style="font-weight: bold">
                                    <td>No Surat</td>
                                    <td>Tiket Pengajuan</td>
                                    <td>Pemohon</td>
                                    <td>Perihal</td>
                                    <td>Keterangan</td>
                                    <td>Tanggal Surat</td>
                                    <td class="no=print">Action</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pbbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('admin.pbb.detail', $pbb->hashid)); ?>"><?php echo e($pbb->no_surat); ?></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.pengajuan.detail', $pbb->pengajuan->hashid)); ?>">#<?php echo e($pbb->pengajuan->hashid); ?></a>
                                    </td>
                                    <td><?php echo e($pbb->pengajuan->warga->nama); ?></td>
                                    <td><?php echo e($pbb->pengajuan->perihal); ?></td>
                                    <td><?php echo e($pbb->pengajuan->keterangan); ?></td>
                                    <td><?php echo e($pbb->tanggal_surat); ?></td>
                                    <td class="no-print">
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('admin.pbb.edit', $pbb->hashid)); ?>" class="btn btn-sm btn-warning text-white">Edit</a>
                                            <div style="width: 10px;"></div>
                                            <button onclick="destroy('<?php echo e($pbb->hashid); ?>')" class="btn btn-sm btn-danger">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->
                    </div>
                </div>

            </div>
        </div>
    </section>

    <script>
        function destroy(id) {
            Swal.fire({
                title: 'Apakah Kamu Yakin?',
                text: "Ingin menghapus data Pajak Bumi Bangunan Ini!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Aku Yakin!',
                cancelButtonText: 'Tidak, Batalkan!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `/admin/pbb/destroy/${id}`;
                }
            })
        };
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Downloads\Compressed\sipeta_hati-main\resources\views/pages/admin/pbb/list.blade.php ENDPATH**/ ?>