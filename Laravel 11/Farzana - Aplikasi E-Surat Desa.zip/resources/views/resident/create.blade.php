@extends('layouts.app')

@section('content')
    @include('components.residentForm')
@endsection
