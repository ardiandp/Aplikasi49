<?php $__env->startSection('content'); ?>
<h1 class="font-semibold text-4xl pt-10 text-white">Buat surat</h1>
    <div class="w-full flex p-5 justify-center">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="w-full max-w-sm bg-white border border-gray-200 rounded-lg m-5 shadow dark:bg-gray-800 dark:border-gray-700">
                <a href="#" class="w-full flex justify-center">
                    <img class="p-8 rounded-t-lg" src="/img/surat.png" alt="product image" />
                </a>
                <div class="px-5 pb-5">
                    <a href="#" class="mb-2.5">
                        <h5 class="text-xl font-semibold tracking-tight mb-5 text-gray-900 dark:text-white">Surat Keterangan
                            <?php echo e($item['title']); ?>

                        </h5>
                    </a>

                    <div class="flex items-center justify-between">
                        <a href="/letter/<?php echo e($item['id']); ?>"
                            class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Buat</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Downloads\Compressed\esuratdesa-main\resources\views/pages/letters.blade.php ENDPATH**/ ?>