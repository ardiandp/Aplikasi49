<?php $__env->startSection('content'); ?>
    <div class="flex justify-between my-5 p-5">
        <h1 class="font-semibold text-4xl">Penduduk</h1>
        <?php if(auth()->user()->role == 'admin'): ?>
        <div>

            <a href="/dashboard/residents/import" class="bg-indigo-700 text-white rounded-md px-5 py-2">Import</a>
            <a href="/dashboard/residents/export" class="bg-green-700 text-white rounded-md px-5 py-2">Export</a>
            <a href="/dashboard/residents/create" class="bg-blue-700 text-white rounded-md px-5 py-2">Tambah</a>
        </div>
        <?php endif; ?>
    </div>
    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        No
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Nama
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Nik
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Tempat/tgl lahir
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Jenis Kelamin
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Agama
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Alamat
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Surat
                    </th>
                    <th scope="col" class="px-6 py-3">
                        <span class="sr-only">Edit</span>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $residents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr
                        class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            <?php echo e($i++); ?>

                        </th>
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            <?php echo e($person['name']); ?>

                        </th>
                        <td class="px-6 py-4">
                            <?php echo e($person['nik']); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($person['born_in'] . ', ' . \Carbon\Carbon::parse($person['birthday'])->translatedFormat('d F Y')); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($person['gender'] === 'male' ? 'Laki-Laki' : 'Perempuan'); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($person['religion']); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e('Dusun ' . $person['dusun'] . ' RT ' . $person['rt'] . ' / RW ' . $person['rw']); ?>

                        </td>
                        <td class="px-6 py-4">
                            <a href="#"
                            onclick="MakeLetter('<?php echo e($person['id']); ?>')"
                                class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Buat</a>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <?php if(auth()->user()->role == 'admin'): ?>
                                <a href="/dashboard/resident/edit?id=<?php echo e($person['id']); ?>"
                                    class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Edit</a>
                                <a href="#" onclick="Delete(<?php echo e($person['id']); ?>)"
                                    class="font-medium text-red-600 dark:text-red-500 hover:underline">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script>
        const Delete = (id) => {
            Swal.fire({
                title: "Hapus Penduduk ini?",
                icon: "warning",
                showCancelButton: true
            }).then(r => {
                if (r.isConfirmed) {
                    location.href = '/dashboard/resident/delete/' + id
                }
            })
        }
        const MakeLetter = (id) => {
            const categories = <?php echo json_encode($categories, 15, 512) ?>;

            const options = categories.map(cat =>
                `<option value="${cat.id}">Surat Keterangan ${cat.title}</option>`
            ).join('');

            Swal.fire({
                title: 'Pilih Surat',
                html: `
            <select id="categories-select" class="form-select rounded-md w-full mt-2">
                ${options}
            </select>
        `,

                confirmButtonText: 'Kirim',
                cancelButtonText: 'Batal',
                showCancelButton: true,
                preConfirm: () => {
                    const selectedValue = document.getElementById('categories-select').value;
                    if (!selectedValue) {
                        Swal.showValidationMessage('Pilih pendanda tangan terlebih dahulu');
                    }

                    return {
                        category: selectedValue,
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const {
                        category,
                    } = result.value;

                    location.href = `/dashboard/letter/add?resident=${id}&category=${category}`;

                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Downloads\Compressed\esuratdesa-main\resources\views/pages/dashboard/residents.blade.php ENDPATH**/ ?>