-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 01 Mar 2023 pada 16.17
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keuanganci4`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) UNSIGNED NOT NULL,
  `admin_username` varchar(255) NOT NULL,
  `admin_nama` varchar(255) NOT NULL,
  `role_id` int(11) UNSIGNED NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_keterangan` text DEFAULT NULL,
  `admin_status` int(11) NOT NULL DEFAULT 1,
  `admin_created` timestamp NOT NULL DEFAULT '2023-03-01 15:11:23',
  `admin_updated` timestamp NOT NULL DEFAULT '2023-03-01 15:11:23'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_nama`, `role_id`, `admin_password`, `admin_keterangan`, `admin_status`, `admin_created`, `admin_updated`) VALUES
(1, 'superadmin', 'Super Admin', 1, '$2a$04$DfyVXEesM0dwFBYVcb5H7u49qdLXQ4rxfIft8vlIzetHwsIWkIWTe', NULL, 1, '2023-03-01 15:12:11', '2023-03-01 15:12:11'),
(2, 'tu', 'Petugas TU', 2, '$2y$10$D4R1PSN37LZXQpksSnf29urR/6ugdhE48tE6cAaXxtSvxuCOXx.tK', NULL, 1, '2023-03-01 15:12:11', '2023-03-01 15:12:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin_log`
--

CREATE TABLE `admin_log` (
  `admin_log_id` int(11) UNSIGNED NOT NULL,
  `admin_username` varchar(255) NOT NULL,
  `admin_log_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `admin_log`
--

INSERT INTO `admin_log` (`admin_log_id`, `admin_username`, `admin_log_at`) VALUES
(1, 'superadmin', '2023-03-01 15:17:13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_transaksi`
--

CREATE TABLE `jenis_transaksi` (
  `jenis_transaksi_id` int(11) UNSIGNED NOT NULL,
  `jenis_transaksi_nama` varchar(255) NOT NULL,
  `jenis_transaksi_harga` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `jenis_transaksi`
--

INSERT INTO `jenis_transaksi` (`jenis_transaksi_id`, `jenis_transaksi_nama`, `jenis_transaksi_harga`) VALUES
(1, 'Pembayaran Infak', 10000000),
(2, 'LKS', 20000000),
(3, 'Daftar Ulang untuk kelas VII', 30000000),
(4, 'Ujian', 40000000),
(5, 'Studi Tour untuk kelas VIII', 50000000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2021-02-05-103126', 'App\\Database\\Migrations\\Role', 'default', 'App', 1677683483, 1),
(2, '2021-02-05-103213', 'App\\Database\\Migrations\\Admin', 'default', 'App', 1677683484, 1),
(3, '2021-02-05-103531', 'App\\Database\\Migrations\\AdminLog', 'default', 'App', 1677683485, 1),
(4, '2021-02-05-103616', 'App\\Database\\Migrations\\Siswa', 'default', 'App', 1677683486, 1),
(5, '2021-02-05-103714', 'App\\Database\\Migrations\\SiswaLog', 'default', 'App', 1677683487, 1),
(6, '2021-02-06-031436', 'App\\Database\\Migrations\\JenisTransaksi', 'default', 'App', 1677683488, 1),
(7, '2021-02-06-043909', 'App\\Database\\Migrations\\Transaksi', 'default', 'App', 1677683491, 1),
(8, '2021-02-06-043909', 'App\\Database\\Migrations\\TransaksiPembayaran', 'default', 'App', 1677683493, 1),
(9, '2021-02-15-111244', 'App\\Database\\Migrations\\TransaksiItem', 'default', 'App', 1677683495, 1),
(10, '2021-03-07-033632', 'App\\Database\\Migrations\\Kelas', 'default', 'App', 1677683495, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `role`
--

CREATE TABLE `role` (
  `role_id` int(11) UNSIGNED NOT NULL,
  `role_nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `role`
--

INSERT INTO `role` (`role_id`, `role_nama`) VALUES
(1, 'super admin'),
(2, 'petugas TU');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `siswa_id` int(11) UNSIGNED NOT NULL,
  `siswa_nis` varchar(255) NOT NULL,
  `siswa_nama` varchar(255) NOT NULL,
  `siswa_alamat` text NOT NULL,
  `siswa_password` varchar(255) NOT NULL,
  `siswa_created` timestamp NOT NULL DEFAULT '2023-03-01 15:11:25',
  `siswa_updated` timestamp NOT NULL DEFAULT '2023-03-01 15:11:25'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`siswa_id`, `siswa_nis`, `siswa_nama`, `siswa_alamat`, `siswa_password`, `siswa_created`, `siswa_updated`) VALUES
(1, '2001', 'Heraya', 'Banjarnegara', '$2y$10$fPSfAL890PvqwW/PGypJIe5zqVCstKLEs3SBu1jKuR8fTEBt0R93O', '2023-03-01 15:12:15', '2023-03-01 15:12:15'),
(2, '2002', 'Fitra', 'Jawa Tengah', '$2y$10$fPSfAL890PvqwW/PGypJIe5zqVCstKLEs3SBu1jKuR8fTEBt0R93O', '2023-03-01 15:12:15', '2023-03-01 15:12:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa_log`
--

CREATE TABLE `siswa_log` (
  `siswa_log_id` int(11) UNSIGNED NOT NULL,
  `siswa_nis` varchar(255) NOT NULL,
  `siswa_log_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `transaksi_id` int(11) UNSIGNED NOT NULL,
  `siswa_id` int(11) UNSIGNED NOT NULL,
  `transaksi_status` int(11) NOT NULL DEFAULT 0,
  `transaksi_status_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `transaksi_by` int(11) UNSIGNED DEFAULT NULL,
  `transaksi_created` timestamp NOT NULL DEFAULT '2023-03-01 15:11:28'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_item`
--

CREATE TABLE `transaksi_item` (
  `transaksi_item_id` int(11) UNSIGNED NOT NULL,
  `transaksi_id` int(11) UNSIGNED NOT NULL,
  `jenis_transaksi_id` int(11) UNSIGNED NOT NULL,
  `transaksi_item_harga` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_pembayaran`
--

CREATE TABLE `transaksi_pembayaran` (
  `transaksi_pembayaran_id` int(11) UNSIGNED NOT NULL,
  `transaksi_id` int(11) UNSIGNED NOT NULL,
  `transaksi_pembayaran_bayar` int(11) NOT NULL DEFAULT 0,
  `transaksi_pembayaran_by` int(11) UNSIGNED NOT NULL,
  `transaksi_pembayaran_keterangan` text NOT NULL,
  `transaksi_pembayaran_created` timestamp NOT NULL DEFAULT '2023-03-01 15:11:31'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_username` (`admin_username`),
  ADD KEY `admin_role_id_foreign` (`role_id`);

--
-- Indeks untuk tabel `admin_log`
--
ALTER TABLE `admin_log`
  ADD PRIMARY KEY (`admin_log_id`);

--
-- Indeks untuk tabel `jenis_transaksi`
--
ALTER TABLE `jenis_transaksi`
  ADD PRIMARY KEY (`jenis_transaksi_id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`siswa_id`),
  ADD UNIQUE KEY `siswa_nis` (`siswa_nis`);

--
-- Indeks untuk tabel `siswa_log`
--
ALTER TABLE `siswa_log`
  ADD PRIMARY KEY (`siswa_log_id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`transaksi_id`),
  ADD KEY `transaksi_siswa_id_foreign` (`siswa_id`),
  ADD KEY `transaksi_transaksi_by_foreign` (`transaksi_by`);

--
-- Indeks untuk tabel `transaksi_item`
--
ALTER TABLE `transaksi_item`
  ADD PRIMARY KEY (`transaksi_item_id`),
  ADD KEY `transaksi_item_transaksi_id_foreign` (`transaksi_id`),
  ADD KEY `transaksi_item_jenis_transaksi_id_foreign` (`jenis_transaksi_id`);

--
-- Indeks untuk tabel `transaksi_pembayaran`
--
ALTER TABLE `transaksi_pembayaran`
  ADD PRIMARY KEY (`transaksi_pembayaran_id`),
  ADD KEY `transaksi_pembayaran_transaksi_id_foreign` (`transaksi_id`),
  ADD KEY `transaksi_pembayaran_transaksi_pembayaran_by_foreign` (`transaksi_pembayaran_by`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `admin_log`
--
ALTER TABLE `admin_log`
  MODIFY `admin_log_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `jenis_transaksi`
--
ALTER TABLE `jenis_transaksi`
  MODIFY `jenis_transaksi_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `siswa_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `siswa_log`
--
ALTER TABLE `siswa_log`
  MODIFY `siswa_log_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `transaksi_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `transaksi_item`
--
ALTER TABLE `transaksi_item`
  MODIFY `transaksi_item_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `transaksi_pembayaran`
--
ALTER TABLE `transaksi_pembayaran`
  MODIFY `transaksi_pembayaran_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`);

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa` (`siswa_id`),
  ADD CONSTRAINT `transaksi_transaksi_by_foreign` FOREIGN KEY (`transaksi_by`) REFERENCES `admin` (`admin_id`);

--
-- Ketidakleluasaan untuk tabel `transaksi_item`
--
ALTER TABLE `transaksi_item`
  ADD CONSTRAINT `transaksi_item_jenis_transaksi_id_foreign` FOREIGN KEY (`jenis_transaksi_id`) REFERENCES `jenis_transaksi` (`jenis_transaksi_id`),
  ADD CONSTRAINT `transaksi_item_transaksi_id_foreign` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`transaksi_id`);

--
-- Ketidakleluasaan untuk tabel `transaksi_pembayaran`
--
ALTER TABLE `transaksi_pembayaran`
  ADD CONSTRAINT `transaksi_pembayaran_transaksi_id_foreign` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`transaksi_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_pembayaran_transaksi_pembayaran_by_foreign` FOREIGN KEY (`transaksi_pembayaran_by`) REFERENCES `admin` (`admin_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
