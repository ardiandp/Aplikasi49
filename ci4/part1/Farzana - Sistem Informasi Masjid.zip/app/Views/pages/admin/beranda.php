<?= $this->extend('layout/page_layout'); ?>
<?= $this->section('content'); ?>

<div class="container">

</div>
<?= $this->endSection(''); ?>