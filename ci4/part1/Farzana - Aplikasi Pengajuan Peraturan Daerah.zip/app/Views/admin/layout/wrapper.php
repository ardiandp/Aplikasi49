<?php
echo view('admin/layout/head');
echo view('admin/layout/navbar');
echo view('admin/layout/sidebar');
echo view('admin/layout/content');
echo view('admin/layout/footer');
echo view('admin/layout/js');
