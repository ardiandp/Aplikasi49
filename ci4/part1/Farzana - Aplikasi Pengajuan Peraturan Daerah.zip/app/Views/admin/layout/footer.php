<footer class="footer">
    <center>
        <div class="copyright ml-auto">
            <span>Copyright &copy; <?= date('Y'); ?> SIPENBARA versi 1.0</span>
        </div>
    </center>
</footer>
</div>

</body>

</html>