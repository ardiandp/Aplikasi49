<?php
echo view('front/layout/head.php');
echo view('front/layout/header.php');
echo view('front/layout/content.php');
echo view('front/layout/footer.php');
