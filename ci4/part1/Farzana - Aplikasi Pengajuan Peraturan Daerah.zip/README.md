# How to install 

1. git clone https://github.com/abiihutabarat29/apperda.git
2. Composser i
3. Pastekan file vendor ke 2 kedalam public, download disini >>  https://drive.google.com/file/d/1vSKVaLm5apFcRriV9a7x-eneTjSw1Bex/view?usp=sharing
4. Import database dari folder db
5. Tambahkan file .env jika kosong, download disini >> https://drive.google.com/file/d/1I_c1nbFLDuaKgAdedXL-8iJ4L3A-is_R/view?usp=sharing
