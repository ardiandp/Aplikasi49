<footer class="footer d-flex justify-content-end">
    <div><span class="text-primary">Sistem Informasi Akuntansi Penjualan - Siap</span> &copy; <?= date('Y'); ?> | Dina Sukmawati - 19.120.0019<div>
</footer>