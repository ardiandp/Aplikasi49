<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
   <path fill="#4D31B9" fill-opacity="1" d="M0,128L1440,224L1440,320L0,320Z"></path>
</svg>
<footer class="sticky-footer">
   <div class="container">
      <div class="row">
         <div class="col-12 col-md-6 col-lg-4 mb-2">
            <h3>Tentang Kami</h3>
            <p>Kawan Baiker’s Indonesia adalah komunitas motor dari segala jenis motor yang dirikan oleh 12 founder yang berasal dari penjuru Indonesia mulai dari Lombok, Sulawesi, Jawa, hingga Sumatera. Struktur organisasi ini memiliki ketua yang bernama Moh Oesai Basyrahil dan wakil ketua H. Reza serta bendahara Erland Darmadi dan penasehat Wuwuh Setiawan. Untuk anggotanya sudah mencapai 340 yang terdiri dari penjuru Indonesia. Wilayah yang sudah terdaftar dalam organisasi ini yaitu Banyumas, Pemalang, Tangerang, Bekasi, Sidoarjo, Surabaya, Muara Enim, Padang Pariaman, Rokan Hulu,Sulawesi Selatan, Lampung, Lombok.</p>
         </div>
         <div class="col-12 col-md-6 col-lg-4 mb-2">
            <h3>Alamat Kami</h3>
            <p>Jl. Pesantren Rt 06 / Rw 07, Dukuhwaluh, Dusun II, Dukuhwaluh, Kec. Kembaran, Kabupaten Banyumas, Jawa Tengah 53182.</p>
         </div>
         <div class="col-12 col-md-6 col-lg-4 mb-2">
            <h3>Kontak</h3>
            <a href="https://wa.me/+6281225592522" target="_blank" class="text-decoration-none"><i class="fab fa-whatsapp"></i> +62 812-2559-2522</a>
            <a href="mailto:kawanbikers@gmail.com" target="_blank" class="text-decoration-none"><i class="fas fa-envelope"></i> kawanbikers@gmail.com</a>
            <a href="https://www.instagram.com/kawanbaikers_indonesia/" target="_blank" class="text-decoration-none"><i class="fab fa-instagram"></i> kawanbaikers_indonesia</a>
            <a href="https://www.facebook.com/groups/210458490163366/" target="_blank" class="text-decoration-none"><i class="fab fa-facebook"></i> Kawan Baiker's Indonesia</a>
         </div>
      </div>
      <div class="text-center mt-4">
         <span>Copyright &copy; Toko Ndog <?= date('Y'); ?></span>
      </div>
   </div>
</footer>