-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 01 Mar 2023 pada 16.06
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4siap`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `id_akun` varchar(5) NOT NULL,
  `nama_akun` varchar(100) NOT NULL,
  `jenis_akun` enum('Debit','Kredit') NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`id_akun`, `nama_akun`, `jenis_akun`, `created_at`, `updated_at`) VALUES
('101', 'Kas', 'Debit', '2023-03-01 22:05:28', '2023-03-01 22:05:28'),
('102', 'Persediaan barang dagang', 'Debit', '2023-03-01 22:05:28', '2023-03-01 22:05:28'),
('103', 'Piutang usaha', 'Debit', '2023-03-01 22:05:28', '2023-03-01 22:05:28'),
('400', 'Penjualan', 'Kredit', '2023-03-01 22:05:28', '2023-03-01 22:05:28'),
('402', 'Potongan penjualan', 'Debit', '2023-03-01 22:05:28', '2023-03-01 22:05:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `angsuran`
--

CREATE TABLE `angsuran` (
  `id_angsuran` char(20) NOT NULL,
  `tanggal_angsuran` date NOT NULL,
  `id_transaksi_header` char(20) NOT NULL,
  `nomor_angsuran` int(3) NOT NULL,
  `nominal_angsuran` mediumtext NOT NULL,
  `piutang_transaksi` mediumtext NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id_barang` bigint(20) UNSIGNED NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `stok_barang` int(11) NOT NULL,
  `satuan_barang` enum('Gram','KG','Drum') NOT NULL,
  `harga_barang` double NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurnal_detail`
--

CREATE TABLE `jurnal_detail` (
  `id_jurnal_detail` bigint(20) UNSIGNED NOT NULL,
  `id_jurnal_header` char(20) NOT NULL,
  `id_akun` varchar(5) NOT NULL,
  `debit` mediumtext NOT NULL,
  `kredit` mediumtext NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurnal_header`
--

CREATE TABLE `jurnal_header` (
  `id_jurnal_header` char(19) NOT NULL,
  `status_posting_jurnal` enum('Posting','Belum Posting') NOT NULL,
  `tanggal_jurnal` date NOT NULL,
  `id_transaksi_header` char(20) NOT NULL,
  `keterangan_jurnal` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2022-03-13-022011', 'App\\Database\\Migrations\\AkunTable', 'default', 'App', 1677682879, 1),
(2, '2022-03-14-164717', 'App\\Database\\Migrations\\PenggunaTable', 'default', 'App', 1677682882, 1),
(3, '2022-03-17-031459', 'App\\Database\\Migrations\\BarangTable', 'default', 'App', 1677682885, 1),
(4, '2022-03-18-171130', 'App\\Database\\Migrations\\PelangganTable', 'default', 'App', 1677682887, 1),
(5, '2022-03-20-152722', 'App\\Database\\Migrations\\TransaksiHeaderTable', 'default', 'App', 1677682889, 1),
(6, '2022-03-20-152738', 'App\\Database\\Migrations\\TransaksiDetailTable', 'default', 'App', 1677682892, 1),
(7, '2022-04-01-064244', 'App\\Database\\Migrations\\JurnalHeaderTable', 'default', 'App', 1677682893, 1),
(8, '2022-04-01-064254', 'App\\Database\\Migrations\\JurnalDetailTable', 'default', 'App', 1677682895, 1),
(9, '2022-04-02-151542', 'App\\Database\\Migrations\\AngsuranTable', 'default', 'App', 1677682897, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` bigint(20) UNSIGNED NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `no_hp_pelanggan` varchar(14) NOT NULL,
  `alamat_pelanggan` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` bigint(20) UNSIGNED NOT NULL,
  `nama_pengguna` varchar(100) NOT NULL,
  `tanggal_lahir_pengguna` date NOT NULL,
  `username_pengguna` varchar(50) NOT NULL,
  `password_pengguna` varchar(255) NOT NULL,
  `hak_akses_pengguna` enum('Admin','Pemilik') NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_pengguna`, `tanggal_lahir_pengguna`, `username_pengguna`, `password_pengguna`, `hak_akses_pengguna`, `created_at`, `updated_at`) VALUES
(1, 'Pemilik', '2022-01-01', 'pemilik', '$2y$10$bdDaQ3PIBTuLRY1dm7lOs.XjedaDh9Nfj36aPsO/cZ30cccJD/ETK', 'Pemilik', '2023-03-01 22:05:27', '2023-03-01 22:05:27'),
(2, 'Admin', '2022-01-01', 'admin', '$2y$10$BUB18eFgns0OjNxmOHHane1cD0pv2dPqwFQVBzcnZE5yq8lIFj0aG', 'Admin', '2023-03-01 22:05:27', '2023-03-01 22:05:27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `id_transaksi_detail` bigint(20) UNSIGNED NOT NULL,
  `id_transaksi_header` char(20) NOT NULL,
  `id_barang` bigint(20) NOT NULL,
  `quantity_barang` bigint(20) NOT NULL,
  `subtotal_transaksi` mediumtext NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_header`
--

CREATE TABLE `transaksi_header` (
  `id_transaksi_header` char(20) NOT NULL,
  `id_pelanggan` bigint(20) DEFAULT NULL,
  `jenis_transaksi` enum('Tunai','Kredit') NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `tanggal_jatuh_tempo_transaksi` date DEFAULT NULL,
  `total_transaksi` mediumtext NOT NULL,
  `piutang_transaksi` mediumtext NOT NULL,
  `status_transaksi` enum('Lunas','Belum Lunas') NOT NULL,
  `keterangan_transaksi` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id_akun`),
  ADD UNIQUE KEY `nama_akun` (`nama_akun`);

--
-- Indeks untuk tabel `angsuran`
--
ALTER TABLE `angsuran`
  ADD PRIMARY KEY (`id_angsuran`);

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD UNIQUE KEY `nama_barang` (`nama_barang`);

--
-- Indeks untuk tabel `jurnal_detail`
--
ALTER TABLE `jurnal_detail`
  ADD PRIMARY KEY (`id_jurnal_detail`);

--
-- Indeks untuk tabel `jurnal_header`
--
ALTER TABLE `jurnal_header`
  ADD PRIMARY KEY (`id_jurnal_header`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD UNIQUE KEY `username_pengguna` (`username_pengguna`);

--
-- Indeks untuk tabel `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`id_transaksi_detail`);

--
-- Indeks untuk tabel `transaksi_header`
--
ALTER TABLE `transaksi_header`
  ADD PRIMARY KEY (`id_transaksi_header`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jurnal_detail`
--
ALTER TABLE `jurnal_detail`
  MODIFY `id_jurnal_detail` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  MODIFY `id_transaksi_detail` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
