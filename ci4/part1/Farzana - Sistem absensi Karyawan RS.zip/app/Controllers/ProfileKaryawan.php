<?php

namespace App\Controllers;

class ProfileKaryawan extends BaseController
{
    public function index()
    {
        return view('pages/profile/index');
    }
}