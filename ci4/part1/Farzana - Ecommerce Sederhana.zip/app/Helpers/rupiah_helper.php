<?php 

function rupiah($harga){
    return number_format($harga, 0, ',','.');
}