<nav class="navbar navbar-expand-lg navbar-light">
    <div class="d-flex justify-content-between w-100">

        <button type="button" id="sidebarCollapse" class="sidebar-button btn">
            <i class="fa-solid fa-align-justify"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url(); ?>">Web</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('logout'); ?>">Logout</a>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link" href="#">Page</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Page</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Page</a>
                </li> -->
            </ul>
        </div>
    </div>
</nav>