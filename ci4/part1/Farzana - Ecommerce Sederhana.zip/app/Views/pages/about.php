<?= $this->extend('layouts/template'); ?>

<?= $this->section('content'); ?>
    <div class="about">
        <div class="container">
            <h2>About</h2>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo possimus praesentium illum dignissimos ipsam laborum, modi blanditiis velit, autem at consectetur!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae quidem ea doloremque asperiores quos officia vel quo blanditiis quas amet. Aperiam architecto explicabo sint earum sapiente quas id eligendi quo, veniam praesentium. Libero alias expedita quidem sunt consequuntur iste autem ea eum necessitatibus? Voluptatem in rerum et impedit qui tempore!</p>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sit ipsam quis nulla molestias officia minus velit sapiente dicta error? Deleniti tempora consequatur architecto cumque et accusantium autem libero excepturi alias.</p>
        </div>
    </div>
<?= $this->endSection(); ?>