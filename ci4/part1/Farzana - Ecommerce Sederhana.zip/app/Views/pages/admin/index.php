<?= $this->extend('layouts/admin/template'); ?>

<?= $this->section('content'); ?>
    <div class="content">
        <h1>Selamat Datang Admin!</h1>
        
    </div>
<?= $this->endSection(); ?>
