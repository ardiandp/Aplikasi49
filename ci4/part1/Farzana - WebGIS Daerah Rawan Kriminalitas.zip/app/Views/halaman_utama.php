<div class="hu-container">
    <div class="row">
        <div class="col">
            <div class="text">
                DAERAH RAWAN KRIMINALITAS KOTA BANDUNG
            </div>
        </div>
        <div class="col">
            <img src="<?= base_url(); ?>/img/danger.png" alt="Danger">
        </div>
    </div>
</div>