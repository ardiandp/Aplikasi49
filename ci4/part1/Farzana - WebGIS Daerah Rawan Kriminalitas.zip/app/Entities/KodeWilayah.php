<?php

namespace App\Entities;

use CodeIgniter\Entity;

class KodeWilayah extends Entity
{
}
